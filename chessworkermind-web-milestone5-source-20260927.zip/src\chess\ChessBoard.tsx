import { useMemo, useState, useRef, useCallback } from "react";
import { Chess, type Square, type Piece } from "chess.js";

type Props = {
  fen: string;
  orientation: "w" | "b";
  lastMove: { from: string; to: string } | null;
  getLegalTargets: (from: Square) => Square[];
  isPromotionMove: (from: Square, to: Square) => boolean;
  tryMove: (from: Square, to: Square, promotion?: "q" | "r" | "b" | "n") => boolean;
};

const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"] as const;
const RANKS = ["8", "7", "6", "5", "4", "3", "2", "1"] as const;

const PIECE_GLYPH: Record<string, string> = {
  "w:k": "♔",
  "w:q": "♕",
  "w:r": "♖",
  "w:b": "♗",
  "w:n": "♘",
  "w:p": "♙",
  "b:k": "♚",
  "b:q": "♛",
  "b:r": "♜",
  "b:b": "♝",
  "b:n": "♞",
  "b:p": "♟",
};

const PROMOTION_CHOICES: Array<{ p: "q" | "r" | "b" | "n"; label: string; glyphW: string; glyphB: string }> = [
  { p: "q", label: "Queen", glyphW: "♕", glyphB: "♛" },
  { p: "r", label: "Rook", glyphW: "♖", glyphB: "♜" },
  { p: "b", label: "Bishop", glyphW: "♗", glyphB: "♝" },
  { p: "n", label: "Knight", glyphW: "♘", glyphB: "♞" },
];

function pieceLabel(piece?: Piece | null): string {
  if (!piece) return "empty";
  const names: Record<string, string> = { p: "pawn", n: "knight", b: "bishop", r: "rook", q: "queen", k: "king" };
  const color = piece.color === "w" ? "White" : "Black";
  return `${color} ${names[piece.type] ?? piece.type}`;
}

export default function ChessBoard({ fen, orientation, lastMove, getLegalTargets, isPromotionMove, tryMove }: Props) {
  const chess = useMemo(() => {
    try {
      return new Chess(fen);
    } catch {
      return new Chess();
    }
  }, [fen]);

  const turn = chess.turn();
  const inCheck = chess.isCheck();

  // display order
  const displayRanks = orientation === "w" ? RANKS : [...RANKS].reverse();
  const displayFiles = orientation === "w" ? FILES : [...FILES].reverse();

  const [selected, setSelected] = useState<Square | null>(null);
  const [legal, setLegal] = useState<Square[]>([]);
  const [pendingPromo, setPendingPromo] = useState<{ from: Square; to: Square } | null>(null);
  const dragFromRef = useRef<Square | null>(null);
  const [dragOver, setDragOver] = useState<Square | null>(null);

  const turnLabel = turn === "w" ? "White to move" : "Black to move";

  const clearSelection = useCallback(() => {
    setSelected(null);
    setLegal([]);
  }, []);

  const selectSquare = useCallback(
    (sq: Square) => {
      const piece = chess.get(sq);
      if (!piece || piece.color !== turn) {
        // not own piece
        return false;
      }
      const targets = getLegalTargets(sq);
      setSelected(sq);
      setLegal(targets);
      return true;
    },
    [chess, getLegalTargets, turn],
  );

  const attemptMove = useCallback(
    (from: Square, to: Square) => {
      if (isPromotionMove(from, to)) {
        setPendingPromo({ from, to });
        return;
      }
      const ok = tryMove(from, to);
      if (ok) clearSelection();
      else {
        // illegal — keep selection if moving own piece target, else clear
        // flash feedback: briefly keep selection
      }
    },
    [isPromotionMove, tryMove, clearSelection],
  );

  const onSquareClick = useCallback(
    (sq: Square) => {
      if (pendingPromo) return;
      const piece = chess.get(sq);

      // if already selected
      if (selected) {
        if (sq === selected) {
          clearSelection();
          return;
        }
        if (legal.includes(sq)) {
          attemptMove(selected, sq);
          return;
        }
        // click own piece → reselect
        if (piece && piece.color === turn) {
          selectSquare(sq);
          return;
        }
        // click elsewhere → clear
        clearSelection();
        return;
      }

      // no selection
      if (piece && piece.color === turn) selectSquare(sq);
    },
    [pendingPromo, chess, selected, legal, turn, clearSelection, attemptMove, selectSquare],
  );

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent, sq: Square) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        onSquareClick(sq);
      } else if (e.key === "Escape") {
        clearSelection();
        setPendingPromo(null);
      }
    },
    [onSquareClick, clearSelection],
  );

  // drag handlers
  const onDragStart = (sq: Square) => (e: React.DragEvent) => {
    if (pendingPromo) {
      e.preventDefault();
      return;
    }
    const piece = chess.get(sq);
    if (!piece || piece.color !== turn) {
      e.preventDefault();
      return;
    }
    dragFromRef.current = sq;
    // select to show targets
    const targets = getLegalTargets(sq);
    setSelected(sq);
    setLegal(targets);
    e.dataTransfer.effectAllowed = "move";
    // use glyph as drag image offset
    try {
      e.dataTransfer.setData("text/plain", sq);
    } catch {
      /* ignore */
    }
  };

  const onDragOver = (sq: Square) => (e: React.DragEvent) => {
    e.preventDefault();
    if (dragOver !== sq) setDragOver(sq);
  };
  const onDragLeave = () => setDragOver(null);
  const onDrop = (sq: Square) => (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(null);
    const from = dragFromRef.current;
    dragFromRef.current = null;
    if (!from || from === sq) return;
    if (!legal.includes(sq) && !isPromotionMove(from, sq)) {
      // allow drop even if legal list stale due to async fen — validate inside tryMove
    }
    if (isPromotionMove(from, sq)) {
      setPendingPromo({ from, to: sq });
      return;
    }
    const ok = tryMove(from, sq);
    if (ok) clearSelection();
  };
  const onDragEnd = () => {
    dragFromRef.current = null;
    setDragOver(null);
  };

  const handlePromotion = (choice: "q" | "r" | "b" | "n") => {
    if (!pendingPromo) return;
    const { from, to } = pendingPromo;
    setPendingPromo(null);
    const ok = tryMove(from, to, choice);
    if (ok) clearSelection();
  };

  const promoTurnColor = useMemo(() => {
    if (!pendingPromo) return turn;
    const p = chess.get(pendingPromo.from);
    return p?.color ?? turn;
  }, [pendingPromo, chess, turn]);

  return (
    <div className="board-wrap">
      <div className="board-meta">
        <span className="pill pill--ok" aria-live="polite">
          {turnLabel}
          {inCheck ? " · Check!" : ""}
        </span>
        {inCheck && <span className="pill pill--warn">King in check</span>}
      </div>

      <div
        className="board"
        role="grid"
        aria-label={`Chess board, ${turnLabel}${inCheck ? ", check" : ""}. ${orientation === "w" ? "White at bottom" : "Black at bottom"}.`}
      >
        {displayRanks.map((rank) =>
          displayFiles.map((file) => {
            const sq = `${file}${rank}` as Square;
            const piece = chess.get(sq);
            const isLight = (file.charCodeAt(0) - 97 + Number(rank)) % 2 === 1;
            // second formulation: (file index + rank) parity; a1 dark.
            // Use canonical light check via squareColor for correctness
            const canonicalLight = chess.squareColor(sq) === "light";
            const selectedHere = selected === sq;
            const isLegal = legal.includes(sq);
            const isLast = lastMove != null && (lastMove.from === sq || lastMove.to === sq);
            const isKingInCheckHere = Boolean(piece && piece.type === "k" && piece.color === turn && inCheck && sq === findKing(chess, turn));
            const isDragOver = dragOver === sq;

            const glyph = piece ? PIECE_GLYPH[`${piece.color}:${piece.type}`] ?? "" : "";

            return (
              <button
                key={sq}
                role="gridcell"
                aria-label={`${sq} ${pieceLabel(piece)}${selectedHere ? " selected" : ""}${isLegal ? " legal move" : ""}${isLast ? " last move" : ""}`}
                aria-selected={selectedHere}
                className={[
                  "board__square",
                  canonicalLight ? "board__square--light" : "board__square--dark",
                  selectedHere ? "board__square--selected" : "",
                  isLast ? "board__square--last" : "",
                  isKingInCheckHere ? "board__square--check" : "",
                  isLegal ? "board__square--target" : "",
                  isDragOver ? "board__square--dragover" : "",
                  isLight ? "" : "",
                ].join(" ")}
                onClick={() => onSquareClick(sq)}
                onKeyDown={(e) => onKeyDown(e, sq)}
                draggable={Boolean(piece && piece.color === turn && !pendingPromo)}
                onDragStart={onDragStart(sq)}
                onDragOver={onDragOver(sq)}
                onDragLeave={onDragLeave}
                onDrop={onDrop(sq)}
                onDragEnd={onDragEnd}
                tabIndex={0}
                type="button"
              >
                {/* coordinates */}
                {displayFiles[displayFiles.length - 1] === file && (
                  <span className="board__rank" aria-hidden="true">
                    {rank}
                  </span>
                )}
                {displayRanks[displayRanks.length - 1] === rank && (
                  <span className="board__file" aria-hidden="true">
                    {file}
                  </span>
                )}

                {piece && (
                  <span
                    className={`board__piece board__piece--${piece.color}`}
                    aria-hidden="true"
                    draggable={false}
                    style={{ cursor: piece.color === turn ? "grab" : "default" }}
                  >
                    {glyph}
                  </span>
                )}
                {isLegal && <span className={`board__dot ${piece ? "board__dot--capture" : ""}`} aria-hidden="true" />}
                {selectedHere && <span className="board__ring" aria-hidden="true" />}
              </button>
            );
          }),
        )}
      </div>

      {pendingPromo && (
        <div className="promo" role="dialog" aria-modal="true" aria-label="Choose promotion piece">
          <div className="promo__card">
            <p className="promo__title">
              Pawn promotion — choose piece for {pendingPromo.to}
            </p>
            <div className="promo__choices">
              {PROMOTION_CHOICES.map((c) => (
                <button
                  key={c.p}
                  type="button"
                  className="promo__btn"
                  onClick={() => handlePromotion(c.p)}
                  aria-label={`Promote to ${c.label}`}
                >
                  <span className="promo__glyph" aria-hidden="true">
                    {promoTurnColor === "w" ? c.glyphW : c.glyphB}
                  </span>
                  <span className="promo__label">{c.label}</span>
                </button>
              ))}
            </div>
            <button type="button" className="btn btn--ghost" onClick={() => setPendingPromo(null)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      <p className="board__hint">
        Tap a piece then a highlighted square — or drag. Illegal moves are ignored. Board uses chess.js for all rules.
      </p>
    </div>
  );
}

function findKing(chess: Chess, color: "w" | "b"): Square | null {
  const found = chess.findPiece({ type: "k", color });
  return (found[0] as Square) ?? null;
}
