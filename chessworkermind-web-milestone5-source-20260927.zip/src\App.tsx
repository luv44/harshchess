import { useCallback, useEffect, useRef, useState } from "react";
import ChessBoard from "./chess/ChessBoard";
import { useChessGame } from "./chess/useChessGame";
import { useEngine } from "./engine/useEngine";
import { LearnPage } from "./coach/LearnPage";
import { AccountPage } from "./billing/AccountPage";
import { useLanguage } from "./i18n/useLanguage";
import { t } from "./i18n/strings";

type Tab = "play" | "sales" | "learn" | "account" | "status";

function useOnline() {
  const [online, setOnline] = useState<boolean>(typeof navigator !== "undefined" ? navigator.onLine : true);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);
  return online;
}

export default function App() {
  const [tab, setTab] = useState<Tab>("play");
  const game = useChessGame();
  const { tag, dir, setTag, level, setLevel } = useLanguage();
  const online = useOnline();
  const [installPrompt, setInstallPrompt] = useState<unknown>(null);
  const canInstall = !!installPrompt;

  useEffect(() => {
    const h = (e: Event) => {
      // beforeinstallprompt is Chromium-only; keep for Android/desktop
      e.preventDefault();
      setInstallPrompt(e);
    };
    window.addEventListener("beforeinstallprompt" as never, h as never);
    return () => window.removeEventListener("beforeinstallprompt" as never, h as never);
  }, []);

  const doInstall = useCallback(async () => {
    const e = installPrompt as { prompt: () => Promise<void>; userChoice?: Promise<{ outcome: string }> } | null;
    if (!e) return;
    try { await e.prompt(); await e.userChoice; } catch { /* ignore */ }
    setInstallPrompt(null);
  }, [installPrompt]);

  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="header" role="banner">
        <div className="header__inner">
          <div className="brand" aria-label="Chessworkermind">
            Chessworker<span>mind</span>
          </div>
          <nav className="nav" aria-label="Primary">
            <button
              className={`btn ${tab === "sales" ? "btn--primary" : ""}`}
              onClick={() => setTab("sales")}
            >
              {t(tag, "sales")}
            </button>
            <button
              className={`btn ${tab === "play" ? "btn--primary" : ""}`}
              onClick={() => setTab("play")}
            >
              {t(tag, "play")}
            </button>
            <button
              className={`btn ${tab === "learn" ? "btn--primary" : ""}`}
              onClick={() => setTab("learn")}
            >
              {t(tag, "learn")}
            </button>
            <button
              className={`btn ${tab === "account" ? "btn--primary" : ""}`}
              onClick={() => setTab("account")}
            >
              Account
            </button>
            <button
              className={`btn ${tab === "status" ? "btn--primary" : ""}`}
              onClick={() => setTab("status")}
            >
              {t(tag, "status")}
            </button>
          </nav>
        </div>
      </header>

      <main id="main" className="container">
        <div className={`netbar ${online ? "" : "netbar--offline"}`} role="status" aria-live="polite">
          <span className={`pill ${online ? "pill--ok" : "pill--warn"}`}>{online ? "Online" : "Offline — board & saved games stay available; login/purchase/sync need network"}</span>
          {!online && <span>Engine cache + local progress remain. Reconnect to sync or restore Pro.</span>}
          {online && <span style={{ color: "var(--text-muted)" }}>PWA shell cached (sw.js v5). Installed app keeps games on reinstall via account sync — unsynced browser storage may be evicted.</span>}
        </div>
        {tab === "sales" && <SalesPage onPlay={() => setTab("play")} canInstall={canInstall} onInstall={doInstall} />}
        {tab === "play" && <PlayPage game={game} onSales={() => setTab("sales")} online={online} />}
        {tab === "learn" && <LearnPage tag={tag} setTag={setTag} level={level} setLevel={setLevel} />}
        {tab === "account" && <AccountPage />}
        {tab === "status" && <StatusPage tag={tag} canInstall={canInstall} onInstall={doInstall} />}
      </main>

      <footer className="footer">
        <div className="container">
          <p>Chessworkermind — Learn how to think, not just what move to play.</p>
          <p style={{ marginTop: 6 }}>
            <a href="#privacy">Privacy</a> · <a href="#support">Support</a> ·{" "}
            <a href="#faq">FAQ</a> · No ads in this release.
          </p>
          <p style={{ marginTop: 6, opacity: 0.7 }}>
            Milestone 5 · PWA + QA + export guide — browser QA (safe-area, logical layout, no horizontal scroll) ·{" "}
            <span className="pill pill--warn" style={{ fontSize: "0.72rem" }}>
              Pro checkout disabled — coming soon
            </span>{" "}
            <span style={{ marginLeft: 6 }}>No ads — AdSense is optional future phase only.</span>
          </p>
          <p style={{ marginTop: 8, fontSize: "0.78rem", opacity: 0.7 }}>
            PWA: manifest + icons + sw.js · offline shell cached; login/purchase/sync require network · Safari iPhone: Share → Add to Home Screen
          </p>
        </div>
      </footer>
    </>
  );
}

function SalesPage({ onPlay, canInstall, onInstall }: { onPlay: () => void; canInstall: boolean; onInstall: () => void }) {
  return (
    <>
      <section className="hero">
        <div className="badge">♔ Chessworkermind — Free to try</div>
        <h1>Learn how to think, not just what move to play.</h1>
        <p>
          One HTTPS link for desktop and phone. Play now with a fully legal board — no install, no
          paywall on moves.
        </p>
        <div className="hero__cta">
          <button className="btn btn--primary" onClick={onPlay}>
            Play Free Board →
          </button>
          <a className="btn" href="#comparison">
            See Free vs Pro
          </a>
        </div>
        <p style={{ marginTop: 10, fontSize: "0.85rem", color: "var(--text-muted)" }}>
           Free board is live: tap/drag, flip, undo, save. Stockfish coaching live; Learn tab adds verified FactPackets &amp; practice in milestone 3.
         </p>
         <div className="card install-card" style={{ marginTop: 16, textAlign: "left" }}>
           <strong>Install Chessworkermind (optional)</strong>
           <p style={{ fontSize: "0.88rem" }}>Works in the browser first — Add to Home Screen is an enhancement, never a prerequisite.</p>
           {canInstall ? (
             <button className="btn btn--primary" onClick={onInstall}>Install Chessworkermind</button>
           ) : (
             <ul className="install-card__steps">
               <li><strong>iPhone (Safari):</strong> Share → Add to Home Screen.</li>
               <li><strong>Android (Chrome):</strong> Menu → Install app / Add to Home screen.</li>
               <li><strong>Desktop (Chrome/Edge):</strong> Address bar install icon or menu → Install.</li>
               <li>If no install prompt appears: Continue in browser — all features still work.</li>
             </ul>
           )}
           <p style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>Installed app is still a website (not an IPA/APK). Updates do not destroy saved games; use Account → sync/export before switching contexts on iPhone.</p>
         </div>
       </section>

      <section className="section grid2">
        <div className="card">
          <h2>Free — ₹0 forever</h2>
          <p>Unlimited legal board. Never limited.</p>
          <ul>
            <li>Legal chess board (chess.js) — ✓ live in this release</li>
            <li>Local save + guest progress (auto-saved, survives reload)</li>
            <li>Tap / drag / flip / undo + keyboard accessible</li>
            <li>Lessons &amp; daily set — ✓ Learn tab (milestone 3)</li>
          </ul>
          <div style={{ marginTop: 14 }}>
            <button className="btn btn--primary" onClick={onPlay}>
              Open Free Board
            </button>
          </div>
        </div>
        <div className="card" style={{ borderColor: "rgba(108,92,231,0.5)" }}>
          <h2>Pro — ₹599/month (INR base)</h2>
          <p>When implemented: auto-renewing monthly, cancel anytime. Shown price is what is charged.</p>
          <ul>
            <li>Adjustable computer opponent — ✓ milestone 2</li>
            <li>Verified Stockfish comparison &amp; FactPackets — ✓ milestone 3</li>
            <li>Adaptive hints, revision &amp; learning plan — ✓ milestone 3</li>
            <li>Account sync + test-mode subscription adapter (₹599 INR, lifecycle) — <em>milestone 4</em></li>
          </ul>
          <p style={{ marginTop: 12 }}>
            <span className="pill pill--warn">Pro checkout disabled — coming soon</span>
          </p>
          <p style={{ marginTop: 8, fontSize: "0.82rem", color: "var(--text-muted)" }}>
            No annual plan unless separately approved. Any local-currency estimate at checkout will be
            labelled approximate and separate from the ₹599 INR charge.
          </p>
        </div>
      </section>

      <section id="comparison" className="section">
        <div className="card">
          <h2>Free / Pro comparison</h2>
          <table className="comparison" aria-label="Free versus Pro">
            <thead>
              <tr>
                <th>Feature</th>
                <th>Free</th>
                <th>Pro (planned)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Legal board &amp; rules</td>
                <td>✓ Unlimited</td>
                <td>✓ Unlimited</td>
              </tr>
              <tr>
                <td>Stockfish worker analysis</td>
                <td>✓ Bounded + stale-guard</td>
                <td>✓ Verified candidates + stale-guard</td>
              </tr>
              <tr>
                <td>FactPackets / coaching</td>
                <td>✓ Verified, local</td>
                <td>✓ + personalized review</td>
              </tr>
              <tr>
                <td>Progress &amp; languages</td>
                <td>✓ Local learner model + 8 languages (local fallback)</td>
                <td>✓ Synced + server caps</td>
              </tr>
              <tr>
                <td>Account sync</td>
                <td>Local only</td>
                <td>✓ Cross-device (milestone 4)</td>
              </tr>
              <tr>
                <td>Ads</td>
                <td colSpan={2}>None in this release (AdSense is optional future phase only)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section className="section grid2">
        <div className="card">
          <h2 id="faq">FAQ</h2>
          <p>
            <strong>Do I need to install?</strong> No — the site works in the browser. Add to Home Screen
            is optional enhancement (PWA manifest/service worker landing in milestone 5).
          </p>
          <p style={{ marginTop: 8 }}>
            <strong>When is Pro?</strong> After milestones 1–4 are verified and the owner approves merchant
            setup. Checkout stays disabled until then.
          </p>
        </div>
        <div className="card">
          <h2 id="privacy">Privacy &amp; Support</h2>
          <p>
            Minimal retention. Export/delete available when account sync lands (milestone 4). Support path
            and billing history arrive with subscription adapter.
          </p>
          <p style={{ marginTop: 8, fontSize: "0.85rem", color: "var(--text-muted)" }}>
            Paid AI is optional, capped, server-side and never required for basic moves. FactPackets cache by FEN+engine+depth+multiPv; translations cache by fact/language/level.
          </p>
        </div>
      </section>
    </>
  );
}

function PlayPage({
  game,
  onSales,
  online,
}: {
  game: ReturnType<typeof useChessGame>;
  onSales: () => void;
  online: boolean;
}) {
  const statusBanner = getStatusText(game.status);
  const [copied, setCopied] = useState<string | null>(null);
  const engine = useEngine();
  const [focusMode, setFocusMode] = useState(false);
  const pendingComputerRef = useRef<number | null>(null);

  // live bounded analysis: on every legal move (fen change) ask worker, tagged by FEN+positionId
  useEffect(() => {
    if (game.status.kind !== "active") return;
    if (focusMode) return;
    engine.analyze(game.fen);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game.fen, focusMode]);

  useEffect(() => () => engine.stop(), [engine.stop]);

  useEffect(() => {
    if (!engine.computerOn) return;
    if (game.status.kind !== "active") return;
    if (focusMode) return;
    if (!engine.analysis || engine.analysis.fen !== game.fen) return;
    if (!engine.analysis.bestUci) return;
    if (pendingComputerRef.current === engine.analysis.positionId) return;
    pendingComputerRef.current = engine.analysis.positionId;
    const t = window.setTimeout(() => {
      if (!engine.analysis || engine.analysis.fen !== game.fen) return;
      const mv = engine.playBestMove(game.fen);
      if (!mv) return;
      game.tryMove(mv.from as never, mv.to as never, mv.promotion as never);
    }, 320);
    return () => window.clearTimeout(t);
  }, [engine.analysis, engine.computerOn, focusMode, game, engine]);

  const copy = useCallback(async (label: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(null), 1600);
    } catch {
      setCopied("Copy failed");
      setTimeout(() => setCopied(null), 1600);
    }
  }, []);

  const historyPairs: string[][] = [];
  for (let i = 0; i < game.historySan.length; i += 2) {
    historyPairs.push([game.historySan[i], game.historySan[i + 1] ?? ""]);
  }

  return (
    <section className="section">
      <div className="play-layout">
        <div className="card play-card">
          <div className="play-toolbar">
            <h2 style={{ fontSize: "1.05rem" }}>Free board — two-player local</h2>
            <div className="play-actions">
              <button className="btn btn--ghost" onClick={game.flip} aria-label="Flip board">
                ⇅ Flip
              </button>
              <button
                className="btn"
                onClick={game.undo}
                disabled={!game.canUndo}
                aria-label="Undo last move"
              >
                ↩ Undo
              </button>
              <button className="btn" onClick={game.newGame} aria-label="Start new game">
                ⟳ New game
              </button>
            </div>
          </div>

          <div className={`status-banner status-banner--${game.status.kind}`} aria-live="polite">
            <strong>{statusBanner.title}</strong>
            <span>{statusBanner.detail}</span>
          </div>

          <ChessBoard
            fen={game.fen}
            orientation={game.orientation}
            lastMove={game.lastMove}
            getLegalTargets={game.getLegalTargets}
            isPromotionMove={game.isPromotionMove}
            tryMove={game.tryMove}
          />

          <div className="play-controls">
            <span className="pill">Local save: on (auto)</span>
            <span className="pill pill--off">Board: chess.js rules</span>
            <button className="btn btn--ghost" onClick={onSales} style={{ marginLeft: "auto" }}>
              Sales page
            </button>
          </div>

          <div className="engine-panel" role="region" aria-label="Engine analysis">
            <div className="engine-panel__head">
              <strong>Engine</strong>
              <span className={`pill ${engine.fallbackVisible ? "pill--warn" : engine.engineState.kind === "ready" || engine.engineState.kind === "analyzing" ? "pill--ok" : "pill--off"}`}>
                {engine.fallbackVisible
                  ? "Rules-only fallback"
                  : engine.engineState.kind === "loading"
                    ? "Loading Stockfish…"
                    : engine.engineState.kind === "analyzing"
                      ? "Analyzing…"
                      : engine.engineState.kind === "ready"
                        ? "Stockfish ready"
                        : engine.engineState.kind === "error"
                          ? "Engine error — rules-only"
                          : "Engine idle"}
              </span>
              <label className="engine-panel__toggle">
                <input
                  type="checkbox"
                  checked={focusMode}
                  onChange={(e) => setFocusMode(e.target.checked)}
                  aria-label="Focus mode — hide hints"
                />
                Focus hides hints
              </label>
            </div>

            {engine.fallbackVisible ? (
              <p className="engine-panel__fallback" role="status">
                Rules-only fallback — no engine analysis. Board remains fully playable; checks, mates, legality via <code>chess.js</code>. Engine will retry on next position.
              </p>
            ) : engine.engineState.kind === "loading" ? (
              <p className="engine-panel__hint">Downloading engine (~1.7 MB)… Board stays responsive.</p>
            ) : (
              <EngineCandidates
                fen={game.fen}
                analysis={engine.analysis}
                isStale={!!engine.analysis && engine.analysis.fen !== game.fen}
                positionId={engine.currentPositionId}
                focusMode={focusMode}
              />
            )}

            <div className="engine-panel__actions">
              <button
                className={`btn ${engine.computerOn ? "btn--primary" : ""}`}
                onClick={() => engine.setComputerOn((v) => !v)}
                aria-pressed={engine.computerOn}
                aria-label="Toggle computer opponent"
              >
                {engine.computerOn ? "Computer: ON" : "Computer: OFF"}
              </button>
              <button
                className="btn btn--ghost"
                onClick={() => {
                  if (engine.engineState.kind === "analyzing") engine.stop();
                  else engine.analyze(game.fen);
                }}
                aria-label={engine.engineState.kind === "analyzing" ? "Stop analysis" : "Re-analyze position"}
              >
                {engine.engineState.kind === "analyzing" ? "Stop" : "Re-analyze"}
              </button>
              <button
                className="btn btn--ghost"
                disabled={!engine.analysis || engine.analysis.fen !== game.fen || !engine.analysis.bestUci}
                onClick={() => {
                  const mv = engine.playBestMove(game.fen);
                  if (mv) game.tryMove(mv.from as never, mv.to as never, mv.promotion as never);
                }}
                aria-label="Play engine best move"
              >
                Play best
              </button>
            </div>

            <p className="engine-panel__meta">
              WASM Stockfish 19 lite-single · depth 12 · 3 lines · bounded · cache by FEN+version+settings · stale results ignored (ID + FEN).
              GPLv3 — see <code>Copying.txt</code> in engine source.
            </p>
          </div>
        </div>

        <div className="card play-side">
          <h3>Move history</h3>
          {historyPairs.length === 0 ? (
            <p style={{ color: "var(--text-muted)", fontSize: "0.92rem", marginTop: 8 }}>
              No moves yet — White to move. Try <code>e4</code>.
            </p>
          ) : (
            <ol className="move-list" aria-label="Move history">
              {historyPairs.map((pair, idx) => (
                <li key={idx} className="move-list__row">
                  <span className="move-list__num">{idx + 1}.</span>
                  <span className="move-list__san">{pair[0]}</span>
                  {pair[1] ? <span className="move-list__san">{pair[1]}</span> : <span className="move-list__san move-list__san--empty">…</span>}
                </li>
              ))}
            </ol>
          )}

          <div className="fen-box">
            <div className="fen-box__head">
              <strong>FEN</strong>
              <button className="btn btn--ghost" style={{ padding: "4px 10px", fontSize: "0.8rem" }} onClick={() => copy("FEN", game.fen)}>
                {copied === "FEN" ? "Copied!" : "Copy FEN"}
              </button>
            </div>
            <code className="fen-box__code">{game.fen}</code>
          </div>

          <div className="fen-box">
            <div className="fen-box__head">
              <strong>PGN</strong>
              <button
                className="btn btn--ghost"
                style={{ padding: "4px 10px", fontSize: "0.8rem" }}
                onClick={() => copy("PGN", game.pgn || "[No moves]")}
              >
                {copied === "PGN" ? "Copied!" : "Copy PGN"}
              </button>
            </div>
            <code className="fen-box__code">{game.pgn || "(no moves yet)"}</code>
          </div>

          <p style={{ marginTop: 12, fontSize: "0.82rem", color: "var(--text-muted)" }}>
            All moves validated by <code>chess.js</code>. Illegal moves are ignored — check, checkmate,
            stalemate, castling, en passant, promotion and draws are enforced. Game auto-saves and restores
            on reload.
          </p>

          <div style={{ marginTop: 14, display: "flex", gap: 8, flexWrap: "wrap" }}>
            <span className="pill pill--ok">✓ Responsive</span>
            <span className="pill pill--ok">✓ Keyboard + touch targets ≥44px</span>
            <span className="pill pill--ok">✓ Worker Stockfish + stale guards</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function getStatusText(s: ReturnType<typeof useChessGame>["status"]): { title: string; detail: string } {
  switch (s.kind) {
    case "active":
      return {
        title: s.turn === "w" ? "White to move" : "Black to move",
        detail: s.inCheck ? "King is in check — you must get out of check." : "Play a legal move. Tap or drag a piece.",
      };
    case "checkmate":
      return {
        title: `Checkmate — ${s.winner === "w" ? "White wins" : "Black wins"}`,
        detail: "Game over. Start a new game to play again.",
      };
    case "stalemate":
      return { title: "Stalemate — Draw", detail: "No legal moves and not in check. Game over." };
    case "draw":
      return {
        title: "Draw",
        detail:
          s.reason === "fifty"
            ? "Fifty-move rule."
            : s.reason === "repetition"
              ? "Threefold repetition."
              : s.reason === "insufficient"
                ? "Insufficient material."
                : "Draw.",
      };
    default:
      return { title: "Game over", detail: "No more legal moves." };
  }
}

function EngineCandidates({
  fen,
  analysis,
  isStale,
  positionId,
  focusMode,
}: {
  fen: string;
  analysis: ReturnType<typeof useEngine>["analysis"];
  isStale: boolean;
  positionId: number;
  focusMode: boolean;
}) {
  if (focusMode) {
    return <p className="engine-panel__hint">Focus mode — hints hidden. Engine still bounded; re-enable to see candidates.</p>;
  }
  if (isStale) {
    return <p className="engine-panel__hint">Updating for new position… (stale ID {analysis?.positionId} ignored, current {positionId})</p>;
  }
  if (!analysis || analysis.fen !== fen) {
    return <p className="engine-panel__hint">No analysis for this position yet — move or press Re-analyze. Cached by FEN+version+settings.</p>;
  }
  if (analysis.candidates.length === 0) {
    return <p className="engine-panel__hint">Engine: no candidates at this depth. {analysis.bestUci ? `Best: ${analysis.bestUci}` : ""}</p>;
  }
  return (
    <div className="engine-panel__candidates">
      <div className="engine-panel__score">
        Depth {analysis.depth} · {analysis.candidates.length} candidate{analysis.candidates.length > 1 ? "s" : ""} {analysis.bestUci ? `· best ${analysis.bestUci}` : ""}
      </div>
      <ol className="engine-panel__list" aria-label="Engine candidates (legal, same-player perspective)">
        {analysis.candidates.map((c) => {
          const score = typeof c.scoreMate === "number" ? (c.scoreMate > 0 ? `#${c.scoreMate}` : `#${c.scoreMate}`) : typeof c.scoreCp === "number" ? `${c.scoreCp > 0 ? "+" : ""}${(c.scoreCp / 100).toFixed(2)}` : "—";
          return (
            <li key={c.multipv} className="engine-panel__item">
              <span className="engine-panel__rank">#{c.multipv}</span>
              <span className="engine-panel__san">{c.san ?? c.uci}</span>
              <span className="engine-panel__uci">({c.uci})</span>
              <span className="engine-panel__scoreval">{score}</span>
              <span className="engine-panel__pv" title={c.raw}>
                {c.pvSans.slice(0, 6).join(" ")}
              </span>
            </li>
          );
        })}
      </ol>
      <p className="engine-panel__hint" style={{ marginTop: 6 }}>
        Scores are from current player's perspective. Only legal continuations shown; stale IDs are ignored.
      </p>
    </div>
  );
}

function StatusPage({ tag, canInstall, onInstall }: { tag: string; canInstall: boolean; onInstall: () => void }) {
  return (
    <section className="section">
      <div className="card">
        <h2>Milestone 5 — Feature inventory (honest) &amp; QA</h2>
        <p>What exists vs what is stubbed. Only verified items are marked complete. Language: <span lang={tag}>{tag}</span></p>
        <div className="status-strip">
          <span className="pill pill--ok">✓ TypeScript + Vite + React scaffold builds</span>
          <span className="pill pill--ok">✓ Sales page (responsive, keyboard nav, safe-area, no horizontal scroll)</span>
          <span className="pill pill--ok">✓ chess.js dependency installed</span>
          <span className="pill pill--ok">✓ Playable Free board — tap/drag/flip/undo + local save + legal rules + keyboard</span>
          <span className="pill pill--ok">✓ Stockfish 19 lite-single worker — bounded, stale-guard, auto-analysis, computer opponent, fallback</span>
          <span className="pill pill--ok">✓ FactPackets verified (before/after FEN, legal move, opponent threat, confidence) — never invents moves/scores</span>
          <span className="pill pill--ok">✓ Diagnosis (supported labels only), TeachingOpportunityFilter, grouping of reasonable alternatives</span>
          <span className="pill pill--ok">✓ Learner model (proficiency+uncertainty, hinted vs unaided, not-enough-data, spaced revision)</span>
          <span className="pill pill--ok">✓ Ranking with tunable weights + diversity + exploration, daily set &amp; Boss, prerequisites</span>
          <span className="pill pill--ok">✓ 8 languages (Latin/Devanagari/Arabic/CJK incl. RTL), ExplanationRenderer with cache &amp; validation, language picker</span>
          <span className="pill pill--ok">✓ Account sync (guest→account merge, two-device LWW union, reconnect, export/delete) + ₹599/month test-mode adapter + lifecycle (renewal/cancel/refund 7d/expiry/grace) — checkout disabled until verified</span>
          <span className="pill pill--ok">✓ PWA manifest + icons (any+maskable) + sw.js (versioned, offline shell, install)</span>
          <span className="pill pill--ok">✓ Milestone 5 QA: responsive, portrait/landscape, touch/drag/keyboard, reduced-motion, offline recovery, language switch</span>
          <span className="pill pill--off">○ Ads — explicitly not in this release (future phase only)</span>
          <span className="pill pill--warn">Owner-only pending: real merchant account, live webhook endpoint, tax/legal signoff, physical iPhone/Android smoke test</span>
        </div>
        <div className="comparison-wrap" style={{ marginTop: 16 }}>
        <table className="comparison">
          <thead>
            <tr>
              <th>Area</th>
              <th>Status</th>
              <th>Evidence</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Build</td>
              <td>npm run build succeeds</td>
              <td>Verified; see RUN_RECOVERY.json</td>
            </tr>
            <tr>
              <td>Tests</td>
              <td>vitest run exits</td>
              <td>legality + engine + FactPacket + learner + ranking + spaced + i18n</td>
            </tr>
            <tr>
              <td>Free board</td>
              <td>Live — legal via chess.js, responsive</td>
              <td>Manual + unit tested; touch ≥44px, keyboard gridcells, no horizontal scroll, safe-area</td>
            </tr>
            <tr>
              <td>Stockfish / coaching</td>
              <td>Worker live + FactPackets + filters</td>
              <td>Verified: bounded, cache, fallback, no invented scores</td>
            </tr>
            <tr>
              <td>Learn / i18n</td>
              <td>Live — 8 languages, RTL, SAN preserved, cache keyed by fact/version/lang/level</td>
              <td>Picker in own scripts, html lang/dir, bilingual glossary, report-wrong path; board logical layout unaffected by dir</td>
            </tr>
            <tr>
              <td>Account sync</td>
              <td>Live — guest→account merge, concurrent LWW union, reconnect, offline grace 3d</td>
              <td>LWW per stableId + union, no silent delete; reconnect re-verifies provider</td>
            </tr>
            <tr>
              <td>Payments</td>
              <td>Test-mode adapter — checkout disabled until verified</td>
              <td>Provider-neutral adapter, webhook sig + amount/currency/plan check, idempotent lifecycle, refund/cancel/expiry/chargeback tests</td>
            </tr>
            <tr>
              <td>PWA / offline</td>
              <td>Manifest + icons + sw.js + offline banner</td>
              <td>manifest.webmanifest validated; sw caches shell+icons+stockfish; HTML network-first; offline still plays, sync needs network</td>
            </tr>
            <tr>
              <td>Export / source</td>
              <td>ZIP on D: + preview guide</td>
              <td>See PREVIEW.md / SETUP.md / FEATURE_MATRIX.md; ZIP excludes node_modules/dist</td>
            </tr>
          </tbody>
        </table>
        </div>

        <div className="card" style={{ marginTop: 16 }}>
          <h3>Browser QA (what was checked in this run)</h3>
          <ul style={{ marginTop: 8 }}>
            <li>Desktop Chromium (this runner): narrow 360px + portrait/landscape, no horizontal scroll, safe-area respected, keyboard tab through board squares, flip/undo/save, offline banner via devtools offline toggle, language switch mid-game preserves FEN and html lang/dir.</li>
            <li>Engine download interrupt: worker fallback pill + board stays playable; re-analyze retries.</li>
            <li>Storage eviction: export/delete on Account page; localStorage corruption fallback tested; reconnect re-verifies.</li>
            <li>Install: manifest valid, icons any+maskable, sw.js registers on load, beforeinstallprompt handled; otherwise device-specific steps shown; “Continue in browser” always available.</li>
            <li><em>Owner smoke on real iPhone Safari + Android Chrome still pending</em> — owner to confirm touch near edges, Add to Home Screen, and that guest games after install are recovered via Account sync (see guide).</li>
          </ul>
        </div>

        <div className="card" style={{ marginTop: 12 }}>
          <h3>Install</h3>
          {canInstall ? (
            <button className="btn btn--primary" onClick={onInstall} style={{ marginTop: 8 }}>Install Chessworkermind</button>
          ) : (
            <ul className="install-card__steps" style={{ marginTop: 8 }}>
              <li><strong>iPhone:</strong> Safari → Share → Add to Home Screen.</li>
              <li><strong>Android:</strong> Chrome menu → Install app / Add to Home screen.</li>
              <li><strong>Desktop:</strong> Address bar install icon or browser menu → Install.</li>
              <li>If unsupported: Continue in browser.</li>
            </ul>
          )}
          <p style={{ marginTop: 8, fontSize: "0.82rem", color: "var(--text-muted)" }}>On iPhone, Home Screen app storage is separate from Safari tab storage — export or sync your account before switching contexts. Updates do not delete saved games.</p>
        </div>

        <p style={{ marginTop: 12, fontSize: "0.85rem", color: "var(--text-muted)" }}>
          Source of truth: <code>MASTER_PROMPT.txt</code> kept in export. Secrets never committed. ZIP + docs in milestone 5.
        </p>
      </div>
    </section>
  );
}
