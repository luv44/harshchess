import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chess, type Square } from "chess.js";
import { loadSavedGame, saveGame, clearSavedGame } from "./storage";

type Orientation = "w" | "b";
type Promotion = "q" | "r" | "b" | "n";

export type GameStatus =
  | { kind: "active"; turn: "w" | "b"; inCheck: boolean }
  | { kind: "checkmate"; winner: "w" | "b" }
  | { kind: "stalemate" }
  | { kind: "draw"; reason: "fifty" | "repetition" | "insufficient" | "draw" }
  | { kind: "other" };

function deriveStatus(c: Chess): GameStatus {
  if (c.isCheckmate()) {
    const winner = c.turn() === "w" ? "b" : "w";
    return { kind: "checkmate", winner };
  }
  if (c.isStalemate()) return { kind: "stalemate" };
  if (c.isDrawByFiftyMoves()) return { kind: "draw", reason: "fifty" };
  if (c.isThreefoldRepetition()) return { kind: "draw", reason: "repetition" };
  if (c.isInsufficientMaterial()) return { kind: "draw", reason: "insufficient" };
  if (c.isDraw()) return { kind: "draw", reason: "draw" };
  if (c.isGameOver()) return { kind: "other" };
  return { kind: "active", turn: c.turn(), inCheck: c.isCheck() };
}

export function useChessGame() {
  const chessRef = useRef<Chess>(new Chess());
  const hydratedRef = useRef(false);

  // prime from localStorage synchronously on first render
  if (!hydratedRef.current) {
    hydratedRef.current = true;
    const saved = loadSavedGame();
    if (saved?.fen) {
      try {
        chessRef.current = new Chess(saved.fen);
      } catch {
        // corrupted fen — keep start pos, wipe later on next save
      }
    }
  }

  const initialOrientation: Orientation =
    (() => {
      const s = loadSavedGame();
      return s?.orientation === "b" ? "b" : "w";
    })() ?? "w";

  const [fen, setFen] = useState(() => chessRef.current.fen());
  const [pgn, setPgn] = useState(() => chessRef.current.pgn());
  const [orientation, setOrientation] = useState<Orientation>(initialOrientation);
  const [lastMove, setLastMove] = useState<{ from: string; to: string } | null>(() => {
    const h = chessRef.current.history({ verbose: true });
    const last = h[h.length - 1];
    return last ? { from: last.from, to: last.to } : null;
  });

  const c = chessRef.current;

  const sync = useCallback(() => {
    const nextFen = c.fen();
    const nextPgn = c.pgn();
    setFen(nextFen);
    setPgn(nextPgn);
    const h = c.history({ verbose: true });
    const last = h[h.length - 1];
    setLastMove(last ? { from: last.from, to: last.to } : null);
    saveGame({ fen: nextFen, pgn: nextPgn, orientation, updatedAt: new Date().toISOString() });
  }, [c, orientation]);

  // persist orientation changes
  useEffect(() => {
    saveGame({ fen: c.fen(), pgn: c.pgn(), orientation, updatedAt: new Date().toISOString() });
  }, [orientation, c]);

  const status: GameStatus = useMemo(() => deriveStatus(new Chess(fen)), [fen]);

  const historyVerbose = useMemo(() => new Chess(fen).history({ verbose: true }), [fen]);
  const historySan = useMemo(() => new Chess(fen).history(), [fen]);

  const board = useMemo(() => new Chess(fen).board(), [fen]);

  const getLegalTargets = useCallback(
    (from: Square): Square[] => {
      const tmp = new Chess(fen);
      const moves = tmp.moves({ verbose: true, square: from });
      return moves.map((m) => m.to as Square);
    },
    [fen],
  );

  const isPromotionMove = useCallback(
    (from: Square, to: Square): boolean => {
      const tmp = new Chess(fen);
      const piece = tmp.get(from);
      if (!piece || piece.type !== "p") return false;
      const rank = to[1];
      if ((piece.color === "w" && rank !== "8") || (piece.color === "b" && rank !== "1")) return false;
      // only promotion if there exists a promotion move for that from->to
      const moves = tmp.moves({ verbose: true, square: from });
      return moves.some((m) => m.to === to && m.promotion);
    },
    [fen],
  );

  const tryMove = useCallback(
    (from: Square, to: Square, promotion?: Promotion): boolean => {
      const tmp = new Chess(fen);
      // existence check via verbose moves — avoids throwing for illegal dest
      const legal = tmp.moves({ verbose: true, square: from }).some((m) => m.to === to);
      if (!legal && !isPromotionMove(from, to)) {
        // also catches "wrong side to move" etc.
        return false;
      }
      try {
        const res = c.move({ from, to, promotion });
        if (!res) return false;
        sync();
        return true;
      } catch {
        return false;
      }
    },
    [c, fen, isPromotionMove, sync],
  );

  const undo = useCallback(() => {
    const res = c.undo();
    if (!res) return false;
    sync();
    return true;
  }, [c, sync]);

  const reset = useCallback(() => {
    c.reset();
    sync();
  }, [c, sync]);

  const newGame = useCallback(() => {
    c.reset();
    clearSavedGame();
    setFen(c.fen());
    setPgn(c.pgn());
    setLastMove(null);
    saveGame({ fen: c.fen(), pgn: c.pgn(), orientation, updatedAt: new Date().toISOString() });
  }, [c, orientation]);

  const flip = useCallback(() => setOrientation((o) => (o === "w" ? "b" : "w")), []);

  return {
    fen,
    pgn,
    board,
    orientation,
    lastMove,
    status,
    historyVerbose,
    historySan,
    getLegalTargets,
    isPromotionMove,
    tryMove,
    undo,
    reset,
    newGame,
    flip,
    canUndo: historyVerbose.length > 0,
    chess: c,
  };
}
