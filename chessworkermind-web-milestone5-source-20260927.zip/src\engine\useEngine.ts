import { useCallback, useEffect, useRef, useState } from "react";
import { Chess, type Square } from "chess.js";
import { parseInfoLine, type ParsedInfo } from "./parse";
import type { WorkerRequest, WorkerResponse } from "./engineWorker";

export type EngineState =
  | { kind: "idle" }
  | { kind: "loading" }
  | { kind: "ready" }
  | { kind: "analyzing"; positionId: number; fen: string }
  | { kind: "error"; message: string };

export type Candidate = {
  multipv: number;
  uci: string;
  san: string | null;
  scoreCp?: number;
  scoreMate?: number;
  depth: number;
  pvSans: string[]; // PV in SAN where convertible, else UCI
  raw: string;
};

export type Analysis = {
  positionId: number;
  fen: string;
  depth: number;
  candidates: Candidate[]; // sorted by multipv
  bestUci: string | null;
  engineVersion: string; // cache key part
};

const ENGINE_VERSION = "stockfish-19-lite-single";
const DEFAULT_DEPTH = 12;
const DEFAULT_MULTIPV = 3;
const CACHE_KEY_MEMO = new Map<string, Analysis>();

function cacheKey(fen: string, depth: number, multiPv: number) {
  return `${fen}::${ENGINE_VERSION}::d${depth}::mpv${multiPv}`;
}

function uciToSan(fen: string, uciMoves: string[]): string[] {
  const c = new Chess(fen);
  const out: string[] = [];
  for (const uci of uciMoves) {
    const from = uci.slice(0, 2) as Square;
    const to = uci.slice(2, 4) as Square;
    const promo = uci.slice(4) as "q" | "r" | "b" | "n" | "";
    try {
      const mv = c.move({ from, to, promotion: promo || undefined });
      if (!mv) break;
      out.push(mv.san);
    } catch {
      break;
    }
  }
  return out;
}

function uciSingleToSan(fen: string, uci: string): string | null {
  const from = uci.slice(0, 2) as Square;
  const to = uci.slice(2, 4) as Square;
  const promo = uci.slice(4) as "q" | "r" | "b" | "n" | "";
  const tmp = new Chess(fen);
  try {
    const mv = tmp.move({ from, to, promotion: promo || undefined });
    return mv ? mv.san : null;
  } catch {
    return null;
  }
}

export function useEngine() {
  const workerRef = useRef<Worker | null>(null);
  const positionIdRef = useRef(0);
  const currentAnalysisRef = useRef<Analysis | null>(null);
  const bestUciRef = useRef<string | null>(null);

  const [engineState, setEngineState] = useState<EngineState>({ kind: "idle" });
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [fallbackVisible, setFallbackVisible] = useState(false);
  const [computerOn, setComputerOn] = useState(false);
  const [computerLevel] = useState<"easy" | "medium" | "strong">("medium");

  // infos accumulator per positionId
  const infosRef = useRef<Map<number, ParsedInfo[]>>(new Map());

  const initWorker = useCallback(() => {
    if (workerRef.current) return workerRef.current;
    if (typeof Worker === "undefined") {
      setEngineState({ kind: "error", message: "Web Workers unavailable — rules-only fallback." });
      setFallbackVisible(true);
      return null;
    }
    try {
      const w = new Worker(new URL("./engineWorker.ts", import.meta.url), { type: "module" });
      workerRef.current = w;
      setEngineState({ kind: "loading" });

      w.onmessage = (e: MessageEvent<WorkerResponse>) => {
        const msg = e.data;
        if (msg.type === "ready") {
          setEngineState({ kind: "ready" });
          setFallbackVisible(false);
          return;
        }
        if (msg.type === "info") {
          // stale guard — only accumulate for current positionId
          if (msg.positionId !== positionIdRef.current) return;
          const parsed = parseInfoLine(msg.line);
          if (!parsed) return;
          const acc = infosRef.current.get(msg.positionId) ?? [];
          // keep latest per multipv (depth-aware: prefer deeper)
          const idx = acc.findIndex((p) => p.multipv === parsed.multipv);
          if (idx >= 0) {
            if (parsed.depth >= acc[idx].depth) acc[idx] = parsed;
          } else {
            acc.push(parsed);
          }
          infosRef.current.set(msg.positionId, acc);
          // build provisional analysis from infos so UI shows live candidates
          const sorted = [...acc].sort((a, b) => a.multipv - b.multipv);
          const candidates: Candidate[] = sorted.map((info) => {
            const san = uciSingleToSan(msg.fen, info.pv[0]);
            const pvSans = uciToSan(msg.fen, info.pv);
            return {
              multipv: info.multipv,
              uci: info.pv[0],
              san,
              scoreCp: info.scoreCp,
              scoreMate: info.scoreMate,
              depth: info.depth,
              pvSans,
              raw: info.raw,
            };
          });
          // also verify legality — filter any candidate whose uci isn't a legal move for that fen
          const legalCheck = new Chess(msg.fen);
          const legalUcis = new Set(legalCheck.moves({ verbose: true }).map((m) => `${m.from}${m.to}${m.promotion ?? ""}`));
          const legalReverse = new Set(legalCheck.moves({ verbose: true }).map((m) => `${m.from}${m.to}`)); // without promo suffix
          const filtered = candidates.filter((c) => legalUcis.has(c.uci) || legalReverse.has(c.uci.slice(0, 4)));
          const next: Analysis = {
            positionId: msg.positionId,
            fen: msg.fen,
            depth: Math.max(...sorted.map((s) => s.depth), 0),
            candidates: filtered.slice(0, 3),
            bestUci: bestUciRef.current,
            engineVersion: ENGINE_VERSION,
          };
          currentAnalysisRef.current = next;
          setAnalysis(next);
          const ck = cacheKey(msg.fen, DEFAULT_DEPTH, DEFAULT_MULTIPV);
          CACHE_KEY_MEMO.set(ck, next);
          return;
        }
        if (msg.type === "bestmove") {
          if (msg.positionId !== positionIdRef.current) return; // stale
          bestUciRef.current = msg.uci;
          // patch analysis bestUci
          if (currentAnalysisRef.current && currentAnalysisRef.current.positionId === msg.positionId) {
            const patched = { ...currentAnalysisRef.current, bestUci: msg.uci };
            currentAnalysisRef.current = patched;
            setAnalysis(patched);
            const ck = cacheKey(msg.fen, DEFAULT_DEPTH, DEFAULT_MULTIPV);
            CACHE_KEY_MEMO.set(ck, patched);
          }
          setEngineState({ kind: "ready" });
          return;
        }
        if (msg.type === "error") {
          setEngineState({ kind: "error", message: msg.message });
          setFallbackVisible(true);
        }
      };

      w.onerror = () => {
        setEngineState({ kind: "error", message: "Stockfish worker failed to load — rules-only fallback." });
        setFallbackVisible(true);
      };

      w.postMessage({ type: "init" } satisfies WorkerRequest);
      return w;
    } catch (e) {
      setEngineState({ kind: "error", message: String((e as Error)?.message ?? e) });
      setFallbackVisible(true);
      return null;
    }
  }, []);

  useEffect(() => {
    initWorker();
    return () => {
      if (workerRef.current) {
        try {
          workerRef.current.postMessage({ type: "quit" } satisfies WorkerRequest);
          workerRef.current.terminate();
        } catch {
          /* ignore */
        }
        workerRef.current = null;
      }
    };
  }, [initWorker]);

  const analyze = useCallback(
    (fen: string, opts?: { depth?: number; multiPv?: number }) => {
      const depth = opts?.depth ?? DEFAULT_DEPTH;
      const multiPv = opts?.multiPv ?? DEFAULT_MULTIPV;
      // monotonic positionId + cache
      positionIdRef.current += 1;
      const positionId = positionIdRef.current;
      infosRef.current.set(positionId, []);
      bestUciRef.current = null;

      const ck = cacheKey(fen, depth, multiPv);
      const cached = CACHE_KEY_MEMO.get(ck);
      if (cached) {
        // still bump id so stale guards remain correct, but serve cached immediately
        // re-tag cached under new positionId so UI shows it as current
        const tagged: Analysis = { ...cached, positionId, fen };
        currentAnalysisRef.current = tagged;
        setAnalysis(tagged);
        // also ask worker for fresh analysis in background
      } else {
        currentAnalysisRef.current = null;
        setAnalysis(null);
      }

      // validate FEN via chess.js before sending to engine — never ask engine about illegal position
      try {
        new Chess(fen);
      } catch {
        setFallbackVisible(true);
        return positionId;
      }

      const w = workerRef.current ?? initWorker();
      if (!w) {
        setFallbackVisible(true);
        setEngineState((s) => (s.kind === "error" ? s : { kind: "error", message: "Worker unavailable — rules-only fallback." }));
        return positionId;
      }

      // stale guard: any previous search is implicitly discarded via positionId check
      w.postMessage({ type: "stop" } satisfies WorkerRequest);
      w.postMessage({ type: "go", fen, positionId, depth, multiPv } satisfies WorkerRequest);
      setEngineState({ kind: "analyzing", positionId, fen });
      setFallbackVisible(false);
      return positionId;
    },
    [initWorker],
  );

  const stop = useCallback(() => {
    // bump positionId so any in-flight bestmove/info is dropped
    positionIdRef.current += 1;
    infosRef.current.clear();
    bestUciRef.current = null;
    setEngineState({ kind: "ready" });
    try {
      workerRef.current?.postMessage({ type: "stop" } satisfies WorkerRequest);
    } catch {
      /* ignore */
    }
  }, []);

  const playBestMove = useCallback(
    (fen: string): { from: string; to: string; promotion?: string } | null => {
      const cur = currentAnalysisRef.current;
      const uci = cur?.bestUci ?? analysis?.bestUci ?? null;
      if (!uci) return null;
      // verify fen matches and uci is legal in that fen — never play invented line
      const ctx = analysis?.fen === fen ? analysis : cur;
      if (!ctx || ctx.fen !== fen) return null;
      const c = new Chess(fen);
      const legalUcis = new Set(c.moves({ verbose: true }).map((m) => `${m.from}${m.to}${m.promotion ?? ""}`));
      const key = uci.length === 5 ? uci : uci.slice(0, 4);
      const fullMatch = legalUcis.has(uci);
      const prefixMatch = !fullMatch && legalUcis.has(key + "q"); // fallback if engine omitted promo — prefer queen
      const chosen = fullMatch ? uci : prefixMatch ? key + "q" : null;
      if (!chosen) return null;
      return { from: chosen.slice(0, 2), to: chosen.slice(2, 4), promotion: (chosen.slice(4) as "q" | "r" | "b" | "n") || undefined };
    },
    [analysis],
  );

  const currentPositionId = positionIdRef.current;

  return {
    engineState,
    analysis,
    fallbackVisible,
    computerOn,
    setComputerOn,
    computerLevel,
    analyze,
    stop,
    playBestMove,
    currentPositionId,
    engineVersion: ENGINE_VERSION,
  };
}
