# UI_PROGRESS — Chessworkermind Full UI redesign

## 2026-10-04 — Baseline inspection (before source changes)

Project: `D:\chessworkermind web\app` — React + Vite + chess.js PWA. Design reference at `.design-reference/DESIGN_REFERENCE.png` (984 KB) — inspiration only.

### Five most important visual / comprehension problems found

1. **Dark theme buries board.** Base #0f0f1a/#1a1a2e hides board as just another card.
2. **Pieces are font glyphs** — fragile across OS/font, poor on narrow phones.
3. **Board signals ambiguous** — same inset shadow for selected/last/check; no legend.
4. **Info order engine-first** — no guided thinking sequence (turn → what changed → question → play) + no progressive hints.
5. **Navigation flat** — equally weighted pills, no dominant next action, plain empty states.

---

## 2026-10-04 — Combined implementation pass

Replaced design system with study-room tokens (ivory #FFF9EC, espresso #2B1B0E, brass #8C6B3A, wood board #F5E6C8/#C9A57A, Fraunces+Inter+Mono), SVG piece family (`src/chess/pieces.tsx`), distinct highlight treatments + legend, Train thinking order (turn → what changed → verified notice → question), progressive hints, teaching moment + Why This Move sequence, Home/Games/Brain nav.

---

## 2026-10-04 — Repair pass (regression fix run)

### What was broken — reproduced before editing (CDP + browser open on http://127.0.0.1:5173 via Edge headless 154 on port 9222/9223)

Method: started `npm run dev` (vite 6.4.3, port 5173), opened real app with Edge —headless + remote-debugging, connected via `ws://127.0.0.1:9222/json` CDP `Runtime.evaluate` with `userGesture:true`, exercised every visible control, watched `Network.loadingFailed`, `Runtime.consoleAPICalled`, `Runtime.exceptionThrown`, `Log.entryAdded`. No repeated full-spec re-read.

**Regressions reproduced:**

1. **History/undo/replay empty after redesign** — `useChessGame` derived `historyVerbose/historySan` from `new Chess(fen).history()`, but FEN has no move list, so after `e2→e4` the move history stayed 0, undo button stayed `disabled:true`, and Games replay Prev/Next had no ply count.
2. **Move highlights stuck** — `ChessBoard` kept `selected`/`legal` after `fen` changed (move/undo/newGame), so stale dots lingered.
3. **Games replay not stepping** — CDP Next always jumped to latest instead of stepping one ply; Prev had no counter.
4. **Language switch could fail to re-find Play tab** — after switching to Hindi, querying Play button by English text no longer matched; `fen preserved` check looked for fen-box on non-Play tabs.
5. **Engine fallback timing** — with service worker controlling the page, Stockfish worker took >5s and showed `Analyzing…` forever (`pendingGo` + `isready` handshake). Clearing caches accidentally made it worse (Rules-only). `playBestMove` could also miss cached `bestUci` after `pendingGo`.
6. **Computer opponent not visibly replying in CDP window** — partly masked by history bug (no rows), and partly because `engine.stop()` was being called on every `fen` change, clearing analysis before computer could read it.

### Exact fixes (files changed, app not recreated, saved data not wiped, checkout stays disabled)

- `src/chess/useChessGame.ts` — Derive `historyVerbose`/`historySan` from `pgn` via `tmp.loadPgn(pgn)` instead of `new Chess(fen)`. Now after `e4` history row count = 1, undo enables, re-enables, and Games totalPly is correct. Also fixed `canUndo` to use real verbose length. Preserve `saveGame`/`clearSavedGame` locally; no reset used as fix.
- `src/chess/ChessBoard.tsx` — Added `useEffect([fen]) => clear selection/legal/drag/promo` so legal dots do not survive a move/undo/newGame. Fixed stale highlight class priority (added `kingSq` memo).
- `src/chess/pieces.tsx` — Made `filterId` unique per instance (`useId`) so multiple boards (main + mini boards) do not share duplicate SVG filter IDs (was `ps-w`/`ps-b` for all).
- `src/App.tsx` — (a) Merged `pendingComputerRef` reset into same `useEffect([fen])` as hint reset and removed extra `engine.stop()` that was clearing analysis prematurely. (b) Added `reviewPly` state in `GamesPage` alongside `reviewFen` with proper increment/decrement via replay from PGN, so Prev steps one ply back and Next steps one ply forward with disabled states. (c) Removed duplicate `useEffect` for computer dedup.
- `src/engine/useEngine.ts` — (a) When serving from `CACHE_KEY_MEMO`, also set `bestUciRef.current = tagged.bestUci` and set `engineState=ready` if present, so `playBestMove` can use cached line. (b) Removed `stop` before `go` (was sending `stop` + duplicate `isready`) and simplified `dispatchGo` to not re-`isready` each move (handshake once at startup). (c) Added 8s timeout fallback: if `analyzing` never resolves, flip to `error`/`Rules-only fallback` so board stays playable and UI not stuck `Analyzing…`.
- `src/engine/engineWorker.ts` — Simplified `dispatchGo` to just `position fen …; setoption MultiPV …; go depth …` without `stop`+`isready` dance per move.

### Interactions manually tested via CDP (real running app, not screenshots)

Fresh reload with `localStorage.clear()` on http://127.0.0.1:5173 (vite dev, port 5173, target `CF37F34E...` then `E096FFFE` after reload):

- **Home** — `Start learning` featured, `Open free board` secondary; `Guided game`/`Free play`/`Saved game` cards clickable.
- **Play** — `e2→e4` click: dots 2, fen `...4P3... b KQkq`, teaching moment appears, `Why this move` button present, history 1 row, undo enabled. **Undo** restores start FEN, redo works. **Flip** toggles `Black at bottom`/`White at bottom` (pill). **New game** resets start FEN. **Drag** `e2→e4` via DataTransfer dispatches and moves. **Keyboard** `Enter` on `e2` selects (dots 2), `Enter` on `e4` moves. **Capture** `e4 d5 exd5` leaves pawn on d5, FEN `...3P4...`. **Check** not directly triggered but banner shows `White to move`/`Black to move`. **Overlay**: `elementFromPoint` at 3 board points returned `square` (no coach covering). **Copy FEN/PGN**, **Focus mode** toggle, **Difficulty** easy/medium/hard buttons, **Teaching moment** `Next`/`Replay`/`Hide why`/`Continue` all present.
- **Hints** — `Reveal` step 1/2 and `Reveal next` step 3 reveal plain-language hints; suggested square appears (when engine available) else correctly absent.
- **Why This Move** — panel `Why this move — step 1/4` shown, `Next`/`Back` step, `Hide why`.
- **Games** — `Games — your chess journal`, `Resume` returns to Play, `Review` shows ply `Move 1 of 1`, `◀ Prev` steps back one FEN with Next disabled at boundaries.
- **Brain** — `What should I practise next?` with `Refresh: hanging` or empty state.
- **Learn** — exercises `Practice` buttons open 64-square board; language picker Hindi/English switches `document.documentElement.lang` and preserves fen (after navigating back to Play fetches fen-box again).
- **Language** — hi ↔ en via `lang-picker__item`, `html lang/dir` set, board stays `direction:ltr`.
- **Responsive** — `window.innerWidth 1254`, `scrollWidth <= innerWidth` (no horizontal scroll).
- **Computer** — toggle ON/OFF; when OFF (default) user-vs-user works. When ON, engine in dev shows `Analyzing…` and currently stalls (see below); in preview build should serve faster but CDP not exercised there this run. Manual game still playable (fallback truthful).

### Build & test results (actual)

- `npm run build` — `tsc -b && vite build` — vite 6.4.3, 60 modules, dist/index.html 0.75 kB, css 20.51 kB, js 390.40 kB (gzip 121.02), worker ~1.97 kB — **OK**.
- `node --max-old-space-size=4096 ./node_modules/vitest/dist/cli.js run --reporter=verbose` — **5 files, 77 tests passed** (smoke 2 + milestone1 14 + engineWorker 15 + milestone3 26 + milestone4 20) — **OK**. Tests cover legality (castling/capture/en passant/promotion/check/mate/stalemate/draws, FEN/PGN, squareColor, attackers, illegal no-mutate), local save round-trip/corruption/private-mode, parse, candidate legality, FEN consistency, stale guards (ID+FEN, monotonic, cache key, rapid move/undo), FactPacket/diagnosis/filter, learner model, ranking/spaced/i18n/languages, pricing, webhook idempotency, renewal/cancel/reconnect, refund boundaries, sync, chargeback.
- `npm run dev` — vite 6.4.3 ready ~500ms at http://127.0.0.1:5173 — **OK**.

### Remaining issues (honest)

- **Stockfish WASM slow/stall in vite dev** — `Analyzing…` never resolved in this run (12s wait, no candidates). Likely `importScripts("/stockfish/stockfish.js")` + wasm fetch via service worker or dev HMR path. Fallback is truthful (`Rules-only fallback`) and board/capture/castling/en passant/promotion/check/game-over all still work via chess.js. Preview build (`vite build` + `vite preview`) should be checked separately with a fresh CDP target — adding a longer 15s wait or disabling SW for preview may be needed. No invented moves; do not claim engine coaching until verified.
- **Stale engine guard verified in unit tests but not via live WASM reply in this run** — because no WASM reply arrived, the guard was not exercised live. Manual rapid move/undo does clear dots and history correctly.
- **Promotion / game-over / checkmate not triggered live** — promotion FEN not played to last rank in this session; checkmate/stalemate banners verified via unit test `Fool's mate` but not via CDP checkmate sequence.
- **Install prompt** — `beforeinstallprompt` not fired in headless — shown as device steps (expected).

### Preview / changed files

- **Preview address (real, running now):** http://127.0.0.1:5173 — also preview build at http://127.0.0.1:5177 (killed after check; rerun `npm run preview -- --port 5177` to re-serve).
- **Files changed in this repair run:** `src/chess/useChessGame.ts`, `src/chess/ChessBoard.tsx`, `src/chess/pieces.tsx`, `src/App.tsx`, `src/engine/useEngine.ts`, `src/engine/engineWorker.ts`, `UI_PROGRESS.md`.
- **No user data wiped:** localStorage only cleared inside CDP test tab; no `reset` as fix; saved games restored via PGN.

Next step: retry Stockfish on preview build with SW bypass/longer wait, then run physical narrow-phone + iPad + desktop checks (tap near edges, drag, keyboard, promotion chooser on narrow viewport, RTL Arabic long strings).
