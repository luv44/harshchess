/**
 * Web Worker that runs Stockfish (lite-single WASM).
 * Falls back gracefully when WASM cannot load — main thread labels "Rules-only".
 * Protocol:
 *  main -> worker: { type:'init' } | { type:'setOption', name, value } | { type:'position', fen, positionId } | { type:'go', fen, positionId, depth, multiPv } | { type:'stop' } | { type:'quit' }
 *  worker -> main: { type:'ready' } | { type:'info', positionId, fen, line } | { type:'bestmove', positionId, fen, uci, ponder } | { type:'error', message }
 *
 * Bounded, single-thread, no Threads option; depth capped for battery.
 */

export type WorkerRequest =
  | { type: "init" }
  | { type: "setOption"; name: string; value: string }
  | { type: "position"; fen: string; positionId: number }
  | { type: "go"; fen: string; positionId: number; depth?: number; multiPv?: number }
  | { type: "stop" }
  | { type: "quit" };

export type WorkerResponse =
  | { type: "ready" }
  | { type: "info"; positionId: number; fen: string; line: string }
  | { type: "bestmove"; positionId: number; fen: string; uci: string | null; ponder?: string | null; raw: string }
  | { type: "error"; message: string };

declare const self: unknown;

let engineReady = false;
let currentFen: string | null = null;
let currentPositionId: number | null = null;
let pendingGo: { fen: string; positionId: number; depth: number; multiPv: number } | null = null;
let loaded = false;

// dynamic import of stockfish lite-single via importScripts
let stockfish: { postMessage: (m: string) => void; addMessageListener?: (fn: (line: string) => void) => void; onmessage?: ((e: { data: string }) => void) | null } | null = null;

const W = self as unknown as {
  postMessage: (m: WorkerResponse) => void;
  importScripts: (...urls: string[]) => void;
  close: () => void;
  onmessage: ((e: MessageEvent<WorkerRequest>) => void) | null;
};

function post(r: WorkerResponse) {
  W.postMessage(r);
}

function loadEngine() {
  if (loaded) return;
  loaded = true;
  try {
    // stockfish lite single — load via importScripts so bundler doesn't try to bundle wasm
    // files are served from /stockfish/stockfish.js + .wasm
    W.importScripts("/stockfish/stockfish.js");
    const g = W as unknown as Record<string, unknown>;
    const SF = (g["Stockfish"] ?? g["stockfish"]) as (() => Promise<Record<string, unknown>>) | undefined;
    if (!SF) throw new Error("Stockfish global not found after importScripts");
    // Stockfish() returns a promise resolving to engine-like object with postMessage / addMessageListener
    (SF as unknown as () => Promise<Record<string, unknown>>)()
      .then((engine) => {
        const eng = engine as unknown as {
          postMessage: (s: string) => void;
          addMessageListener?: (cb: (msg: string) => void) => void;
          addMessageListener2?: (cb: (msg: string) => void) => void;
        };
        stockfish = eng as unknown as typeof stockfish;
        const attach = eng.addMessageListener ?? (eng.addMessageListener2 as unknown as ((cb: (msg: string) => void) => void) | undefined);
        if (attach) {
          attach.call(eng, (line: string) => onEngineLine(String(line)));
        } else {
          // fallback: engine may use onmessage
          const maybe = eng as unknown as { onmessage?: (e: { data: string }) => void };
          maybe.onmessage = (e: { data: string }) => onEngineLine(String(e.data ?? e));
        }
        // UCI init
        sendToEngine("uci");
      })
      .catch((e: unknown) => {
        post({ type: "error", message: `Stockfish load failed: ${String((e as Error)?.message ?? e)}` });
      });
  } catch (e) {
    post({ type: "error", message: `importScripts failed: ${String((e as Error)?.message ?? e)}` });
  }
}

function sendToEngine(cmd: string) {
  if (!stockfish) return;
  try {
    stockfish.postMessage(cmd);
  } catch {
    /* engine gone */
  }
}

function onEngineLine(line: string) {
  const trimmed = line.trim();
  if (!trimmed) return;
  if (trimmed === "uciok") {
    // configure for capped, single-thread use; ignore errors
    sendToEngine("setoption name UCI_ShowWDL value false");
    sendToEngine("setoption name Hash value 16");
    sendToEngine("isready");
    return;
  }
  if (trimmed === "readyok") {
    engineReady = true;
    post({ type: "ready" });
    // if a go was queued before ready, dispatch now
    if (pendingGo) {
      const g = pendingGo;
      pendingGo = null;
      dispatchGo(g);
    }
    return;
  }
  if (trimmed.startsWith("info ")) {
    if (currentPositionId != null && currentFen != null) {
      post({ type: "info", positionId: currentPositionId, fen: currentFen, line: trimmed });
    }
    return;
  }
  if (trimmed.startsWith("bestmove")) {
    // bestmove e2e4 ponder e7e5  (ponder may be absent)
    const parts = trimmed.split(/\s+/);
    const uci = parts[1] && parts[1] !== "(none)" ? parts[1] : null;
    const ponder = parts[3] ?? null;
    if (currentPositionId != null && currentFen != null) {
      post({ type: "bestmove", positionId: currentPositionId, fen: currentFen, uci, ponder, raw: trimmed });
    }
    // clear so next position's infos don't leak
    return;
  }
}

function dispatchGo(req: { fen: string; positionId: number; depth: number; multiPv: number }) {
  const { fen, positionId, depth, multiPv } = req;
  currentFen = fen;
  currentPositionId = positionId;
  // UCI position — note: isready handshake already done at startup; no need to re-isready per move
  sendToEngine(`position fen ${fen}`);
  const mpv = Math.max(1, Math.min(3, multiPv));
  const d = Math.max(6, Math.min(18, depth));
  sendToEngine(`setoption name MultiPV value ${mpv}`);
  // bounded search — depth for battery, no infinite go
  sendToEngine(`go depth ${d}`);
}

W.onmessage = (e: MessageEvent<WorkerRequest>) => {
  const msg = e.data;
  try {
    switch (msg.type) {
      case "init":
        loadEngine();
        break;
      case "setOption":
        sendToEngine(`setoption name ${msg.name} value ${msg.value}`);
        break;
      case "position":
        currentFen = msg.fen;
        currentPositionId = msg.positionId;
        sendToEngine("stop");
        sendToEngine(`position fen ${msg.fen}`);
        break;
      case "go": {
        const depth = msg.depth ?? 12;
        const multiPv = msg.multiPv ?? 3;
        if (!engineReady || !stockfish) {
          pendingGo = { fen: msg.fen, positionId: msg.positionId, depth, multiPv };
          loadEngine();
          break;
        }
        dispatchGo({ fen: msg.fen, positionId: msg.positionId, depth, multiPv });
        break;
      }
      case "stop":
        sendToEngine("stop");
        break;
      case "quit":
        sendToEngine("quit");
        try {
          W.close();
        } catch {
          /* ignore */
        }
        break;
    }
  } catch (err) {
    post({ type: "error", message: String((err as Error)?.message ?? err) });
  }
};
