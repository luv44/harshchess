# Chessworkermind feature matrix — 2026-10-02

This is the real supplied React/TypeScript app, not a replacement. Current requirements: `UPDATED_PROMPT.txt`. Older narrative claims in state history are not current verification. Exact check outcomes belong in `QA_REPORT.md` and `RUN_RECOVERY.json`.

| Area | Current implementation and limits |
|---|---|
| Free board and current saved game | chess.js legal moves, touch/click/keyboard, promotion choice, castling, en passant, draws, PGN-backed restoration. Fixed threefold status to retain history and reject moves after game over. One current game is saved; not a multi-game cloud archive. |
| Computer opponent | Ten real Stockfish profiles, separate from coach strength. Exact turn/FEN/request guards, at most one reply, bounded single-thread search. Honest legal fallback when unavailable. `ENGINE_STRENGTH.md` documents options and budgets. No Elo or guaranteed ordering claim. |
| Learning level | Separate persistent 1–10 control, Adaptive recommendations or Manual. Each tier opens an existing legally validated representative exercise. Upper-tier breadth, calibration and full expert own-game training remain incomplete; labelled in controls. |
| Adaptive evidence | New attempts include exact position, answer, hints/reveal, independent/repeated status, exercise tier, both settings, verifier and timestamp. Per-concept estimates/uncertainty and consent-based one-step suggestion after varied comparable transfer success. No automatic global demotion, no calibrated success-rate claim. |
| Live facts and discovery | Exact-FEN + generation fact packet; legal checks/captures, geometric attacks/defenders, explicit unknowns. Attention highlight, candidate selection, conditional legal reply replay, independent practice board, return to saved position. Geometric defense is explicitly not proof of a legal recapture. |
| Coaching | Existing bounded local analysis preserved. Optional stronger Stockfish coaching is separate from opponent settings. Legacy FactPacket now legally replays complete PVs, rejects missing promotions and abstains from transplanting a reply from a different variation. Full four-category classification throughout every older coach screen remains unfinished. |
| Mistake repair | Original-position reviewer with conditional language; candidate/consequence replay and retry are isolated from original game history. Explicit Undo/Take it back still intentionally edits the current game. Deeper engine comparison/stability verification for every local review is not complete. |
| Lessons | 36 original lessons across five existing stages; some are reading lessons. Transfer actually remounts to a different board; a failed move must reset before another answer. Reveals/repeats are not independent evidence. Full extensible concept metadata and delayed transfer scheduler remain incomplete. |
| Home / Train / Games / Progress | Existing warm design retained, local bundled chess font, separate settings panel. Home points at a selected-tier lesson. Games offers current-game resume and PGN review. Progress shows attempts and supporting positions, not a numerical Brain rating or mixed-difficulty speed-improvement claim. |
| Language | Partial existing translations only, with visible English fallback warning on non-English screens. Complete localized lessons, long-translation review and native-speaker QA remain open. |
| Offline/PWA | Production service worker, relative asset URLs and optional installation instructions preserved. Assets must load before offline use; browser storage can be evicted. Real physical-device installation is unverified. |
| Account / Free–Pro | Existing local test adapter, entitlement/refund/sync logic preserved. No real backend or cross-device sync connected. ₹599/month base architecture retained; checkout disabled. |
| Payments / ads / deployment | No live payments, deployment, publishing or AdSense. No secrets included in export. |

## Evidence versus completion

Meaningful unit/integration tests cover these foundations; real Chromium checks exercise the integrated app rather than a mocked board. See the final QA log for results and any failures. No claim of a completed full updated-prompt product, human-rated teaching quality, calibrated expert strength or physical Android/iPhone validation is made.
