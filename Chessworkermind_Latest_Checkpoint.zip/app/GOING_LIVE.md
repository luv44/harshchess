# Going live — exactly what is missing, and what is already done

Nothing in this document has been done for you, and nothing here can be done
from the build sandbox. It needs a real merchant account and real keys.

## Already built and tested (20 tests, `src/billing/__tests__/milestone4.test.ts`)

- ₹599/month, INR, one price, no regional discounts, no annual plan
  (`src/billing/pricing.ts`)
- Webhook signature verification, and a **forged event is rejected**
- **Replay protection**: the same provider event id applied twice changes
  nothing
- **Out-of-order events**: an older event cannot overwrite newer state
- Wrong amount or wrong currency in a webhook never grants Pro
- Renewal extends the period; a failed renewal moves to grace; past grace
  expires
- Cancellation keeps Pro until the paid period ends, then Free, history kept
- **7-day first-purchase refund**: eligible inside the window, not eligible
  at 7 days + 1ms, not eligible on a second-month charge
- Refunds are idempotent, and a chargeback is recorded separately rather
  than disguised as a refund
- Pro can only come from a signature-verified snapshot — never from a URL,
  never from a device-local flag
- Guest → account merge unions data and never deletes server games

## What is deliberately switched off

`src/billing/pricing.ts`:

```ts
export const CHECKOUT_ENABLED = false;
```

The UI says "Pro coming soon" while this is false. **Do not flip it** until
every step below is done.

## The steps only you can do

1. **Open a merchant account** with a provider that supports INR recurring
   payments. The code is provider-neutral; `src/billing/provider.ts` is a
   test adapter with the same shape a real one needs.
2. **Get the keys** and put them in server-side environment variables.
   They must never appear in this repository or in the browser bundle.
3. **Stand up a webhook endpoint** on a real server. It must:
   - verify the signature with the provider's real HMAC, using a
     constant-time compare (`crypto.timingSafeEqual`), not the test stub
   - store the provider event id and ignore a repeat
   - reject an event whose amount or currency is not ₹599 / INR
4. **Replace the test adapter** with the real provider's SDK, keeping the
   same functions so the 20 existing tests still apply.
5. **Run the lifecycle against the provider's sandbox**: create, renew, fail
   a renewal, cancel, refund inside 7 days, refund outside, chargeback.
6. **Publish the refund policy** to customers before the first charge.
7. Only then set `CHECKOUT_ENABLED = true`.

## Not being done, on purpose

- No AdSense, no advertising code of any kind.
- No public launch. The preview is private.
- No live charge has ever been attempted from this project.
