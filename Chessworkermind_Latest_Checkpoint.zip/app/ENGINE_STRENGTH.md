# Computer strength and engine safety

## Engine actually shipped

The installed package is Stockfish.js 19. The app uses the **lite single-threaded** pair already in `public/stockfish/`:

- `stockfish-19-lite-single.js`
- `stockfish-19-lite-single.wasm`

The JS file runs directly as a **classic Web Worker**, accepts string UCI commands with `postMessage`, emits string lines, and fetches its adjacent `.wasm`. It does **not** expose the assumed `Stockfish().postMessage()` factory in a module worker. `createEngineWorker.ts` lazily creates the module protocol adapter; the adapter starts that classic worker. The main thread passes an absolute URL resolved against Vite's base and `document.baseURI`, so relative-base subfolder builds do not hardcode `/stockfish/`.

Direct `uci` inspection of the installed executable reported:

- `Threads`: default/min/max **1** (single-threaded; no cross-origin isolation requirement).
- `Hash`: default **16** MiB.
- `MultiPV`: **1–256** (application caps coaching to 3 and opponent to 1).
- `Skill Level`: **0–20**.
- `UCI_LimitStrength`: boolean, default false.
- `UCI_Elo`: **1320–3190**. This is advertised by the engine, **not** a calibration of this lite build with our budgets. The app does not set it or display an Elo claim.
- Also advertised: `Ponder`, `Clear Hash`, `Move Overhead`, `nodestime`, `UCI_Chess960`, `UCI_ShowWDL`, `EvalFile`.

The adapter only sends supported advertised options. Normal searches use Threads=1, Hash=16, Ponder=false, UCI_ShowWDL=false and UCI_LimitStrength=false. Serve over HTTP(S), not `file://`, and serve `.wasm` as `application/wasm` for the shipped streaming loader.

## Ten profiles

Each opponent request resets Skill Level, MultiPV=1, and starts with `ucinewgame` to avoid retained search hash from another profile. `go` includes **all three limits** below; whichever stops the engine first applies. Profiles are frozen configuration records in `src/engine/strength.ts`.

| Strength | Skill Level | Depth cap | Node budget | Move time cap (ms) |
| --- | ---: | ---: | ---: | ---: |
| 1 | 0 | 4 | 2,000 | 80 |
| 2 | 2 | 5 | 5,000 | 120 |
| 3 | 4 | 6 | 10,000 | 180 |
| 4 | 6 | 7 | 20,000 | 250 |
| 5 | 8 | 8 | 40,000 | 350 |
| 6 | 10 | 9 | 80,000 | 500 |
| 7 | 12 | 10 | 120,000 | 700 |
| 8 | 15 | 12 | 180,000 | 950 |
| 9 | 18 | 14 | 260,000 | 1,250 |
| 10 | 20 | 16 | 400,000 | 1,600 |

These are **reproducible settings, not reproducible identical Stockfish moves**. Stockfish's skill weakening can randomize choices; wall-clock limits, device speed and search timing affect results. Ten different presets do not establish ten calibrated Elo ratings, tournament strength, or guaranteed ordering in every position. No Elo or win-rate claim has been measured. Lower skill does not guarantee a beginner will win.

Numeric values are rounded and clamped to 1–10; nonfinite values default to 5. Legacy `gentle`, `steady`, `sharp` map to 2, 5, 9. Explicit numeric strength takes precedence.

## Opponent API and UI labels

```ts
const opponent = useComputerOpponent({
  fen, turn, generation, statusKind, paused,
  session: { mode: "vsComputer", humanSide: "w" },
  strength: 5,
  applyMove,
});
```

Existing `level`, `thinking`, `cancelPending`, `delayMs` interfaces remain supported. The old `engineBestUci` input remains accepted for source compatibility but is intentionally **ignored**: it has no opponent request ID/settings provenance.

Additional returned fields:

- `strength`, `profile`: normalized selected profile.
- `source`: `null` while a new result is unverified, `"stockfish"` after a legal tagged engine reply, or `"rules-only"` after fallback. The last settled source is retained between turns, not represented as the source of a future analysis.
- `status`: `"idle" | "loading" | "thinking" | "ready" | "fallback"`. Ready/fallback can include the short display delay before commit; `thinking` remains true until the move is consumed.
- `message`: failure reason, or null.
- `fallbackVisible`: source is `"rules-only"`.

UI should display **Stockfish** only for a verified Stockfish result, **Rules-only fallback** when fallbackVisible, and loading/thinking otherwise. Selecting strength alone does not prove the engine ran.

The standard White-human/Black-computer session schedules nothing on White's turn and applies one Black reply. Existing explicitly selected Black-human and watch modes remain supported by the shared session rules; this hook does not silently change a saved session.

## Coaching is separate

`useEngine()` is lazy: mounting the screen does not create a worker or download WASM. `analyze` starts it. `stop` invalidates the ID and all playable/cached analysis immediately. Coaching searches explicitly reset Skill Level=20 and UCI_LimitStrength=false; opponent strength never weakens coaching. Default coaching is depth 12, MultiPV=3, 300,000 nodes, 1,500 ms; hard caps are depth 18, MultiPV=3, 500,000 nodes, 3,000 ms. There is no persistent/provisional analysis cache that can revive a stopped best move.

Opponent and coaching hooks own separate lazy worker instances. The parent screens should avoid requesting coaching during the computer's turn and call `engine.stop()` when deeper coaching is disabled. No unbounded `go infinite` or continuous pondering is used.

## Cancellation and trust boundaries

UCI emits no request identifiers. The adapter keeps an immutable active FEN/ID, invalidates its output as soon as stop/replacement arrives, **waits for that search's `bestmove`**, then waits for `readyok` before sending the next position/go. Rapid replacements coalesce to the latest queued request. Settings are never sent into an active search. Stop before initialization also clears the queued request.

Both the protocol adapter and hook reject illegal UCI moves. Promotion suffixes must match exactly. Every PV ply is replayed with chess.js; an illegal continuation rejects the **whole PV**, not merely its suffix. Hooks additionally require exact request ID and FEN. Finished/duplicate messages cannot schedule another reply.

Opponent commit rechecks generation, FEN, turn, mode, human side, strength, pause, game status, request token and exact legality against the latest render values. Cleanup/cancel removes handlers and timers and stops pending work. Settings changes cancel the old search/reply and, if it is still a computer turn, request a fresh one. A consumed turn is recorded before `applyMove`, preventing duplicate commits even before the parent rerenders. The parent must keep incrementing generation on reset/undo, including returning to the same FEN.

Initialization/readiness has a 30-second watchdog. Integrated production-browser QA found that the first module response alone could take over ten seconds on this D-drive mount; the old ten-second loading limit caused a legal fallback before WASM arrived. The search budgets are unchanged. Active search has the selected move-time budget plus 2 seconds to produce its final result; cancelled-search draining has a 1.5-second deadline. Hook watchdogs also cover a module worker that never responds. A failed worker is terminated, not silently reused; a subsequent turn can retry. Browser timer suspension/background throttling can delay wall-clock watchdog delivery.

Fallback is deterministic rules-only scoring (`pickReply`) with stable FEN/profile tie-breaking, not Stockfish and not calibrated to these profiles. It handles missing Workers, worker errors, timeouts and unusable bestmoves, and passes the same final exact-legal commit gate. It never manufactures an engine score. When Worker is unavailable it runs the existing bounded local move scorer inline; this is less capable than Stockfish and can occupy the main thread briefly.

## Verification commands

From `app/` (the project also provides npm aliases):

```sh
node node_modules/vitest/vitest.mjs run src/engine/__tests__ src/chess/__tests__/opponent.test.ts src/chess/__tests__/useComputerOpponent.test.ts src/chess/__tests__/session.test.ts src/coach/__tests__/engineTrust.test.ts
node node_modules/typescript/bin/tsc --noEmit
```

These exercise the production UCI state machine and React hooks, not just duplicate guard expressions: delayed stop output, ready barriers, settings isolation, timeouts, exact FEN/IDs, full PV legality, promotions, one-turn ownership, strength/reset/undo/mode changes, duplicate callbacks, and honest deterministic fallback.

Optional real browser/WASM smoke against an already-running local Vite dev server:

```sh
TMPDIR="$PWD/.cache/tmp" node src/engine/__tests__/browser-smoke.mjs
```

The smoke uses the existing Playwright/browser installation, a D-drive temporary profile, the **real** module/classic workers and WASM, and checks readiness plus a legal Black bestmove for the exact FEN and request ID. `CHROME_PATH` and `SMOKE_URL` override local defaults. No browser download or deployment is initiated by the test.

Recorded checks for this change: the focused 7-file suite passed **84 tests**; the optional real-browser smoke returned `ready`, 8 legal info lines and a legal Black bestmove (`e7e6`) tagged with request 101 and the exact requested FEN. `node node_modules/vite/bin/vite.js build --outDir .cache/engine-build` passed, with the existing >500 kB main-chunk warning. The final full-project `node node_modules/typescript/bin/tsc --noEmit` **passed**. An earlier run was temporarily blocked by unrelated missing jest-dom matcher typings in `src/__tests__/checkpoint.regressions.test.tsx`; those were resolved outside this scoped engine change.

Stockfish remains GPLv3; existing redistribution/source obligations still apply. This change does not certify a public release or change licensing artifacts.
