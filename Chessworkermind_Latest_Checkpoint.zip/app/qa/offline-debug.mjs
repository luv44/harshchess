import { chromium } from 'playwright';
import fs from 'node:fs';
const root=process.cwd();
const browser=await chromium.launch({executablePath:root+'/.cache/browser/chrome-headless-shell-linux64/chrome-headless-shell',headless:true,args:['--no-sandbox'],env:{...process.env,TMPDIR:root+'/.cache/tmp',LD_LIBRARY_PATH:root+'/.cache/libs-flat'}});
try {
 const context=await browser.newContext(); const page=await context.newPage();const errors=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 await page.goto('http://127.0.0.1:4173',{waitUntil:'load',timeout:90000});
 await page.evaluate(async()=>{await navigator.serviceWorker.ready;});
 await page.waitForTimeout(1000);
 const before=await page.evaluate(async()=>({control:navigator.serviceWorker.controller?.scriptURL,registrations:(await navigator.serviceWorker.getRegistrations()).map(r=>({active:r.active?.scriptURL,waiting:r.waiting?.state})),caches:await Promise.all((await caches.keys()).map(async k=>({key:k,urls:(await(await caches.open(k)).keys()).map(r=>r.url)})))}));
 await context.setOffline(true);await page.reload({waitUntil:'domcontentloaded',timeout:30000});await page.waitForTimeout(1500);
 const after=await page.evaluate(()=>({control:navigator.serviceWorker.controller?.scriptURL,text:document.body.innerText,html:document.head.innerHTML}));
 fs.writeFileSync('qa/offline-debug.json',JSON.stringify({before,after,errors},null,2));
} finally {await browser.close();}
