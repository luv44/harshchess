#!/usr/bin/env python3
"""Create and verify a source-only dated checkpoint on the user's D: drive.
Run from app/: python3 scripts/checkpoint.py
State/recovery must be updated with real checks BEFORE running this script.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import shutil
import zipfile

APP = Path(__file__).resolve().parents[1]
WORKSPACE = APP.parent.parent
if not str(WORKSPACE).startswith('/mnt/d/'):
    raise SystemExit('Refusing to write a checkpoint outside the requested D: drive.')
STAMP = os.environ.get('CHECKPOINT_STAMP', datetime.now(timezone.utc).strftime('%Y-%m-%d_%H%M%S_UTC'))
if not re.fullmatch(r'\d{4}-\d{2}-\d{2}_\d{6}_UTC', STAMP):
    raise SystemExit('Invalid checkpoint timestamp.')
DEST = WORKSPACE / 'Chessworkermind_Checkpoints' / STAMP
ZIP = WORKSPACE / 'Chessworkermind_Latest_Checkpoint.zip'
EXCLUDED = {'node_modules', 'dist', '.cache', '.git', '.omnirush', '_secrets', '_agent_data',
            '_tools', '_system', '_checkpoints', 'coverage', 'test-results', 'playwright-report',
            'browser-results', '__pycache__'}

def included(p):
    rel = p.relative_to(APP)
    return (not any(part in EXCLUDED for part in rel.parts)
            and not p.is_symlink()
            and not p.name.startswith('.env')
            and p.name not in {'opencode.json', '.DS_Store'}
            and p.suffix.lower() not in {'.zip', '.tsbuildinfo', '.pem', '.key', '.pfx', '.pyc'}
            and not any(word in p.name.lower() for word in ('credentials', 'auth-token', 'private-key')))

for name in ['package.json', 'package-lock.json', 'PROJECT_STATE.json', 'RUN_RECOVERY.json']:
    json.loads((APP / name).read_text())
files = sorted(p for p in APP.rglob('*') if p.is_file() and included(p))
DEST.mkdir(parents=True, exist_ok=False)
entries = []
for p in files:
    rel = Path('app') / p.relative_to(APP)
    target = DEST / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, target)
    entries.append({'path': rel.as_posix(), 'bytes': target.stat().st_size,
                    'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
manifest = {'created_utc': STAMP, 'root': 'app/', 'files': entries,
            'exclusions': sorted(EXCLUDED), 'note': 'Source checkpoint. No node_modules, dist, secrets, caches or old ZIPs.'}
(DEST / 'CHECKPOINT_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
tmp = ZIP.with_suffix('.zip.partial')
with zipfile.ZipFile(tmp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for e in entries:
        z.write(DEST / e['path'], e['path'])
    z.write(DEST / 'CHECKPOINT_MANIFEST.json', 'CHECKPOINT_MANIFEST.json')
with zipfile.ZipFile(tmp) as z:
    bad = z.testzip()
    if bad:
        raise RuntimeError(f'ZIP integrity failure: {bad}')
    assert 'app/package.json' in z.namelist()
    assert 'app/src/App.tsx' in z.namelist()
    for e in entries:
        assert hashlib.sha256(z.read(e['path'])).hexdigest() == e['sha256'], e['path']
    for name in ['PROJECT_STATE.json', 'RUN_RECOVERY.json']:
        json.loads(z.read('app/' + name))
tmp.replace(ZIP)
report = {'checkpoint': str(DEST), 'zip': str(ZIP), 'zip_bytes': ZIP.stat().st_size,
          'zip_sha256': hashlib.sha256(ZIP.read_bytes()).hexdigest(),
          'root': 'app/', 'files': len(entries), 'crc': 'passed', 'all_source_hashes': 'passed'}
(DEST / 'ARCHIVE_VERIFICATION.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
