import { defineConfig } from "@playwright/test";
import path from "node:path";
const root=process.cwd();
export default defineConfig({
  testDir: "./e2e", timeout: 150000, expect: { timeout: 45000 }, workers: 1,
  outputDir: "qa/browser-results", reporter: [["list"],["json",{outputFile:"qa/browser-results.json"}]],
  use: { baseURL: "http://127.0.0.1:4173", headless: true, trace: "retain-on-failure",
    launchOptions: { executablePath: process.env.CHROME_PATH ?? path.join(root,".cache/browser/chrome-headless-shell-linux64/chrome-headless-shell"),
      args:["--no-sandbox"], env:{...process.env, TMPDIR:path.join(root,".cache/tmp"),
        LD_LIBRARY_PATH:`${root}/.cache/libs-flat:${process.env.LD_LIBRARY_PATH??""}`} }
  },
});
