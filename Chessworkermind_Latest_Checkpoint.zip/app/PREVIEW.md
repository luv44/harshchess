# Local preview — not deployed

The former temporary cloud URLs in the archive are historical and have been removed. No public site was created in this session. Local servers used for QA are stopped before handoff.

From Ubuntu WSL:

```bash
cd '/mnt/d/MMy New Project/Chessworkermind/app'
npm run build
npm run preview -- --host 127.0.0.1
```

Then open **http://localhost:4173** on this PC. For development use `npm run dev -- --host 127.0.0.1` and **http://localhost:5173**. The production localhost preview is a secure context for service-worker testing; opening files directly or a plain non-localhost phone URL is not equivalent.

## Try the real learning loop

1. Open Train. If the saved mode is local two-player, choose **Use computer coaching — you play White**. This changes mode but does not rewrite your moves.
2. Make a legal White move. Wait for exactly one Black reply; the status states Stockfish or rules-only fallback honestly.
3. The last-move line comes from actual history. Choose a hint, or open **Explore this exact position**.
4. Use **Show me where to look**, inspect board facts and unknowns, select a legal candidate, and choose **If I play this…**.
5. Step through the conditional legal line. **Retry from original position** uses a separate board. **Return to current position** leaves the original saved game unchanged.
6. Expand **Train settings** for independent Learning 1–10 and Computer 1–10 controls. Lessons offers a working practice action for each selected learning tier.
7. Progress shows saved practice counts and exact supporting attempts, not a numerical chess rating.

`qa/live-loop.json`, when present, records the actual engine-generated position and candidate used by the browser test. It is evidence of one real run, not a canned live lesson.

## Keyboard / offline / devices

The board is one tab stop. Arrows move the cursor; Enter/Space selects and plays, Escape clears selection. Home/End and PageUp/PageDown navigate the grid. Optional engine assets must finish loading before offline engine use. Rules-only fallback remains legal if they do not.

Chromium desktop and narrow-viewport automated checks are documented in `QA_REPORT.md`; physical installation and interaction still **need your phone**. No claim of iPhone Safari, Android installed-PWA, screen-reader or real-device battery verification is made. See `SETUP.md` for source installation and the checked ZIP root.
