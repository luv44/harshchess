import { useEffect, useState } from "react";
import { coachTrick } from "../coach/coachTrick";
import type { CoachCard } from "../coach/coachCard";
import type { RenderedCard } from "../coach/coachText";

/**
 * The Coach card, exactly one per turn, always in this order:
 *   1 what just happened (+ a verified threat, or an honest "nothing hangs")
 *   2 your move to try (FROM = 1, TO = 2)
 *   3 why this helps (ONE reason)
 *   4 what might happen next (conditional, "if … you can try …")
 *   5 try it yourself (think → hint → show → do it for me)
 *
 * The card never plays the move by itself. "Show me on the board" only
 * highlights; "Move it for me" is a separate, clearly named button.
 */

export type CoachCardViewProps = {
  card: CoachCard | null;
  text: RenderedCard | null;
  status: "idle" | "thinking" | "ready" | "error";
  /** highlight the suggestion on the board */
  onShowOnBoard: () => void;
  /** actually play the suggested move */
  onMoveForMe: () => void;
  onRefresh: () => void;
  onReportWrong: () => void;
  /** true while it is not the learner's turn */
  waiting: boolean;
  showing: boolean;
  engineLabel: string;
  computeMs: number | null;
};

export default function CoachCardView({
  card,
  text,
  status,
  onShowOnBoard,
  onMoveForMe,
  onRefresh,
  onReportWrong,
  waiting,
  showing,
  engineLabel,
  computeMs,
}: CoachCardViewProps) {
  const [tier, setTier] = useState(0);
  const trick = coachTrick(card?.reason?.key);
  const [seeMore, setSeeMore] = useState(false);

  // A new position resets the help tiers: no carry-over from the last move.
  useEffect(() => {
    setTier(0);
    setSeeMore(false);
  }, [card?.fen]);

  if (status === "thinking" && !card) {
    return (
      <section className="coach" aria-live="polite">
        <div className="coach__head">
          <div className="coach__avatar" aria-hidden="true">♞</div>
          <div>
            <div className="coach__title">Coach</div>
            <div className="coach__sub">Looking at the board…</div>
          </div>
          <div className="coach__end" style={{ marginInlineStart: "auto" }}>
            <span className="thinkdots" aria-hidden="true"><i /><i /><i /></span>
          </div>
        </div>
        <div className="coach__body">
          <p className="muted small" style={{ padding: "10px 0" }}>
            Checking every legal move in this exact position. This takes a moment and never guesses.
          </p>
        </div>
      </section>
    );
  }

  if (!card || !text) {
    return (
      <section className="coach">
        <div className="coach__head">
          <div className="coach__avatar" aria-hidden="true">♞</div>
          <div>
            <div className="coach__title">Coach</div>
            <div className="coach__sub">Waiting for a position</div>
          </div>
        </div>
        <div className="coach__body">
          <p className="emptynote">Make a move and the coach will explain what happened.</p>
        </div>
      </section>
    );
  }

  const sg = card.suggestion;

  return (
    <section className="coach" aria-label="Coach explanation">
      <div className="coach__head">
        <div className="coach__avatar" aria-hidden="true">♞</div>
        <div style={{ minWidth: 0 }}>
          <div className="coach__title">Coach</div>
          <div className="coach__sub">
            {card.gameOver
              ? "Game over"
              : waiting
                ? "Explaining the position"
                : "Your turn — here is one idea"}
          </div>
        </div>
        <div style={{ marginInlineStart: "auto", display: "flex", gap: 6, alignItems: "center" }}>
          {status === "thinking" && <span className="thinkdots" aria-hidden="true"><i /><i /><i /></span>}
        </div>
      </div>

      <div className="coach__body">
        {text.fallbackNotice && (
          <p className="pill pill--warn" style={{ margin: "10px 0", whiteSpace: "normal" }}>
            {text.fallbackNotice}
          </p>
        )}

        {text.endLine && (
          <div className="csec">
            <p className="movebig">{text.endLine}</p>
          </div>
        )}

        {/* ================= THE ONE IDEA =================
            Everything above the fold is a single short thought: what the
            situation is, the move to try, and the line to remember. The
            full sections 1 and 3 to 5 live in the fold below. Before this
            the card opened with two numbered sections, four paragraphs and
            two caveats, for one move. */}
        {!card.gameOver && (
          <div className="idea">
            <p className={`idea__status ${text.threatIsReal ? "idea__status--warn" : ""}`}>
              <em aria-hidden="true">{text.threatIsReal ? "⚠" : "✓"}</em>
              <span>
                {text.s1Lines.length > 0 ? `${text.s1Lines[0]} ` : ""}
                {text.threatLine}
              </span>
            </p>

            {sg && (
              <>
                <p className="idea__move">{renderWithSquares(text.s2Line, sg.from, sg.to)}</p>
                {trick && (
                  <p className="trick">
                    <span className="trick__label">Remember</span>
                    <span className="trick__text">{trick}</span>
                  </p>
                )}
                <div className="btnrow" style={{ marginTop: 12 }}>
                  <button
                    className={`btn ${showing ? "" : "btn--primary"}`}
                    onClick={onShowOnBoard}
                    style={{ flex: "1 1 auto" }}
                  >
                    {showing ? "✓ Shown on the board" : `👀 ${text.showMeLabel}`}
                  </button>
                  <button className="btn btn--quiet" onClick={onMoveForMe}>
                    ▶ {text.moveForMeLabel}
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        {/* Sections 3 to 5 used to be three stacked walls of text under the
            answer. They are all still here, in the same order, but folded
            away so the card answers the question first and explains second. */}
        {!card.gameOver && (sg || card.practice) && (
          <details className="coachmore">
            <summary className="coachmore__toggle">
              Why it helps, what might happen, and a question to try
            </summary>

            {/* ---- 1. What just happened, in full ---- */}
            <div className="csec">
              <div className="csec__label"><i>1</i> {text.s1Title}</div>
              {text.s1Lines.length > 0 ? (
                text.s1Lines.map((l, i) => <p key={i}>{l}</p>)
              ) : (
                <p className="muted">The game is just starting — nothing has happened yet.</p>
              )}
              {card.threat.present && card.threat.continuation.length > 0 && (
                <p className="small muted" style={{ marginTop: 6 }}>
                  Checked line: <code>{card.threat.continuation.join("  ")}</code>
                </p>
              )}
            </div>

            {/* ---- 2. The move, with its caveats ---- */}
            {sg && (
              <div className="csec">
                <div className="csec__label"><i>2</i> {text.s2Title}</div>
                <p>{text.s2Line}</p>
                {text.s2Note && <p className="small muted" style={{ marginTop: 4 }}>{text.s2Note}</p>}
                <p className="small muted" style={{ marginTop: 6 }}>
                  You do not have to play this. Any legal move you like is fine — the coach will follow your real
                  board.
                </p>
              </div>
            )}

        {/* ---- 3. Why this helps ---- */}
        {!card.gameOver && sg && (
          <div className="csec">
            <div className="csec__label"><i>3</i> {text.s3Title}</div>
            <p>{text.s3Line}</p>
            {sg.confidence === "low" && (
              <p className="small muted" style={{ marginTop: 5 }}>
                Several moves look about equally good here, so treat this as one safe idea rather than the only move.
              </p>
            )}
          </div>
        )}

        {/* ---- 4. What might happen next ---- */}
        {!card.gameOver && text.s4Lines.length > 0 && (
          <div className="csec">
            <div className="csec__label"><i>4</i> {text.s4Title}</div>
            {text.s4Lines.map((l, i) => (
              <p key={i}>{l}</p>
            ))}
            <p className="small muted" style={{ marginTop: 5 }}>{text.s4Caveat}</p>
            {text.s4Plan && <p style={{ marginTop: 7, fontWeight: 700 }}>{text.s4Plan}</p>}
            {sg && sg.alternatives.length > 0 && (
              <>
                {!seeMore ? (
                  <button className="btn btn--ghost btn--sm" style={{ marginTop: 8 }} onClick={() => setSeeMore(true)}>
                    {text.seeMoreLabel}
                  </button>
                ) : (
                  <p className="small muted" style={{ marginTop: 8 }}>{text.s2Alternatives}</p>
                )}
              </>
            )}
          </div>
        )}

        {/* ---- 5. Try it yourself ---- */}
        {!card.gameOver && card.practice && (
          <div className="csec">
            <div className="csec__label"><i>5</i> {text.s5Title}</div>
            <p className="question">{text.s5Question}</p>
            <div className="tiers">
              <button className={`tier ${tier >= 1 ? "tier--revealed" : ""}`} onClick={() => setTier(Math.max(tier, 1))}>
                <span className="tier__n">1</span>
                <span>{tier >= 1 ? text.tier1 : "Think about it first"}</span>
              </button>
              <button className={`tier ${tier >= 2 ? "tier--revealed" : ""}`} onClick={() => setTier(Math.max(tier, 2))}>
                <span className="tier__n">2</span>
                <span>{tier >= 2 ? text.tier2 : "Give me a gentle hint"}</span>
              </button>
              <button
                className={`tier ${tier >= 3 ? "tier--revealed" : ""}`}
                onClick={() => {
                  setTier(Math.max(tier, 3));
                  onShowOnBoard();
                }}
              >
                <span className="tier__n">3</span>
                <span>{tier >= 3 ? text.tier3 : "Show me the squares"}</span>
              </button>
              <button className="tier" onClick={onMoveForMe}>
                <span className="tier__n">4</span>
                <span>{text.tier4}</span>
              </button>
            </div>
            {tier > 0 && (
              <p className="small muted" style={{ marginTop: 7 }}>
                You used a hint on this one, so it will not be counted as solving it on your own. That is fine — it
                will come back later in a different position.
              </p>
            )}
          </div>
        )}
          </details>
        )}

        {/* The FEN, the engine name, the confidence and the timing used to
            sit here in a "Details for this position" block. None of that
            helps someone learning to play, and the beginner path is not
            supposed to need notation or engine internals. It lives in
            Settings > Coach lab now. What stays is the one thing a learner
            might genuinely need: a way to say the advice looks wrong. */}
        <p className="coachfoot">
          <button className="linkbtn" onClick={onReportWrong}>
            This explanation looks wrong
          </button>
          <span aria-hidden="true"> · </span>
          <button className="linkbtn" onClick={onRefresh}>
            Check again
          </button>
        </p>

      </div>
    </section>
  );
}

/** Wrap the two square names in the sentence so text and board agree visually. */
function renderWithSquares(line: string, from: string, to: string) {
  const parts: Array<string | { sq: string; n: 1 | 2 }> = [];
  let rest = line;
  // Replace the first occurrence of `from` then of `to`, keeping the rest intact.
  const pushSplit = (needle: string, n: 1 | 2) => {
    const idx = rest.indexOf(needle);
    if (idx === -1) return;
    parts.push(rest.slice(0, idx));
    parts.push({ sq: needle, n });
    rest = rest.slice(idx + needle.length);
  };
  pushSplit(from, 1);
  pushSplit(to, 2);
  parts.push(rest);
  return (
    <>
      {parts.map((p, i) =>
        typeof p === "string" ? (
          <span key={i}>{p}</span>
        ) : (
          <span key={i} className={`sqref sqref--${p.n}`}>
            <span className="sqref__n" aria-hidden="true">{p.n}</span>
            {p.sq}
          </span>
        ),
      )}
    </>
  );
}
