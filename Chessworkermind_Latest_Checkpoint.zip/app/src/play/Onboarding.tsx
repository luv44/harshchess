import { useState } from "react";
import type { GameMode } from "../chess/session";

/**
 * First 30 seconds.
 * Two taps maximum before a beginner is looking at a board they can move.
 * No chess words, no settings dashboard, no jargon.
 */

export type OnboardingResult = {
  beginner: boolean;
  mode: GameMode;
  humanSide: "w" | "b";
};

export default function Onboarding({
  onDone,
  onSkip,
}: {
  onDone: (r: OnboardingResult) => void;
  onSkip: () => void;
}) {
  const [step, setStep] = useState<1 | 2>(1);
  const [beginner, setBeginner] = useState(true);

  return (
    <div className="sheet-backdrop" role="dialog" aria-modal="true" aria-label="Welcome to Chessworkermind">
      <div className="sheet ob">
        <div className="sheet__grab" aria-hidden="true" />
        {step === 1 ? (
          <>
            <div className="ob__hero">
              <div className="ob__logo" aria-hidden="true">♞</div>
              <h2>Welcome to Chessworkermind</h2>
              <p>Learn how to think, not just what move to play.</p>
            </div>
            <div className="ob__choices">
              <button
                className="choice choice--primary"
                onClick={() => {
                  setBeginner(true);
                  setStep(2);
                }}
              >
                <span className="choice__icon" aria-hidden="true">🌱</span>
                <span className="choice__text">
                  <span className="choice__t">I am new to chess</span>
                  <span className="choice__d">Start from zero. The coach explains every move in plain words.</span>
                </span>
              </button>
              <button
                className="choice"
                onClick={() => {
                  setBeginner(false);
                  setStep(2);
                }}
              >
                <span className="choice__icon" aria-hidden="true">⚡</span>
                <span className="choice__text">
                  <span className="choice__t">Skip — I know the rules</span>
                  <span className="choice__d">Go straight to the board with shorter coaching.</span>
                </span>
              </button>
            </div>
            <button className="btn btn--ghost btn--sm" style={{ marginTop: 14 }} onClick={onSkip}>
              Just show me the board
            </button>
          </>
        ) : (
          <>
            <div className="ob__hero">
              <div className="ob__logo" aria-hidden="true">♟</div>
              <h2>How do you want to play?</h2>
              <p>You can change this at any time.</p>
            </div>
            <div className="ob__choices">
              <button
                className="choice choice--primary"
                onClick={() => onDone({ beginner, mode: "vsComputer", humanSide: "w" })}
              >
                <span className="choice__icon" aria-hidden="true">🤖</span>
                <span className="choice__text">
                  <span className="choice__t">Play with the computer</span>
                  <span className="choice__d">
                    You are White and move first. The computer answers with one move and waits for you.
                  </span>
                </span>
              </button>
              <button className="choice" onClick={() => onDone({ beginner, mode: "solo", humanSide: "w" })}>
                <span className="choice__icon" aria-hidden="true">👥</span>
                <span className="choice__text">
                  <span className="choice__t">Two players on this phone</span>
                  <span className="choice__d">Take turns with a friend. The computer never moves.</span>
                </span>
              </button>
              <button className="choice" onClick={() => onDone({ beginner, mode: "watch", humanSide: "w" })}>
                <span className="choice__icon" aria-hidden="true">🎬</span>
                <span className="choice__text">
                  <span className="choice__t">Watch computer vs computer</span>
                  <span className="choice__d">
                    A demo game. This is the only mode where the computer plays both colours.
                  </span>
                </span>
              </button>
            </div>
            <button className="btn btn--ghost btn--sm" style={{ marginTop: 14 }} onClick={() => setStep(1)}>
              ← Back
            </button>
          </>
        )}
      </div>
    </div>
  );
}
