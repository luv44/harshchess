import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Square } from "chess.js";
import Board, { type BoardHighlights } from "../chess/Board";
import { useChessGame } from "../chess/useChessGame";
import { useComputerOpponent } from "../chess/useComputerOpponent";
import { useDifficulty } from "../learn/difficulty";
import DifficultyPanel from "../learn/DifficultyPanel";
import { useCoach } from "../coach/useCoach";
import { renderCoachCard, pieceWord, type WordingLevel } from "../coach/coachText";
import { pieceRole } from "../coach/pieceHelp";
import CoachCardView from "./CoachCardView";
import { useEngine } from "../engine/useEngine";
import { useStockfishSetting } from "../engine/stockfishSetting";
import type { GameMode } from "../chess/session";
import { getLanguage } from "../i18n/languages";

type Props = {
  game: ReturnType<typeof useChessGame>;
  tag: string;
  wording: WordingLevel;
  beginner: boolean;
  onOpenLearn: () => void;
};

const PIECE_HINT_KEY = "chessworkermind:pieceHints:v1";

const PIECE_GLYPH: Record<"w" | "b", Record<string, string>> = {
  w: { p: "♙", n: "♘", b: "♗", r: "♖", q: "♕", k: "♔" },
  b: { p: "♟", n: "♞", b: "♝", r: "♜", q: "♛", k: "♚" },
};

const MODE_LABEL: Record<GameMode, string> = {
  solo: "Two players",
  vsComputer: "vs Computer",
  watch: "Watch demo",
};

export default function PlayScreen({ game, tag, wording, beginner, onOpenLearn }: Props) {
  const coach = useCoach();
  const engine = useEngine();

  const [focusMode, setFocusMode] = useState(false);
  const [showSuggestion, setShowSuggestion] = useState(false);
  const [promoOpen, setPromoOpen] = useState(false);
  const [difficulty] = useDifficulty();
  const [useStockfish, setUseStockfish] = useStockfishSetting();
  const [inspect, setInspect] = useState<{ square: Square; type: string; color: "w" | "b" } | null>(null);
  // The piece explanation used to be a pop-up that blocked the board on every
  // single tap. It is now a quiet line under the board, and it can be switched
  // off for good — the choice is remembered on this device.
  const [pieceHints, setPieceHints] = useState<boolean>(() => {
    try {
      return localStorage.getItem(PIECE_HINT_KEY) !== "0";
    } catch {
      return true;
    }
  });
  const stopPieceHints = useCallback(() => {
    setPieceHints(false);
    setInspect(null);
    try {
      localStorage.setItem(PIECE_HINT_KEY, "0");
    } catch {
      /* ignore */
    }
  }, []);
  const [setupOpen, setSetupOpen] = useState(false);
  const [reported, setReported] = useState(false);
  const [firstMoveDone, setFirstMoveDone] = useState(() => game.historySan.length > 0);

  const statusKind = game.status.kind === "active" ? "active" : game.status.kind;
  const isHumanTurn =
    game.mode === "watch" ? false : game.mode === "solo" ? true : game.turn === game.humanSide;

  /* ---------------- computer opponent: one legal reply, own colour only ---- */

  const engineBest =
    useStockfish && engine.analysis && engine.analysis.fen === game.fen ? engine.analysis.bestUci : null;

  const opponent = useComputerOpponent({
    fen: game.fen,
    turn: game.turn,
    session: game.session,
    generation: game.generation,
    statusKind: statusKind as "active",
    paused: promoOpen,
    level: "gentle",
    strength: difficulty.computer,
    applyMove: game.tryMove,
    engineBestUci: engineBest,
  });

  /* ---------------- optional Stockfish (off by default, saves battery) ---- */

  useEffect(() => {
    if (!useStockfish || game.status.kind !== "active" || !isHumanTurn) { engine.stop(); return; }
    engine.analyze(game.fen);
    return () => engine.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [useStockfish, game.fen, game.generation, game.status.kind, isHumanTurn]);

  /* ---------------- coach card, one per turn, frozen to this position ----- */

  const cardSide = game.mode === "solo" || game.mode === "watch" ? game.turn : game.humanSide;

  useEffect(() => {
    if (focusMode) {
      coach.clear();
      return;
    }
    if (game.status.kind !== "active") {
      // still build a card so the end of the game gets explained
      coach.request({ fen: game.fen, humanSide: cardSide, lastMove: game.lastRawMove });
      return;
    }
    if (!isHumanTurn) return; // one card per computer turn — wait for their move
    coach.request({
      fen: game.fen,
      humanSide: cardSide,
      lastMove: game.lastRawMove,
      engineCandidates:
        useStockfish && engine.analysis?.fen === game.fen
          ? engine.analysis.candidates.map((c) => ({ uci: c.uci, scoreCp: c.scoreCp, scoreMate: c.scoreMate }))
          : undefined,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game.fen, game.generation, focusMode, isHumanTurn, cardSide, useStockfish]);

  // A new position always hides the previous "show me" highlight.
  useEffect(() => {
    setShowSuggestion(false);
    setReported(false);
    setInspect(null);
  }, [game.fen]);

  useEffect(() => {
    if (game.historySan.length > 0) setFirstMoveDone(true);
  }, [game.historySan.length]);

  const langName = getLanguage(tag)?.nameOwn ?? tag;
  const text = useMemo(
    () => (coach.card?.fen === game.fen && isHumanTurn ? renderCoachCard(coach.card, tag, wording, langName) : null),
    [coach.card, game.fen, isHumanTurn, tag, wording, langName],
  );

  /* ---------------- board highlights -------------------------------------- */

  const highlights: BoardHighlights = useMemo(() => {
    if (focusMode || !coach.card || coach.card.fen !== game.fen || !isHumanTurn) return {};
    const c = coach.card;
    const h: BoardHighlights = {};
    if (showSuggestion && c.suggestion) {
      h.suggestFrom = c.suggestion.from;
      h.suggestTo = c.suggestion.to;
    }
    if (c.threat.present && c.threat.threat) {
      h.threatFrom = c.threat.threat.from;
      h.threatTo = c.threat.threat.to;
    }
    if (c.opponentMove) h.path = c.opponentMove.path;
    if (showSuggestion && c.reason) h.focus = c.reason.squares.slice(0, 4);
    return h;
  }, [coach.card, game.fen, isHumanTurn, showSuggestion, focusMode]);

  const moveForMe = useCallback(() => {
    const s = coach.card?.suggestion;
    if (!s) return;
    if (coach.card?.fen !== game.fen) return; // never play a move from a stale card
    game.tryHumanMove(s.from as Square, s.to as Square, s.promotion as "q" | undefined);
  }, [coach.card, game]);

  const onPieceInspect = useCallback(
    (info: { square: Square; type: string; color: "w" | "b" } | null) => {
      if (focusMode || !pieceHints || !info) {
        setInspect(null);
        return;
      }
      setInspect({ square: info.square, type: info.type, color: info.color });
    },
    [focusMode, pieceHints],
  );

  /* ---------------- turn strip -------------------------------------------- */

  const turnStrip = (() => {
    if (game.status.kind === "checkmate") {
      const youWon = game.status.winner === game.humanSide && game.mode === "vsComputer";
      return {
        cls: "turnstrip--over",
        dot: game.status.winner,
        title: game.mode === "vsComputer" ? (youWon ? "You won!" : "The computer won") : `${game.status.winner === "w" ? "White" : "Black"} wins`,
        sub: "Checkmate — the king cannot escape.",
      };
    }
    if (game.status.kind === "stalemate") {
      return { cls: "turnstrip--over", dot: game.turn, title: "Draw — stalemate", sub: "No legal moves, but the king is not in check." };
    }
    if (game.status.kind === "draw") {
      return { cls: "turnstrip--over", dot: game.turn, title: "Draw", sub: "Nobody can win this position." };
    }
    if (game.mode === "watch") {
      return { cls: "turnstrip--wait", dot: game.turn, title: "Watching the computer", sub: `${game.turn === "w" ? "White" : "Black"} is thinking. You are not playing in this mode.` };
    }
    if (isHumanTurn) {
      const you = game.mode === "solo" ? (game.turn === "w" ? "White" : "Black") : "You";
      return {
        cls: "turnstrip--you",
        dot: game.turn,
        title: game.mode === "solo" ? `${you} to move` : "Your turn",
        sub: game.status.kind === "active" && game.status.inCheck
          ? "You are in check — you must answer it."
          : `You play ${game.humanSide === "w" ? "White" : "Black"}. Tap one of your pieces.`,
      };
    }
    return {
      cls: "turnstrip--wait",
      dot: game.turn,
      title: opponent.thinking ? "Computer is thinking…" : "Computer to move",
      sub: "It will make exactly one move, then wait for you.",
    };
  })();

  const engineLabel = useStockfish
    ? engine.fallbackVisible
      ? "Stockfish failed to load — using the built-in verified search"
      : engine.engineState.kind === "loading"
        ? "Stockfish downloading (~1.7 MB)"
        : engine.engineState.kind === "analyzing"
          ? "Stockfish analysing"
          : engine.engineState.kind === "ready"
            ? "Stockfish ready"
            : "Stockfish idle"
    : "Built-in verified search (no download, low battery)";

  return (
    <div className="playgrid">
      <div className="playgrid__board">
        <div className={`turnstrip ${turnStrip.cls}`} role="status" aria-live="polite">
          <span className={`turnstrip__dot turnstrip__dot--${turnStrip.dot}`} aria-hidden="true" />
          <span className="turnstrip__main">
            <span className="turnstrip__title">{turnStrip.title}</span>
            <span className="turnstrip__sub">{turnStrip.sub}</span>
          </span>
          <span className="turnstrip__end">
            {opponent.thinking && <span className="thinkdots" aria-hidden="true"><i /><i /><i /></span>}
            <button className="btn btn--ghost btn--sm" onClick={() => setSetupOpen(true)} aria-label="Game setup">
              ⚙
            </button>
          </span>
        </div>

        {game.mode !== "solo" && <p className="small muted" aria-live="polite">{opponent.thinking ? `Computer ${difficulty.computer}: loading or searching Stockfish…` : opponent.source === "rules-only" ? "Computer reply: rules-only fallback — Stockfish strength unavailable." : opponent.source === "stockfish" ? "Last computer reply: Stockfish." : `Computer strength ${difficulty.computer} applies on the next computer turn.`}</p>}
        <Board
          fen={game.fen}
          orientation={game.orientation}
          lastMove={game.lastMove}
          getLegalTargets={game.getLegalTargets}
          isPromotionMove={game.isPromotionMove}
          tryMove={game.tryHumanMove}
          canPickUp={game.canPickUp}
          highlights={highlights}
          showLegalTargets={!focusMode}
          onPieceInspect={onPieceInspect}
          onPromotionOpenChange={setPromoOpen}
        />

        <div className="btnrow" style={{ marginTop: 10, justifyContent: "center" }}>
          <button className="btn btn--sm" onClick={game.undo} disabled={!game.canUndo}>↩ Undo</button>
          <button className="btn btn--sm" onClick={game.newGame}>⟳ New game</button>
          <button className="btn btn--sm" onClick={game.flip}>⇅ Flip</button>
          <button
            className={`btn btn--sm ${focusMode ? "btn--primary" : ""}`}
            onClick={() => setFocusMode((f) => !f)}
            aria-pressed={focusMode}
          >
            {focusMode ? "🎯 Focus on" : "🎯 Focus"}
          </button>
        </div>

        {inspect && (
          <div className="piecehint" role="note">
            <span className="piecehint__glyph" aria-hidden="true">{PIECE_GLYPH[inspect.color][inspect.type] ?? "?"}</span>
            <span className="piecehint__text">
              <b>
                {inspect.color === "w" ? "White" : "Black"} {pieceWord(tag, inspect.type)} on {inspect.square}
              </b>
              {pieceRole(tag, inspect.type)} Its squares are lit up on the board.
              <br />
              <button className="piecehint__more" onClick={stopPieceHints}>
                Stop showing these tips
              </button>
            </span>
          </div>
        )}

        {beginner && !firstMoveDone && (
          <div className="card" style={{ marginTop: 10, borderColor: "var(--accent)" }}>
            <strong>Your first lesson: make a move</strong>
            <p className="small" style={{ marginTop: 4 }}>
              The pieces at the bottom are yours. Tap one — the squares it can go to will light up — then tap one of
              those squares. That is a whole turn.
            </p>
            <button className="btn btn--ghost btn--sm" style={{ marginTop: 8 }} onClick={onOpenLearn}>
              Open the full beginner lessons →
            </button>
          </div>
        )}
      </div>

      <div>
        {focusMode ? (
          <div className="card">
            <strong>Focus mode</strong>
            <p className="small muted" style={{ marginTop: 5 }}>
              Coaching, hints and highlights are hidden. Just you and the board. Tap Focus again to bring the coach
              back.
            </p>
          </div>
        ) : (
          <CoachCardView
            card={coach.card}
            text={text}
            status={coach.status}
            waiting={!isHumanTurn}
            showing={showSuggestion}
            engineLabel={engineLabel}
            computeMs={coach.lastMs}
            onShowOnBoard={() => setShowSuggestion(true)}
            onMoveForMe={moveForMe}
            onRefresh={() =>
              coach.request({ fen: game.fen, humanSide: cardSide, lastMove: game.lastRawMove, force: true })
            }
            onReportWrong={() => {
              try {
                const key = "cwm:reports";
                const prev = JSON.parse(localStorage.getItem(key) ?? "[]");
                prev.push({
                  fen: game.fen,
                  suggestion: coach.card?.suggestion?.san ?? null,
                  reason: coach.card?.reason?.key ?? null,
                  engine: engineLabel,
                  language: tag,
                  at: new Date().toISOString(),
                });
                localStorage.setItem(key, JSON.stringify(prev.slice(-50)));
              } catch {
                /* ignore */
              }
              setReported(true);
            }}
          />
        )}

        {reported && (
          <p className="pill pill--ok" style={{ marginTop: 8, whiteSpace: "normal" }}>
            Thanks — this position and its settings were saved on this device so the example can be checked. No
            personal data was included.
          </p>
        )}

        {!coach.workerOk && (
          <p className="pill pill--warn" style={{ marginTop: 8, whiteSpace: "normal" }}>
            Background worker not available in this browser — the coach runs on the main thread and may feel slower.
          </p>
        )}
      </div>

      {/* -------- game setup sheet -------- */}
      {setupOpen && (
        <div className="sheet-backdrop" role="dialog" aria-modal="true" onClick={() => setSetupOpen(false)}>
          <div className="sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet__grab" aria-hidden="true" />
            <h3>Game setup</h3>
            <p className="small">Changing any of these cancels a move the computer was about to make.</p>

            <div style={{ marginTop: 14 }}>
              <div className="csec__label">Who is playing</div>
              <div className="seg" role="group" aria-label="Game mode">
                {(["vsComputer", "solo", "watch"] as GameMode[]).map((m) => (
                  <button
                    key={m}
                    className="seg__btn"
                    aria-pressed={game.mode === m}
                    onClick={() => game.setMode(m)}
                  >
                    {MODE_LABEL[m]}
                  </button>
                ))}
              </div>
              {game.mode === "watch" && (
                <p className="pill pill--warn" style={{ marginTop: 8, whiteSpace: "normal" }}>
                  Watch mode is the only place the computer plays both colours.
                </p>
              )}
            </div>

            {game.mode === "vsComputer" && (
              <>
                <div style={{ marginTop: 16 }}>
                  <div className="csec__label">Your colour</div>
                  <div className="seg" role="group" aria-label="Your colour">
                    <button className="seg__btn" aria-pressed={game.humanSide === "w"} onClick={() => game.setHumanSide("w")}>
                      White (moves first)
                    </button>
                    <button className="seg__btn" aria-pressed={game.humanSide === "b"} onClick={() => game.setHumanSide("b")}>
                      Black
                    </button>
                  </div>
                </div>

                <DifficultyPanel />
              </>
            )}

            <div style={{ marginTop: 16 }}>
              <div className="csec__label">Engine</div>
              <label className="choice" style={{ cursor: "pointer" }}>
                <input
                  type="checkbox"
                  checked={useStockfish}
                  onChange={(e) => setUseStockfish(e.target.checked)}
                  style={{ width: 20, height: 20 }}
                />
                <span className="choice__text">
                  <span className="choice__t">Use Stockfish for a deeper check</span>
                  <span className="choice__d">
                    Downloads about 1.7 MB the first time and uses more battery. The coach works fully without it —
                    every suggestion is verified either way.
                  </span>
                </span>
              </label>
              <p className="small muted" style={{ marginTop: 6 }}>{engineLabel}</p>
            </div>

            <div className="btnrow" style={{ marginTop: 18 }}>
              <button className="btn btn--primary btn--big" onClick={() => setSetupOpen(false)}>Done</button>
            </div>
            <button
              className="btn btn--ghost btn--sm"
              style={{ marginTop: 10, width: "100%" }}
              onClick={() => {
                game.startGame(game.mode, game.humanSide);
                setSetupOpen(false);
              }}
            >
              Start a fresh game with these settings
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
