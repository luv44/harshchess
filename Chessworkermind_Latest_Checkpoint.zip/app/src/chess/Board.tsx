import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chess, type Square } from "chess.js";

/**
 * The board.
 *
 * Accessibility / clarity rules honoured here:
 *  - Selected square, last move, suggested FROM (badge "1"), suggested TO
 *    (badge "2"), legal targets (dot / ring) and a real threat (⚠ + stripes)
 *    are each distinguishable WITHOUT relying on colour.
 *  - Every square is a real button in a grid, reachable by keyboard, with a
 *    spoken label ("e2, White pawn, legal move").
 *  - Touch, drag and click all work; targets stay large on a phone.
 */

export type BoardHighlights = {
  suggestFrom?: string | null;
  suggestTo?: string | null;
  threatFrom?: string | null;
  threatTo?: string | null;
  /** Squares on the path of the move just played (sliding pieces). */
  path?: string[];
  /** Squares the learner should look at (e.g. squares a move protects). */
  focus?: string[];
};

type Props = {
  fen: string;
  orientation: "w" | "b";
  lastMove: { from: string; to: string } | null;
  getLegalTargets: (from: Square) => Square[];
  isPromotionMove: (from: Square, to: Square) => boolean;
  tryMove: (from: Square, to: Square, promotion?: "q" | "r" | "b" | "n") => boolean;
  canPickUp: (color: "w" | "b") => boolean;
  highlights?: BoardHighlights;
  showLegalTargets?: boolean;
  /** Called when a piece is tapped, so the coach can explain how it moves. */
  /** Called with the tapped piece, or null when nothing is selected any more. */
  onPieceInspect?: (info: { square: Square; type: string; color: "w" | "b"; targets: Square[] } | null) => void;
  onPromotionOpenChange?: (open: boolean) => void;
  disabled?: boolean;
  pieceStyle?: "classic" | "outline";
};

const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"] as const;
const RANKS = ["8", "7", "6", "5", "4", "3", "2", "1"] as const;

/** Solid glyphs for BOTH colours; colour + outline distinguishes the side.
 *  This renders consistently across Android/iOS fonts, unlike ♔ vs ♚ pairs. */
const GLYPH: Record<string, string> = { k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟" };

const PIECE_EN: Record<string, string> = {
  p: "pawn",
  n: "knight",
  b: "bishop",
  r: "rook",
  q: "queen",
  k: "king",
};

const PROMOTION_CHOICES: Array<{ p: "q" | "r" | "b" | "n"; label: string }> = [
  { p: "q", label: "Queen" },
  { p: "r", label: "Rook" },
  { p: "b", label: "Bishop" },
  { p: "n", label: "Knight" },
];

export default function Board({
  fen,
  orientation,
  lastMove,
  getLegalTargets,
  isPromotionMove,
  tryMove,
  canPickUp,
  highlights,
  onPieceInspect,
  onPromotionOpenChange,
  disabled,
  pieceStyle = "classic",
  showLegalTargets = true,
}: Props) {
  const chess = useMemo(() => {
    try {
      return new Chess(fen);
    } catch {
      return new Chess();
    }
  }, [fen]);

  const turn = chess.turn();
  const inCheck = chess.isCheck();

  const displayRanks = orientation === "w" ? RANKS : [...RANKS].reverse();
  const displayFiles = orientation === "w" ? FILES : [...FILES].reverse();

  /**
   * Keyboard cursor, as a position in what the learner SEES (row, column),
   * so the arrow keys always match the picture even when the board is
   * flipped. The grid is a single tab stop with a roving tabindex, which is
   * how a grid is meant to behave — 64 separate tab stops is not usable.
   */
  const [cursor, setCursor] = useState<{ r: number; c: number }>({ r: 7, c: 4 });
  const gridRef = useRef<HTMLDivElement | null>(null);

  const [selected, setSelected] = useState<Square | null>(null);
  const [legal, setLegal] = useState<Square[]>([]);
  const [pendingPromo, setPendingPromo] = useState<{ from: Square; to: Square } | null>(null);
  const [shake, setShake] = useState<Square | null>(null);
  const dragFromRef = useRef<Square | null>(null);
  const [dragOver, setDragOver] = useState<Square | null>(null);

  useEffect(() => {
    onPromotionOpenChange?.(!!pendingPromo);
  }, [pendingPromo, onPromotionOpenChange]);

  // A new position clears any half-finished interaction.
  useEffect(() => {
    setSelected(null);
    setLegal([]);
    setPendingPromo(null);
    onPieceInspect?.(null);
    // only when the position itself changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fen]);

  const kingSquare = useMemo(() => {
    if (!inCheck) return null;
    for (const row of chess.board()) {
      for (const sq of row) {
        if (sq && sq.type === "k" && sq.color === turn) return sq.square;
      }
    }
    return null;
  }, [chess, inCheck, turn]);

  const clearSelection = useCallback(() => {
    setSelected(null);
    setLegal([]);
    onPieceInspect?.(null);
  }, [onPieceInspect]);

  const selectSquare = useCallback(
    (sq: Square) => {
      const piece = chess.get(sq);
      if (!piece) return false;
      const targets = getLegalTargets(sq);
      // Tapping any piece explains it, even when it is not your turn.
      onPieceInspect?.({ square: sq, type: piece.type, color: piece.color as "w" | "b", targets });
      if (piece.color !== turn || !canPickUp(piece.color as "w" | "b")) {
        setSelected(sq);
        setLegal([]); // show the piece, but no move dots — it is not yours to move
        return false;
      }
      setSelected(sq);
      setLegal(targets);
      return true;
    },
    [chess, getLegalTargets, turn, canPickUp, onPieceInspect],
  );

  const attemptMove = useCallback(
    (from: Square, to: Square) => {
      if (isPromotionMove(from, to)) {
        setPendingPromo({ from, to });
        return;
      }
      const ok = tryMove(from, to);
      if (ok) clearSelection();
      else {
        setShake(to);
        window.setTimeout(() => setShake(null), 320);
      }
    },
    [isPromotionMove, tryMove, clearSelection],
  );

  const onSquareActivate = useCallback(
    (sq: Square) => {
      if (pendingPromo || disabled) return;
      if (selected) {
        if (sq === selected) {
          clearSelection();
          return;
        }
        if (legal.includes(sq)) {
          attemptMove(selected, sq);
          return;
        }
      }
      const piece = chess.get(sq);
      if (piece) {
        selectSquare(sq);
        return;
      }
      clearSelection();
    },
    [pendingPromo, disabled, selected, legal, chess, attemptMove, clearSelection, selectSquare],
  );

  const onDragStart = useCallback(
    (sq: Square, e: React.DragEvent) => {
      const piece = chess.get(sq);
      if (!piece || piece.color !== turn || !canPickUp(piece.color as "w" | "b") || disabled) {
        e.preventDefault();
        return;
      }
      dragFromRef.current = sq;
      setSelected(sq);
      setLegal(getLegalTargets(sq));
      try {
        e.dataTransfer.setData("text/plain", sq);
        e.dataTransfer.effectAllowed = "move";
      } catch {
        /* ignore */
      }
    },
    [chess, turn, canPickUp, disabled, getLegalTargets],
  );

  const onDrop = useCallback(
    (sq: Square, e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(null);
      const from = dragFromRef.current;
      dragFromRef.current = null;
      if (!from) return;
      if (from === sq) return;
      attemptMove(from, sq);
    },
    [attemptMove],
  );

  /** Move the keyboard cursor and take the focus with it. */
  const moveCursor = useCallback((dr: number, dc: number, absolute?: { r: number; c: number }) => {
    setCursor((cur) => {
      const next = absolute ?? {
        r: Math.min(7, Math.max(0, cur.r + dr)),
        c: Math.min(7, Math.max(0, cur.c + dc)),
      };
      const el = gridRef.current?.querySelector<HTMLButtonElement>(
        `[data-r="${next.r}"][data-c="${next.c}"]`,
      );
      el?.focus();
      return next;
    });
  }, []);

  const onGridKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (pendingPromo) return;
      switch (e.key) {
        case "ArrowUp":
          e.preventDefault();
          moveCursor(-1, 0);
          break;
        case "ArrowDown":
          e.preventDefault();
          moveCursor(1, 0);
          break;
        case "ArrowLeft":
          e.preventDefault();
          moveCursor(0, -1);
          break;
        case "ArrowRight":
          e.preventDefault();
          moveCursor(0, 1);
          break;
        case "Home":
          e.preventDefault();
          moveCursor(0, 0, { r: cursor.r, c: 0 });
          break;
        case "End":
          e.preventDefault();
          moveCursor(0, 0, { r: cursor.r, c: 7 });
          break;
        case "PageUp":
          e.preventDefault();
          moveCursor(0, 0, { r: 0, c: cursor.c });
          break;
        case "PageDown":
          e.preventDefault();
          moveCursor(0, 0, { r: 7, c: cursor.c });
          break;
        case "Escape":
          if (selected) {
            e.preventDefault();
            clearSelection();
          }
          break;
        default:
          break;
      }
    },
    [cursor.r, cursor.c, moveCursor, pendingPromo, selected, clearSelection],
  );

  const hl = highlights ?? {};

  return (
    <div className="boardwrap">
      <p id="board-keys" className="visually-hidden">
        Use the arrow keys to move around the board. Press Enter or Space to pick up a piece, then move to a
        square and press Enter again to play the move. Press Escape to put the piece back.
      </p>
      <div className="boardframe">
        <div className="boardframe__ranks" aria-hidden="true">
          {displayRanks.map((r) => (
            <span key={r}>{r}</span>
          ))}
        </div>
        <div
        ref={gridRef}
        className={`board board--${pieceStyle}`}
        role="grid"
        aria-label="Chess board"
        aria-rowcount={8}
        aria-colcount={8}
        aria-describedby="board-keys"
        onKeyDown={onGridKeyDown}
      >
        {displayRanks.map((rank, rIdx) => (
          <div className="board__row" role="row" key={rank} aria-rowindex={rIdx + 1}>
            {displayFiles.map((file, fIdx) => {
              const sq = `${file}${rank}` as Square;
              const piece = chess.get(sq);
              const dark = (FILES.indexOf(file) + Number(rank)) % 2 === 0;
              const isSelected = selected === sq;
              const isLegalTarget = showLegalTargets && legal.includes(sq);
              const isLast = lastMove && (lastMove.from === sq || lastMove.to === sq);
              const isSuggestFrom = hl.suggestFrom === sq;
              const isSuggestTo = hl.suggestTo === sq;
              const isThreat = hl.threatFrom === sq || hl.threatTo === sq;
              const isPath = hl.path?.includes(sq);
              const isFocus = hl.focus?.includes(sq);
              const isCheckSq = kingSquare === sq;
              const isCapture = isLegalTarget && !!piece;

              const classes = [
                "sq",
                dark ? "sq--dark" : "sq--light",
                isSelected ? "sq--selected" : "",
                isLast ? "sq--last" : "",
                isSuggestFrom ? "sq--sfrom" : "",
                isSuggestTo ? "sq--sto" : "",
                isThreat ? "sq--threat" : "",
                isPath ? "sq--path" : "",
                isFocus ? "sq--focus" : "",
                isCheckSq ? "sq--check" : "",
                dragOver === sq ? "sq--dragover" : "",
                shake === sq ? "sq--shake" : "",
              ]
                .filter(Boolean)
                .join(" ");

              const label = [
                sq,
                piece ? `${piece.color === "w" ? "White" : "Black"} ${PIECE_EN[piece.type]}` : "empty",
                isLegalTarget ? (isCapture ? "capture available" : "legal move") : "",
                isSuggestFrom ? "suggested move, step 1" : "",
                isSuggestTo ? "suggested move, step 2" : "",
                isThreat ? "warning, threatened square" : "",
                isCheckSq ? "your king is in check" : "",
              ]
                .filter(Boolean)
                .join(", ");

              return (
                <button
                  type="button"
                  role="gridcell"
                  aria-colindex={fIdx + 1}
                  key={sq}
                  className={classes}
                  aria-label={label}
                  aria-selected={isSelected}
                  data-r={rIdx}
                  data-c={fIdx}
                  tabIndex={cursor.r === rIdx && cursor.c === fIdx ? 0 : -1}
                  onFocus={() => setCursor({ r: rIdx, c: fIdx })}
                  onClick={() => onSquareActivate(sq)}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragOver(sq);
                  }}
                  onDragLeave={() => setDragOver((d) => (d === sq ? null : d))}
                  onDrop={(e) => onDrop(sq, e)}
                  disabled={!!pendingPromo}
                >

                  {isSuggestFrom && <span className="sq__badge sq__badge--from" aria-hidden="true">1</span>}
                  {isSuggestTo && <span className="sq__badge sq__badge--to" aria-hidden="true">2</span>}
                  {isThreat && !isSuggestFrom && !isSuggestTo && (
                    <span className="sq__badge sq__badge--warn" aria-hidden="true">!</span>
                  )}

                  {piece && (
                    <span
                      className={`piece piece--${piece.color}`}
                      draggable={!disabled && piece.color === turn && canPickUp(piece.color as "w" | "b")}
                      onDragStart={(e) => onDragStart(sq, e)}
                      aria-hidden="true"
                    >
                      {GLYPH[piece.type]}
                    </span>
                  )}

                  {isLegalTarget && !piece && <span className="sq__dot" aria-hidden="true" />}
                  {isLegalTarget && piece && <span className="sq__ring" aria-hidden="true" />}
                </button>
              );
            })}
          </div>
        ))}
        </div>
        <span className="boardframe__corner" aria-hidden="true" />
        <div className="boardframe__files" aria-hidden="true">
          {displayFiles.map((f) => (
            <span key={f}>{f}</span>
          ))}
        </div>
      </div>

      {pendingPromo && (
        <div className="promo" role="dialog" aria-modal="true" aria-label="Choose a promotion piece">
          <div className="promo__card">
            <strong>Your pawn reached the end!</strong>
            <p>Choose what it becomes. Most players choose the Queen.</p>
            <div className="promo__row">
              {PROMOTION_CHOICES.map((c) => (
                <button
                  key={c.p}
                  className="promo__btn"
                  onClick={() => {
                    const { from, to } = pendingPromo;
                    setPendingPromo(null);
                    const ok = tryMove(from, to, c.p);
                    if (ok) clearSelection();
                  }}
                >
                  <span className="promo__glyph">{GLYPH[c.p]}</span>
                  <span>{c.label}</span>
                </button>
              ))}
            </div>
            <button className="btn btn--ghost" onClick={() => setPendingPromo(null)}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export { PIECE_EN };
