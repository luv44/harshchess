/**
 * "Use Stockfish" is one choice for the whole app, remembered on the device.
 *
 * It used to be local state inside the free-game screen, which meant the
 * training screen could never use the engine and the two screens could
 * disagree about whether it was on. Now there is one answer.
 *
 * It is OFF by default on purpose: the engine is ~1.7 MB and costs battery,
 * and every suggestion is verified on the real board either way.
 */
import { useCallback, useEffect, useState } from "react";

export const STOCKFISH_KEY = "cwm:stockfish";

export function loadStockfishOn(): boolean {
  try {
    return localStorage.getItem(STOCKFISH_KEY) === "1";
  } catch {
    return false;
  }
}

function saveStockfishOn(on: boolean): void {
  try {
    localStorage.setItem(STOCKFISH_KEY, on ? "1" : "0");
  } catch {
    /* a private-mode browser must not crash the app */
  }
}

/** Everything that listens, so turning it on in Settings updates every screen. */
const listeners = new Set<(on: boolean) => void>();

export function useStockfishSetting(): [boolean, (on: boolean) => void] {
  const [on, setOn] = useState<boolean>(loadStockfishOn);

  useEffect(() => {
    const fn = (next: boolean) => setOn(next);
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  }, []);

  const set = useCallback((next: boolean) => {
    saveStockfishOn(next);
    for (const fn of listeners) fn(next);
  }, []);

  return [on, set];
}

/**
 * How this position was analysed, for the coach's cache key.
 *
 * A card built WITHOUT the engine must never be handed back when the engine
 * has since produced candidates, and the other way round. Before this, the
 * cache key said "local" for every card, so the engine's opinion could be
 * silently thrown away on a revisit.
 */
export function engineCacheTag(
  candidates?: Array<{ uci: string }> | null,
): string {
  if (!candidates || candidates.length === 0) return "local";
  return `engine:${candidates.map((c) => c.uci).join(",")}`;
}
