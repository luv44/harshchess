/** Optional real-WASM browser smoke, against a running Vite DEV server.
 * Run from app/: node src/engine/__tests__/browser-smoke.mjs
 * Uses an existing local browser, writes temporary browser data only on D:.
 * No mocks and no network other than the local dev server. */
import { chromium } from "playwright";
import assert from "node:assert/strict";
import { Chess } from "chess.js";

const root = process.cwd();
const browser = await chromium.launch({
  executablePath: process.env.CHROME_PATH ?? `${root}/.cache/browser/chrome-headless-shell-linux64/chrome-headless-shell`,
  headless: true,
  args: ["--no-sandbox"],
  env: { ...process.env, TMPDIR: `${root}/.cache/tmp`,
    LD_LIBRARY_PATH: `${root}/.cache/libs-flat:${root}/.cache/libs/usr/lib/x86_64-linux-gnu:${process.env.LD_LIBRARY_PATH ?? ""}` },
});
try {
  const page = await browser.newPage();
  // A tiny same-origin document isolates the engine from app fonts/onboarding/HMR.
  await page.route("**/__engine-smoke.html", (route) => route.fulfill({ contentType: "text/html", body: "<!doctype html><title>Engine smoke</title>" }));
  await page.goto(new URL("__engine-smoke.html", process.env.SMOKE_URL ?? "http://127.0.0.1:5173/").href);
  const fen = "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1";
  const result = await page.evaluate(async (fen) => {
    const { createEngineWorker } = await import("/src/engine/createEngineWorker.ts");
    const worker = createEngineWorker();
    return new Promise((resolve, reject) => {
      const messages = [];
      const deadline = setTimeout(() => finish(new Error("real browser Stockfish timeout")), 25_000);
      function finish(error, value) {
        clearTimeout(deadline);
        worker.terminate();
        if (error) reject(error); else resolve(value);
      }
      worker.onerror = (event) => finish(new Error(event.message));
      worker.onmessage = ({ data }) => {
        messages.push(data);
        if (data.type === "error") finish(new Error(data.message));
        if (data.type === "bestmove") finish(null, { bestmove: data,
          infoCount: messages.filter((m) => m.type === "info").length,
          ready: messages.some((m) => m.type === "ready"),
        });
      };
      worker.postMessage({ type: "go", positionId: 101, fen, purpose: "opponent", strength: 5 });
    });
  }, fen);
  assert.equal(result.ready, true);
  assert.equal(result.bestmove.positionId, 101);
  assert.equal(result.bestmove.fen, fen);
  assert.ok(new Chess(fen).moves({ verbose: true }).some((m) => `${m.from}${m.to}${m.promotion ?? ""}` === result.bestmove.uci));
  console.log(JSON.stringify(result, null, 2));
} finally {
  await browser.close();
}
