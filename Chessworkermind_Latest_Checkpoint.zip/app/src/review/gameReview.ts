/**
 * Review your own game.
 *
 * Reads a finished game, replays it on a real board, and looks for the
 * moments where the learner played something that can be PROVED to lose
 * material or allow mate — using the same reviewMove engine as the training
 * screen, so the standard of evidence is identical.
 *
 * What this file will not do:
 *  - guess at "inaccuracies" it cannot demonstrate
 *  - invent an evaluation, a plan or an opponent's intention
 *  - tell the learner the game was good or bad overall
 *
 * If it finds nothing, it says it found nothing — which is not the same as
 * saying the game was perfect, and the wording makes that difference clear.
 */

import { Chess, type Square } from "chess.js";
import { isSerious, reviewMove, SERIOUS_LOSS, type MoveReview } from "../coach/reviewMove";
import type { Color } from "../chess/session";

export type Ply = {
  /** 0-based index in the game */
  index: number;
  /** 1-based move number as a human writes it */
  moveNumber: number;
  color: Color;
  /** p n b r q k — so the move can be said in words, not notation */
  pieceType: string;
  from: Square;
  to: Square;
  san: string;
  promotion?: string;
  captured?: string;
  /** position BEFORE this move */
  fenBefore: string;
  /** position AFTER this move */
  fenAfter: string;
};

export type ParsedGame =
  | { ok: true; plies: Ply[]; headers: Record<string, string>; result: string }
  | { ok: false; error: string };

/** How many plies we are willing to read. A pasted book is not a game. */
export const MAX_PLIES = 600;

/**
 * Read a game from PGN, or from a plain list of moves like "e4 e5 Nf3".
 * Every error message is written for a person, not a parser.
 */
export function parseGame(text: string): ParsedGame {
  const raw = (text ?? "").trim();
  if (!raw) return { ok: false, error: "There is nothing to read yet. Paste a game first." };

  const chess = new Chess();
  let loaded = false;
  try {
    chess.loadPgn(raw);
    loaded = true;
  } catch {
    loaded = false;
  }

  if (!loaded) {
    // Second chance: a bare move list, which is what most people paste.
    const cleaned = raw
      .replace(/\{[^}]*\}/g, " ")
      .replace(/\([^)]*\)/g, " ")
      .replace(/\$\d+/g, " ")
      .replace(/\b\d+\.(\.\.)?/g, " ")
      .replace(/\b(1-0|0-1|1\/2-1\/2|\*)\b/g, " ")
      .trim();
    const tokens = cleaned.split(/\s+/).filter(Boolean);
    if (tokens.length === 0) {
      return { ok: false, error: "That does not look like a game. Paste the moves, for example: e4 e5 Nf3 Nc6" };
    }
    const probe = new Chess();
    for (const [i, token] of tokens.entries()) {
      try {
        probe.move(token);
      } catch {
        return {
          ok: false,
          error:
            i === 0
              ? `"${token}" is not a move White could play from the start. Check the beginning of the game.`
              : `The game reads fine up to move ${Math.ceil(i / 2)}, then "${token}" cannot be played on the board. Check that move.`,
        };
      }
      if (probe.history().length >= MAX_PLIES) break;
    }
    return finish(probe, {}, "*");
  }

  const headers = (chess.getHeaders?.() ?? {}) as Record<string, string>;
  return finish(chess, headers, headers.Result ?? "*");
}

function finish(chess: Chess, headers: Record<string, string>, result: string): ParsedGame {
  const verbose = chess.history({ verbose: true });
  if (verbose.length === 0) {
    return { ok: false, error: "That game has no moves in it." };
  }

  const plies: Ply[] = verbose.slice(0, MAX_PLIES).map((m, i) => ({
    index: i,
    moveNumber: Math.floor(i / 2) + 1,
    color: m.color as Color,
    pieceType: m.piece,
    from: m.from as Square,
    to: m.to as Square,
    san: m.san,
    promotion: m.promotion,
    captured: m.captured,
    fenBefore: m.before,
    fenAfter: m.after,
  }));

  return { ok: true, plies, headers, result };
}

/** Which side the learner was. Guessed from the headers, never assumed silently. */
export function guessLearnerSide(headers: Record<string, string>): Color | null {
  const white = (headers.White ?? "").toLowerCase();
  const black = (headers.Black ?? "").toLowerCase();
  const me = /you|me|player|human/;
  const bot = /stockfish|computer|engine|bot|ai|chessworkermind/;
  if (me.test(white) || bot.test(black)) return "w";
  if (me.test(black) || bot.test(white)) return "b";
  return null;
}

export type TurningPoint = {
  ply: Ply;
  review: MoveReview;
  /** centipawns the move gave away, versus the best tested alternative */
  cost: number;
};

/**
 * Review ONE of the learner's moves. Kept separate so the UI can do this a
 * few plies at a time and stay responsive on a phone.
 */
export function reviewPly(ply: Ply): MoveReview {
  return reviewMove({ fen: ply.fenBefore, from: ply.from, to: ply.to, promotion: ply.promotion });
}

/** The plies belonging to the learner — the only ones we comment on. */
export function learnerPlies(plies: Ply[], side: Color): Ply[] {
  return plies.filter((p) => p.color === side);
}

export type ScanState = {
  /** learner plies still to look at */
  queue: Ply[];
  done: number;
  total: number;
  found: TurningPoint[];
};

export function startScan(plies: Ply[], side: Color): ScanState {
  const queue = learnerPlies(plies, side);
  return { queue: [...queue], done: 0, total: queue.length, found: [] };
}

/**
 * Do a little work and return the new state. The caller loops this with a
 * gap between calls so the phone stays responsive and the progress bar is
 * honest rather than decorative.
 */
export function scanStep(state: ScanState, batch = 2): ScanState {
  const queue = [...state.queue];
  const found = [...state.found];
  let done = state.done;

  for (let i = 0; i < batch && queue.length > 0; i++) {
    const ply = queue.shift()!;
    done += 1;
    let review: MoveReview;
    try {
      review = reviewPly(ply);
    } catch {
      continue; // a move we cannot read is skipped, never guessed about
    }
    // Only a serious loss goes in the report. A single pawn can be a gambit,
    // and we are not going to tell someone their Ruy Lopez was a mistake.
    const risk = review.risk;
    if (risk && isSerious(risk)) {
      found.push({
        ply,
        review,
        cost: risk.kind === "mate" ? Number.POSITIVE_INFINITY : risk.materialLost,
      });
    }
  }

  return { queue, done, total: state.total, found };
}

export function scanFinished(state: ScanState): boolean {
  return state.queue.length === 0;
}

/** Biggest mistakes first, and never more than this many. */
export const MAX_TURNING_POINTS = 5;

export function rankTurningPoints(found: TurningPoint[]): TurningPoint[] {
  return [...found].sort((a, b) => b.cost - a.cost).slice(0, MAX_TURNING_POINTS);
}

/**
 * The one sentence shown at the top of the report. It has to be true for a
 * beginner who blundered six times and for a strong player who did not.
 */
export function reportLine(state: ScanState, side: Color): string {
  const you = side === "w" ? "White" : "Black";
  if (state.total === 0) return `There are no ${you} moves in this game to look at.`;
  const n = state.found.length;
  if (n === 0) {
    return `Nothing the coach can prove went wrong in your ${state.total} ${
      state.total === 1 ? "move" : "moves"
    }. That is not the same as saying the game was perfect — it means no move here gives away ${SERIOUS_LOSS / 100} pawns' worth of material in a way we can show you on the board.`;
  }
  return `${n} ${n === 1 ? "moment" : "moments"} worth a look, out of your ${state.total} moves. Each one is a move where the opponent had a reply that wins at least ${SERIOUS_LOSS / 100} pawns' worth of material, and we can show it to you on the board.`;
}
