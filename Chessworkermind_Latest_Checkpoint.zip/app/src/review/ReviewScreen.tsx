import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chess, type Square } from "chess.js";
import Board from "../chess/Board";
import type { Color } from "../chess/session";
import { PIECE_WORD, spellMove } from "../coach/reviewMove";
import WhyNotMyMove from "../train/WhyNotMyMove";
import { trainText } from "../train/trainText";
import { getLanguage } from "../i18n/languages";
import {
  guessLearnerSide,
  parseGame,
  rankTurningPoints,
  reportLine,
  scanFinished,
  scanStep,
  startScan,
  type ParsedGame,
  type Ply,
  type ScanState,
  type TurningPoint,
} from "./gameReview";

/**
 * REVIEW YOUR OWN GAME.
 *
 * Paste a game (or load the one you just played), step through it, and see
 * the moments the coach can PROVE were costly — using exactly the same
 * evidence rule as the training screen. Nothing is graded, nothing is
 * guessed, and a game with no provable mistakes is reported as such rather
 * than padded out with invented "inaccuracies".
 */

type Props = {
  tag: string;
  /** The PGN of the game in progress, if there is one. */
  currentPgn: string;
  currentMoveCount: number;
  currentHumanSide: Color;
  onBack: () => void;
};

const SAMPLE = "1. e4 e5 2. Nf3 Qg5 3. Nxg5";

export default function ReviewScreen({
  tag,
  currentPgn,
  currentMoveCount,
  currentHumanSide,
  onBack,
}: Props) {
  const t = useMemo(() => trainText(tag, getLanguage(tag)?.nameOwn ?? tag), [tag]);

  const [text, setText] = useState("");
  const [game, setGame] = useState<ParsedGame | null>(null);
  const [side, setSide] = useState<Color>("w");
  const [cursor, setCursor] = useState(0); // 0 = starting position
  const [scan, setScan] = useState<ScanState | null>(null);
  const [openPoint, setOpenPoint] = useState<TurningPoint | null>(null);
  const timer = useRef<number | null>(null);

  /* ---- load ------------------------------------------------------------- */
  const load = useCallback(
    (raw: string, preferredSide?: Color) => {
      const parsed = parseGame(raw);
      setGame(parsed);
      setOpenPoint(null);
      setCursor(0);
      if (parsed.ok) {
        const guessed = preferredSide ?? guessLearnerSide(parsed.headers) ?? "w";
        setSide(guessed);
        setScan(startScan(parsed.plies, guessed));
      } else {
        setScan(null);
      }
    },
    [],
  );

  /* ---- scan a couple of moves at a time, so the phone stays usable ------ */
  useEffect(() => {
    if (!scan || scanFinished(scan)) return;
    timer.current = window.setTimeout(() => {
      setScan((s) => (s && !scanFinished(s) ? scanStep(s, 2) : s));
    }, 0);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [scan]);

  /* ---- changing side re-scans from scratch ------------------------------ */
  const changeSide = useCallback(
    (next: Color) => {
      setSide(next);
      setOpenPoint(null);
      if (game?.ok) setScan(startScan(game.plies, next));
    },
    [game],
  );

  const plies: Ply[] = game?.ok ? game.plies : [];
  const fen = cursor === 0 ? new Chess().fen() : plies[cursor - 1].fenAfter;
  const shown = cursor === 0 ? null : plies[cursor - 1];
  const noop = useMemo(() => () => [] as Square[], []);

  const ranked = useMemo(() => (scan ? rankTurningPoints(scan.found) : []), [scan]);
  const busy = !!scan && !scanFinished(scan);
  const percent = scan && scan.total > 0 ? Math.round((scan.done / scan.total) * 100) : 100;

  if (openPoint) {
    return (
      <WhyNotMyMove
        review={openPoint.review}
        t={t}
        humanSide={side}
        onKeepMove={() => setOpenPoint(null)}
        onClose={() => setOpenPoint(null)}
      />
    );
  }

  return (
    <div className="stack splitpage">
      <div className="subhead">
        <button className="iconbtn" onClick={onBack} aria-label="Back">‹</button>
        <h1 className="subhead__title">Review a game</h1>
        <span style={{ width: 40 }} />
      </div>

      {!game && (
        <>
          <div className="card">
            <p className="sect__p" style={{ marginTop: 0 }}>
              Paste a finished game and the coach will walk through your moves. It only points at moves where it
              can <strong>show you</strong> what went wrong on the board. It does not grade you and it does not
              guess.
            </p>
            <label className="csec__label" htmlFor="pgn-in" style={{ display: "block", marginTop: 14 }}>
              Your game
            </label>
            <textarea
              id="pgn-in"
              className="pgnbox"
              rows={6}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={"1. e4 e5 2. Nf3 Nc6 3. Bb5 a6"}
              aria-describedby="pgn-help"
            />
            <p id="pgn-help" className="small muted" style={{ marginTop: 6 }}>
              A full PGN works, and so does a plain list of moves. Comments and question marks are ignored.
            </p>
            <div className="btnrow" style={{ marginTop: 12 }}>
              <button className="btn btn--primary" onClick={() => load(text)} disabled={!text.trim()}>
                Review this game
              </button>
              <button className="btn btn--ghost btn--sm" onClick={() => { setText(SAMPLE); load(SAMPLE); }}>
                Try an example
              </button>
            </div>
          </div>

          <div className="card">
            <h3 style={{ fontSize: "1rem" }}>The game you are playing now</h3>
            {currentMoveCount > 0 ? (
              <>
                <p className="small muted" style={{ marginTop: 6 }}>
                  {currentMoveCount} {currentMoveCount === 1 ? "move" : "moves"} played so far. Reviewing it does
                  not change or end the game.
                </p>
                <button
                  className="btn"
                  style={{ marginTop: 10 }}
                  onClick={() => { setText(currentPgn); load(currentPgn, currentHumanSide); }}
                >
                  Review my current game
                </button>
              </>
            ) : (
              <p className="small muted" style={{ marginTop: 6 }}>
                You have not played any moves yet, so there is nothing here to review.
              </p>
            )}
          </div>
        </>
      )}

      {game && !game.ok && (
        <div className="card">
          <p className="verdict verdict--risky" role="alert" style={{ marginBottom: 0 }}>
            <span className="verdict__icon" aria-hidden="true">!</span>
            <span>
              <strong>That game could not be read.</strong>
              <br />
              {game.error}
            </span>
          </p>
          <button className="btn" style={{ marginTop: 12 }} onClick={() => setGame(null)}>
            Try again
          </button>
        </div>
      )}

      {game?.ok && (
        <>
          <Board
            fen={fen}
            orientation={side}
            lastMove={shown ? { from: shown.from, to: shown.to } : null}
            getLegalTargets={noop}
            isPromotionMove={() => false}
            tryMove={() => false}
            canPickUp={() => false}
            highlights={shown ? { path: [] } : {}}
            disabled
          />

          <div className="btnrow" style={{ marginTop: 10, justifyContent: "center" }}>
            <button className="btn btn--sm" onClick={() => setCursor(0)} disabled={cursor === 0}>⏮ Start</button>
            <button className="btn btn--sm" onClick={() => setCursor((c) => Math.max(0, c - 1))} disabled={cursor === 0}>
              ‹ Back
            </button>
            <button
              className="btn btn--sm"
              onClick={() => setCursor((c) => Math.min(plies.length, c + 1))}
              disabled={cursor >= plies.length}
            >
              Next ›
            </button>
            <button className="btn btn--sm" onClick={() => setCursor(plies.length)} disabled={cursor >= plies.length}>
              End ⏭
            </button>
          </div>

          <p className="movechip" role="status" aria-live="polite" style={{ marginTop: 10 }}>
            <span className="movechip__icon" aria-hidden="true">♟</span>
            {shown
              ? `Move ${shown.moveNumber}${shown.color === "w" ? "." : "..."} — ${
                  shown.color === "w" ? "White" : "Black"
                } played ${spellMove(shown.pieceType, shown.from, shown.to).replace("your ", "the ")}${
                  shown.captured ? `, taking a ${PIECE_WORD[shown.captured] ?? "piece"}` : ""
                }.`
              : "The starting position. Step forward to walk through the game."}
          </p>

          <div className="card">
            <div className="csec__label">Which side were you?</div>
            <div className="seg" role="group" aria-label="Your side" style={{ marginTop: 8 }}>
              <button className="seg__btn" aria-pressed={side === "w"} onClick={() => changeSide("w")}>White</button>
              <button className="seg__btn" aria-pressed={side === "b"} onClick={() => changeSide("b")}>Black</button>
            </div>

            <h3 style={{ fontSize: "1rem", marginTop: 18 }}>What the coach found</h3>

            {busy ? (
              <div style={{ marginTop: 10 }}>
                <p className="small muted">
                  Checking your move {Math.min(scan!.done + 1, scan!.total)} of {scan!.total}…
                </p>
                <span className="bar__track" aria-hidden="true" style={{ marginTop: 8 }}>
                  <span className="bar__fill" style={{ width: `${percent}%` }} />
                </span>
                <p className="small muted" style={{ marginTop: 8 }}>
                  Every move is replayed on a real board, so this takes a moment.
                </p>
              </div>
            ) : (
              <>
                <p className="sect__p">{reportLine(scan!, side)}</p>

                {ranked.length > 0 && (
                  <div className="lessonlist" style={{ marginTop: 12 }}>
                    {ranked.map((tp) => (
                      <button
                        key={tp.ply.index}
                        className="lessonrow"
                        onClick={() => {
                          setCursor(tp.ply.index + 1);
                          setOpenPoint(tp);
                        }}
                      >
                        <span className="lessonrow__badge" aria-hidden="true">
                          {tp.cost === Number.POSITIVE_INFINITY ? "♔" : "!"}
                        </span>
                        <span className="lessonrow__body">
                          <span className="lessonrow__title">
                            Move {tp.ply.moveNumber}
                            {tp.ply.color === "w" ? "." : "..."} {tp.ply.san}
                          </span>
                          <span className="lessonrow__note">
                            {tp.cost === Number.POSITIVE_INFINITY
                              ? "This allowed checkmate"
                              : `${tp.review.risk!.san} wins ${
                                  PIECE_WORD[tp.review.risk!.captured ?? "p"] ?? "material"
                                } here`}
                          </span>
                        </span>
                        <span className="rowcard__chev" aria-hidden="true">›</span>
                      </button>
                    ))}
                  </div>
                )}

                <p className="small muted" style={{ marginTop: 12 }}>
                  The coach only lists a move when it can play the punishment out on the board for you. It does not
                  score your game, it does not compare you to anyone, and quiet or slow moves are never called
                  mistakes just because a computer prefers something else.
                </p>
              </>
            )}

            <button className="btn btn--ghost" style={{ marginTop: 14 }} onClick={() => { setGame(null); setScan(null); }}>
              Review a different game
            </button>
          </div>
        </>
      )}
    </div>
  );
}
