import { describe, expect, it } from "vitest";
import { Chess } from "chess.js";
import {
  MAX_PLIES,
  MAX_TURNING_POINTS,
  guessLearnerSide,
  learnerPlies,
  parseGame,
  rankTurningPoints,
  reportLine,
  reviewPly,
  scanFinished,
  scanStep,
  startScan,
  type TurningPoint,
} from "../gameReview";

const SCHOLAR_PGN = `[Event "Test"]
[White "You"]
[Black "Computer"]
[Result "1-0"]

1. e4 e5 2. Bc4 Nc6 3. Qh5 Nf6 4. Qxf7# 1-0`;

describe("reading a game", () => {
  it("reads a normal PGN with headers", () => {
    const g = parseGame(SCHOLAR_PGN);
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    expect(g.plies).toHaveLength(7);
    expect(g.plies[0].san).toBe("e4");
    expect(g.plies[6].san).toBe("Qxf7#");
    expect(g.headers.White).toBe("You");
    expect(g.result).toBe("1-0");
  });

  it("reads a bare list of moves, which is what people actually paste", () => {
    const g = parseGame("1. e4 e5 2. Nf3 Nc6 3. Bb5");
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    expect(g.plies.map((p) => p.san)).toEqual(["e4", "e5", "Nf3", "Nc6", "Bb5"]);
  });

  it("reads moves with no numbers at all", () => {
    const g = parseGame("e4 e5 Nf3 Nc6");
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    expect(g.plies).toHaveLength(4);
  });

  it("strips comments and annotation marks instead of choking on them", () => {
    const g = parseGame("1. e4 {a good start} e5 $1 2. Nf3 (2. Bc4 is also fine) Nc6");
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    expect(g.plies.map((p) => p.san)).toEqual(["e4", "e5", "Nf3", "Nc6"]);
  });

  it("records the position before and after every move, from the real board", () => {
    const g = parseGame("e4 e5 Nf3");
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    for (const ply of g.plies) {
      const probe = new Chess(ply.fenBefore);
      const played = probe.move({ from: ply.from, to: ply.to, promotion: ply.promotion ?? "q" });
      expect(played.san).toBe(ply.san);
      expect(probe.fen()).toBe(ply.fenAfter);
    }
  });

  it("numbers the moves the way a person writes them", () => {
    const g = parseGame("e4 e5 Nf3 Nc6 Bb5 a6");
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    expect(g.plies.map((p) => `${p.moveNumber}${p.color}`)).toEqual(["1w", "1b", "2w", "2b", "3w", "3b"]);
  });
});

describe("when the paste is wrong, it says so in words a person can act on", () => {
  it("asks for something when given nothing", () => {
    const g = parseGame("   ");
    expect(g.ok).toBe(false);
    if (g.ok) return;
    expect(g.error).toMatch(/nothing to read yet/i);
  });

  it("points at the exact move that cannot be played", () => {
    const g = parseGame("1. e4 e5 2. Nf3 Nc6 3. Qh9");
    expect(g.ok).toBe(false);
    if (g.ok) return;
    expect(g.error).toMatch(/Qh9/);
    expect(g.error).toMatch(/move 2|move 3/);
  });

  it("says plainly when the very first move is impossible", () => {
    const g = parseGame("e9 e5");
    expect(g.ok).toBe(false);
    if (g.ok) return;
    expect(g.error).toMatch(/not a move White could play from the start/i);
  });

  it("rejects prose without pretending to understand it", () => {
    const g = parseGame("I played a really good game yesterday against my brother");
    expect(g.ok).toBe(false);
  });

  it("never reads more than a sane number of moves", () => {
    // a long but legal shuffle
    const c = new Chess();
    const moves: string[] = [];
    while (moves.length < MAX_PLIES + 40) {
      const legal = c.moves();
      if (legal.length === 0 || c.isGameOver()) break;
      const pick = legal[0];
      c.move(pick);
      moves.push(pick);
    }
    const g = parseGame(moves.join(" "));
    if (g.ok) expect(g.plies.length).toBeLessThanOrEqual(MAX_PLIES);
  });
});

describe("whose game is it", () => {
  it("works out the learner's side from the names when it can", () => {
    expect(guessLearnerSide({ White: "You", Black: "Computer" })).toBe("w");
    expect(guessLearnerSide({ White: "Stockfish 16", Black: "Luv" })).toBe("b");
    expect(guessLearnerSide({ White: "Chessworkermind", Black: "Player" })).toBe("b");
  });

  it("returns null rather than guessing between two real names", () => {
    expect(guessLearnerSide({ White: "Anand", Black: "Carlsen" })).toBeNull();
    expect(guessLearnerSide({})).toBeNull();
  });

  it("only ever looks at the learner's own moves", () => {
    const g = parseGame("e4 e5 Nf3 Nc6");
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    expect(learnerPlies(g.plies, "w").map((p) => p.san)).toEqual(["e4", "Nf3"]);
    expect(learnerPlies(g.plies, "b").map((p) => p.san)).toEqual(["e5", "Nc6"]);
  });
});

describe("finding the moments worth a look", () => {
  function scanAll(pgn: string, side: "w" | "b") {
    const g = parseGame(pgn);
    expect(g.ok).toBe(true);
    if (!g.ok) throw new Error("bad fixture");
    let state = startScan(g.plies, side);
    let guard = 0;
    while (!scanFinished(state) && guard++ < 500) state = scanStep(state, 4);
    return state;
  }

  it("works through every one of the learner's moves and stops", () => {
    const state = scanAll("e4 e5 Nf3 Nc6 Bc4 Bc5", "w");
    expect(state.total).toBe(3);
    expect(state.done).toBe(3);
    expect(scanFinished(state)).toBe(true);
  });

  it("does not call a normal main line a mistake", () => {
    // The Ruy Lopez. 5.O-O allows 5...Nxe4 and a pawn — that is the Open
    // Variation, played by world champions. An earlier version flagged it.
    const state = scanAll("e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O", "w");
    expect(state.found).toHaveLength(0);
    const line = reportLine(state, "w");
    expect(line).toMatch(/Nothing the coach can prove went wrong/i);
    expect(line).toMatch(/not the same as saying the game was perfect/i);
  });

  it("catches a real blunder and can prove it on the board", () => {
    // Black hangs the queen: 1.e4 e5 2.Nf3 Qf6 3.Nxe5 Qxe5?? loses to d4
    // 2...Qg5?? simply hangs the queen to Nxg5.
    const state = scanAll("e4 e5 Nf3 Qg5 Nxg5", "b");
    expect(state.found.length).toBeGreaterThan(0);
    for (const tp of state.found) {
      const probe = new Chess(tp.review.fenAfter!);
      expect(() => probe.move({ from: tp.review.risk!.from, to: tp.review.risk!.to, promotion: "q" })).not.toThrow();
      expect(tp.cost).toBeGreaterThan(0);
    }
  });

  it("every flagged move is one of the learner's own", () => {
    const state = scanAll("e4 e5 Nf3 Qg5 Nxg5 d6", "b");
    for (const tp of state.found) expect(tp.ply.color).toBe("b");
  });

  it("shows the worst moments first and never floods the learner", () => {
    const fake = (cost: number): TurningPoint =>
      ({ ply: { index: cost } as never, review: {} as never, cost });
    const ranked = rankTurningPoints([fake(100), fake(900), fake(300), fake(500), fake(200), fake(800), fake(400)]);
    expect(ranked.map((t) => t.cost)).toEqual([900, 800, 500, 400, 300]);
    expect(ranked.length).toBeLessThanOrEqual(MAX_TURNING_POINTS);
  });

  it("puts a move that allowed mate above every material loss", () => {
    const state = scanAll("f3 e5 g4 Qh4", "w");
    const worst = rankTurningPoints(state.found)[0];
    if (worst) expect(worst.cost).toBe(Number.POSITIVE_INFINITY);
  });

  it("is reviewable one small batch at a time, so a phone stays responsive", () => {
    const g = parseGame("e4 e5 Nf3 Nc6 Bc4 Bc5 d3 d6 O-O Nf6");
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    let state = startScan(g.plies, "w");
    expect(state.total).toBe(5);
    state = scanStep(state, 1);
    expect(state.done).toBe(1);
    expect(scanFinished(state)).toBe(false);
    state = scanStep(state, 1);
    expect(state.done).toBe(2);
  });

  it("handles a game with no moves by the learner at all", () => {
    const g = parseGame("e4");
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    const state = startScan(g.plies, "b");
    expect(state.total).toBe(0);
    expect(scanFinished(state)).toBe(true);
    expect(reportLine(state, "b")).toMatch(/no Black moves in this game/i);
  });
});

describe("one move, reviewed", () => {
  it("uses the same standard of evidence as the training screen", () => {
    const g = parseGame("e4 e5 Nf3 Nc6");
    expect(g.ok).toBe(true);
    if (!g.ok) return;
    const r = reviewPly(g.plies[0]);
    expect(r.legal).toBe(true);
    expect(r.played?.san).toBe("e4");
    expect(r.risk).toBeNull(); // 1.e4 is not a blunder
    expect(r.candidates.length).toBeLessThanOrEqual(3);
  });
});
