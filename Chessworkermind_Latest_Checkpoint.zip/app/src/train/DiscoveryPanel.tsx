import { useMemo, useState } from "react";
import { Chess, type Square } from "chess.js";
import { defenders, positionFacts } from "../coach/positionFacts";

export default function DiscoveryPanel({fen,positionId,onLook,onExplore}:{fen:string;positionId:number;onLook:(squares:string[])=>void;onExplore:(line:string[])=>void}) {
  const packet=useMemo(()=>positionFacts(fen,positionId),[fen,positionId]);
  const c=useMemo(()=>new Chess(fen),[fen]);
  const moves=useMemo(()=>c.moves({verbose:true}),[c]);
  const [selected,setSelected]=useState("");
  const [scan,setScan]=useState(false);
  const facts=packet.boardFacts;
  const target=facts.attacked[0]??facts.undefended[0];
  return <details className="discovery" onToggle={e=>{if(!e.currentTarget.open)onLook([]);}}>
    <summary>Explore this exact position</summary>
    <div className="stack" style={{marginTop:10}}>
      <button className="btn" onClick={()=>{onLook(target?[target]:[]);setScan(true);}}>Show me where to look</button>
      {scan&&<div role="status"><strong>BOARD FACT</strong>
        <p>{facts.inCheck?"Your king is in check.":"Your king is not currently in check."} {target?`Inspect ${target}.` : "No attacked or undefended non-king piece was found for the side to move."}</p>
        {target&&<p>{target} has {defenders(fen,target as Square).length} same-colour geometric defenders. A pinned defender may be unable to move; this is not proof of a safe exchange.</p>}
        <p>Legal checks: {facts.checks.join(", ")||"none"}. Legal captures: {facts.captures.join(", ")||"none"}.</p>
        <p><strong>UNKNOWN</strong> — {packet.unknown.join(" ")}</p>
      </div>}
      <label htmlFor="candidate-check">Candidate check — choose a legal idea</label>
      <select id="candidate-check" value={selected} onChange={e=>setSelected(e.target.value)}>
        <option value="">Think myself first</option>
        {moves.map(m=>{const u=`${m.from}${m.to}${m.promotion??""}`;return <option key={u} value={u}>{m.san} · {m.from} → {m.to}</option>;})}
      </select>
      <button className="btn" disabled={!selected} onClick={()=>{
        const branch=new Chess(fen);branch.move({from:selected.slice(0,2),to:selected.slice(2,4),promotion:selected.slice(4)||undefined});
        const reply=branch.isGameOver()?undefined:branch.moves({verbose:true})[0];
        onExplore(reply?[selected,`${reply.from}${reply.to}${reply.promotion??""}`]:[selected]);
      }}>If I play this…</button>
      <p className="small muted">Replay one legal reply from the rules library, not a claimed best reply. Return and compare another candidate; the saved game never changes.</p>
    </div>
  </details>;
}
