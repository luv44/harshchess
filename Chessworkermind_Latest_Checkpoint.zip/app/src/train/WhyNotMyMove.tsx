import { useMemo, useState } from "react";
import Rehearsal from "./Rehearsal";
import { Chess, type Square } from "chess.js";
import Board from "../chess/Board";
import {
  CANDIDATE_REASON_TEXT,
  JARGON,
  PIECE_WORD,
  spellMove,
  type MoveReview,
} from "../coach/reviewMove";
import { candidateTrick } from "../coach/coachTrick";
import type { TrainText } from "./trainText";

/**
 * "Why not my move?" — screen 3 of the design.
 *
 * It shows the SAME position the learner moved from, their move, and at most
 * three legal alternatives. It only says a move was risky when `review.risk`
 * is set, which only happens when a legal punishing reply was replayed on the
 * real board AND a normal alternative avoided it. When nothing is proven it
 * says so out loud instead of inventing a fork or a lost queen.
 */

type Props = {
  review: MoveReview;
  t: TrainText;
  humanSide: "w" | "b";
  /** keep the move and let the game continue */
  onKeepMove: () => void;
  onClose: () => void;
};

export default function WhyNotMyMove({
  review,
  t,
  humanSide,
  onKeepMove,
  onClose,
}: Props) {
  // The board shows the position BEFORE the learner's move, so "rewind and
  // compare" is literally true.
  const chess = useMemo(() => new Chess(review.fen), [review.fen]);
  const noop = useMemo(() => () => [] as Square[], []);

  const played = review.played;
  const best = review.candidates[0] ?? null;
  const risk = review.risk;
  const [rehearsal, setRehearsal] = useState<string[] | null>(null);
  const onTryAgain = () => setRehearsal([]);
  const onPlayCandidate = (from: Square, to: Square, promotion?: string) => {
    const branch = new Chess(review.fen);
    try { const m = branch.move({from,to,promotion});
      const reply = branch.isGameOver() ? undefined : branch.moves({verbose:true})[0];
      setRehearsal([`${m.from}${m.to}${m.promotion ?? ""}`, ...(reply ? [`${reply.from}${reply.to}${reply.promotion ?? ""}`] : [])]);
    } catch { /* abstain */ }
  };

  const highlights = useMemo(
    () => ({
      // the learner's move in one style…
      threatFrom: played?.from ?? null,
      threatTo: played?.to ?? null,
      // …and the coach's suggestion in the other
      suggestFrom: best?.from ?? null,
      suggestTo: best?.to ?? null,
      // Risk belongs to the AFTER position and must not be drawn here.
      focus: [],
    }),
    [played, best, risk],
  );

  if (rehearsal) return <Rehearsal fen={review.fen} line={rehearsal} onClose={() => setRehearsal(null)} />;

  if (!played) {
    return (
      <div className="stack">
        <button className="btn btn--ghost btn--sm" style={{ alignSelf: "flex-start" }} onClick={onClose}>
          ← Back
        </button>
        <div className="card">
          <p>That move could not be read back, so there is nothing honest to say about it.</p>
        </div>
      </div>
    );
  }

  const youWord = humanSide === "w" ? t.white : t.black;
  const themWord = humanSide === "w" ? t.black : t.white;

  return (
    <div className="stack splitpage">
      <div className="subhead">
        <button className="iconbtn" onClick={onClose} aria-label="Back to the board">‹</button>
        <h1 className="subhead__title">{t.whyTitle}</h1>
        <span style={{ width: 40 }} />
      </div>

      <Board
        fen={review.fen}
        orientation={humanSide}
        lastMove={null}
        getLegalTargets={noop}
        isPromotionMove={() => false}
        tryMove={() => false}
        canPickUp={() => false}
        highlights={highlights}
        disabled
      />

      <p className="small muted" style={{ textAlign: "center", marginTop: -2 }}>
        This is the position you moved from. Your move is marked with a warning outline; the coach's move is marked{" "}
        <strong>1</strong> and <strong>2</strong>.
      </p>

      {/* ---- the verdict on the played move ---- */}
      {risk ? (
        <div className="verdict verdict--risky" role="status">
          <span className="verdict__icon" aria-hidden="true">✕</span>
          <span>
            <strong>
              Your move: {spellMove(played.pieceType, played.from, played.to)}.
            </strong>
            <br />
            {themWord} can answer with {risk.kind === "mate" ? "checkmate" : `${risk.san}`}
            {risk.kind === "mate"
              ? " — the game would end there."
              : risk.captured
                ? ` and take your ${PIECE_WORD[risk.captured] ?? "piece"}. You do not get it back.`
                : " and win material."}
          </span>
        </div>
      ) : review.endsGame ? (
        <div className="verdict verdict--ok" role="status">
          <span className="verdict__icon" aria-hidden="true">✓</span>
          <span>
            <strong>That move ends the game.</strong>
            <br />
            {review.endsGame.kind === "checkmate" ? "Checkmate." : "It is a draw."}
          </span>
        </div>
      ) : (
        <div className="verdict verdict--ok" role="status">
          <span className="verdict__icon" aria-hidden="true">✓</span>
          <span>
            <strong>Your move: {spellMove(played.pieceType, played.from, played.to)}.</strong>
            <br />
            No punishment was established by this bounded search. That is not proof that the move is best or safe.
          </span>
        </div>
      )}

      {/* ---- the six plain-words sections ---- */}
      <section className="card">
        <h2 className="sect__h">{t.sideWants(themWord)}</h2>
        <p className="sect__p">
          {risk
            ? risk.kind === "mate"
              ? `After your move, ${themWord} has the legal mating reply ${risk.san}.`
              : `After your move, ${themWord} can legally play ${risk.san}. The bounded exchange search found a material gain; deeper compensation has not been assessed.`
            : `No winning reply was established. This is not a claim about ${themWord}'s intentions.`}
        </p>

        <h2 className="sect__h">{t.shouldNotice}</h2>
        <p className="sect__p">
          {risk
            ? `Look at ${risk.to}. After your move that square is attacked by ${themWord} and not defended enough by you.`
            : best
              ? `Look at ${best.to}. That is the square the coach would use.`
              : "There is nothing sharp in this position — a calm, safe move is enough."}
        </p>

        {best && (
          <>
            <h2 className="sect__h">{t.tryThisMove}</h2>
            <p className="sect__p">
              Move {spellMove(best.pieceType, best.from, best.to)}.
              {best.isCapture && best.captured
                ? ` It takes the ${PIECE_WORD[best.captured] ?? "piece"} on ${best.to}.`
                : ""}
            </p>

            <h2 className="sect__h">{t.whyItHelps}</h2>
            <p className="sect__p">
              It {CANDIDATE_REASON_TEXT[best.reason]}
              {best.opponentCanWin === 0 ? ". No immediate material loss was found in the bounded check." : "."}
            </p>
            {candidateTrick(best.reason) && (
              <p className="trick">
                <span className="trick__label">{t.rememberLabel}</span>
                <span className="trick__text">{candidateTrick(best.reason)}</span>
              </p>
            )}
          </>
        )}

        <h2 className="sect__h">{t.mightDoNext(themWord)}</h2>
        <p className="sect__p">
          {risk
            ? `If you keep your move, ${risk.san} is one legal possible reply, not a prediction.`
            : `The coach cannot promise what ${themWord} will play. Anything it shows here would be a guess, so it is not shown.`}
        </p>

        {risk && (
          <>
            <h2 className="sect__h">{t.whyRisky}</h2>
            <p className="sect__p">
              {risk.kind === "mate"
                ? `It allows checkmate. The coach checked this by playing ${risk.san} on the board.`
                : `After ${played.san}, the reply ${risk.san} wins material and you cannot win it back. The coach checked this by playing the whole exchange out on the board, not by guessing.`}
            </p>
          </>
        )}

        {review.uncertain && !risk && (
          <p className="pill pill--warn" style={{ whiteSpace: "normal", marginTop: 10 }}>
            The coach cannot compare properly in this position, so it is not making a judgement.
          </p>
        )}
      </section>

      {risk && <button className="btn" onClick={() => {
        const branch = new Chess(review.fen); const m = branch.move(played.san);
        const reply = branch.move(risk.san);
        setRehearsal([`${m.from}${m.to}${m.promotion ?? ""}`, `${reply.from}${reply.to}${reply.promotion ?? ""}`]);
      }}>Replay the legal consequence</button>}

      {/* ---- candidates ---- */}
      {review.candidates.length > 0 && (
        <>
          <p className="divider-note">{t.rewindCompare}</p>
          <div className="lessonlist">
            {review.candidates.map((c) => (
              <button
                key={`${c.from}${c.to}`}
                className="lessonrow"
                onClick={() => onPlayCandidate(c.from, c.to, c.promotion)}
              >
                <span className="lessonrow__badge" aria-hidden="true">
                  {GLYPH[c.pieceType] ?? "♟"}
                </span>
                <span className="lessonrow__body">
                  <span className="lessonrow__title">
                    {PIECE_WORD[c.pieceType]} {c.from} → {c.to}
                  </span>
                  <span className="lessonrow__note">{CANDIDATE_REASON_TEXT[c.reason]}</span>
                </span>
                <span className="rowcard__chev" aria-hidden="true">›</span>
              </button>
            ))}
          </div>
          <p className="small muted" style={{ margin: "8px 4px 0" }}>
            {review.candidates.length === 1 ? "This move was" : `These ${review.candidates.length} moves were`} all
            checked on the board first. Tapping one opens a separate conditional variation; your saved game is unchanged.
          </p>
        </>
      )}

      <div className="btnrow" style={{ marginTop: 14 }}>
        {best && (
          <button
            className="btn btn--primary"
            onClick={() => onPlayCandidate(best.from, best.to, best.promotion)}
          >
            ▶ {t.btnPlaySuggested}
          </button>
        )}
        <button className="btn" onClick={onTryAgain}>{t.btnTryAgain}</button>
        <button className="btn btn--ghost" onClick={onKeepMove}>{t.btnKeepMove}</button>
      </div>

      <details className="card" style={{ marginTop: 12 }}>
        <summary style={{ cursor: "pointer", fontWeight: 600 }}>Words the coach used</summary>
        <ul className="small muted" style={{ marginTop: 10, paddingInlineStart: 18, lineHeight: 1.7 }}>
          {Object.entries(JARGON).map(([word, meaning]) => (
            <li key={word}>
              <strong>{word}</strong> — {meaning}.
            </li>
          ))}
        </ul>
        <p className="small muted" style={{ marginTop: 8 }}>
          You ({youWord}) always move first in this training game.
        </p>
      </details>
    </div>
  );
}

const GLYPH: Record<string, string> = { k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟" };
