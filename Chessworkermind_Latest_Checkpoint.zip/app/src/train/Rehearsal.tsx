import { useMemo, useState } from "react";
import { Chess, type Square } from "chess.js";
import Board from "../chess/Board";
import { legalLine } from "../coach/positionFacts";

/** Isolated branch: never receives the saved game's mutation methods. */
export default function Rehearsal({ fen, line = [], onClose }: { fen: string; line?: string[]; onClose: () => void }) {
  const replay=useMemo(()=>legalLine(fen,line),[fen,line]);
  const [step,setStep]=useState(0);
  const [practice,setPractice]=useState<string|null>(null);
  const [message,setMessage]=useState("");
  const position=practice ?? replay?.fens[step] ?? fen;
  const c=useMemo(()=>new Chess(position),[position]);
  const [promotion,setPromotion]=useState(false);
  return <div className="stack">
    <div className="subhead"><h1 className="subhead__title">If I play this…</h1><button className="btn" onClick={onClose}>Return to current position</button></div>
    <p className="pill pill--warn" style={{whiteSpace:"normal"}}>Separate practice board. Your original game and move history are unchanged.</p>
    <Board fen={position} orientation={new Chess(fen).turn()} lastMove={null}
      getLegalTargets={from=>c.moves({verbose:true,square:from}).map(m=>m.to)}
      isPromotionMove={(from,to)=>c.moves({verbose:true,square:from}).some(m=>m.to===to&&!!m.promotion)}
      onPromotionOpenChange={setPromotion}
      canPickUp={color=>practice!==null&&!c.isGameOver()&&color===c.turn()}
      tryMove={(from:Square,to:Square,promo)=>{ try { const m=c.move({from,to,promotion:promo});setPractice(c.fen());setMessage(`Board fact: ${m.san}${c.isCheckmate()?" is checkmate":c.isCheck()?" gives check":" is legal"}. This is practice, not a best-move claim.`);return true; } catch {return false;} }} />
    <div className="card">
      <p role="status">{practice!==null ? message||"Try a legal move from the exact original position." : step===0?"Original position — before this conditional line.":`Conditional continuation, step ${step}: ${replay?.sans[step-1]}. Not a prediction or a strongest-reply claim.`}</p>
      <div className="btnrow">
        <button className="btn" disabled={practice!==null||step===0||promotion} onClick={()=>setStep(s=>s-1)}>Back one move</button>
        <button className="btn" disabled={practice!==null||!replay||step===replay.sans.length||promotion} onClick={()=>setStep(s=>s+1)}>Next move</button>
        <button className="btn btn--primary" onClick={()=>{setPractice(fen);setMessage("");}}>Retry from original position</button>
        {practice!==null&&<button className="btn" onClick={()=>{setPractice(null);setStep(0);}}>Return to variation</button>}
      </div>
      {!replay&&<p role="alert">This line could not be legally replayed, so it is not shown.</p>}
    </div>
  </div>;
}
