import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Square } from "chess.js";
import Board, { type BoardHighlights } from "../chess/Board";
import type { useChessGame } from "../chess/useChessGame";
import { useComputerOpponent } from "../chess/useComputerOpponent";
import { useDifficulty } from "../learn/difficulty";
import DifficultyPanel from "../learn/DifficultyPanel";
import DiscoveryPanel from "./DiscoveryPanel";
import Rehearsal from "./Rehearsal";
import { useCoach } from "../coach/useCoach";
import { useEngine } from "../engine/useEngine";
import { useStockfishSetting } from "../engine/stockfishSetting";
import {
  isSerious,
  PIECE_WORD,
  reviewMove,
  spellMove,
  spellOpponentMove,
  type MoveReview,
} from "../coach/reviewMove";
import WhyNotMyMove from "./WhyNotMyMove";
import { trainText } from "./trainText";
import { coachTrick } from "../coach/coachTrick";
import { getLanguage } from "../i18n/languages";

/**
 * TRAIN — "What's your move?" (screen 2 of the design).
 *
 * This is the beginner coaching loop, in order, after every computer move:
 *   1  Black did this.                (verified from the real move history)
 *   2  Black may be threatening this. (only when replay proves it)
 *   3  Look at these squares.         (highlighted on the board)
 *   4  What could you do?             (the learner moves first — always)
 *   5  Hint 1, on request             (which piece)
 *   6  Hint 2 / Show one move         (named in words: "your knight from g1 to f3")
 *   7  Why it helps                   (one sentence)
 *   8  One possible Black reply       (only when legally verified)
 *   9  The learner plays it
 *  10  The same idea returns later in the Learn journey
 *
 * The learner always moves first. Nothing is played for them unless they ask.
 */

type Props = {
  game: ReturnType<typeof useChessGame>;
  tag: string;
  online: boolean;
  onOpenLessons: () => void;
};

export default function TrainScreen({ game, tag, online, onOpenLessons }: Props) {
  const coach = useCoach();
  const engine = useEngine();
  const [useStockfish] = useStockfishSetting();
  const t = useMemo(() => trainText(tag, getLanguage(tag)?.nameOwn ?? tag), [tag]);
  const [hint, setHint] = useState(0); // 0 none, 1 piece, 2 squares, 3 full move
  const [focusMode, setFocusMode] = useState(false);
  const [promoOpen, setPromoOpen] = useState(false);
  const [review, setReview] = useState<MoveReview | null>(null);
  const [whyOpen, setWhyOpen] = useState(false);
  const [keptMove, setKeptMove] = useState(false);
  const [difficulty] = useDifficulty();
  const [look, setLook] = useState<string[]>([]);
  const [rehearsal, setRehearsal] = useState<{fen: string; line: string[]} | null>(null);

  const statusKind = game.status.kind === "active" ? "active" : game.status.kind;
  const isHumanTurn =
    game.status.kind === "active" && game.mode !== "watch" && (game.mode === "solo" || game.turn === game.humanSide);

  /**
   * Only a SERIOUS mistake stops the game. Losing one pawn can be a gambit —
   * an earlier version interrupted the learner for castling in the Ruy Lopez.
   * A one-pawn loss is still mentioned, quietly, without taking over.
   */
  const serious = isSerious(review?.risk ?? null);
  const holding = serious && !keptMove;

  const opponent = useComputerOpponent({
    fen: game.fen,
    turn: game.turn,
    session: game.session,
    generation: game.generation,
    statusKind,
    paused: promoOpen || holding || whyOpen || rehearsal !== null,
    level: "gentle",
    strength: difficulty.computer,
    applyMove: game.tryMove,
  });

  /* ---- optional deeper check with Stockfish (off by default) ------------ */
  useEffect(() => {
    if (!useStockfish || game.status.kind !== "active" || !isHumanTurn) { engine.stop(); return; }
    engine.analyze(game.fen);
    return () => engine.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [useStockfish, game.fen, game.generation, game.status.kind, isHumanTurn]);

  /**
   * Candidates are only ever passed on when they belong to THIS exact
   * position. A result that arrived for the previous position is thrown
   * away, not reused. The coach then re-checks every one of them on the
   * board before it will repeat anything the engine said.
   */
  const engineCandidates =
    useStockfish && engine.analysis?.fen === game.fen
      ? engine.analysis.candidates.map((c) => ({ uci: c.uci, scoreCp: c.scoreCp, scoreMate: c.scoreMate }))
      : undefined;

  /* ---- ask the coach about the CURRENT position, for the human ---------- */
  const cardSide = game.mode === "vsComputer" ? game.humanSide : game.turn;
  const requestedFor = useRef("");
  useEffect(() => {
    if (!isHumanTurn) return;
    // The key includes the engine's answer, so when Stockfish finishes we ask
    // again with it — and the coach re-verifies everything before using it.
    const key = `${game.generation}:${game.fen}:${engineCandidates?.map((c) => c.uci).join(",") ?? "none"}`;
    if (requestedFor.current === key) return;
    requestedFor.current = key;
    coach.request({
      fen: game.fen,
      humanSide: cardSide,
      lastMove: game.lastRawMove,
      engineCandidates,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game.fen, game.generation, isHumanTurn, cardSide, game.lastRawMove, engineCandidates]);

  // A new position means the old hint level and the old review are stale.
  useEffect(() => {
    setHint(0);
    setLook([]);
  }, [game.fen, game.generation]);

  useEffect(() => {
    setReview(null); setWhyOpen(false); setKeptMove(false);
  }, [game.mode, game.humanSide]);

  const card = coach.card && coach.card.fen === game.fen ? coach.card : null;

  /* ---- the learner's move goes through the reviewer --------------------- */
  const tryMoveAndReview = useCallback(
    (from: Square, to: Square, promotion?: "q" | "r" | "b" | "n") => {
      if (!isHumanTurn) return false;
      const fenBefore = game.fen;
      const ok = game.tryHumanMove(from, to, promotion);
      if (!ok) return false;
      setKeptMove(false);
      setHint(0);
      try {
        setReview(reviewMove({ fen: fenBefore, from, to, promotion }));
      } catch {
        setReview(null);
      }
      return true;
    },
    [game, isHumanTurn],
  );

  const takeBack = useCallback(() => {
    game.undo();
    setReview(null);
    setWhyOpen(false);
    setKeptMove(false);
    setHint(0);
  }, [game]);

  const keepMove = useCallback(() => {
    setKeptMove(true);
    setWhyOpen(false);
  }, []);

  const showOneMove = useCallback(() => setHint(3), []);

  /* ---- highlights ------------------------------------------------------- */
  const highlights: BoardHighlights = useMemo(() => {
    if (focusMode || !card) return {};
    const h: BoardHighlights = {};
    if (card.opponentMove) h.path = card.opponentMove.path;
    if (card.threat.present && card.threat.threat) {
      h.threatFrom = card.threat.threat.from;
      h.threatTo = card.threat.threat.to;
    }
    if (hint >= 3 && card.suggestion) {
      h.suggestFrom = card.suggestion.from;
      h.suggestTo = card.suggestion.to;
    }
    if (hint === 2 && card.suggestion) h.focus = [card.suggestion.from];
    if (look.length) h.focus = look;
    return h;
  }, [card, hint, focusMode, look]);

  /* ---- the "Black did this" line, straight from the real move ----------- */
  const opponentLine = useMemo(() => {
    const m = card?.opponentMove;
    if (!m) return null;
    return spellOpponentMove(m.color, m.pieceType, m.from, m.to, m.captured);
  }, [card]);

  if (rehearsal) return <Rehearsal fen={rehearsal.fen} line={rehearsal.line} onClose={() => setRehearsal(null)} />;

  if (whyOpen && review) {
    return (
      <WhyNotMyMove
        review={review}
        t={t}
        humanSide={game.humanSide}
        onKeepMove={keepMove}
        onClose={() => setWhyOpen(false)}
      />
    );
  }

  const over = game.status.kind !== "active";

  return (
    <div className="playgrid">
      <div className="playgrid__board">
        {!online && (
          <p className="pill pill--warn" style={{ whiteSpace: "normal", marginBottom: 10 }} role="status">
            {t.offlineNote}
          </p>
        )}
        {t.fallback && (
          <p className="pill pill--warn" style={{ whiteSpace: "normal", marginBottom: 10 }}>
            {t.fallback}
          </p>
        )}
        <div className="subhead">
          <h1 className="subhead__title">{t.title}</h1>
          <button className="btn btn--ghost btn--sm" onClick={onOpenLessons}>
            {t.lessons}
          </button>
        </div>

        {/* 1. Black did this */}
        <div className={`movechip ${opponentLine ? "" : "movechip--muted"}`} role="status" aria-live="polite">
          <span className="movechip__icon" aria-hidden="true">♟</span>
          {over
            ? game.status.kind === "checkmate"
              ? `Checkmate — ${game.status.winner === game.humanSide ? "you won" : "the computer won"}.`
              : "The game is over — it is a draw."
            : opponentLine
              ? opponentLine
              : isHumanTurn
                ? t.youMoveFirst(game.humanSide === "w" ? t.white : t.black)
                : opponent.thinking
                  ? t.computerThinking
                  : t.computerAbout}
        </div>

        <Board
          fen={game.fen}
          orientation={game.orientation}
          lastMove={game.lastMove}
          getLegalTargets={game.getLegalTargets}
          isPromotionMove={game.isPromotionMove}
          tryMove={tryMoveAndReview}
          canPickUp={game.canPickUp}
          highlights={highlights}
          showLegalTargets={!focusMode && difficulty.learning <= 2}
          onPromotionOpenChange={setPromoOpen}
          disabled={holding}
        />

        <div className="btnrow" style={{ marginTop: 12, justifyContent: "center" }}>
          <button className="btn btn--sm" onClick={() => setRehearsal({fen: review?.fen ?? game.fen, line: []})}>⟲ Retry in practice</button>
          <button className="btn btn--sm" onClick={takeBack} disabled={!game.canUndo}>↩ {t.btnUndo}</button>
          <button className="btn btn--sm" onClick={() => { game.newGame(); setReview(null); setHint(0); }}>
            ⟳ {t.btnNewGame}
          </button>
          <button
            className={`btn btn--sm ${focusMode ? "btn--primary" : ""}`}
            onClick={() => setFocusMode((f) => !f)}
            aria-pressed={focusMode}
          >
            ◉ {t.btnFocus}
          </button>
        </div>
      </div>

      <div>
        {/* The held-back risky move */}
        {holding && review?.risk && (
          <div className="verdict verdict--risky" role="alert">
            <span className="verdict__icon" aria-hidden="true">!</span>
            <span>
              <strong>{t.heldBack}</strong>
              <br />
              {game.humanSide === "w" ? "Black" : "White"} can reply {review.risk.san}
              {review.risk.captured ? ` and take your ${PIECE_WORD[review.risk.captured] ?? "piece"}.` : "."} The
              computer has not replied yet.
              <span className="btnrow" style={{ marginTop: 10 }}>
                <button className="btn btn--primary btn--sm" onClick={() => setWhyOpen(true)}>
                  Show me why
                </button>
                <button className="btn btn--sm" onClick={takeBack}>Take it back</button>
                <button className="btn btn--ghost btn--sm" onClick={keepMove}>{t.btnKeepMove}</button>
              </span>
            </span>
          </div>
        )}

        {/* A small, non-serious cost: say it once, do not take over */}
        {!holding && review?.risk && !serious && review.legal && review.fenAfter === game.fen && !over && (
          <p className="pill pill--warn" style={{ whiteSpace: "normal", marginBottom: 10 }}>
            {game.humanSide === "w" ? "Black" : "White"} can win a pawn with {review.risk.san}. That is sometimes a
            fair price for a good move, so the coach is not calling it a mistake.{" "}
            <button className="linkbtn" onClick={() => setWhyOpen(true)}>Have a look</button>
          </p>
        )}

        {/* The sound move — offer the comparison without nagging */}
        {!holding && review && !review.risk && review.legal && !over && (
          <p className="pill pill--ok" style={{ whiteSpace: "normal", marginBottom: 10 }}>
            {t.noPunishment}{" "}
            <button className="linkbtn" onClick={() => setWhyOpen(true)}>{t.compareOthers}</button>
          </p>
        )}

        {focusMode ? (
          <div className="card">
            <strong>Focus mode</strong>
            <p className="small muted" style={{ marginTop: 5 }}>
              All hints and highlights are hidden. Just you and the board.
            </p>
          </div>
        ) : (
          <div className="card">
            {/* 2. a verified threat, or an honest nothing */}
            {card?.threat.present && card.threat.threat ? (
              <p className="sect__p" style={{ marginTop: 0 }}>
                <strong>{t.careful}</strong>{" "}
                {card.threat.threat.kind === "mate"
                  ? t.threatMate
                  : card.threat.threat.kind === "check"
                    ? t.threatCheck
                    : t.threatCapture(card.threat.threat.san)}
              </p>
            ) : card ? (
              <p className="sect__p" style={{ marginTop: 0 }}>
                <strong>No immediate winning threat established.</strong> This bounded check is not proof that every piece is safe.
              </p>
            ) : null}

            {/* 4. the question — the learner moves first */}
            <h2 className="ask">{t.whatWouldYouPlay}</h2>
            <p className="small muted" style={{ marginTop: 4 }}>
              {isHumanTurn
                ? t.howToMove
                : t.waitForReply}
            </p>

            {card && isHumanTurn && <DiscoveryPanel key={`${game.generation}:${game.fen}`} fen={game.fen} positionId={game.generation} onLook={setLook} onExplore={line => setRehearsal({fen: game.fen, line})} />}

            {/* 5-6. progressive hints */}
            {coach.status === "thinking" && !card && (
              <p className="small muted" style={{ marginTop: 10 }}>The coach is checking the position…</p>
            )}

            {card?.suggestion && isHumanTurn && (
              <div className="hints">
                {hint >= 1 && (
                  <p className="hintline">
                    <span className="hintline__n">{t.hint1}</span>
                    {t.hint1Text(t.pieces[card.suggestion.pieceType] ?? "piece")}
                  </p>
                )}
                {hint >= 2 && (
                  <p className="hintline">
                    <span className="hintline__n">{t.hint2}</span>
                    {t.hint2Text(card.suggestion.from)}
                  </p>
                )}
                {hint >= 3 && (
                  <>
                    <p className="hintline hintline--answer">
                      <span className="hintline__n">{t.moveLabel}</span>
                      {t.moveText(
                        t.pieces[card.suggestion.pieceType] ?? "piece",
                        card.suggestion.from,
                        card.suggestion.to,
                      )}
                      {card.suggestion.isCapture && card.suggestion.captured
                        ? ` It takes the ${PIECE_WORD[card.suggestion.captured] ?? "piece"}.`
                        : ""}
                    </p>
                    {/* 7. why it helps */}
                    <p className="hintline">
                      <span className="hintline__n">{t.whyLabel}</span>
                      {reasonSentence(card.reason?.key, card.suggestion.severalSound)}
                    </p>
                    {coachTrick(card.reason?.key) && (
                      <p className="trick">
                        <span className="trick__label">{t.rememberLabel}</span>
                        <span className="trick__text">{coachTrick(card.reason?.key)}</span>
                      </p>
                    )}
                    {/* 8. one verified reply only */}
                    {card.future && card.future.lines[0] ? (
                      <p className="hintline">
                        <span className="hintline__n">{t.thenLabel}</span>
                        If the computer answers {card.future.lines[0].theirMove.san}, that is legal and expected. It
                        is not the only possible answer.
                      </p>
                    ) : (
                      <p className="hintline">
                        <span className="hintline__n">{t.thenLabel}</span>
                        The coach will not guess the computer's answer here.
                      </p>
                    )}
                  </>
                )}

                <div className="btnrow" style={{ marginTop: 10 }}>
                  {hint < 3 && (
                    <button className="btn btn--sm" onClick={() => setHint((h) => Math.min(3, h + 1))}>
                      {hint === 0 ? `💡 ${t.btnHint1}` : hint === 1 ? `💡 ${t.btnHint2}` : `💡 ${t.btnMore}`}
                    </button>
                  )}
                  {hint < 3 && (
                    <button className="btn btn--primary btn--sm" onClick={showOneMove}>
                      {t.btnShowMove}
                    </button>
                  )}
                  {hint >= 3 && (
                    <button className="btn btn--sm" onClick={() => setHint(0)}>{t.btnHideAnswer}</button>
                  )}
                </div>
                <p className="small muted" style={{ marginTop: 8 }}>
                  {t.hintsDoNotCount}
                </p>
              </div>
            )}

            {card?.suggestion && isHumanTurn && (
              <p className="evidence" role="note">
                <span className="evidence__dot" aria-hidden="true" />
                {card.suggestion.source === "engine" ? t.sourceEngine : t.sourceRules}
                {useStockfish && engine.fallbackVisible
                  ? " The engine could not be loaded, so the built-in rules were used instead."
                  : useStockfish && card.suggestion.source !== "engine"
                    ? " The engine has not finished with this position yet."
                    : ""}
              </p>
            )}

            {card && !card.suggestion && !over && (
              <p className="small muted" style={{ marginTop: 10 }}>
                The coach has nothing it can prove here, so it is not suggesting anything.
              </p>
            )}

            {/* 10. transfer */}
            <button className="btn btn--ghost btn--sm" style={{ marginTop: 14 }} onClick={onOpenLessons}>
              {t.practiseInLesson}
            </button>
          </div>
        )}

        <DifficultyPanel />
        <p className="small muted" aria-live="polite">{game.mode === "solo" ? "Local two-player mode — computer strength has no effect." : game.mode === "watch" ? "Watch mode — computer plays both sides." : "Computer mode: one legal reply per turn."}</p>
        {game.mode !== "vsComputer" && <button className="btn" onClick={() => { game.setHumanSide("w"); game.setMode("vsComputer"); }}>Use computer coaching — you play White</button>}
        {game.mode !== "solo" && <p className="small muted" aria-live="polite">{opponent.thinking ? `Computer ${difficulty.computer}: ${opponent.status === "loading" ? "loading Stockfish…" : "thinking…"}` : opponent.source === "stockfish" ? "Last computer reply: Stockfish" : opponent.source === "rules-only" ? "Last computer reply: rules-only fallback (not the selected Stockfish strength)." : `Computer ${difficulty.computer}: ready for its next turn.`}</p>}
        {opponent.message && <details><summary>Computer engine status</summary><p className="small muted">{opponent.message}</p></details>}

        {!coach.workerOk && (
          <p className="pill pill--warn" style={{ marginTop: 8, whiteSpace: "normal" }}>
            Background worker not available in this browser — the coach runs on the main thread and may feel slower.
          </p>
        )}
      </div>
    </div>
  );
}

function reasonSentence(key: string | undefined, severalSound: boolean): string {
  if (severalSound) return "The bounded search found several comparable moves; this is one legal idea.";
  switch (key) {
    case "mate":
      return "It is checkmate — the game ends.";
    case "escapeCheck":
      return "It gets your king out of check, which you must do.";
    case "savesPiece":
      return "It moves your piece out of danger.";
    case "safeCapture":
      return "It wins a piece and you keep it.";
    case "defendsPiece":
      return "It defends a piece that was not protected.";
    case "castleSafety":
      return "It tucks your king away safely.";
    case "develops":
      return "It brings a piece out so it can help.";
    case "controlsCenter":
      return "It takes space in the middle of the board.";
    default:
      return "It is a legal option. A stronger comparison has not been established.";
  }
}
