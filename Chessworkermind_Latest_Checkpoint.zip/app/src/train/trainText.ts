/**
 * Wording for the guided Train screen and "Why not my move?".
 *
 * Only languages listed in TRAIN_LANGUAGES have real, written wording. For
 * every other language we return English AND set `fallback`, so the UI can
 * say plainly that the coach's words are still English. We never pretend a
 * translation exists.
 */

export type TrainLang = "en" | "hi";

export const TRAIN_LANGUAGES: TrainLang[] = ["en", "hi"];

export function hasTrainWording(tag: string): boolean {
  return (TRAIN_LANGUAGES as string[]).includes(tag);
}

type Pack = {
  title: string;
  lessons: string;
  youMoveFirst: (side: string) => string;
  computerThinking: string;
  computerAbout: string;
  whatWouldYouPlay: string;
  howToMove: string;
  waitForReply: string;
  calm: string;
  careful: string;
  threatMate: string;
  threatCheck: string;
  threatCapture: (san: string) => string;
  hint1: string;
  hint2: string;
  moveLabel: string;
  whyLabel: string;
  thenLabel: string;
  hint1Text: (piece: string) => string;
  hint2Text: (square: string) => string;
  moveText: (piece: string, from: string, to: string) => string;
  btnHint1: string;
  btnHint2: string;
  btnMore: string;
  btnShowMove: string;
  btnHideAnswer: string;
  btnTryAgain: string;
  btnUndo: string;
  btnNewGame: string;
  btnFocus: string;
  hintsDoNotCount: string;
  practiseInLesson: string;
  rememberLabel: string;
  sourceEngine: string;
  sourceRules: string;
  offlineNote: string;
  /* why-not-my-move */
  whyTitle: string;
  sideWants: (side: string) => string;
  shouldNotice: string;
  tryThisMove: string;
  whyItHelps: string;
  mightDoNext: (side: string) => string;
  whyRisky: string;
  rewindCompare: string;
  btnPlaySuggested: string;
  btnKeepMove: string;
  heldBack: string;
  noPunishment: string;
  compareOthers: string;
  white: string;
  black: string;
  pieces: Record<string, string>;
};

const EN: Pack = {
  title: "What's your move?",
  lessons: "Lessons",
  youMoveFirst: (side) => `You are ${side}. You move first.`,
  computerThinking: "The computer is thinking…",
  computerAbout: "The computer is about to move.",
  whatWouldYouPlay: "What would you play?",
  howToMove: "Tap one of your pieces, then tap where you want it to go. Take your time — nothing moves on its own.",
  waitForReply: "Wait for the computer's one reply.",
  calm: "No immediate winning threat was established by this bounded check.",
  careful: "Careful:",
  threatMate: "the computer is threatening checkmate next move.",
  threatCheck: "your king is in check — you must answer it.",
  threatCapture: (san) => `the computer is threatening ${san}, which wins material.`,
  hint1: "Hint 1",
  hint2: "Hint 2",
  moveLabel: "Move",
  whyLabel: "Why",
  thenLabel: "Then",
  hint1Text: (piece) => `Think about your ${piece}.`,
  hint2Text: (square) => `It is the one on ${square}. Where can it go that helps?`,
  moveText: (piece, from, to) => `Move your ${piece} from ${from} to ${to}.`,
  btnHint1: "Hint 1",
  btnHint2: "Hint 2",
  btnMore: "More",
  btnShowMove: "Show one move",
  btnHideAnswer: "Hide the answer",
  btnTryAgain: "Try again",
  btnUndo: "Undo",
  btnNewGame: "New game",
  btnFocus: "Focus mode",
  hintsDoNotCount:
    "The move is only ever named. You still have to play it yourself — and a hinted answer does not count as doing it on your own.",
  practiseInLesson: "Practise this idea in a lesson →",
  rememberLabel: "Remember",
  sourceEngine: "Checked with the chess engine running on your phone.",
  sourceRules:
    "This comes from the built-in rules, not the full chess engine. Every move is still checked on the real board. You can switch the engine on in Settings.",
  offlineNote:
    "You are offline. The board, your saved game, the lessons and the coach all still work — everything runs on your phone. Only signing in and buying need the internet.",
  whyTitle: "Why not my move?",
  sideWants: (side) => `What ${side} can legally do`,
  shouldNotice: "What you should notice",
  tryThisMove: "Try this move",
  whyItHelps: "Why it helps",
  mightDoNext: (side) => `What ${side} might do next`,
  whyRisky: "Why your move was risky",
  rewindCompare: "Let's rewind and compare",
  btnPlaySuggested: "Explore suggested move",
  btnKeepMove: "Keep my move",
  heldBack: "Hold on — that move can be punished.",
  noPunishment: "Good — the coach cannot find a way to punish that move.",
  compareOthers: "Compare it with other moves",
  white: "White",
  black: "Black",
  pieces: { p: "pawn", n: "knight", b: "bishop", r: "rook", q: "queen", k: "king" },
};

const HI: Pack = {
  title: "आपकी चाल क्या है?",
  lessons: "पाठ",
  youMoveFirst: (side) => `आप ${side} हैं। पहली चाल आपकी है।`,
  computerThinking: "कंप्यूटर सोच रहा है…",
  computerAbout: "कंप्यूटर अभी चाल चलेगा।",
  whatWouldYouPlay: "आप क्या खेलेंगे?",
  howToMove: "अपना कोई मोहरा छुएँ, फिर उस खाने को छुएँ जहाँ भेजना है। जल्दी नहीं — कुछ भी अपने आप नहीं चलेगा।",
  waitForReply: "कंप्यूटर की एक चाल का इंतज़ार करें।",
  calm: "आपका कुछ भी खतरे में नहीं है, जहाँ तक कोच जाँच सका। यह शांत पल है।",
  careful: "ध्यान दें:",
  threatMate: "कंप्यूटर अगली चाल में शह-मात की धमकी दे रहा है।",
  threatCheck: "आपके राजा को शह है — इसका जवाब देना ज़रूरी है।",
  threatCapture: (san) => `कंप्यूटर ${san} की धमकी दे रहा है, जिससे उसे मोहरा मिल जाएगा।`,
  hint1: "संकेत 1",
  hint2: "संकेत 2",
  moveLabel: "चाल",
  whyLabel: "क्यों",
  thenLabel: "फिर",
  hint1Text: (piece) => `अपने ${piece} के बारे में सोचें।`,
  hint2Text: (square) => `वह ${square} पर है। यह कहाँ जाकर मदद कर सकता है?`,
  moveText: (piece, from, to) => `अपना ${piece} ${from} से ${to} पर ले जाएँ।`,
  btnHint1: "संकेत 1",
  btnHint2: "संकेत 2",
  btnMore: "और",
  btnShowMove: "एक चाल दिखाएँ",
  btnHideAnswer: "उत्तर छिपाएँ",
  btnTryAgain: "फिर कोशिश करें",
  btnUndo: "वापस लें",
  btnNewGame: "नया खेल",
  btnFocus: "फोकस मोड",
  hintsDoNotCount:
    "चाल सिर्फ़ बताई जाती है। खेलना आपको ही है — और संकेत लेकर किया गया काम 'अपने आप किया' नहीं गिना जाता।",
  practiseInLesson: "इस विचार का अभ्यास एक पाठ में करें →",
  rememberLabel: "याद रखें",
  sourceEngine: "आपके फ़ोन पर चल रहे शतरंज इंजन से जाँचा गया।",
  sourceRules:
    "यह पूरे शतरंज इंजन से नहीं, ऐप के अपने नियमों से आया है। फिर भी हर चाल असली बोर्ड पर जाँची जाती है। सेटिंग्स में इंजन चालू कर सकते हैं।",
  offlineNote:
    "आप ऑफ़लाइन हैं। बोर्ड, आपका सहेजा हुआ खेल, पाठ और कोच — सब चलते रहेंगे, क्योंकि सब कुछ आपके फ़ोन पर ही चलता है। सिर्फ़ साइन-इन और ख़रीदारी के लिए इंटरनेट चाहिए।",
  whyTitle: "मेरी चाल क्यों नहीं?",
  sideWants: (side) => `${side} क्या चाहता है`,
  shouldNotice: "आपको क्या देखना चाहिए",
  tryThisMove: "यह चाल आज़माएँ",
  whyItHelps: "यह कैसे मदद करती है",
  mightDoNext: (side) => `${side} आगे क्या कर सकता है`,
  whyRisky: "आपकी चाल जोखिम भरी क्यों थी",
  rewindCompare: "चलिए पीछे जाकर तुलना करें",
  btnPlaySuggested: "सुझाई गई चाल खेलें",
  btnKeepMove: "मेरी चाल रहने दें",
  heldBack: "रुकिए — इस चाल की सज़ा मिल सकती है।",
  noPunishment: "अच्छा — कोच को इस चाल को दंडित करने का कोई तरीका नहीं मिला।",
  compareOthers: "दूसरी चालों से तुलना करें",
  white: "सफ़ेद",
  black: "काला",
  pieces: { p: "प्यादा", n: "घोड़ा", b: "ऊँट", r: "हाथी", q: "वज़ीर", k: "राजा" },
};

const PACKS: Record<TrainLang, Pack> = { en: EN, hi: HI };

export type TrainText = Pack & { fallback: string | null };

export function trainText(tag: string, languageName?: string): TrainText {
  if (hasTrainWording(tag)) {
    return { ...PACKS[tag as TrainLang], fallback: null };
  }
  return {
    ...EN,
    fallback: `Training wording is not written in ${languageName ?? tag} yet — showing English. The chess facts are the same.`,
  };
}
