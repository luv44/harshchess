/**
 * The whole app was written for a phone and then looked at on a laptop,
 * where a single column of full-width cards reads as one long ribbon and
 * paragraphs run to 160 characters a line. That was not caught for a long
 * time because nobody here can open a browser.
 *
 * These tests make the wide-screen layout a requirement rather than an
 * afterthought, and are checked against the real stylesheet and the real
 * components.
 */
import { describe, expect, it } from "vitest";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { resolve, join } from "node:path";

const SRC = resolve(__dirname, "..");
const CSS = readFileSync(resolve(SRC, "styles/coach.css"), "utf8");

function allTsx(dir: string): string[] {
  return readdirSync(dir).flatMap((e) => {
    const p = join(dir, e);
    if (statSync(p).isDirectory()) return e === "__tests__" ? [] : allTsx(p);
    return p.endsWith(".tsx") ? [p] : [];
  });
}

/** The text of every `@media (min-width: …)` block, joined. */
const WIDE = [...CSS.matchAll(/@media\s*\(min-width:[^)]*\)\s*\{([\s\S]*?)\n\}/g)]
  .map((m) => m[1])
  .join("\n");

describe("every full screen has a wide-screen layout", () => {
  it.each([
    ["playgrid", "Train and Games"],
    ["brainpage", "Progress"],
    ["homepage", "Home"],
    ["lessonspage", "the lesson journey"],
    ["splitpage", "Review and Why not my move"],
  ])("%s (%s) lays out differently on a big screen", (cls) => {
    expect(WIDE, `.${cls} has no wide-screen rule`).toMatch(new RegExp(`\\.${cls}\\b`));
  });

  it("each of those page roots is actually used by a component", () => {
    const markup = allTsx(SRC).map((f) => readFileSync(f, "utf8")).join("\n");
    for (const cls of ["playgrid", "brainpage", "homepage", "lessonspage", "splitpage"]) {
      expect(markup, `.${cls} is styled but never rendered`).toMatch(new RegExp(`className="[^"]*\\b${cls}\\b`));
    }
  });
});

describe("text stays readable however wide the window is", () => {
  it("caps the line length of prose inside cards", () => {
    expect(CSS).toMatch(/max-width:\s*\d+ch/);
    const rule = CSS.slice(CSS.indexOf("READABILITY ON A WIDE SCREEN"));
    expect(rule).toMatch(/:where\(p, li, \.sect__p, \.small\)/);
    const ch = /max-width:\s*(\d+)ch/.exec(rule)?.[1];
    expect(Number(ch)).toBeGreaterThan(45); // not so narrow it looks silly
    expect(Number(ch)).toBeLessThanOrEqual(80); // not so wide it is hard to read
  });

  it("never sets a width in px on a page container", () => {
    for (const cls of ["screen", "homepage", "brainpage", "splitpage", "lessonspage"]) {
      const i = CSS.indexOf(`.${cls} {`);
      if (i < 0) continue;
      const rule = CSS.slice(i, CSS.indexOf("}", i));
      expect(rule, `.${cls} should not be a fixed pixel width`).not.toMatch(/(?<!max-)width:\s*\d+px/);
    }
  });
});

describe("the sticky board column points at the real element", () => {
  it("targets .boardwrap, which is what the Board component renders", () => {
    const board = readFileSync(resolve(SRC, "chess/Board.tsx"), "utf8");
    expect(board).toMatch(/className="boardwrap"/);
    expect(WIDE).toMatch(/\.splitpage > \.boardwrap/);
    // and not the inner frame, which would never match
    expect(WIDE).not.toMatch(/\.splitpage > \.boardframe/);
  });
});
