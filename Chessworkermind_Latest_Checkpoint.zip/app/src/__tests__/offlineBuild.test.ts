/**
 * Does the built app actually work with the network unplugged?
 *
 * A service worker can be perfect and the app can still break offline if the
 * build pulls a font, a script or an icon from someone else's server. This
 * reads the real `dist/` output and refuses to let that happen.
 *
 * Run `npm run build` first. Without dist/ these tests skip loudly rather
 * than pretending to pass.
 */
import { describe, expect, it } from "vitest";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { resolve } from "node:path";

const DIST = resolve(__dirname, "../../dist");
const hasDist = existsSync(resolve(DIST, "index.html"));

describe.skipIf(!hasDist)("the built app is self-contained", () => {
  const html = hasDist ? readFileSync(resolve(DIST, "index.html"), "utf8") : "";

  it("pulls nothing from another server", () => {
    // every src=, href= and import that points at http(s):// or //
    const external = [...html.matchAll(/(?:src|href)\s*=\s*"([^"]+)"/g)]
      .map((m) => m[1])
      .filter((u) => /^(https?:)?\/\//.test(u));
    expect(external, `index.html loads from outside: ${external.join(", ")}`).toEqual([]);
  });

  it("ships every file index.html asks for", () => {
    // Paths are relative now so the build travels to any sub-folder, so
    // accept "./x" as well as "/x".
    const local = [...html.matchAll(/(?:src|href)\s*=\s*"(\.?\/[^"]+)"/g)].map((m) => m[1]);
    expect(local.length).toBeGreaterThan(0);
    for (const rel of local) {
      const onDisk = rel.replace(/^\.?\//, "");
      expect(existsSync(resolve(DIST, onDisk)), `${rel} is referenced but missing from dist/`).toBe(true);
    }
  });

  it("ships the service worker, the manifest and the icons", () => {
    for (const f of ["sw.js", "manifest.webmanifest"]) {
      expect(existsSync(resolve(DIST, f)), `${f} missing from dist/`).toBe(true);
    }
    const manifest = JSON.parse(readFileSync(resolve(DIST, "manifest.webmanifest"), "utf8"));
    expect(manifest.icons.length).toBeGreaterThan(0);
    for (const icon of manifest.icons) {
      const p = icon.src.startsWith("/") ? icon.src.slice(1) : icon.src;
      expect(existsSync(resolve(DIST, p)), `icon ${icon.src} is in the manifest but missing from dist/`).toBe(true);
    }
    expect(manifest.start_url).toBeTruthy();
    expect(manifest.display).toMatch(/standalone|fullscreen|minimal-ui/);
  });

  it("ships the chess engine files the app offers to use", () => {
    const sf = resolve(DIST, "stockfish");
    expect(existsSync(sf), "dist/stockfish missing — the opt-in engine would 404").toBe(true);
    const files = readdirSync(sf);
    expect(files.some((f) => f.endsWith(".wasm"))).toBe(true);
    expect(files.some((f) => f.endsWith(".js"))).toBe(true);
  });

  it("keeps the shell the service worker caches in step with what was built", () => {
    const sw = readFileSync(resolve(DIST, "sw.js"), "utf8");
    const shell = [...sw.matchAll(/"(\/[^"]*)"/g)].map((m) => m[1]).filter((u) => u !== "/" && !u.includes("*"));
    for (const rel of shell) {
      // only check real file paths, not path prefixes like /assets/
      if (rel.endsWith("/")) continue;
      expect(existsSync(resolve(DIST, rel.slice(1))), `sw.js pre-caches ${rel}, which is not in dist/`).toBe(true);
    }
  });

  it("can be served from a sub-folder, not only from a domain root", () => {
    // Most free hosts serve a project at /something/. With Vite's default
    // base the build referenced /assets/... absolutely and broke there.
    const abs = [...html.matchAll(/(?:src|href)\s*=\s*"(\/[^"/][^"]*)"/g)].map((m) => m[1]);
    expect(abs, `these only work at a domain root: ${abs.join(", ")}`).toEqual([]);

    const rel = [...html.matchAll(/(?:src|href)\s*=\s*"(\.\/[^"]+)"/g)].map((m) => m[1]);
    expect(rel.length, "assets should be referenced relatively").toBeGreaterThan(0);
    for (const r of rel) {
      expect(existsSync(resolve(DIST, r.replace(/^\.\//, ""))), `${r} missing from dist/`).toBe(true);
    }

    // the manifest and the service worker have to travel too
    const manifest = JSON.parse(readFileSync(resolve(DIST, "manifest.webmanifest"), "utf8"));
    expect(manifest.start_url).not.toMatch(/^\//);
    expect(manifest.scope).not.toMatch(/^\//);
    for (const icon of manifest.icons) expect(icon.src).not.toMatch(/^\//);

    const sw = readFileSync(resolve(DIST, "sw.js"), "utf8");
    expect(sw, "the worker must resolve its own paths, not assume a root").toMatch(/new URL\("\.\/", self\.location\.href\)/);
  });

  it("does not ship a source map that leaks the whole codebase", () => {
    const assets = readdirSync(resolve(DIST, "assets"));
    expect(assets.filter((f) => f.endsWith(".map"))).toEqual([]);
  });
});

describe.skipIf(hasDist)("offline build checks", () => {
  it("were skipped because dist/ does not exist — run npm run build", () => {
    expect(hasDist).toBe(false);
  });
});
