/**
 * The guided training loop, driven through the real UI in jsdom.
 *
 * This is the experience the whole product is about, so it is tested as a
 * beginner would use it: open Train, see what Black did, ask for hints in
 * order, play a move, and be shown honestly when a move can be punished.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor, within, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { SESSION_KEY } from "../chess/session";

const ONBOARD_KEY = "chessworkermind:onboarded:v2";
const START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
/** White queen on c1 can step to c4, where the d5 pawn simply takes it. */
const FREE_QUEEN = "4k3/8/8/3p4/8/8/8/2Q1K3 w - - 0 1";

function seed(fen: string) {
  localStorage.setItem(ONBOARD_KEY, "1");
  localStorage.setItem(
    SESSION_KEY,
    JSON.stringify({ fen, pgn: "", orientation: "w", mode: "vsComputer", humanSide: "w", savedAt: Date.now() }),
  );
}

function square(id: string) {
  return screen.getByRole("gridcell", { name: new RegExp(`^${id},`) });
}

/** Where the pieces are, ignoring coaching state that lands asynchronously. */
function piecePlacement() {
  return screen
    .getAllByRole("gridcell")
    .map((el) => (el.getAttribute("aria-label") ?? "").split(",").slice(0, 2).join(","));
}

async function openTrain(user: ReturnType<typeof userEvent.setup>) {
  await user.click(
    within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^train$/i }),
  );
}

async function wait(ms: number) {
  await act(async () => {
    await new Promise((r) => setTimeout(r, ms));
  });
}

describe("Train — What's your move?", () => {
  beforeEach(() => localStorage.clear());

  it("opens on the guided game with a playable board and the learner to move", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await openTrain(user);

    expect(screen.getByRole("heading", { name: /what's your move\?/i })).toBeTruthy();
    expect(screen.getByRole("grid", { name: /chess board/i })).toBeTruthy();
    expect(await screen.findByText(/What would you play\?/i)).toBeTruthy();
    expect(screen.getByText(/You are White\. You move first\./i)).toBeTruthy();
  });

  it("does not move a single piece by itself", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await openTrain(user);

    const before = piecePlacement();
    await wait(1600);
    expect(piecePlacement()).toEqual(before);
  });

  it("plays exactly one Black reply and says in words what Black did", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await openTrain(user);

    await user.click(square("e2"));
    await user.click(square("e4"));

    // one reply arrives and it is described in plain words, with real squares
    const chip = await screen.findByText(/Black moved the \w+ from [a-h][1-8] to [a-h][1-8]/i, {}, { timeout: 8000 });
    expect(chip).toBeTruthy();

    // …and then the board stops. Nothing else moves.
    const after = piecePlacement();
    await wait(1600);
    expect(piecePlacement()).toEqual(after);
  });

  it("gives hints in order and never plays the move for you", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await openTrain(user);

    await screen.findByRole("button", { name: /hint 1/i }, { timeout: 8000 });
    const before = screen.getAllByRole("gridcell").map((el) => (el.getAttribute("aria-label") ?? "").split(",").slice(0, 2).join(","));

    await user.click(screen.getByRole("button", { name: /hint 1/i }));
    // hint 1 names a piece but not a square
    const h1 = screen.getByText(/Think about your (pawn|knight|bishop|rook|queen|king)/i);
    expect(h1.textContent).not.toMatch(/[a-h][1-8]/);

    await user.click(screen.getByRole("button", { name: /hint 2/i }));
    expect(screen.getByText(/It is the one on [a-h][1-8]/i)).toBeTruthy();

    await user.click(screen.getByRole("button", { name: /show one move/i }));
    // the answer is given in WORDS, not notation only
    expect(screen.getByText(/Move your (pawn|knight|bishop|rook|queen|king) from [a-h][1-8] to [a-h][1-8]/i)).toBeTruthy();
    // and one reason
    expect(screen.getByText(/^Why$/)).toBeTruthy();

    // the pieces have not moved — the learner still has to play it
    const after = screen.getAllByRole("gridcell").map((el) => (el.getAttribute("aria-label") ?? "").split(",").slice(0, 2).join(","));
    expect(after).toEqual(before);
    // …but the board now points at the move
    expect(screen.getAllByRole("gridcell").some((el) => /step 1/.test(el.getAttribute("aria-label") ?? ""))).toBe(true);
  });
});

describe("Why not my move?", () => {
  beforeEach(() => localStorage.clear());

  it("holds a provably losing move back before the computer can reply", async () => {
    const user = userEvent.setup();
    seed(FREE_QUEEN);
    render(<App />);
    await openTrain(user);

    await user.click(square("c1"));
    await user.click(square("c4"));

    expect(await screen.findByText(/that move can be punished/i)).toBeTruthy();
    expect(screen.getByText(/can reply dxc4/i)).toBeTruthy();

    // the computer has NOT taken the queen — the learner still owns the turn
    await wait(1500);
    expect(square("c4").getAttribute("aria-label")).toMatch(/White queen/i);
  });

  it("explains the punishment on the position the learner moved from", async () => {
    const user = userEvent.setup();
    seed(FREE_QUEEN);
    render(<App />);
    await openTrain(user);
    await user.click(square("c1"));
    await user.click(square("c4"));
    await user.click(await screen.findByRole("button", { name: /show me why/i }));

    expect(await screen.findByRole("heading", { name: /why not my move\?/i })).toBeTruthy();
    // the six plain sections
    for (const h of [/What Black can legally do/i, /What you should notice/i, /Try this move/i, /Why it helps/i, /What Black might do next/i, /Why your move was risky/i]) {
      expect(screen.getByRole("heading", { name: h })).toBeTruthy();
    }
    // it rewinds: the queen is back on c1 in the picture
    expect(square("c1").getAttribute("aria-label")).toMatch(/White queen/i);
    // and it says how it knows, rather than asserting
    expect(screen.getByText(/playing the whole exchange out on the board, not by guessing/i)).toBeTruthy();
  });

  it("'Try again' puts the position back exactly as it was", async () => {
    const user = userEvent.setup();
    seed(FREE_QUEEN);
    render(<App />);
    await openTrain(user);
    await user.click(square("c1"));
    await user.click(square("c4"));
    await user.click(await screen.findByRole("button", { name: /take it back/i }));

    await waitFor(() => expect(square("c1").getAttribute("aria-label")).toMatch(/White queen/i));
    expect(square("c4").getAttribute("aria-label")).toMatch(/empty/i);
    expect(screen.queryByText(/that move can be punished/i)).toBeNull();
  });

  it("exploring a suggested move replays legally without rewriting the original saved game", async () => {
    const user = userEvent.setup();
    seed(FREE_QUEEN);
    render(<App />);
    await openTrain(user);
    await user.click(square("c1"));
    await user.click(square("c4"));
    await user.click(await screen.findByRole("button", { name: /show me why/i }));
    const saved = localStorage.getItem("chessworkermind:game:v2");
    await user.click(await screen.findByRole("button", { name: /explore suggested move/i }));
    await user.click(await screen.findByRole("button", { name: /next move/i }));
    expect(localStorage.getItem("chessworkermind:game:v2")).toBe(saved);

    // the isolated branch no longer has the queen hanging on c4
    await waitFor(() => expect(square("c4").getAttribute("aria-label")).not.toMatch(/White queen/i), { timeout: 4000 });
    // the white queen is still on the board somewhere
    await waitFor(() =>
      expect(screen.getAllByRole("gridcell").some((el) => /White queen/i.test(el.getAttribute("aria-label") ?? ""))).toBe(true),
    );
  });

  it("does not accuse a reasonable move", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await openTrain(user);

    await user.click(square("e2"));
    await user.click(square("e4"));

    expect(screen.queryByText(/that move can be punished/i)).toBeNull();
    expect(await screen.findByText(/cannot find a way to punish that move/i)).toBeTruthy();
  });
});

describe("Hindi on the training screen", () => {
  beforeEach(() => localStorage.clear());

  it("shows the guided screen in Hindi when Hindi is chosen", async () => {
    const user = userEvent.setup();
    seed(START);
    localStorage.setItem("cwm:lang", "hi");
    render(<App />);
    await openTrain(user);

    // If the app did not pick the saved tag, set it through the real picker.
    if (!screen.queryByRole("heading", { name: /आपकी चाल क्या है\?/ })) {
      await user.click(screen.getByRole("button", { name: /settings and language/i }));
      const picker = await screen.findByRole("region", { name: /language picker/i });
      await user.click(within(picker).getByRole("option", { name: /हिन्दी/ }));
      await openTrain(user);
    }

    expect(screen.getByRole("heading", { name: /आपकी चाल क्या है\?/ })).toBeTruthy();
    expect(await screen.findByText(/आप क्या खेलेंगे\?/)).toBeTruthy();
    // and no "not translated" notice, because this one really is translated
    expect(screen.queryByText(/not written in .* yet/i)).toBeNull();
  });

  it("says plainly when the training wording is not translated", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await user.click(screen.getByRole("button", { name: /settings and language/i }));
    const picker = await screen.findByRole("region", { name: /language picker/i });
    await user.click(within(picker).getByRole("option", { name: /日本語/ }));
    await openTrain(user);

    expect(await screen.findByText(/not written in .* yet/i)).toBeTruthy();
    // English is still shown, so the screen is never blank
    expect(screen.getByRole("heading", { name: /what's your move\?/i })).toBeTruthy();
  });
});

describe("offline and where the advice came from", () => {
  beforeEach(() => localStorage.clear());

  it("says what still works when the phone has no internet", async () => {
    const user = userEvent.setup();
    seed(START);
    const spy = vi.spyOn(navigator, "onLine", "get").mockReturnValue(true);
    render(<App />);
    await openTrain(user);

    expect(screen.queryByText(/You are offline/i)).toBeNull();

    spy.mockReturnValue(false);
    await act(async () => {
      window.dispatchEvent(new Event("offline"));
    });

    const note = await screen.findByText(/You are offline/i);
    expect(note.textContent).toMatch(/board, your saved game, the lessons and the coach all still work/i);
    expect(note.textContent).toMatch(/Only signing in and buying need the internet/i);
    // the board is still fully playable
    await user.click(square("e2"));
    await user.click(square("e4"));
    expect(square("e4").getAttribute("aria-label")).toMatch(/White pawn/i);
    spy.mockRestore();
  });

  it("never claims engine backing it does not have", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await openTrain(user);

    const evidence = await screen.findByRole("note", {}, { timeout: 8000 });
    // Stockfish is off by default, so this must say rules — not "engine"
    expect(evidence.textContent).toMatch(/built-in rules, not the full chess engine/i);
    expect(evidence.textContent).toMatch(/still checked on the real board/i);
    expect(evidence.textContent).not.toMatch(/Checked with the chess engine/i);
  });
});

describe("the Stockfish setting is one choice for the whole app", () => {
  beforeEach(() => localStorage.clear());

  it("is off by default and says so in plain words", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await user.click(screen.getByRole("button", { name: /settings and language/i }));

    const group = await screen.findByRole("group", { name: /stockfish engine/i });
    expect(within(group).getByRole("button", { name: /rules only/i }).getAttribute("aria-pressed")).toBe("true");
    expect(within(group).getByRole("button", { name: /use the engine/i }).getAttribute("aria-pressed")).toBe("false");
    expect(screen.getByText(/only ever allowed to reorder moves the app has already verified/i)).toBeTruthy();
  });

  it("remembers the choice and applies it to the training screen", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await user.click(screen.getByRole("button", { name: /settings and language/i }));
    const group = await screen.findByRole("group", { name: /stockfish engine/i });
    await user.click(within(group).getByRole("button", { name: /use the engine/i }));

    expect(localStorage.getItem("cwm:stockfish")).toBe("1");
    expect(within(group).getByRole("button", { name: /use the engine/i }).getAttribute("aria-pressed")).toBe("true");

    // Training now tells the learner the engine has been asked but has not
    // answered — jsdom has no WebAssembly worker, which is exactly the
    // "engine unavailable" case a real phone can also hit.
    await openTrain(user);
    const evidence = await screen.findByRole("note", {}, { timeout: 8000 });
    expect(evidence.textContent).toMatch(/built-in rules|could not be loaded|has not finished/i);
    expect(evidence.textContent).not.toMatch(/^Checked with the chess engine[^.]*\.$/);
  });

  it("a broken engine never blocks the board or the coach", async () => {
    const user = userEvent.setup();
    localStorage.setItem("cwm:stockfish", "1");
    seed(START);
    render(<App />);
    await openTrain(user);

    // the coach still produced a full suggestion without the engine
    await user.click(await screen.findByRole("button", { name: /show one move/i }, { timeout: 8000 }));
    expect(screen.getByText(/Move your (pawn|knight|bishop|rook|queen|king) from [a-h][1-8] to [a-h][1-8]/i)).toBeTruthy();

    // and the board is fully playable
    await user.click(square("e2"));
    await user.click(square("e4"));
    expect(square("e4").getAttribute("aria-label")).toMatch(/White pawn/i);
  });
});

describe("the Remember line appears everywhere advice is given", () => {
  beforeEach(() => localStorage.clear());

  it("Train shows it with the revealed move", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await openTrain(user);

    await user.click(await screen.findByRole("button", { name: /show one move/i }, { timeout: 8000 }));

    const trick = document.querySelector(".trick");
    expect(trick, "Train must end its advice with a Remember line").toBeTruthy();
    expect(trick!.querySelector(".trick__label")!.textContent).toMatch(/remember/i);
    expect(trick!.querySelector(".trick__text")!.textContent!.length).toBeGreaterThan(20);
  });

  it("'Why not my move?' shows it under the reason", async () => {
    const user = userEvent.setup();
    seed(FREE_QUEEN);
    render(<App />);
    await openTrain(user);
    await user.click(square("c1"));
    await user.click(square("c4"));
    await user.click(await screen.findByRole("button", { name: /show me why/i }));

    await screen.findByRole("heading", { name: /why it helps/i });
    const trick = document.querySelector(".trick");
    expect(trick, "the reviewer must end its reason with a Remember line").toBeTruthy();
    expect(trick!.querySelector(".trick__text")!.textContent!.length).toBeGreaterThan(20);
  });

  it("is written in Hindi when Hindi is chosen", async () => {
    const user = userEvent.setup();
    seed(START);
    render(<App />);
    await user.click(screen.getByRole("button", { name: /settings and language/i }));
    const picker = await screen.findByRole("region", { name: /language picker/i });
    await user.click(within(picker).getByRole("option", { name: /हिन्दी/ }));
    await openTrain(user);
    await user.click(await screen.findByRole("button", { name: /एक चाल दिखाएँ/ }, { timeout: 8000 }));

    expect(document.querySelector(".trick__label")!.textContent).toBe("याद रखें");
  });
});

describe("every reason the reviewer can give has a Remember line", () => {
  it("covers the candidate reasons exactly", async () => {
    const { candidateTrick, CANDIDATE_TRICK_KEYS } = await import("../coach/coachTrick");
    const reasons = [
      "winsMaterial", "savesPiece", "escapeCheck", "givesMate",
      "develops", "controlsCentre", "keepsEverythingDefended",
    ];
    expect(new Set(CANDIDATE_TRICK_KEYS)).toEqual(new Set(reasons));
    for (const r of reasons) {
      const t = candidateTrick(r as never);
      expect(t, `no trick for ${r}`).toBeTruthy();
      expect(t!.length).toBeGreaterThan(20);
      expect(t!.length).toBeLessThanOrEqual(110);
    }
    expect(candidateTrick(undefined)).toBeNull();
    expect(candidateTrick("madeUp" as never)).toBeNull();
  });
});
