/**
 * Real-world checks the user asked for, in areas that break quietly:
 * castling, en passant, promotion, checkmate, stalemate, draw by material,
 * a game that is already over, and the language / right-to-left switch.
 *
 * These run against the real hooks and the real UI, not mocks.
 */
import { describe, expect, it } from "vitest";
import { act, render, renderHook, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Chess } from "chess.js";
import { useChessGame } from "../chess/useChessGame";
import { buildCoachCard } from "../coach/coachCard";
import { pickReply } from "../chess/opponentWorker";
import App from "../App";
import { SESSION_KEY } from "../chess/session";

const ONBOARD_KEY = "chessworkermind:onboarded:v2";

function seed(fen: string, mode: "solo" | "vsComputer" = "solo", humanSide: "w" | "b" = "w") {
  localStorage.setItem(ONBOARD_KEY, "yes");
  localStorage.setItem(
    SESSION_KEY,
    JSON.stringify({ fen, pgn: "", mode, humanSide, orientation: humanSide, savedAt: Date.now() }),
  );
}

describe("special chess rules on the real board", () => {
  it("lets White castle short and moves both king and rook", () => {
    seed("r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/2N2N2/PPPP1PPP/R1BQK2R w KQkq - 0 1");
    const { result } = renderHook(() => useChessGame());
    expect(result.current.getLegalTargets("e1")).toContain("g1");
    act(() => {
      result.current.tryMove("e1", "g1");
    });
    expect(result.current.fen.split(" ")[0]).toContain("R1BQ1RK1");
    expect(result.current.lastRawMove?.san).toBe("O-O");
  });

  it("plays en passant and removes the captured pawn from its own square", () => {
    seed("4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 2");
    const { result } = renderHook(() => useChessGame());
    expect(result.current.getLegalTargets("e5")).toContain("d6");
    act(() => {
      result.current.tryMove("e5", "d6");
    });
    // the black pawn stood on d5, not d6 — it must be gone
    expect(result.current.fen.split(" ")[0]).toBe("4k3/8/3P4/8/8/8/8/4K3");
  });

  it("asks before promoting and honours the piece the player picks", () => {
    seed("8/4P3/8/8/8/8/8/4K2k w - - 0 1");
    const { result } = renderHook(() => useChessGame());
    expect(result.current.isPromotionMove("e7", "e8")).toBe(true);
    act(() => {
      result.current.tryMove("e7", "e8", "n");
    });
    expect(result.current.fen.split(" ")[0]).toContain("4N3");
    expect(result.current.lastRawMove?.promotion).toBe("n");
  });

  it("reports checkmate, stalemate and a dead draw in plain terms", () => {
    const cases: Array<[string, string]> = [
      ["6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1", "checkmate"],
      ["7k/5Q2/6K1/8/8/8/8/8 b - - 0 1", "stalemate"],
      ["4k3/8/8/8/8/8/8/4K3 w - - 0 1", "draw"],
    ];
    for (const [fen, want] of cases) {
      localStorage.clear();
      seed(fen);
      const { result, unmount } = renderHook(() => useChessGame());
      if (want === "checkmate") {
        act(() => {
          result.current.tryMove("a1", "a8");
        });
      }
      expect(result.current.status.kind).toBe(want);
      unmount();
    }
  });

  it("never asks the computer to move in a finished game", () => {
    expect(pickReply("R5k1/5ppp/8/8/8/8/5PPP/6K1 b - - 0 1", "steady")).toBeNull(); // mated
    expect(pickReply("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1", "steady")).toBeNull(); // stalemate
  });

  it("reports a finished game instead of inventing advice", () => {
    const mated = buildCoachCard({ fen: "R5k1/5ppp/8/8/8/8/5PPP/6K1 b - - 0 1", positionId: 1, humanSide: "b" });
    expect(mated.suggestion).toBeNull();
    expect(mated.gameOver).toEqual({ kind: "checkmate", winner: "w" });

    const stale = buildCoachCard({ fen: "7k/5Q2/6K1/8/8/8/8/8 b - - 0 1", positionId: 2, humanSide: "b" });
    expect(stale.suggestion).toBeNull();
    expect(stale.gameOver?.kind).toBe("stalemate");
  });

  it("the coach still produces a legal suggestion when the human is in check", () => {
    const fen = "rnbqk1nr/pppp1ppp/8/4p3/1b2P3/8/PPP1PPPP/RNBQKBNR w KQkq - 0 1";
    const card = buildCoachCard({ fen, positionId: 3, humanSide: "w" });
    expect(card.suggestion).not.toBeNull();
    const probe = new Chess(fen);
    expect(() => probe.move({ from: card.suggestion!.from, to: card.suggestion!.to, promotion: "q" })).not.toThrow();
  });
});

describe("promotion on the touch board", () => {
  it("shows a choice of pieces instead of silently making a queen", async () => {
    const user = userEvent.setup();
    seed("6k1/4P3/8/8/8/8/8/4K3 w - - 0 1");
    render(<App />);
    await user.click(within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^games$/i }));
    const square = (id: string) => screen.getByRole("gridcell", { name: new RegExp(`^${id},`) });
    await user.click(square("e7"));
    await user.click(square("e8"));
    const dialog = await screen.findByRole("dialog", { name: /promotion/i });
    expect(within(dialog).getAllByRole("button").length).toBeGreaterThanOrEqual(4);
    await user.click(within(dialog).getByRole("button", { name: /rook/i }));
    await waitFor(() => expect(square("e8").getAttribute("aria-label")).toMatch(/White rook/i));
  });
});

describe("language and reading direction", () => {
  it("switches the page to right-to-left when Arabic is chosen", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "yes");
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    await user.click(screen.getByRole("button", { name: /settings and language/i }));
    const picker = await screen.findByRole("region", { name: /language picker/i });
    await user.click(within(picker).getByRole("option", { name: /العربية/ }));
    await waitFor(() => expect(document.documentElement.dir).toBe("rtl"));
    expect(document.documentElement.lang).toBe("ar");
    await user.click(within(picker).getByRole("option", { name: /English/i }));
    await waitFor(() => expect(document.documentElement.dir).toBe("ltr"));
  });

  it("says plainly when a language has no coach wording yet", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "yes");
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    await user.click(screen.getByRole("button", { name: /settings and language/i }));
    const picker = await screen.findByRole("region", { name: /language picker/i });
    await user.click(within(picker).getByRole("option", { name: /日本語/ }));
    await user.click(within(nav).getByRole("button", { name: /^games$/i }));
    await waitFor(
      () => expect(screen.getByText(/not available in .* yet|showing English/i)).toBeTruthy(),
      { timeout: 8000 },
    );
  });
});
