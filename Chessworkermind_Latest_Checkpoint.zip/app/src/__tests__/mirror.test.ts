/**
 * Metamorphic testing: the coach must not care which colour you are.
 *
 * Fuzzing checks one position at a time and can only catch answers that are
 * obviously wrong. This checks a RELATIONSHIP between two positions, which
 * catches answers that look perfectly reasonable but are quietly biased.
 *
 * Take any position, swap the colours and flip the board top to bottom. The
 * game is identical — the same side to move faces the same problem. So the
 * coach's verdict must be identical too: the same threat, the same material
 * at stake, the same judgement of a move. Any difference is a bug in a
 * `color === "w"` branch somewhere.
 *
 * This is how you find colour bugs that no single-position test can see,
 * because each answer on its own looks fine.
 */
import { describe, expect, it } from "vitest";
import { Chess } from "chess.js";
import { findThreat, tacticalSwing, scoreMoves, materialEval, safeChess } from "../coach/localAnalysis";
import { reviewMove } from "../coach/reviewMove";
import { buildCoachCard } from "../coach/coachCard";

/* ------------------------------------------------------------------ */
/* The mirror                                                          */
/* ------------------------------------------------------------------ */

/** a1 <-> a8, e4 <-> e5: flip the rank, keep the file. */
function mirrorSquare(sq: string): string {
  return `${sq[0]}${9 - Number(sq[1])}`;
}

/**
 * Swap colours and flip the board. The resulting position is the same
 * problem seen from the other side.
 */
function mirrorFen(fen: string): string | null {
  const [board, turn, castling, ep, half, full] = fen.split(" ");
  const rows = board.split("/");
  if (rows.length !== 8) return null;

  const flipped = rows
    .slice()
    .reverse()
    .map((row) =>
      row
        .split("")
        .map((ch) => (/[a-z]/.test(ch) ? ch.toUpperCase() : /[A-Z]/.test(ch) ? ch.toLowerCase() : ch))
        .join(""),
    )
    .join("/");

  const swapCastle =
    castling === "-"
      ? "-"
      : castling
          .split("")
          .map((c) => (c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase()))
          .sort((a, b) => "KQkq".indexOf(a) - "KQkq".indexOf(b))
          .join("");

  const next = `${flipped} ${turn === "w" ? "b" : "w"} ${swapCastle} ${
    ep === "-" ? "-" : mirrorSquare(ep)
  } ${half} ${full}`;

  // Not every mirror is a legal position (castling rights can become
  // nonsense), so only keep the ones a board accepts.
  return safeChess(next) ? next : null;
}

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}

/** Random positions that survive mirroring, with their mirror. */
function mirroredPairs(count: number, seed = 99): Array<{ fen: string; mir: string }> {
  const rand = rng(seed);
  const out: Array<{ fen: string; mir: string }> = [];
  let guard = 0;
  while (out.length < count && guard++ < count * 40) {
    const c = new Chess();
    const plies = 2 + Math.floor(rand() * 40);
    for (let i = 0; i < plies; i++) {
      const moves = c.moves();
      if (moves.length === 0 || c.isGameOver()) break;
      c.move(moves[Math.floor(rand() * moves.length)]);
    }
    if (c.isGameOver()) continue;
    const fen = c.fen();
    const mir = mirrorFen(fen);
    if (!mir) continue;
    // the mirror must offer the same number of moves, or it is not a mirror
    const m = safeChess(mir)!;
    if (m.moves().length !== c.moves().length) continue;
    out.push({ fen, mir });
  }
  return out;
}

const PAIRS = mirroredPairs(40);

describe("the mirror itself is sound", () => {
  it("produces legal positions with the same shape", () => {
    expect(PAIRS.length).toBeGreaterThan(20);
    for (const { fen, mir } of PAIRS) {
      const a = new Chess(fen);
      const b = new Chess(mir);
      expect(b.turn()).not.toBe(a.turn());
      expect(b.moves().length).toBe(a.moves().length);
      expect(b.isCheck()).toBe(a.isCheck());
    }
  });

  it("mirroring twice gives the position back", () => {
    for (const { fen } of PAIRS.slice(0, 10)) {
      const back = mirrorFen(mirrorFen(fen)!);
      expect(back).toBe(fen);
    }
  });
});

describe("the coach treats both colours the same", () => {
  it("sees the same material at stake", () => {
    const bad: string[] = [];
    for (const { fen, mir } of PAIRS) {
      const a = tacticalSwing(fen);
      const b = tacticalSwing(mir);
      if (a !== b) bad.push(`${fen}: swing ${a} but mirrored ${b}`);
    }
    expect(bad.slice(0, 5)).toEqual([]);
  });

  it("values the position the same for whoever is to move", () => {
    const bad: string[] = [];
    for (const { fen, mir } of PAIRS) {
      const a = new Chess(fen);
      const b = new Chess(mir);
      const ea = materialEval(a, a.turn());
      const eb = materialEval(b, b.turn());
      if (ea !== eb) bad.push(`${fen}: material ${ea} but mirrored ${eb}`);
    }
    expect(bad.slice(0, 5)).toEqual([]);
  });

  it("finds the same threat, of the same kind and size", () => {
    const bad: string[] = [];
    for (const { fen, mir } of PAIRS) {
      const a = findThreat(fen);
      const b = findThreat(mir);
      if (!!a !== !!b) {
        bad.push(`${fen}: threat ${a ? a.kind : "none"} but mirrored ${b ? b.kind : "none"}`);
        continue;
      }
      if (!a || !b) continue;
      if (a.kind !== b.kind) bad.push(`${fen}: kind ${a.kind} vs ${b.kind}`);
      if (a.materialAtRisk !== b.materialAtRisk) {
        bad.push(`${fen}: at risk ${a.materialAtRisk} vs ${b.materialAtRisk}`);
      }
      if (mirrorSquare(a.from) !== b.from || mirrorSquare(a.to) !== b.to) {
        bad.push(`${fen}: threat ${a.from}${a.to} vs mirrored ${b.from}${b.to}`);
      }
    }
    expect(bad.slice(0, 5)).toEqual([]);
  });

  it("scores the best move the same for either colour", () => {
    const bad: string[] = [];
    for (const { fen, mir } of PAIRS) {
      const a = scoreMoves(fen, { limit: 12 })[0];
      const b = scoreMoves(mir, { limit: 12 })[0];
      if (!a || !b) continue;
      if (a.score !== b.score) bad.push(`${fen}: best score ${a.score} (${a.san}) vs ${b.score} (${b.san})`);
    }
    expect(bad.slice(0, 5)).toEqual([]);
  });
});

describe("the move reviewer treats both colours the same", () => {
  it("judges a move and its mirror identically", () => {
    const bad: string[] = [];
    for (const { fen, mir } of PAIRS.slice(0, 12)) {
      const c = new Chess(fen);
      for (const m of c.moves({ verbose: true }).slice(0, 8)) {
        const ra = reviewMove({ fen, from: m.from, to: m.to, promotion: m.promotion });
        const rb = reviewMove({
          fen: mir,
          from: mirrorSquare(m.from),
          to: mirrorSquare(m.to),
          promotion: m.promotion,
        });

        if (ra.legal !== rb.legal) {
          bad.push(`${fen}: ${m.san} legal=${ra.legal} but mirrored ${rb.legal}`);
          continue;
        }
        if (!!ra.risk !== !!rb.risk) {
          bad.push(`${fen}: ${m.san} risk=${ra.risk?.kind ?? "none"} but mirrored ${rb.risk?.kind ?? "none"}`);
          continue;
        }
        if (ra.risk && rb.risk && ra.risk.materialLost !== rb.risk.materialLost) {
          bad.push(`${fen}: ${m.san} loses ${ra.risk.materialLost} but mirrored ${rb.risk.materialLost}`);
        }
      }
    }
    expect(bad.slice(0, 5)).toEqual([]);
  }, 120_000);
});

describe("the coach card reads the same for either colour", () => {
  it("gives the same kind of answer, and the same reason", () => {
    const bad: string[] = [];
    for (const { fen, mir } of PAIRS.slice(0, 20)) {
      const a = new Chess(fen);
      const b = new Chess(mir);
      const ca = buildCoachCard({ fen, positionId: 1, humanSide: a.turn() });
      const cb = buildCoachCard({ fen: mir, positionId: 1, humanSide: b.turn() });

      if (!!ca.suggestion !== !!cb.suggestion) {
        bad.push(`${fen}: suggestion on one side only`);
        continue;
      }
      if (ca.threat.present !== cb.threat.present) {
        bad.push(`${fen}: threat present=${ca.threat.present} vs ${cb.threat.present}`);
      }
      if (ca.abstained !== cb.abstained) bad.push(`${fen}: abstained=${ca.abstained} vs ${cb.abstained}`);
      if (ca.reason?.key !== cb.reason?.key) {
        bad.push(`${fen}: reason ${ca.reason?.key} vs ${cb.reason?.key}`);
      }
    }
    expect(bad.slice(0, 5)).toEqual([]);
  }, 120_000);
});
