/**
 * The service worker is the whole offline story, and until now nothing
 * checked it. These tests load the REAL `public/sw.js` file and drive it
 * through a fake browser, so "it works on a plane" stops being a claim and
 * starts being something that fails the build when it breaks.
 */
import { beforeEach, describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const ORIGIN = "https://chessworkermind.example";

/* ---------------------------------------------------------------- */
/* A small fake of the bits of the browser that a service worker uses */
/* ---------------------------------------------------------------- */

class FakeHeaders {
  constructor(private map: Record<string, string> = {}) {}
  get(k: string) {
    return this.map[k.toLowerCase()] ?? null;
  }
}

class FakeRequest {
  url: string;
  method: string;
  mode: string;
  headers: FakeHeaders;
  constructor(url: string, init: { method?: string; mode?: string; accept?: string } = {}) {
    this.url = url;
    this.method = init.method ?? "GET";
    this.mode = init.mode ?? "no-cors";
    this.headers = new FakeHeaders(init.accept ? { accept: init.accept } : {});
  }
}

class FakeResponse {
  constructor(
    public body: string,
    public ok = true,
    public tag = "network",
  ) {}
  clone() {
    return new FakeResponse(this.body, this.ok, this.tag);
  }
  async json() { return JSON.parse(this.body); }
  static error() {
    return new FakeResponse("", false, "error");
  }
}

class FakeCache {
  store = new Map<string, FakeResponse>();
  async addAll(urls: string[]) {
    for (const u of urls) this.store.set(u, new FakeResponse(`cached:${u}`, true, "cache"));
  }
  async put(req: FakeRequest | string, res: FakeResponse) {
    this.store.set(typeof req === "string" ? req : req.url, new FakeResponse(res.body, res.ok, "cache"));
  }
  async match(req: FakeRequest | string) {
    return this.store.get(typeof req === "string" ? req : req.url);
  }
}

type Harness = {
  listeners: Record<string, (event: any) => void>;
  cacheStorage: Map<string, FakeCache>;
  fetchCalls: string[];
  /** set to true to simulate being offline */
  offline: boolean;
  /** urls the fake server answers with 404 */
  notFound: Set<string>;
  skipWaitingCalled: boolean;
  claimCalled: boolean;
  fire: (type: string) => Promise<void>;
  request: (req: FakeRequest) => Promise<FakeResponse | undefined>;
};

function loadServiceWorker(base = "/"): Harness {
  const code = readFileSync(resolve(__dirname, "../../public/sw.js"), "utf8");

  const listeners: Record<string, (event: any) => void> = {};
  const cacheStorage = new Map<string, FakeCache>();
  const h: Partial<Harness> = {
    listeners,
    cacheStorage,
    fetchCalls: [],
    offline: false,
    notFound: new Set<string>(),
  };

  const self = {
    addEventListener: (type: string, fn: (e: any) => void) => {
      listeners[type] = fn;
    },
    skipWaiting: () => {
      h.skipWaitingCalled = true;
    },
    clients: {
      claim: async () => {
        h.claimCalled = true;
      },
    },
    location: { origin: ORIGIN, href: `${ORIGIN}${base}sw.js` },
  };

  const caches = {
    open: async (name: string) => {
      if (!cacheStorage.has(name)) cacheStorage.set(name, new FakeCache());
      return cacheStorage.get(name)!;
    },
    keys: async () => [...cacheStorage.keys()],
    delete: async (name: string) => cacheStorage.delete(name),
    match: async (req: FakeRequest | string) => {
      for (const c of cacheStorage.values()) {
        const hit = await c.match(req);
        if (hit) return hit;
      }
      return undefined;
    },
  };

  const fetchFn = async (req: FakeRequest | string) => {
    const url = typeof req === "string" ? req : req.url;
    h.fetchCalls!.push(url);
    if (h.offline) throw new TypeError("Failed to fetch");
    if (h.notFound!.has(url)) return new FakeResponse("not found", false, "network");
    if (url.endsWith("offline-assets.json")) return new FakeResponse(JSON.stringify(["assets/app-test.js", "assets/app-test.css"]));
    return new FakeResponse(`network:${url}`, true, "network");
  };

  // eslint-disable-next-line @typescript-eslint/no-implied-eval
  const run = new Function("self", "caches", "fetch", "Response", "URL", code);
  run(self, caches, fetchFn, FakeResponse, URL);

  h.fire = async (type: string) => {
    const waits: Promise<unknown>[] = [];
    listeners[type]?.({ waitUntil: (p: Promise<unknown>) => waits.push(p) });
    await Promise.all(waits);
  };

  h.request = async (req: FakeRequest) => {
    let responded: Promise<FakeResponse> | undefined;
    listeners.fetch?.({ request: req, respondWith: (p: Promise<FakeResponse>) => (responded = p) });
    if (!responded) return undefined; // the worker let the browser handle it
    return await responded;
  };

  return h as Harness;
}

let sw: Harness;
beforeEach(() => {
  sw = loadServiceWorker();
});

describe("installing", () => {
  it("caches the app shell so the very first offline open works", async () => {
    await sw.fire("install");
    const cache = [...sw.cacheStorage.values()][0];
    expect(cache).toBeTruthy();
    const urls = [...cache.store.keys()];
    expect(urls).toContain("/");
    expect(urls).toContain("/manifest.webmanifest");
    expect(urls).toContain("/assets/app-test.js");
    expect(urls).toContain("/assets/app-test.css");
    expect(urls.some((u) => u.includes("icon-192"))).toBe(true);
    expect(sw.skipWaitingCalled).toBe(true);
  });

  it("uses a versioned cache name, so a new build cannot serve stale code forever", () => {
    const code = readFileSync(resolve(__dirname, "../../public/sw.js"), "utf8");
    const name = /const CACHE = "([^"]+)"/.exec(code)?.[1];
    expect(name).toBeTruthy();
    expect(name).toMatch(/v\d+/);
  });

  it("rejects incomplete installation so it cannot replace a working offline version", async () => {
    sw.offline = true;
    await expect(sw.fire("install")).rejects.toThrow("Failed to fetch");
    expect(sw.skipWaitingCalled).not.toBe(true);
  });
});

describe("activating", () => {
  it("throws away caches from older builds and keeps the current one", async () => {
    sw.cacheStorage.set("cwm-v1-old", new FakeCache());
    sw.cacheStorage.set("cwm-v2-older", new FakeCache());
    await sw.fire("install");
    const current = [...sw.cacheStorage.keys()].find((k) => !k.includes("old"))!;

    await sw.fire("activate");

    expect([...sw.cacheStorage.keys()]).toEqual([current]);
    expect(sw.claimCalled).toBe(true);
  });
});

describe("what it refuses to touch", () => {
  it("ignores anything that is not a GET, so a purchase is never cached or replayed", async () => {
    const res = await sw.request(new FakeRequest(`${ORIGIN}/api/checkout`, { method: "POST" }));
    expect(res).toBeUndefined();
    expect(sw.fetchCalls).toHaveLength(0);
  });

  it("ignores other origins, so a payment provider is never intercepted", async () => {
    const res = await sw.request(new FakeRequest("https://payments.example/session"));
    expect(res).toBeUndefined();
  });
});

describe("opening the app", () => {
  it("prefers the network for the page, so a new version is picked up", async () => {
    const req = new FakeRequest(`${ORIGIN}/`, { mode: "navigate" });
    const res = await sw.request(req);
    expect(res!.tag).toBe("network");
    expect(sw.fetchCalls).toContain(`${ORIGIN}/`);
  });

  it("falls back to the cached page when the phone is offline", async () => {
    await sw.request(new FakeRequest(`${ORIGIN}/`, { mode: "navigate" })); // warm the cache
    sw.offline = true;

    const res = await sw.request(new FakeRequest(`${ORIGIN}/`, { mode: "navigate" }));
    expect(res!.tag).toBe("cache");
    expect(res!.body).toContain("/");
  });

  it("falls back to the cached home page for a deep link it has never seen", async () => {
    await sw.fire("install"); // "/" is in the shell
    sw.offline = true;

    const res = await sw.request(new FakeRequest(`${ORIGIN}/learn/knight`, { accept: "text/html" }));
    expect(res!.body).toBe("cached:/");
  });

  it("never throws when there is nothing cached and no network", async () => {
    sw.offline = true;
    const res = await sw.request(new FakeRequest(`${ORIGIN}/`, { mode: "navigate" }));
    expect(res!.ok).toBe(false); // a real error response, not an exception
  });
});

describe("the assets the game needs to run offline", () => {
  it("serves the built app bundle from the cache without touching the network twice", async () => {
    const asset = new FakeRequest(`${ORIGIN}/assets/index-abc123.js`);
    const first = await sw.request(asset);
    expect(first!.tag).toBe("network");
    expect(sw.fetchCalls).toHaveLength(1);

    const second = await sw.request(asset);
    expect(second!.tag).toBe("cache");
    expect(sw.fetchCalls).toHaveLength(1); // no second network call
  });

  it("serves Stockfish from the cache once it has been downloaded", async () => {
    const wasm = new FakeRequest(`${ORIGIN}/stockfish/stockfish.wasm`);
    await sw.request(wasm);
    sw.offline = true;

    const offlineHit = await sw.request(wasm);
    expect(offlineHit!.tag).toBe("cache");
  });

  it("does not poison the cache with a failed download", async () => {
    // A half-deployed build can 404 an asset. If the worker cached that, the
    // app would stay broken offline forever, even after a good deploy.
    const url = `${ORIGIN}/assets/index-broken.js`;
    sw.notFound.add(url);

    const first = await sw.request(new FakeRequest(url));
    expect(first!.ok).toBe(false);
    for (const cache of sw.cacheStorage.values()) {
      expect(await cache.match(url)).toBeUndefined();
    }

    // once the asset really exists, it is fetched again and cached properly
    sw.notFound.delete(url);
    const second = await sw.request(new FakeRequest(url));
    expect(second!.ok).toBe(true);
    const third = await sw.request(new FakeRequest(url));
    expect(third!.tag).toBe("cache");
  });
});


describe("served from a sub-folder, as most free hosts do", () => {
  it("caches its own folder, not the domain root", async () => {
    const sub = loadServiceWorker("/chessworkermind/");
    await sub.fire("install");
    const cache = [...sub.cacheStorage.values()][0];
    const urls = [...cache.store.keys()];

    expect(urls).toContain("/chessworkermind/");
    expect(urls).toContain("/chessworkermind/manifest.webmanifest");
    expect(urls, "it must not reach for the domain root").not.toContain("/");
  });

  it("still serves its own assets from the cache offline", async () => {
    const sub = loadServiceWorker("/chessworkermind/");
    const asset = new FakeRequest(`${ORIGIN}/chessworkermind/assets/index-abc.js`);
    await sub.request(asset);
    sub.offline = true;
    const hit = await sub.request(asset);
    expect(hit!.tag).toBe("cache");
  });

  it("falls back to its own index for a deep link, not the domain root", async () => {
    const sub = loadServiceWorker("/chessworkermind/");
    await sub.fire("install");
    sub.offline = true;
    const res = await sub.request(new FakeRequest(`${ORIGIN}/chessworkermind/learn/knight`, { accept: "text/html" }));
    expect(res!.body).toBe("cached:/chessworkermind/");
  });
});
