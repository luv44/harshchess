/**
 * "Review a game", driven through the real UI.
 *
 * The thing being protected here is restraint: a game reviewer is the
 * easiest place in a chess app to start inventing "inaccuracies" and
 * grading people. These tests check it stays quiet unless it can prove
 * something.
 */
import { beforeEach, describe, expect, it } from "vitest";
import { act, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { SESSION_KEY } from "../chess/session";

const ONBOARD_KEY = "chessworkermind:onboarded:v2";

/** 2...Qg5?? simply hangs the queen to 3.Nxg5. */
const BLUNDER = "1. e4 e5 2. Nf3 Qg5 3. Nxg5";
/** A calm, normal opening with nothing provable in it. */
const CLEAN = "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6";

function seed() {
  localStorage.setItem(ONBOARD_KEY, "1");
  localStorage.setItem(
    SESSION_KEY,
    JSON.stringify({
      fen: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
      pgn: "",
      orientation: "w",
      mode: "vsComputer",
      humanSide: "w",
      savedAt: Date.now(),
    }),
  );
}

async function openReview(user: ReturnType<typeof userEvent.setup>) {
  await user.click(
    within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^games$/i }),
  );
  await user.click(await screen.findByRole("button", { name: /review a game/i }));
}

/** The scan runs a couple of moves per tick; let it finish. */
async function waitForScan() {
  await waitFor(() => expect(screen.queryByText(/Checking your move/i)).toBeNull(), { timeout: 15000 });
}

describe("Review a game", () => {
  beforeEach(() => localStorage.clear());

  it("is reachable from the Games tab and asks for a game", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openReview(user);

    expect(screen.getByRole("heading", { name: /review a game/i })).toBeTruthy();
    expect(screen.getByLabelText(/your game/i)).toBeTruthy();
    expect(screen.getByText(/It does not grade you and it does not guess/i)).toBeTruthy();
  });

  it("reads a pasted game and lets you step through it", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openReview(user);

    await user.type(screen.getByLabelText(/your game/i), CLEAN);
    await user.click(screen.getByRole("button", { name: /review this game/i }));

    expect(await screen.findByRole("grid", { name: /chess board/i })).toBeTruthy();
    expect(screen.getByText(/The starting position/i)).toBeTruthy();

    await user.click(screen.getByRole("button", { name: /next/i }));
    // the move is described in words, not just notation
    expect(await screen.findByText(/White played the pawn from e2 to e4/i)).toBeTruthy();
    expect(screen.getByRole("gridcell", { name: /^e4,/ }).getAttribute("aria-label")).toMatch(/White pawn/i);

    await user.click(screen.getByRole("button", { name: /^end/i }));
    expect(await screen.findByText(/Move 4\.\.\. — Black played the knight from g8 to f6/i)).toBeTruthy();
  });

  it("stays quiet about a clean game instead of inventing mistakes", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openReview(user);
    await user.type(screen.getByLabelText(/your game/i), CLEAN);
    await user.click(screen.getByRole("button", { name: /review this game/i }));
    await waitForScan();

    expect(screen.getByText(/Nothing the coach can prove went wrong/i)).toBeTruthy();
    // and it does not turn that into praise
    expect(screen.getByText(/not the same as saying the game was perfect/i)).toBeTruthy();
    expect(screen.queryByText(/excellent|brilliant|well played|accuracy/i)).toBeNull();
  });

  it("finds a real blunder, names it, and proves it", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openReview(user);
    await user.type(screen.getByLabelText(/your game/i), BLUNDER);
    await user.click(screen.getByRole("button", { name: /review this game/i }));

    // the pasted game has no player names, so pick the side that blundered
    await user.click(within(screen.getByRole("group", { name: /your side/i })).getByRole("button", { name: /black/i }));
    await waitForScan();

    expect(screen.getByText(/1 moment worth a look/i)).toBeTruthy();
    const row = screen.getByRole("button", { name: /Move 2\.\.\. Qg5/i });
    expect(within(row).getByText(/wins queen here/i)).toBeTruthy();

    // opening it shows the full explanation, on the position before the move
    await user.click(row);
    expect(await screen.findByRole("heading", { name: /why not my move\?/i })).toBeTruthy();
    expect(screen.getByRole("heading", { name: /Why your move was risky/i })).toBeTruthy();
    expect(screen.getByText(/playing the whole exchange out on the board, not by guessing/i)).toBeTruthy();
  });

  it("shows a progress bar while it works, because every move is really replayed", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openReview(user);
    await user.type(screen.getByLabelText(/your game/i), CLEAN);
    await user.click(screen.getByRole("button", { name: /review this game/i }));

    expect(screen.getByText(/Checking your move \d+ of \d+/i)).toBeTruthy();
    await waitForScan();
  });

  it("explains a game it cannot read instead of failing silently", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openReview(user);

    await user.type(screen.getByLabelText(/your game/i), "1. e4 e5 2. Nf3 Qh9");
    await user.click(screen.getByRole("button", { name: /review this game/i }));

    expect(await screen.findByText(/That game could not be read/i)).toBeTruthy();
    expect(screen.getByText(/Qh9/)).toBeTruthy();
    await user.click(screen.getByRole("button", { name: /try again/i }));
    expect(screen.getByLabelText(/your game/i)).toBeTruthy();
  });

  it("offers the game in progress, and reviewing it does not disturb it", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);

    // play one move in the free game first
    await user.click(
      within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^games$/i }),
    );
    await user.click(screen.getByRole("gridcell", { name: /^e2,/ }));
    await user.click(screen.getByRole("gridcell", { name: /^e4,/ }));
    await act(async () => {
      await new Promise((r) => setTimeout(r, 1200));
    });

    await user.click(await screen.findByRole("button", { name: /review a game/i }));
    expect(screen.getByText(/Reviewing it does not change or end the game/i)).toBeTruthy();
    await user.click(screen.getByRole("button", { name: /review my current game/i }));
    await waitForScan();

    // go back — the game is exactly where it was
    await user.click(screen.getByRole("button", { name: /^back$/i }));
    expect(screen.getByRole("gridcell", { name: /^e4,/ }).getAttribute("aria-label")).toMatch(/White pawn/i);
  });

  it("says so plainly when there is no game in progress to review", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    await openReview(user);

    expect(screen.getByText(/You have not played any moves yet/i)).toBeTruthy();
    expect(screen.queryByRole("button", { name: /review my current game/i })).toBeNull();
  });
});
