import { describe, it, expect, beforeEach } from "vitest";
import { render, screen, waitFor, within, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { SESSION_KEY } from "../chess/session";

/**
 * End-to-end behaviour in a real DOM (jsdom).
 *
 * Web Workers do not exist in jsdom, so these tests also prove the
 * no-worker fallback path works: the coach and the opponent still run.
 */

const ONBOARD_KEY = "chessworkermind:onboarded:v2";

/** The app opens on Home. This is the one tap that gets you to the board. */
async function openBoard(user: ReturnType<typeof userEvent.setup>) {
  const nav = screen.getByRole("navigation", { name: /main/i });
  await user.click(within(nav).getByRole("button", { name: /^games$/i }));
}

/** Train opens on the guided game; the lesson list is one more tap. */
async function openTrain(user: ReturnType<typeof userEvent.setup>) {
  const nav = screen.getByRole("navigation", { name: /main/i });
  await user.click(within(nav).getByRole("button", { name: /^train$/i }));
}

async function openLessonList(user: ReturnType<typeof userEvent.setup>) {
  await openTrain(user);
  await user.click(await screen.findByRole("button", { name: /^lessons$/i }));
}

function squareBtn(name: string) {
  return screen.getByRole("gridcell", { name: new RegExp(`^${name},`) });
}

/**
 * Just the pieces: "e4, White pawn". The rest of the aria-label carries
 * coaching state (legal move, step 1, step 2) which arrives a moment later
 * and is not what these tests are asking about.
 */
function piecePlacement() {
  return screen
    .getAllByRole("gridcell")
    .map((el) => (el.getAttribute("aria-label") ?? "").split(",").slice(0, 2).join(","));
}

function pieceCountOnBoard() {
  return screen.getAllByRole("gridcell").filter((el) => !/empty/.test(el.getAttribute("aria-label") ?? "")).length;
}

/** Read the move list length from the board state via aria labels of last move. */
async function waitForBlackReply(timeout = 6000) {
  await waitFor(
    () => {
      // after Black replies it is White's turn again
      expect(screen.getByRole("status").textContent).toMatch(/Your turn/i);
    },
    { timeout },
  );
}

describe("a complete beginner opens the link", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it("is greeted with a choice, not a dashboard", async () => {
    render(<App />);
    expect(screen.getByRole("dialog", { name: /welcome/i })).toBeTruthy();
    expect(screen.getByText(/I am new to chess/i)).toBeTruthy();
    expect(screen.getByText(/Skip — I know the rules/i)).toBeTruthy();
    // no chess jargon, no engine score, no technical panel on the welcome screen
    const dialog = screen.getByRole("dialog", { name: /welcome/i });
    expect(within(dialog).queryByText(/centipawn|multipv|FEN|depth|engine/i)).toBeNull();
  });

  it("reaches a playable board in two taps and shows whose turn it is", async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(screen.getByText(/I am new to chess/i));
    await user.click(screen.getByText(/Play with the computer/i));

    expect(screen.getByRole("grid", { name: /chess board/i })).toBeTruthy();
    expect(pieceCountOnBoard()).toBe(32);
    const strip = screen.getByRole("status");
    expect(strip.textContent).toMatch(/Your turn/i);
    expect(strip.textContent).toMatch(/You play White/i);
  });

  it("explains a piece when it is tapped", async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(screen.getByText(/I am new to chess/i));
    await user.click(screen.getByText(/Play with the computer/i));

    await user.click(squareBtn("g1")); // white knight
    const hint = await screen.findByRole("note");
    expect(within(hint).getByText(/L shape/i)).toBeTruthy();
    // it must NOT be a pop-up that blocks the board
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("grid", { name: /chess board/i })).toBeTruthy();

    // tapping the same piece again puts it away, and it can be turned off for good
    await user.click(within(hint).getByRole("button", { name: /stop showing these tips/i }));
    expect(screen.queryByRole("note")).toBeNull();
    await user.click(squareBtn("b1"));
    expect(screen.queryByRole("note")).toBeNull();
  });
});

describe("the turn loop that was broken before", () => {
  beforeEach(() => {
    localStorage.clear();
    localStorage.setItem(ONBOARD_KEY, "1");
    localStorage.setItem(
      SESSION_KEY,
      JSON.stringify({
        fen: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        pgn: "",
        orientation: "w",
        mode: "vsComputer",
        humanSide: "w",
        updatedAt: new Date().toISOString(),
      }),
    );
  });

  it("does NOT move White by itself — the board waits for the human", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);
    expect(screen.getByRole("status").textContent).toMatch(/Your turn/i);
    // give the opponent hook plenty of time to misbehave
    await act(async () => {
      await new Promise((r) => setTimeout(r, 1500));
    });
    expect(pieceCountOnBoard()).toBe(32);
    expect(squareBtn("e2").getAttribute("aria-label")).toMatch(/White pawn/);
    expect(screen.getByRole("status").textContent).toMatch(/Your turn/i);
  });

  it("lets the human move White, then plays EXACTLY ONE Black reply and stops", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);

    await user.click(squareBtn("e2"));
    expect(squareBtn("e4").getAttribute("aria-label")).toMatch(/legal move/);
    await user.click(squareBtn("e4"));

    // White's move landed
    expect(squareBtn("e4").getAttribute("aria-label")).toMatch(/White pawn/);
    expect(squareBtn("e2").getAttribute("aria-label")).toMatch(/empty/);

    // Black answers once
    await waitForBlackReply();
    expect(pieceCountOnBoard()).toBe(32); // a reply, not a capture-fest

    // and then it STOPS: White is not moved by the computer
    const before = piecePlacement();
    await act(async () => {
      await new Promise((r) => setTimeout(r, 1500));
    });
    expect(piecePlacement()).toEqual(before);
    expect(screen.getByRole("status").textContent).toMatch(/Your turn/i);
  });

  it("refuses to let the human drag the computer's pieces", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);
    // e7 is a black pawn; the human plays White, so it must not move
    await user.click(squareBtn("e7"));
    await user.click(squareBtn("e5"));
    expect(squareBtn("e7").getAttribute("aria-label")).toMatch(/Black pawn/);
    expect(squareBtn("e5").getAttribute("aria-label")).toMatch(/empty/);
  });

  it("undo gives the human their move back and does not replay a stale reply", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);
    await user.click(squareBtn("e2"));
    await user.click(squareBtn("e4"));
    await waitForBlackReply();

    await user.click(screen.getByRole("button", { name: /undo/i }));

    // back to the very start, White to move
    await waitFor(() => {
      expect(squareBtn("e2").getAttribute("aria-label")).toMatch(/White pawn/);
    });
    expect(screen.getByRole("status").textContent).toMatch(/Your turn/i);

    // nothing sneaks in afterwards
    await act(async () => {
      await new Promise((r) => setTimeout(r, 1200));
    });
    expect(squareBtn("e2").getAttribute("aria-label")).toMatch(/White pawn/);
    expect(pieceCountOnBoard()).toBe(32);
  });

  it("new game cancels pending computer work instead of moving the fresh board", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);
    await user.click(squareBtn("e2"));
    await user.click(squareBtn("e4"));
    // immediately start a new game while the reply is still pending
    await user.click(screen.getByRole("button", { name: /new game/i }));

    await act(async () => {
      await new Promise((r) => setTimeout(r, 1500));
    });
    expect(squareBtn("e2").getAttribute("aria-label")).toMatch(/White pawn/);
    expect(squareBtn("e4").getAttribute("aria-label")).toMatch(/empty/);
    expect(pieceCountOnBoard()).toBe(32);
  });
});

describe("the Coach card", () => {
  beforeEach(() => {
    localStorage.clear();
    localStorage.setItem(ONBOARD_KEY, "1");
  });

  it("shows the five sections in order and never moves the piece by itself", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);

    const coach = await screen.findByRole("region", { name: /coach explanation/i }, { timeout: 8000 });
    await waitFor(() => expect(within(coach).getByText(/Your move to try/i)).toBeTruthy(), { timeout: 8000 });

    const order = within(coach)
      .getAllByText(/just moved|Your move to try|Why this helps|What might happen next|Try it yourself/i)
      .map((el) => el.textContent ?? "");
    expect(order.length).toBeGreaterThanOrEqual(4);

    // "Show me on the board" only highlights — the position must not change
    const placement = () =>
      screen
        .getAllByRole("gridcell")
        .map((el) => (el.getAttribute("aria-label") ?? "").split(",").slice(0, 2).join(","));
    const before = placement();
    await user.click(within(coach).getAllByRole("button", { name: /show me on the board/i })[0]);
    expect(placement()).toEqual(before);
    // and it marks step 1 and step 2 on the board
    expect(screen.getAllByRole("gridcell").some((el) => /step 1/.test(el.getAttribute("aria-label") ?? ""))).toBe(true);
    expect(screen.getAllByRole("gridcell").some((el) => /step 2/.test(el.getAttribute("aria-label") ?? ""))).toBe(true);
  });

  it("'Move it for me' is a separate button that does play the move", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);
    const coach = await screen.findByRole("region", { name: /coach explanation/i }, { timeout: 8000 });
    await waitFor(() => expect(within(coach).getByText(/Your move to try/i)).toBeTruthy(), { timeout: 8000 });

    const occupied = () =>
      screen
        .getAllByRole("gridcell")
        .filter((el) => !/empty/.test(el.getAttribute("aria-label") ?? ""))
        .map((el) => (el.getAttribute("aria-label") ?? "").split(",")[0])
        .join("|");
    const before = occupied();
    await user.click(within(coach).getAllByRole("button", { name: /move it for me/i })[0]);
    // exactly one white piece changed square — the coach played the move it suggested
    await waitFor(() => expect(occupied()).not.toEqual(before), { timeout: 6000 });
  });

  it("says there is no danger in the calm starting position instead of inventing drama", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);
    const coach = await screen.findByRole("region", { name: /coach explanation/i }, { timeout: 8000 });
    await waitFor(() => expect(within(coach).getByText(/calm moment/i)).toBeTruthy(), { timeout: 8000 });
  });
});

describe("a refresh keeps the right side and position", () => {
  it("restores the saved game, mode and colour", async () => {
    localStorage.clear();
    localStorage.setItem(ONBOARD_KEY, "1");
    localStorage.setItem(
      SESSION_KEY,
      JSON.stringify({
        fen: "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2",
        pgn: '[SetUp "1"]',
        orientation: "b",
        mode: "vsComputer",
        humanSide: "b",
        updatedAt: new Date().toISOString(),
      }),
    );
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);
    // human is Black, so with White to move the computer is the one to play
    await waitFor(() => {
      expect(screen.getByRole("status").textContent).toMatch(/Computer/i);
    });
    // and the saved pawns are still where they were
    expect(squareBtn("e4").getAttribute("aria-label")).toMatch(/White pawn/);
    expect(squareBtn("e5").getAttribute("aria-label")).toMatch(/Black pawn/);
  });
});

describe("the Learn journey", () => {
  beforeEach(() => {
    localStorage.clear();
    localStorage.setItem(ONBOARD_KEY, "1");
  });

  it("lists real lessons, and marks a stage as not built only when it truly is not", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openLessonList(user);

    expect(await screen.findByText(/The board, your colour and whose turn it is/i)).toBeTruthy();

    // Every stage is written now. The label must appear exactly as many
    // times as there are unbuilt stages — never more, never fewer.
    const { STAGES } = await import("../learn/journey");
    expect(screen.queryAllByText(/Not built yet/i)).toHaveLength(STAGES.filter((s) => !s.built).length);
    for (const stage of STAGES) expect(screen.getByText(stage.name)).toBeTruthy();
  });

  it("runs a lesson and accepts the correct move", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openLessonList(user);
    await user.click(await screen.findByText(/The board, your colour and whose turn it is/i));

    await user.click(squareBtn("e2"));
    await user.click(squareBtn("e4"));

    expect(await screen.findByText(/Well done/i)).toBeTruthy();
    expect(screen.getByText(/entirely on your own/i)).toBeTruthy();
  });

  it("does not punish a wrong-but-legal move", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openLessonList(user);
    await user.click(await screen.findByText(/The board, your colour and whose turn it is/i));

    await user.click(squareBtn("e2"));
    await user.click(squareBtn("e3")); // legal, but not the lesson's move
    expect(await screen.findByText(/that is a legal move, just not the one/i)).toBeTruthy();
    expect(screen.queryByText(/wrong|incorrect|failed/i)).toBeNull();
  });
});

describe("the Coach card is one idea, not an essay", () => {
  it("shows a short situation line, the move, the trick and two buttons — and little else", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);

    const coach = await screen.findByRole("region", { name: /coach explanation/i }, { timeout: 8000 });
    await waitFor(() => expect(coach.querySelector(".idea__move")).toBeTruthy(), { timeout: 8000 });

    const fold = coach.querySelector("details.coachmore");
    expect(fold, "the explanation must be behind a fold").toBeTruthy();
    expect(fold!.hasAttribute("open"), "the fold must start closed").toBe(false);

    // Everything the learner sees before opening anything. Content inside
    // ANY closed <details> is not on screen, so it does not count.
    const hidden = (el: Element) =>
      Array.from(coach.querySelectorAll("details")).some((d) => !d.hasAttribute("open") && d.contains(el));
    // Body text only. The small footer ("This explanation looks wrong ·
    // Check again") is two quiet links, not something to read.
    const visible = Array.from(coach.querySelectorAll("p"))
      .filter((p) => !hidden(p))
      .filter((p) => !p.classList.contains("coachfoot"));
    expect(visible.length, `too much text above the fold: ${visible.map((p) => p.textContent).join(" | ")}`)
      .toBeLessThanOrEqual(3);

    // …and it is the right three things.
    expect(coach.querySelector(".idea__status")!.textContent).toBeTruthy();
    // The square chips put the step number before the square, so the text
    // content reads "from 1b1 to 2c3". Check the chips properly instead.
    const move = coach.querySelector(".idea__move")!;
    expect(move.textContent).toMatch(/move your (pawn|knight|bishop|rook|queen|king) from/i);
    const chips = Array.from(move.querySelectorAll(".sqref"));
    expect(chips).toHaveLength(2);
    expect(chips[0].textContent).toMatch(/^1[a-h][1-8]$/);
    expect(chips[1].textContent).toMatch(/^2[a-h][1-8]$/);
    expect(coach.querySelector(".trick__text")!.textContent!.length).toBeGreaterThan(20);

    // Two actions, and nothing else competing with them. The <summary> of
    // the fold is not a button, and the card header carries a status chip.
    // Exactly two real actions compete for attention.
    const actions = Array.from(coach.querySelectorAll("button.btn"))
      .filter((b) => !hidden(b))
      .map((b) => (b.textContent ?? "").trim());
    expect(actions.some((t) => /show me on the board/i.test(t))).toBe(true);
    expect(actions.some((t) => /move it for me/i.test(t))).toBe(true);
    expect(actions.length, `extra actions above the fold: ${actions.join(" | ")}`).toBe(2);

    // The technical dump (FEN, engine name, confidence, timing) is gone from
    // the card entirely — a beginner never needs notation or engine internals.
    expect(coach.textContent).not.toMatch(/Exact position \(FEN\)|confidence:|Details for this position/i);

    // the long caveats are not shouted before the answer
    expect(visible.map((p) => p.textContent).join(" ")).not.toMatch(/You do not have to play this/i);
  });

  it("still has all five sections, one tap away", async () => {
    const user = userEvent.setup();
    render(<App />);
    await openBoard(user);
    const coach = await screen.findByRole("region", { name: /coach explanation/i }, { timeout: 8000 });
    await waitFor(() => expect(coach.querySelector(".idea__move")).toBeTruthy(), { timeout: 8000 });

    await user.click(within(coach).getByText(/why it helps, what might happen/i));

    for (const t of [/just moved/i, /Your move to try/i, /Why this helps/i, /What might happen next/i, /Try it yourself/i]) {
      expect(within(coach).getAllByText(t).length, `${t} missing`).toBeGreaterThan(0);
    }
  });
});
