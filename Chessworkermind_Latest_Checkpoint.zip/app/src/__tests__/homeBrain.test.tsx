/**
 * The Home and Brain screens are the two places where it would be easiest to
 * lie to the user with a nice-looking number. These tests exist to stop that.
 */
import { describe, expect, it } from "vitest";
import { act, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import {
  computeInsights,
  currentStreak,
  greeting,
  MIN_EVIDENCE,
  POINTS_UNAIDED,
  POINTS_WITH_HELP,
  SKILL_AREAS,
} from "../learn/insights";
import { EMPTY_PROGRESS, PROGRESS_KEY, dayKey, recordAttempt, type LearnProgress } from "../learn/progress";

const ONBOARD_KEY = "chessworkermind:onboarded:v2";

function daysAgo(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return dayKey(d);
}

function progressWith(entries: Array<{ id: string; concepts: string[]; unaided: boolean }>): LearnProgress {
  let p = EMPTY_PROGRESS;
  for (const e of entries) p = recordAttempt(p, e.id, e.concepts, e.unaided);
  return p;
}

describe("the numbers on Home and Brain are real", () => {
  it("says 'not enough data' instead of inventing a score", () => {
    const none = computeInsights(EMPTY_PROGRESS);
    expect(none.enoughData).toBe(false);
    expect(none.score).toBe(0);
    expect(none.headline).toMatch(/not started/i);

    const two = computeInsights(progressWith([
      { id: "board-basics", concepts: ["orientation"], unaided: true },
      { id: "pawn-first-move", concepts: ["pawnMoves"], unaided: true },
    ]));
    expect(two.enoughData).toBe(false);
    expect(two.headline).toMatch(/not enough data/i);
  });

  it("uses the published formula and nothing else", () => {
    const p = progressWith([
      { id: "board-basics", concepts: ["orientation"], unaided: true },
      { id: "pawn-first-move", concepts: ["pawnMoves"], unaided: true },
      { id: "knight-l", concepts: ["knightMoves"], unaided: false },
    ]);
    const i = computeInsights(p);
    expect(i.enoughData).toBe(true);
    expect(i.score).toBe(2 * POINTS_UNAIDED + 1 * POINTS_WITH_HELP);
    expect(i.lessonsDone).toBe(3);
    expect(i.lessonsUnaided).toBe(2);
    expect(i.reviewsDue).toBe(1);
  });

  it("a hinted lesson never counts towards a skill bar", () => {
    const hinted = computeInsights(progressWith([{ id: "knight-l", concepts: ["knightMoves"], unaided: false }]));
    const moves = hinted.areas.find((a) => a.id === "moves")!;
    expect(moves.done).toBe(1);
    expect(moves.unaided).toBe(0);
    expect(moves.percent).toBe(0);
  });

  it("never reports a bar above 100% or an area it has no lessons for", () => {
    const i = computeInsights(EMPTY_PROGRESS);
    expect(i.areas).toHaveLength(SKILL_AREAS.length);
    for (const a of i.areas) {
      expect(a.percent).toBeGreaterThanOrEqual(0);
      expect(a.percent).toBeLessThanOrEqual(100);
      expect(a.unaided).toBeLessThanOrEqual(a.built);
    }
  });

  it("counts a streak of real days and forgives one late night", () => {
    const today = dayKey();
    expect(currentStreak([], today)).toBe(0);
    expect(currentStreak([today], today)).toBe(1);
    expect(currentStreak([daysAgo(2), daysAgo(1), today], today)).toBe(3);
    // finished yesterday but not yet today — the streak is still alive
    expect(currentStreak([daysAgo(2), daysAgo(1)], today)).toBe(2);
    // a gap ends it, it is never negative and never punishes
    expect(currentStreak([daysAgo(5), daysAgo(4)], today)).toBe(0);
  });

  it("greets by the clock", () => {
    expect(greeting(new Date(2026, 8, 30, 8))).toBe("Good morning");
    expect(greeting(new Date(2026, 8, 30, 14))).toBe("Good afternoon");
    expect(greeting(new Date(2026, 8, 30, 21))).toBe("Good evening");
  });
});

describe("the Home screen", () => {
  it("opens first and offers a real next lesson, not a fake dashboard", async () => {
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    expect(screen.getByText(/Good (morning|afternoon|evening)\./)).toBeTruthy();
    expect(screen.getByText(/Today's training/i)).toBeTruthy();
    // with no history it must not show a score
    expect(screen.queryByText(/^brain score$/i)).toBeNull();
    expect(screen.getByText(/lessons solved without help/i)).toBeTruthy();
    expect(screen.getByText(/Practice counts are not a chess rating/i)).toBeTruthy();
  });

  it("takes you straight into the lesson the card names", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    const title = screen.getByText(/The board, your colour and whose turn it is/i);
    expect(title).toBeTruthy();
    await user.click(screen.getByRole("button", { name: /start training/i }));
    // the lesson runner is open, not just the lesson list
    await waitFor(() => expect(screen.getByRole("grid", { name: /chess board/i })).toBeTruthy());
  });

  it("offers to carry on a saved game only when one exists", async () => {
    localStorage.setItem(ONBOARD_KEY, "1");
    const { unmount } = render(<App />);
    expect(screen.queryByText(/carry on where you stopped/i)).toBeNull();
    unmount();

    localStorage.setItem(
      "chessworkermind:game:v2",
      JSON.stringify({
        fen: "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2",
        pgn: '1. e4 e5 *',
        mode: "vsComputer",
        humanSide: "w",
        orientation: "w",
        savedAt: Date.now(),
      }),
    );
    render(<App />);
    expect(screen.getByText(/carry on where you stopped/i)).toBeTruthy();
  });
});

describe("the Brain screen", () => {
  it("refuses to show a score without evidence and says why", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    await user.click(within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^progress$/i }));

    expect((await screen.findAllByText(/Not enough practice yet/i)).length).toBeGreaterThan(0);
    expect(screen.getByText(/completed set is not a mastery score/i)).toBeTruthy();
    // and it must not claim to be a rating
    expect(screen.getByText(/not an Elo rating/i)).toBeTruthy();
  });

  it("shows auditable practice counts rather than a Brain rating even with history", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    localStorage.setItem(
      PROGRESS_KEY,
      JSON.stringify(
        progressWith([
          { id: "board-basics", concepts: ["orientation"], unaided: true },
          { id: "pawn-first-move", concepts: ["pawnMoves"], unaided: true },
          { id: "knight-l", concepts: ["knightMoves"], unaided: false },
        ]),
      ),
    );
    render(<App />);
    await user.click(within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^progress$/i }));

    expect(await screen.findByText("2 lessons")).toBeTruthy();
    expect(screen.queryByText(String(2 * POINTS_UNAIDED + POINTS_WITH_HELP))).toBeNull();
    expect(screen.getByText(/This counts practice, not intelligence or chess strength/i)).toBeTruthy();
    // every skill area is shown, and each one is either a real bar or an
    // honest "no lessons built yet" — never a silent gap
    for (const area of SKILL_AREAS) {
      expect(screen.getByText(area.name)).toBeTruthy();
    }
    // every skill is a tappable card that leads somewhere real
    const cards = screen.getAllByRole("button", { name: /lessons solved without help|no lessons built yet/i });
    expect(cards.length).toBe(SKILL_AREAS.length);
  });
});

describe("practice evidence on the Progress screen", () => {
  it("says 'Not enough practice yet' on a fresh phone", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    await user.click(within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^progress$/i }));

    const card = await screen.findByRole("region", { name: /Practice evidence/i });
    expect(within(card).getAllByText(/Not enough practice yet/i).length).toBeGreaterThan(0);
    expect(within(card).getByText(/Older summary counts are preserved/i)).toBeTruthy();
    // no invented number anywhere in the card
    expect(card.textContent).not.toMatch(/\d+\.\d+s\s*→/);
  });

  it("does not claim improvement from six mixed-difficulty historical times", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    const ids = ["board-and-sides", "pawn-capture", "knight-l", "bishop-diagonal", "rook-lines", "queen-power"];
    const times = [12000, 11000, 10600, 5200, 4600, 4600];
    let p = EMPTY_PROGRESS;
    ids.forEach((id, i) => { p = recordAttempt(p, id, [], true, times[i]); });
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(p));

    render(<App />);
    await user.click(within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^progress$/i }));

    const card = await screen.findByRole("region", { name: /Practice evidence/i });
    expect(screen.queryByText("Overall: 11.2s → 4.8s")).toBeNull();
    expect(within(card).getByText(/Time and repeated answers do not prove mastery/i)).toBeTruthy();
  });

  it("actually times a lesson solved with no hint", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    await user.click(within(nav).getByRole("button", { name: /^train$/i }));
    await user.click(await screen.findByRole("button", { name: /^lessons$/i }));
    await user.click(await screen.findByText(/The board, your colour and whose turn it is/i));

    // a real person takes at least a moment; anything under 0.4s is discarded
    await act(async () => { await new Promise((r) => setTimeout(r, 600)); });

    await user.click(screen.getByRole("gridcell", { name: /^e2,/ }));
    await user.click(screen.getByRole("gridcell", { name: /^e4,/ }));

    await waitFor(() => {
      const saved = JSON.parse(localStorage.getItem(PROGRESS_KEY) ?? "{}");
      expect(saved.solveTimes?.length).toBe(1);
      expect(saved.solveTimes[0].id).toBe("board-and-sides");
      expect(saved.solveTimes[0].ms).toBeGreaterThanOrEqual(400);
    });
  });
});

describe("the Intermediate stage in the app", () => {
  it("no longer says 'not built yet' for Intermediate", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    await user.click(within(nav).getByRole("button", { name: /^train$/i }));
    await user.click(await screen.findByRole("button", { name: /^lessons$/i }));

    expect(await screen.findByText(/^Intermediate$/)).toBeTruthy();
    expect(screen.getByText(/Forks, pins, skewers/i)).toBeTruthy();

    // "Not built yet" must appear exactly as often as there are unbuilt
    // stages — no more (over-claiming) and no fewer (hiding).
    const { STAGES } = await import("../learn/journey");
    const unbuilt = STAGES.filter((s) => !s.built).length;
    expect(screen.queryAllByText(/Not built yet/i)).toHaveLength(unbuilt);
    for (const stage of STAGES) expect(screen.getByText(stage.name)).toBeTruthy();
  });

  it("suggests an order without blocking anything", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    await user.click(within(nav).getByRole("button", { name: /^train$/i }));
    await user.click(await screen.findByRole("button", { name: /^lessons$/i }));

    // A brand new learner has no evidence, so the fork lesson is out of the
    // suggested order — but it must NOT be disabled. A padlock on something
    // that is not behind a payment reads as a paywall.
    const fork = await screen.findByText(/A fork — one piece attacking two at once/i);
    const row = fork.closest("button")!;
    expect(row.hasAttribute("disabled")).toBe(false);
    expect(row.getAttribute("aria-disabled")).not.toBe("true");
    expect(row.textContent).toMatch(/easier after/i);

    // and it really does open
    await user.click(row);
    expect(await screen.findByRole("grid", { name: /chess board/i })).toBeTruthy();
    expect(screen.getByText(/You are taking this one early/i)).toBeTruthy();
    expect(screen.getByText(/it counts just the same/i)).toBeTruthy();
  });

  it("opens the fork lesson once the learner has earned it, and it is playable", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    localStorage.setItem(
      PROGRESS_KEY,
      JSON.stringify({ version: 1, lessons: {}, concepts: ["safeCapture"], days: [], solveTimes: [] }),
    );
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    await user.click(within(nav).getByRole("button", { name: /^train$/i }));
    await user.click(await screen.findByRole("button", { name: /^lessons$/i }));
    await user.click(await screen.findByText(/A fork — one piece attacking two at once/i));

    expect(await screen.findByRole("grid", { name: /chess board/i })).toBeTruthy();
    // the lesson explains the word before using it
    expect(screen.getByText(/attacks two things at the same time/i)).toBeTruthy();

    // and the fork can actually be played
    await user.click(screen.getByRole("gridcell", { name: /^b5,/ }));
    await user.click(screen.getByRole("gridcell", { name: /^c7,/ }));
    expect(screen.getByRole("gridcell", { name: /^c7,/ }).getAttribute("aria-label")).toMatch(/White knight/i);
  });
});

describe("the Progress page does not repeat itself", () => {
  async function openProgress(user: ReturnType<typeof userEvent.setup>) {
    render(<App />);
    await user.click(
      within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^progress$/i }),
    );
    return await screen.findByText(/Your skills/i);
  }

  it("says 'not enough practice yet' at most twice, not once per card", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    await openProgress(user);

    // It used to appear eight times on one screen: the hero, the speed card
    // and all six skill cards. Six refusals in a row is not a progress page.
    const repeats = screen.queryAllByText(/not enough practice yet/i);
    expect(repeats.length, "the page is repeating itself").toBeLessThanOrEqual(2);
  });

  it("an empty skill card invites you to start instead of refusing", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    await openProgress(user);

    const cards = screen.getAllByRole("button", { name: /lessons solved without help|no lessons built yet/i });
    expect(cards.length).toBe(6);
    const withStart = cards.filter((c) => /start with:/i.test(c.textContent ?? ""));
    expect(withStart.length, "empty cards should point at a first lesson").toBeGreaterThan(0);
    for (const c of withStart) {
      expect(c.textContent).not.toMatch(/not enough practice yet/i);
    }
  });

  it("uses no colour emoji, which fight the palette", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    await openProgress(user);
    // the shield, book and abacus rendered bright blue, brown and red
    const page = document.body.textContent ?? "";
    for (const emoji of ["🛡", "📖", "🧮", "🧠"]) {
      expect(page, `${emoji} is a colour emoji`).not.toContain(emoji);
    }
  });

  it("gives the weekly numbers once, as numbers", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    localStorage.setItem(
      PROGRESS_KEY,
      JSON.stringify(recordAttempt(EMPTY_PROGRESS, "board-and-sides", ["orientation"], false)),
    );
    await openProgress(user);

    // one compact row, not three paragraphs all saying "1 lesson"
    for (const label of [/^Finished$/, /^With no help$/, /^To review$/]) {
      expect(screen.getByText(label)).toBeTruthy();
    }
    const report = screen.getByText(/This week's report/i).closest(".card")!;
    const paragraphs = Array.from(report.querySelectorAll("p"));
    expect(paragraphs.length, "the report should be one sentence, not three").toBeLessThanOrEqual(1);
  });
});

describe("the Progress page gives you something to press", () => {
  async function progress(user: ReturnType<typeof userEvent.setup>) {
    render(<App />);
    await user.click(
      within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^progress$/i }),
    );
    await screen.findByText(/Your skills/i);
  }

  it("leads with one clear action", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    await progress(user);

    const cta = screen.getByRole("button", { name: /start your first lesson/i });
    expect(cta).toBeTruthy();
    await user.click(cta);
    expect(await screen.findByRole("grid", { name: /chess board/i })).toBeTruthy();
  });

  it("offers Train, Play and Review, and each one goes somewhere", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    await progress(user);

    const row = screen.getByRole("navigation", { name: /what next/i });
    for (const name of [/train/i, /play/i, /review/i]) {
      expect(within(row).getByRole("button", { name }), `${name} missing`).toBeTruthy();
    }

    await user.click(within(row).getByRole("button", { name: /review/i }));
    expect(await screen.findByRole("heading", { name: /review a game/i })).toBeTruthy();
  });

  it("shows progress through a first practice set without promising a rating", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    localStorage.setItem(
      PROGRESS_KEY,
      JSON.stringify(recordAttempt(EMPTY_PROGRESS, "board-and-sides", ["orientation"], true, 5000)),
    );
    await progress(user);

    const meter = screen.getByRole("img", { name: /1 of 3 lessons in your first practice set/i });
    expect(meter.querySelectorAll(".brainhero__pip")).toHaveLength(3);
    expect(meter.querySelectorAll(".brainhero__pip.is-done")).toHaveLength(1);
  });

  it("every skill card that can be practised says so", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    await progress(user);

    const cards = screen.getAllByRole("button", { name: /lessons solved without help|no lessons built yet/i });
    const pressable = cards.filter((c) => !c.hasAttribute("disabled"));
    expect(pressable.length).toBeGreaterThan(0);
    for (const c of pressable) {
      expect(c.querySelector(".skillcard__go"), "a tappable card must show its action").toBeTruthy();
    }
  });
});

describe("regression: a skill card opens its own lesson", () => {
  it("tapping a skill goes to that lesson, not the lesson list", async () => {
    // App passed `onTrain={() => goTrain()}`, which swallowed the lesson id,
    // so every skill card and the hero button just opened the list.
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    await user.click(
      within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^progress$/i }),
    );
    await screen.findByText(/Your skills/i);

    await user.click(screen.getByRole("button", { name: /Piece moves: .*Practise/i }));

    // the lesson itself opened: a board, and the lesson's own words
    expect(await screen.findByRole("grid", { name: /chess board/i })).toBeTruthy();
    expect(screen.getByText(/The board, your colour and whose turn it is/i)).toBeTruthy();
  });
});

describe("every piece on the board is drawn and told apart by colour", () => {
  it("shows a piece on all 32 occupied squares, marked white or black", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    await user.click(
      within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^games$/i }),
    );

    const occupied = screen
      .getAllByRole("gridcell")
      .filter((c) => !/empty/.test(c.getAttribute("aria-label") ?? ""));
    expect(occupied).toHaveLength(32);
    for (const c of occupied) {
      expect(c.querySelector(".piece"), "every occupied square shows a piece").toBeTruthy();
    }

    // colour is carried by a class, not only by the glyph, so the two sides
    // stay distinguishable in high contrast and to a screen reader
    expect(screen.getByRole("gridcell", { name: /^e1,/ }).querySelector(".piece--w")).toBeTruthy();
    expect(screen.getByRole("gridcell", { name: /^e8,/ }).querySelector(".piece--b")).toBeTruthy();
    expect(screen.getByRole("gridcell", { name: /^e1,/ }).getAttribute("aria-label")).toMatch(/White king/i);
  });
});

describe("a lesson shows the whole clue ladder up front", () => {
  it("every step is listed, and each reveals only when asked", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    await user.click(within(nav).getByRole("button", { name: /^train$/i }));
    await user.click(await screen.findByRole("button", { name: /^lessons$/i }));
    await user.click(await screen.findByText(/Trick: the pawn that is not free/i));

    // the learner can see how much help exists before taking any of it
    expect(screen.getByText("Clue 1")).toBeTruthy();
    expect(screen.getByText("Clue 2")).toBeTruthy();
    expect(screen.getByText("Clue 3")).toBeTruthy();
    expect(screen.getByText(/The idea behind it/i)).toBeTruthy();
    expect(screen.getByText(/Show me the answer/i)).toBeTruthy();

    await user.click(screen.getByText("Clue 1"));
    expect(screen.getByText(/The pawn on c6 is the important one/i)).toBeTruthy();
    expect(screen.queryByText("Clue 1")).toBeNull();
    expect(screen.getByText("Clue 2"), "later clues stay hidden until asked").toBeTruthy();
  });
});
