import "@testing-library/jest-dom/vitest";
import { fireEvent, render, screen, cleanup } from "@testing-library/react";
import { Chess } from "chess.js";
import { describe, expect, it } from "vitest";
import { DEFAULT_DIFFICULTY, DIFFICULTY_KEY, LEARNING_TIERS, lessonForTier, loadDifficulty, saveDifficulty } from "../learn/difficulty";
import DifficultyPanel from "../learn/DifficultyPanel";
import { solutionMoves } from "../learn/lessonEngine";
import { adaptiveRecommendation, loadEvidence, recordEvidence, skillEvidence } from "../learn/evidence";
import Rehearsal from "../train/Rehearsal";
import { buildFactPacket } from "../coach/factPacket";
import { legalLine, positionFacts } from "../coach/positionFacts";
import type { Candidate } from "../engine/useEngine";
import { saveSession, loadSession } from "../chess/session";

const fen=new Chess().fen();
const candidate=(uci:string,pvSans:string[]):Candidate=>({uci,pvSans,san:pvSans[0],depth:12,multipv:1,scoreCp:30,raw:""});
const input=(id:string,positionId:string,correct=true)=>{
  const c=new Chess(); const opening=({b:"e4","0":"e4","1":"d4","2":"c4"} as Record<string,string>)[positionId];
  if(opening)c.move(opening); const m=c.moves({verbose:true})[0];
  return {id,positionId,lessonId:"free-piece",fen:c.fen(),concepts:["safeCapture"],dimension:"transfer" as const,exerciseTier:2,hintLevel:0,revealed:false,answer:`${m.from}${m.to}${m.promotion??""}`,correct,independent:true};
};

describe("independent difficulty controls",()=>{
  it.each(LEARNING_TIERS)("Learning $level opens a real solvable representative exercise",t=>{
    const lesson=lessonForTier(t.level); const c=new Chess(lesson.fen);
    expect(c.isGameOver()).toBe(false); expect(lesson.goal.kind).not.toBe("read");
    expect(solutionMoves(lesson.fen!,lesson.goal).length).toBeGreaterThan(0);
  });
  it("has labelled selectors and preserves independent levels and Manual after remount",()=>{
    render(<DifficultyPanel/>);
    fireEvent.click(screen.getByText(/Train settings/));
    fireEvent.change(screen.getByLabelText("Learning level (1–10)"),{target:{value:"2"}});
    fireEvent.change(screen.getByLabelText("Computer strength (1–10)"),{target:{value:"7"}});
    fireEvent.change(screen.getByLabelText("Learning guidance"),{target:{value:"manual"}});
    cleanup();render(<DifficultyPanel/>);
    expect(screen.getByLabelText("Learning level (1–10)")).toHaveValue("2");
    expect(screen.getByLabelText("Computer strength (1–10)")).toHaveValue("7");
    expect(screen.getByLabelText("Learning guidance")).toHaveValue("manual");
    fireEvent.change(screen.getByLabelText("Learning guidance"),{target:{value:"adaptive"}});
    expect(loadDifficulty()).toEqual({learning:2,computer:7,mode:"adaptive"});
  });
  it("rejects corrupt/out of range settings",()=>{
    localStorage.setItem(DIFFICULTY_KEY,'{"learning":11,"computer":-1,"mode":"oops"}');
    expect(loadDifficulty()).toEqual(DEFAULT_DIFFICULTY);
  });
});
describe("auditable practice, not fake mastery",()=>{
  it("stores settings, exact position, answer and verifier; repeated/revealed positions are not independent",()=>{
    saveDifficulty({learning:2,computer:7,mode:"manual"});
    recordEvidence(input("1","a"));recordEvidence(input("1","a"));recordEvidence(input("2","a"));
    recordEvidence({...input("3","b"),revealed:true});
    const e=loadEvidence();expect(e).toHaveLength(3);expect(e.map(a=>a.independent)).toEqual([true,false,false]);
    expect(e[0]).toMatchObject({learningLevel:2,computerStrength:7,mode:"manual",fen,provenance:{engineVersion:"not used"}});
    expect(skillEvidence(e,"safeCapture").distinctIndependent).toBe(1);
    expect(adaptiveRecommendation(e,2)).toBeNull();
  });
  it("suggests only after varied comparable independent success and never changes settings automatically",()=>{
    saveDifficulty({learning:2,computer:7,mode:"manual"});
    for(let i=0;i<3;i++)recordEvidence(input(String(i),String(i)));
    expect(adaptiveRecommendation(loadEvidence(),2)?.level).toBe(3);
    expect(adaptiveRecommendation(loadEvidence(),8)).toBeNull();
    expect(loadDifficulty().learning).toBe(2);
  });
});
describe("exact-position facts and conditional replay",()=>{
  it("reconstructs each legal PV move instead of repeating the candidate UCI",()=>{
    const p=buildFactPacket({beforeFen:fen,playedUci:"d2d4",candidates:[candidate("e2e4",["e4","e5","Nf3"])],engineVersion:"test",depth:12,multiPv:1})!;
    expect(p.candidates[0].pvUcis).toEqual(["e2e4","e7e5","g1f3"]);
    expect(p.opponentThreat).toBeNull();
    expect(legalLine(fen,p.candidates[0].pvUcis)).not.toBeNull();
  });
  it("rejects illegal line suffixes and malformed or omitted promotions",()=>{
    const p=buildFactPacket({beforeFen:fen,playedUci:"e2e4",candidates:[candidate("e2e4",["e4","e5","Qh9"])],engineVersion:"test",depth:12,multiPv:1})!;
    expect(p.candidates).toEqual([]);
    const promotion="7k/P7/8/8/8/8/8/4K3 w - - 0 1";
    expect(buildFactPacket({beforeFen:promotion,playedUci:"a7a8",candidates:[],engineVersion:"none",depth:0,multiPv:0})).toBeNull();
  });
  it("quiet initial board has no invented tactic and mismatched analysis is discarded",()=>{
    const p=positionFacts(fen,12,{fen,positionId:11,depth:12,candidates:[candidate("e2e4",["e4"])],bestUci:"e2e4",engineVersion:"test"});
    expect(p.boardFacts.checks).toEqual([]);expect(p.boardFacts.captures).toEqual([]);expect(p.verifiedAnalysis).toBeNull();
    expect(p.unknown.join(" ")).toContain("No strongest reply");
  });
  it("replay and isolated retry leave the saved game byte-for-byte unchanged",()=>{
    saveSession({fen,pgn:new Chess().pgn(),orientation:"w",mode:"vsComputer",humanSide:"w",updatedAt:"2026-10-02T00:00:00Z"});
    const original=JSON.stringify(loadSession());
    render(<Rehearsal fen={fen} line={["e2e4","e7e5"]} onClose={()=>{}}/>);
    fireEvent.click(screen.getByRole("button",{name:"Next move"}));
    expect(screen.getByRole("gridcell",{name:/^e4, White pawn/})).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button",{name:"Retry from original position"}));
    fireEvent.click(screen.getByRole("gridcell",{name:/^d2, White pawn/}));fireEvent.click(screen.getByRole("gridcell",{name:/^d4, empty/}));
    expect(JSON.stringify(loadSession())).toBe(original);
    expect(screen.getByRole("button",{name:"Return to current position"})).toBeInTheDocument();
  });
});
