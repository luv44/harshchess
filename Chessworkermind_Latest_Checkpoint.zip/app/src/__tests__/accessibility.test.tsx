/**
 * Can someone actually use this without a mouse, without good eyesight, or
 * with the phone's text size turned all the way up?
 *
 * Most of this can be checked here. What cannot — how big 44px really feels,
 * whether the Hindi and Arabic layouts look right — is written down in
 * PREVIEW.md as needing a real device, not quietly claimed.
 */
import { beforeEach, describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { SESSION_KEY } from "../chess/session";

const ONBOARD_KEY = "chessworkermind:onboarded:v2";
const CSS = readFileSync(resolve(__dirname, "../styles/coach.css"), "utf8");

function seed(fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1") {
  localStorage.setItem(ONBOARD_KEY, "1");
  localStorage.setItem(
    SESSION_KEY,
    JSON.stringify({ fen, pgn: "", orientation: "w", mode: "vsComputer", humanSide: "w", savedAt: Date.now() }),
  );
}

async function openGames(user: ReturnType<typeof userEvent.setup>) {
  await user.click(
    within(screen.getByRole("navigation", { name: /main/i })).getByRole("button", { name: /^games$/i }),
  );
}

function square(id: string) {
  return screen.getByRole("gridcell", { name: new RegExp(`^${id},`) });
}

beforeEach(() => localStorage.clear());

describe("playing chess with only a keyboard", () => {
  it("the board is ONE tab stop, not sixty-four", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openGames(user);

    const cells = screen.getAllByRole("gridcell");
    expect(cells).toHaveLength(64);
    const reachable = cells.filter((c) => c.getAttribute("tabindex") === "0");
    expect(reachable).toHaveLength(1);
    expect(cells.filter((c) => c.getAttribute("tabindex") === "-1")).toHaveLength(63);
  });

  it("the arrow keys walk around the board", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openGames(user);

    square("e1").focus();
    expect(document.activeElement).toBe(square("e1"));

    await user.keyboard("{ArrowUp}");
    expect(document.activeElement).toBe(square("e2"));
    await user.keyboard("{ArrowRight}");
    expect(document.activeElement).toBe(square("f2"));
    await user.keyboard("{ArrowDown}");
    expect(document.activeElement).toBe(square("f1"));
    await user.keyboard("{ArrowLeft}");
    expect(document.activeElement).toBe(square("e1"));
  });

  it("does not fall off the edge of the board", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openGames(user);

    square("a1").focus();
    await user.keyboard("{ArrowLeft}{ArrowLeft}{ArrowDown}{ArrowDown}");
    expect(document.activeElement).toBe(square("a1"));

    square("h8").focus();
    await user.keyboard("{ArrowRight}{ArrowUp}");
    expect(document.activeElement).toBe(square("h8"));
  });

  it("Home, End, Page Up and Page Down jump to the edges", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openGames(user);

    square("d4").focus();
    await user.keyboard("{Home}");
    expect(document.activeElement).toBe(square("a4"));
    await user.keyboard("{End}");
    expect(document.activeElement).toBe(square("h4"));
    await user.keyboard("{PageUp}");
    expect(document.activeElement).toBe(square("h8"));
    await user.keyboard("{PageDown}");
    expect(document.activeElement).toBe(square("h1"));
  });

  it("plays a whole legal move with the keyboard alone", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openGames(user);

    square("e2").focus();
    await user.keyboard("{Enter}"); // pick the pawn up
    expect(square("e2").getAttribute("aria-selected")).toBe("true");
    expect(square("e4").getAttribute("aria-label")).toMatch(/legal move/i);

    await user.keyboard("{ArrowUp}{ArrowUp}{Enter}"); // e3, e4, play it
    expect(square("e4").getAttribute("aria-label")).toMatch(/White pawn/i);
    expect(square("e2").getAttribute("aria-label")).toMatch(/empty/i);
  });

  it("Escape puts a picked-up piece back", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openGames(user);

    square("g1").focus();
    await user.keyboard("{Enter}");
    expect(square("g1").getAttribute("aria-selected")).toBe("true");

    await user.keyboard("{Escape}");
    expect(square("g1").getAttribute("aria-selected")).toBe("false");
    expect(square("f3").getAttribute("aria-label")).not.toMatch(/legal move/i);
  });

  it("the arrow keys follow the picture when the board is flipped", async () => {
    const user = userEvent.setup();
    seed();
    localStorage.setItem(
      SESSION_KEY,
      JSON.stringify({
        fen: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        pgn: "",
        orientation: "b",
        mode: "vsComputer",
        humanSide: "w",
        savedAt: Date.now(),
      }),
    );
    render(<App />);
    await openGames(user);

    // Black at the bottom: pressing Up must move UP the screen, which is
    // towards rank 1, not rank 8.
    square("e8").focus();
    await user.keyboard("{ArrowUp}");
    expect(document.activeElement).toBe(square("e7"));
  });

  it("tells a screen-reader user how the keys work", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openGames(user);

    const grid = screen.getByRole("grid", { name: /chess board/i });
    const describedBy = grid.getAttribute("aria-describedby");
    expect(describedBy).toBeTruthy();
    const help = document.getElementById(describedBy!);
    expect(help?.textContent).toMatch(/arrow keys/i);
    expect(help?.textContent).toMatch(/Enter or Space/i);
    expect(help?.textContent).toMatch(/Escape/i);
  });
});

describe("getting around the app without a mouse", () => {
  it("offers a skip link before anything else on the page", async () => {
    seed();
    render(<App />);
    const skip = screen.getByRole("link", { name: /skip to the board/i });
    expect(skip.getAttribute("href")).toBe("#main");
    // it must be the very first focusable thing
    const focusables = Array.from(
      document.querySelectorAll<HTMLElement>("a[href], button:not([tabindex='-1']), [tabindex='0']"),
    );
    expect(focusables[0]).toBe(skip);
    expect(document.getElementById("main")).toBeTruthy();
  });

  it("every navigation button says what it is, in words", async () => {
    seed();
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    for (const b of within(nav).getAllByRole("button")) {
      expect((b.textContent ?? "").replace(/[^A-Za-z]/g, "").length).toBeGreaterThan(2);
    }
  });

  it("no button anywhere is an unlabelled icon", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openGames(user);

    for (const b of screen.getAllByRole("button")) {
      const name = b.getAttribute("aria-label") ?? b.textContent ?? "";
      expect(name.trim().length, `a button with no name: ${b.outerHTML.slice(0, 90)}`).toBeGreaterThan(0);
    }
  });
});

describe("eyes, colour and motion", () => {
  it("board state never depends on colour alone", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await openGames(user);

    // selection, legal moves and the last move all reach the accessible name
    square("e2").focus();
    await user.keyboard("{Enter}");
    expect(square("e4").getAttribute("aria-label")).toMatch(/legal move/i);
    expect(square("e2").getAttribute("aria-selected")).toBe("true");
  });

  it("respects the phone's reduce-motion setting for everything, not just some parts", () => {
    expect(CSS).toMatch(/@media \(prefers-reduced-motion: reduce\)/);
    const block = CSS.slice(CSS.indexOf("@media (prefers-reduced-motion: reduce)"));
    expect(block).toMatch(/\*,/); // a blanket rule, not a handful of classes
    expect(block).toMatch(/animation-duration:\s*0\.001ms\s*!important/);
  });

  it("keeps the board readable in forced-colours / high-contrast mode", () => {
    expect(CSS).toMatch(/@media \(forced-colors: active\)/);
    const block = CSS.slice(CSS.indexOf("@media (forced-colors: active)"));
    expect(block).toMatch(/CanvasText/);
  });

  it("has one focus ring rule that covers everything interactive", () => {
    expect(CSS).toMatch(/:where\(a, button, input, select, textarea, summary, \[tabindex\]\):focus-visible/);
  });
});

describe("large text and big fingers", () => {
  it("no text is pinned to a pixel size, so the phone's text setting works", () => {
    const pinned = [...CSS.matchAll(/font-size:\s*(\d+(?:\.\d+)?)px/g)].map((m) => m[0]);
    expect(pinned, `these ignore the reader's text size: ${pinned.join(", ")}`).toEqual([]);
  });

  it("guarantees a 44px target for buttons, with a floor for dense rows", () => {
    expect(CSS).toMatch(/min-height:\s*44px/);
    expect(CSS).toMatch(/\.btn--sm,[\s\S]{0,80}min-height:\s*40px/);
  });

  it("the board scales with the screen instead of a fixed pixel width", () => {
    const board = CSS.slice(CSS.indexOf(".board {"), CSS.indexOf(".board {") + 400);
    // the grid itself simply fills whatever the frame gives it
    expect(board).toMatch(/width:\s*100%/);
    expect(board).not.toMatch(/width:\s*\d+px/);

    // and the frame never grows wider than the screen
    const frame = CSS.slice(CSS.indexOf(".boardframe {"), CSS.indexOf(".boardframe {") + 300);
    expect(frame).toMatch(/width:\s*min\(100%/);
  });

  it("no coordinate is painted on top of a piece any more", () => {
    // They used to be absolutely positioned inside the corner of an edge
    // square, over the piece. They live in the frame now.
    expect(CSS).not.toMatch(/\.sq__coord/);
    expect(CSS).toMatch(/\.boardframe__ranks/);
    expect(CSS).toMatch(/\.boardframe__files/);
  });

  it("marks every highlighted square in high-contrast mode, using classes that exist", () => {
    const block = CSS.slice(CSS.indexOf("@media (forced-colors: active)"));
    for (const cls of ["sq--selected", "sq--last", "sq--sfrom", "sq--sto", "sq--threat", "sq--check"]) {
      expect(block, `${cls} must be covered`).toMatch(new RegExp(`\\.${cls}\\b`));
    }
  });
});

describe("right-to-left languages", () => {
  it("turns the whole page around for Arabic and back again", async () => {
    const user = userEvent.setup();
    seed();
    render(<App />);
    await user.click(screen.getByRole("button", { name: /settings and language/i }));
    const picker = await screen.findByRole("region", { name: /language picker/i });

    await user.click(within(picker).getByRole("option", { name: /العربية/ }));
    expect(document.documentElement.dir).toBe("rtl");
    expect(document.documentElement.lang).toBe("ar");

    await user.click(within(picker).getByRole("option", { name: /English/ }));
    expect(document.documentElement.dir).toBe("ltr");
  });

  it("uses direction-neutral spacing, so nothing sits on the wrong side in Arabic", () => {
    const physical = [...CSS.matchAll(/^\s*(margin|padding)-(left|right):/gm)].map((m) => m[0].trim());
    expect(physical, `use inline-start / inline-end instead: ${physical.join(", ")}`).toEqual([]);
  });
});

/**
 * Layout bugs the user actually reported, turned into tests so they cannot
 * come back. The worst was "The rook slides in straight linesOne move to
 * find" — a title and its note rendered on the same line with no space,
 * because the wrapper held <span> children and was not a column.
 */
describe("stacked labels never share a line", () => {
  it("every __body wrapper is a column", () => {
    for (const sel of [".rowcard__body", ".lessonrow__body"]) {
      const rule = CSS.slice(CSS.indexOf(`${sel} {`), CSS.indexOf(`${sel} {`) + 220);
      expect(rule, `${sel} must stack its children`).toMatch(/flex-direction:\s*column/);
    }
    // plus a catch-all so a new __body cannot repeat the bug
    expect(CSS).toMatch(/span\[class\$="__body"\][\s\S]{0,140}flex-direction:\s*column/);
  });

  it("title, note and kicker spans are block-level", () => {
    for (const sel of [".lessonrow__title", ".lessonrow__note", ".rowcard__kicker", ".rowcard__title"]) {
      const rule = CSS.slice(CSS.indexOf(`${sel} {`), CSS.indexOf(`${sel} {`) + 200);
      expect(rule, `${sel} must be display:block`).toMatch(/display:\s*block/);
    }
  });

  it("a lesson row really renders its title and note as separate lines", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    await user.click(within(nav).getByRole("button", { name: /^train$/i }));
    await user.click(await screen.findByRole("button", { name: /^lessons$/i }));

    const title = await screen.findByText(/The rook slides in straight lines/i);
    // the note must be a SIBLING element, not glued into the same text node
    expect(title.textContent?.trim()).toBe("The rook slides in straight lines");
    const note = title.parentElement?.querySelector(".lessonrow__note");
    expect(note).toBeTruthy();
    expect(note!.textContent).toMatch(/one move to find/i);
  });
});

describe("no developer jargon leaks into the interface", () => {
  it("a not-yet-suggested lesson explains itself in words, not camelCase ids", async () => {
    const user = userEvent.setup();
    localStorage.setItem(ONBOARD_KEY, "1");
    render(<App />);
    const nav = screen.getByRole("navigation", { name: /main/i });
    await user.click(within(nav).getByRole("button", { name: /^train$/i }));
    await user.click(await screen.findByRole("button", { name: /^lessons$/i }));

    const notes = Array.from(document.querySelectorAll(".lessonrow__note")).map((n) => n.textContent ?? "");
    expect(notes.length).toBeGreaterThan(0);
    for (const n of notes) {
      expect(n, `camelCase id leaked: ${n}`).not.toMatch(/[a-z][A-Z]/);
    }
    expect(notes.some((n) => /easier after/i.test(n))).toBe(true);
    expect(notes.some((n) => /how the rook moves|how the bishop moves/i.test(n))).toBe(true);
  });
});

describe("bars that sit over the page are solid", () => {
  it("content cannot show through the header or the bottom bar", () => {
    const top = CSS.slice(CSS.indexOf(".topbar {"), CSS.indexOf(".topbar {") + 320);
    const bottom = CSS.slice(CSS.indexOf(".bottomnav {"), CSS.indexOf(".bottomnav {") + 380);
    for (const [name, rule] of [["topbar", top], ["bottomnav", bottom]] as const) {
      expect(rule, `${name} must not be see-through`).not.toMatch(/background:\s*rgba\([^)]*0\.\d+\s*\)/);
      expect(rule, `${name} must not rely on backdrop-filter`).not.toMatch(/backdrop-filter/);
    }
  });
});
