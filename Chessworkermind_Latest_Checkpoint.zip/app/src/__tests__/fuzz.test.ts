/**
 * Property-based fuzzing.
 *
 * The hand-written tests check positions I thought of. This plays thousands
 * of random positions through the coach, the move reviewer and the lesson
 * grader, and asserts the properties that must hold for EVERY position —
 * which is how you find the cases nobody thought of.
 *
 * The properties are all the same shape: the app may not point at a move
 * that cannot be played, and may not claim something a replay disagrees
 * with.
 */
import { describe, expect, it, vi } from "vitest";

// A fuzzer sweeps; it is not a unit test. The suite-wide 20s limit is right
// for everything else and far too short for this file.
vi.setConfig({ testTimeout: 180_000, hookTimeout: 180_000 });
import { Chess } from "chess.js";
import { buildCoachCard } from "../coach/coachCard";
import { threatIsReplayable } from "../coach/localAnalysis";
import { isSerious, reviewMove } from "../coach/reviewMove";
import { checkMove, goalAchievable } from "../learn/lessonEngine";
import { parseGame } from "../review/gameReview";
import { parseProgress } from "../learn/progress";
import { parseSaved } from "../chess/session";

/**
 * How wide to sweep. These are deliberately small so the everyday suite
 * stays usable — the point of a fuzzer is that it runs every time, not
 * that it runs once. Raise them when hunting something specific; the
 * seed is fixed, so a bigger sweep is a superset of this one.
 */
const CARD_POSITIONS = 30;
const REVIEWER_POSITIONS = 2;
/** Reviewing one move runs a full search, so cap how many per position. */
const MOVES_PER_POSITION = 12;
const GRADER_POSITIONS = 3;

/** Deterministic PRNG, so a failure can be reproduced exactly. */
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}

/** Random legal positions, reached by playing random legal games. */
function randomPositions(count: number, seed = 12345): string[] {
  const rand = rng(seed);
  const out: string[] = [];
  while (out.length < count) {
    const c = new Chess();
    const plies = 1 + Math.floor(rand() * 60);
    for (let i = 0; i < plies; i++) {
      const moves = c.moves();
      if (moves.length === 0) break;
      c.move(moves[Math.floor(rand() * moves.length)]);
      if (c.isGameOver()) break;
    }
    out.push(c.fen());
  }
  return out;
}

const POSITIONS = randomPositions(CARD_POSITIONS);

/**
 * Build every card ONCE and share it. The first version of this file
 * rebuilt the same cards inside each test, which at ~0.5s a card meant the
 * suite could not finish.
 */
const CARDS = POSITIONS.map((fen) => {
  const c = new Chess(fen);
  return { fen, turn: c.turn(), over: c.isGameOver(), card: buildCoachCard({ fen, positionId: 1, humanSide: c.turn() }) };
});

/** Can this move be played on this board? */
function playable(fen: string, from: string, to: string, promotion?: string): boolean {
  const c = new Chess(fen);
  try {
    return !!c.move({ from, to, promotion: (promotion as never) ?? "q" });
  } catch {
    return false;
  }
}

describe("the coach card, over random positions", () => {
  it("never points at a move that cannot be played", () => {
    const broken: string[] = [];
    for (const { fen, card } of CARDS) {
      if (card.fen !== fen) broken.push(`${fen}: card is for a different position`);

      if (card.suggestion) {
        const s = card.suggestion;
        if (!playable(fen, s.from, s.to, s.promotion)) broken.push(`${fen}: suggestion ${s.from}${s.to} illegal`);
        for (const alt of s.alternatives) {
          if (!playable(fen, alt.from, alt.to)) broken.push(`${fen}: alternative ${alt.from}${alt.to} illegal`);
        }
      }
      if (card.practice) {
        const p = card.practice;
        if (!playable(fen, p.fromSquare, p.toSquare)) broken.push(`${fen}: practice ${p.fromSquare}${p.toSquare} illegal`);
      }
    }
    expect(broken.slice(0, 5)).toEqual([]);
  });

  it("never claims a mate, capture or check that a replay disagrees with", () => {
    const lies: string[] = [];
    for (const { fen, over, card } of CARDS) {
      if (over) continue;
      const s = card.suggestion;
      if (!s) continue;

      const probe = new Chess(fen);
      const played = probe.move({ from: s.from, to: s.to, promotion: (s.promotion as never) ?? "q" });

      if (s.isMate !== probe.isCheckmate()) lies.push(`${fen}: isMate=${s.isMate} but board says ${probe.isCheckmate()}`);
      if (s.isCheck !== probe.isCheck()) lies.push(`${fen}: isCheck=${s.isCheck} but board says ${probe.isCheck()}`);
      if (s.isCapture !== !!played.captured) lies.push(`${fen}: isCapture=${s.isCapture} but board says ${!!played.captured}`);
      if (s.pieceType !== played.piece) lies.push(`${fen}: pieceType=${s.pieceType} but board says ${played.piece}`);
      if (s.captured && s.captured !== played.captured) lies.push(`${fen}: captured=${s.captured} vs ${played.captured}`);
      if (card.reason?.key === "mate" && !probe.isCheckmate()) lies.push(`${fen}: reason says mate, board disagrees`);
    }
    expect(lies.slice(0, 5)).toEqual([]);
  });

  it("every threat it reports is real — a playable move, or a check that exists", () => {
    const bad: string[] = [];
    for (const { fen, over, card } of CARDS) {
      if (over) continue;
      const t = card.threat.threat;
      if (!card.threat.present || !t) continue;

      if (threatIsReplayable(t)) {
        // a future move: it must be playable in the position it was found in
        if (!playable(t.threatFen, t.from, t.to)) {
          bad.push(`${fen}: threat ${t.from}${t.to} not playable in ${t.threatFen}`);
        }
      } else {
        // an existing check: `from` holds an enemy piece, `to` holds OUR king
        const c = new Chess(fen);
        const attacker = c.get(t.from as never);
        const king = c.get(t.to as never);
        if (!c.isCheck()) bad.push(`${fen}: claimed an immediate check but the board is not in check`);
        if (!attacker || attacker.color === c.turn()) bad.push(`${fen}: ${t.from} does not hold an enemy piece`);
        if (!king || king.type !== "k" || king.color !== c.turn()) bad.push(`${fen}: ${t.to} is not our king`);
      }
    }
    expect(bad.slice(0, 5)).toEqual([]);
  });

  it("every 'what might happen next' line is legal, in order", () => {
    const bad: string[] = [];
    for (const { fen, over, card } of CARDS) {
      if (over) continue;
      if (!card.future || !card.suggestion) continue;

      for (const line of card.future.lines) {
        const probe = new Chess(fen);
        probe.move({ from: card.suggestion.from, to: card.suggestion.to, promotion: "q" });
        try {
          probe.move({ from: line.theirMove.from, to: line.theirMove.to, promotion: "q" });
        } catch {
          bad.push(`${fen}: their reply ${line.theirMove.san} is not legal`);
          continue;
        }
        if (line.ourReply) {
          try {
            probe.move({ from: line.ourReply.from, to: line.ourReply.to, promotion: "q" });
          } catch {
            bad.push(`${fen}: our follow-up ${line.ourReply.san} is not legal`);
          }
        }
      }
    }
    expect(bad.slice(0, 5)).toEqual([]);
  });
});

describe("the move reviewer, over every legal move of a few random positions", () => {
  it("never names a punishment that cannot be played", () => {
    const bad: string[] = [];
    for (const fen of POSITIONS.slice(0, REVIEWER_POSITIONS)) {
      const c = new Chess(fen);
      if (c.isGameOver()) continue;
      for (const m of c.moves({ verbose: true }).slice(0, MOVES_PER_POSITION)) {
        const r = reviewMove({ fen, from: m.from, to: m.to, promotion: m.promotion });
        if (!r.legal) {
          bad.push(`${fen}: ${m.san} reported illegal but chess.js allows it`);
          continue;
        }
        if (r.risk && !playable(r.fenAfter!, r.risk.from, r.risk.to)) {
          bad.push(`${fen}: punishment ${r.risk.san} not playable after ${m.san}`);
        }
        for (const cand of r.candidates) {
          if (!playable(fen, cand.from, cand.to, cand.promotion)) {
            bad.push(`${fen}: candidate ${cand.san} is not legal`);
          }
        }
      }
    }
    expect(bad.slice(0, 5)).toEqual([]);
  });

  it("only calls a move serious when it can show mate or two pawns", () => {
    const bad: string[] = [];
    for (const fen of POSITIONS.slice(0, REVIEWER_POSITIONS)) {
      const c = new Chess(fen);
      if (c.isGameOver()) continue;
      for (const m of c.moves({ verbose: true }).slice(0, MOVES_PER_POSITION)) {
        const r = reviewMove({ fen, from: m.from, to: m.to, promotion: m.promotion });
        if (!r.risk) continue;
        if (r.risk.kind === "mate") {
          const probe = new Chess(r.fenAfter!);
          probe.move({ from: r.risk.from, to: r.risk.to, promotion: "q" });
          if (!probe.isCheckmate()) bad.push(`${fen}: claimed mate after ${m.san}, board disagrees`);
        } else if (isSerious(r.risk) && r.risk.materialLost < 200) {
          bad.push(`${fen}: called ${m.san} serious for only ${r.risk.materialLost}`);
        }
      }
    }
    expect(bad.slice(0, 5)).toEqual([]);
  });
});

describe("the lesson grader, over random positions", () => {
  it("accepts a move only when it is legal, for every goal kind", () => {
    const bad: string[] = [];
    // avoidLoss runs the whole move reviewer for every move, so it gets a
    // narrower sweep than the cheap goals rather than being left out.
    const cheap = [
      { kind: "capture" as const },
      { kind: "capture" as const, safe: true },
      { kind: "mate" as const },
      { kind: "check" as const },
      { kind: "avoidMate" as const },
    ];
    for (const fen of POSITIONS.slice(0, GRADER_POSITIONS)) {
      const c = new Chess(fen);
      if (c.isGameOver()) continue;
      const goals = [...cheap, ...(fen === POSITIONS[0] ? [{ kind: "avoidLoss" as const }] : [])];
      for (const goal of goals) {
        // an illegal move is never accepted
        if (checkMove(fen, "a1", "a1", undefined, goal).ok) bad.push(`${fen}: ${goal.kind} accepted a non-move`);
        // and whatever it accepts really is playable
        for (const m of c.moves({ verbose: true }).slice(0, 8)) {
          if (checkMove(fen, m.from, m.to, m.promotion, goal).ok && !playable(fen, m.from, m.to, m.promotion)) {
            bad.push(`${fen}: ${goal.kind} accepted unplayable ${m.san}`);
          }
        }
        // goalAchievable must agree with the grader
        const any = c.moves({ verbose: true }).some((m) => checkMove(fen, m.from, m.to, m.promotion, goal).ok);
        if (goalAchievable(fen, goal) !== any) {
          bad.push(`${fen}: goalAchievable disagrees with checkMove for ${goal.kind}`);
        }
      }
    }
    expect(bad.slice(0, 5)).toEqual([]);
  });
});

describe("the parsers survive rubbish instead of crashing", () => {
  const JUNK = [
    "", " ", "\n\n", "null", "undefined", "[]", "{}", "0", "false",
    "<script>alert(1)</script>", "1. e4 ".repeat(500), "♟♞♝", "e4 e5 ".repeat(400),
    '{"version":1}', '{"lessons":null}', '{"lessons":{"a":{}}}',
    '{"fen":"not a fen"}', '{"fen":null,"mode":"vsComputer"}',
    "1-0", "*", "[White \"a\"]", "%%%%", "\u0000", "é".repeat(100),
  ];

  it("parseGame never throws, and never reports success without moves", () => {
    for (const j of JUNK) {
      let r;
      expect(() => (r = parseGame(j)), `parseGame threw on ${JSON.stringify(j.slice(0, 20))}`).not.toThrow();
      if (r && (r as ReturnType<typeof parseGame>).ok) {
        const g = r as Extract<ReturnType<typeof parseGame>, { ok: true }>;
        expect(g.plies.length).toBeGreaterThan(0);
        for (const p of g.plies) expect(playable(p.fenBefore, p.from, p.to, p.promotion)).toBe(true);
      } else if (r) {
        expect((r as Extract<ReturnType<typeof parseGame>, { ok: false }>).error.length).toBeGreaterThan(5);
      }
    }
  });

  it("parseProgress and parseSaved never throw and always return usable shapes", () => {
    for (const j of JUNK) {
      expect(() => parseProgress(j), `parseProgress threw on ${j.slice(0, 20)}`).not.toThrow();
      const p = parseProgress(j);
      expect(typeof p.lessons).toBe("object");
      expect(Array.isArray(p.concepts)).toBe(true);
      expect(Array.isArray(p.days)).toBe(true);
      expect(Array.isArray(p.solveTimes)).toBe(true);

      expect(() => parseSaved(j), `parseSaved threw on ${j.slice(0, 20)}`).not.toThrow();
    }
  });

  it("a saved game with a corrupt FEN is rejected, not loaded", () => {
    const bad = JSON.stringify({ fen: "nonsense", pgn: "", mode: "vsComputer", humanSide: "w", orientation: "w" });
    const parsed = parseSaved(bad);
    if (parsed) expect(() => new Chess(parsed.fen)).not.toThrow();
  });
});
