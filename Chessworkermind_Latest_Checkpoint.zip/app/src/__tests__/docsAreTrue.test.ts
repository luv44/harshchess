/**
 * Documentation rots faster than code. The Progress page already shipped a
 * sentence that had become false ("Intermediate, Advanced and Expert stages
 * are not written yet") after those stages were built.
 *
 * These tests hold the handover documents to the same standard as the app:
 * every file they point at must exist, and every claim they make about the
 * code must still be true.
 */
import { describe, expect, it } from "vitest";
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { CHECKOUT_ENABLED, PRO_CURRENCY, PRO_MONTHLY_PRICE_RUPEES } from "../billing/pricing";
import { STAGES } from "../learn/journey";

const APP = resolve(__dirname, "../..");
const doc = (name: string) => readFileSync(resolve(APP, name), "utf8");

const DOCS = ["QA_REPORT.md", "GOING_LIVE.md", "SETUP.md", "FEATURE_MATRIX.md", "PREVIEW.md"];

describe("the handover documents exist", () => {
  it.each(DOCS)("%s is present", (name) => {
    expect(existsSync(resolve(APP, name)), `${name} is missing`).toBe(true);
    expect(doc(name).length).toBeGreaterThan(400);
  });
});

describe("every file the documents point at really exists", () => {
  it.each(DOCS)("%s cites no missing file", (name) => {
    const text = doc(name);
    // things that look like a repo path: src/..., public/..., *.md
    const paths = [...text.matchAll(/`((?:src|public)\/[A-Za-z0-9_./-]+|[A-Z_]+\.md)`/g)].map((m) => m[1]);
    const missing = paths.filter((p) => !existsSync(resolve(APP, p)) && !existsSync(resolve(APP, "src", p)));
    expect(missing, `${name} points at files that do not exist: ${missing.join(", ")}`).toEqual([]);
  });
});

describe("the documents tell the truth about the code", () => {
  it("quotes the real price and the real checkout switch", () => {
    const g = doc("GOING_LIVE.md");
    expect(g).toContain(`₹${PRO_MONTHLY_PRICE_RUPEES}/month`);
    expect(g).toContain(PRO_CURRENCY);
    expect(CHECKOUT_ENABLED, "checkout must stay off until a merchant account exists").toBe(false);
    expect(g).toMatch(/CHECKOUT_ENABLED = false/);
  });

  it("does not claim a stage is unwritten when it is built", () => {
    const unbuilt = STAGES.filter((s) => !s.built).map((s) => s.name);
    for (const name of DOCS) {
      // Strip quoted text first: the QA report quotes the OLD false
      // sentence when describing the bug that was fixed, and a report is
      // allowed to say "it used to say X".
      const text = doc(name).replace(/"[^"]*"/g, "").replace(/“[^”]*”/g, "");
      for (const s of STAGES.filter((x) => x.built)) {
        const lies = new RegExp(`${s.name}[^.\\n]{0,40}(not built|not written)`, "i");
        expect(lies.test(text), `${name} says ${s.name} is not built, but it is`).toBe(false);
      }
    }
    // and if something really is unbuilt, the QA report must not hide it
    if (unbuilt.length > 0) {
      expect(doc("QA_REPORT.md")).toMatch(new RegExp(unbuilt[0], "i"));
    }
  });

  it("links check claims to actual logs rather than counting source declarations", () => {
    const report = doc("QA_REPORT.md");
    const logs = [...report.matchAll(/`(qa\/[A-Za-z0-9_.-]+\.log)`/g)].map(m => m[1]);
    expect(logs.length).toBeGreaterThan(0);
    for (const log of logs) expect(existsSync(resolve(APP, log)), log).toBe(true);
    expect(report).toContain("npm run build");
  });

  it("distinguishes real Chromium checks from untested physical phones", () => {
    expect(doc("QA_REPORT.md")).toMatch(/Chromium/);
    expect(doc("QA_REPORT.md")).toMatch(/Physical Android\/iPhone devices were \*\*not tested\*\*/);
    expect(doc("PREVIEW.md")).toMatch(/need your phone/i);
  });

  it("never promises a rating, a title or a guaranteed result", () => {
    for (const name of DOCS) {
      expect(doc(name), `${name} must not promise a rating`).not.toMatch(
        /guarantee[sd]? (a|your) (rating|win|title)/i,
      );
    }
  });
});
