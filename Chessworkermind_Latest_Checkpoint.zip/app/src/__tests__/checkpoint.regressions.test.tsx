import "@testing-library/jest-dom/vitest";
import { act, fireEvent, render, renderHook, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { useChessGame } from "../chess/useChessGame";
import LearnJourney from "../learn/LearnJourney";
import { PROGRESS_KEY } from "../learn/progress";

const square = (s: string) => screen.getByRole("gridcell", { name: new RegExp(`^${s},`) });
const move = (a: string,b: string) => { fireEvent.click(square(a)); fireEvent.click(square(b)); };

describe("updated-prompt regression cases", () => {
  it("threefold repetition uses actual history and blocks subsequent moves", () => {
    const { result } = renderHook(() => useChessGame());
    act(() => result.current.setMode("solo"));
    for (let round=0; round<2; round++) for (const [a,b] of [["g1","f3"],["g8","f6"],["f3","g1"],["f6","g8"]] as const) {
      act(() => { expect(result.current.tryMove(a,b)).toBe(true); });
    }
    expect(result.current.status).toEqual({ kind: "draw", reason: "repetition" });
    act(() => { expect(result.current.tryMove("e2","e4")).toBe(false); });
  });
  it("transfer opens a genuinely different board and can be solved", () => {
    render(<LearnJourney openLessonId="pawn-capture" />);
    move("e4","d5");
    fireEvent.click(screen.getByRole("button",{name:/Try a similar idea/}));
    expect(square("f5")).toHaveAttribute("aria-label", expect.stringContaining("Black pawn"));
    expect(square("d5")).toHaveAttribute("aria-label", expect.stringContaining("empty"));
    move("e4","f5");
    expect(screen.getByText("Well done")).toBeInTheDocument();
  });
  it("a wrong legal lesson move cannot turn into an unaided success on the opponent turn", () => {
    render(<LearnJourney openLessonId="pawn-capture" />);
    move("e4","e5");
    move("d5","d4");
    const saved=JSON.parse(localStorage.getItem(PROGRESS_KEY) ?? '{}');
    expect(saved.lessons?.['pawn-capture']?.unaidedSuccesses ?? 0).toBe(0);
    expect(screen.getByRole("button",{name:/Reset exercise/})).toBeInTheDocument();
  });
});
