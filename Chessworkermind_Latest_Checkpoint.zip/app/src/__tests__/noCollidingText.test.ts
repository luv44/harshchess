/**
 * A guard against the bug the user kept finding.
 *
 *   "The rook slides in straight linesOne move to find"
 *   "I am new to chessStart from zero. The coach explains every move..."
 *
 * Both were the same mistake: two <span> elements meant to be a title and a
 * description underneath it, sitting inside a wrapper that did not stack
 * them. Spans are inline, so they render on one line with no space.
 *
 * Fixing them one at a time did not work — the third one was in a wrapper
 * with no class at all, which no CSS rule could reach. So this test reads
 * the real components, finds every place two or more label spans are
 * siblings, and fails unless the CSS actually stacks them.
 */
import { describe, expect, it } from "vitest";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { resolve, join } from "node:path";

const SRC = resolve(__dirname, "..");
const CSS = readFileSync(resolve(SRC, "styles/coach.css"), "utf8");

function allTsx(dir: string): string[] {
  return readdirSync(dir).flatMap((e) => {
    const p = join(dir, e);
    if (statSync(p).isDirectory()) return e === "__tests__" ? [] : allTsx(p);
    return p.endsWith(".tsx") ? [p] : [];
  });
}

/**
 * Spans that are decorations, not text: icons, chevrons, badges, dots and
 * the little numbered pills that are SUPPOSED to sit beside their text.
 */
const DECORATION = /(__icon|__chev|__badge|__dot|__ring|__glyph|__mark|__go|__spacer|__end|__top|__fill|__track|__n$|^pill|^thinkdots|^btnrow|^sq__|^board__|__corner)/;

/** Every rule body in the stylesheet, keyed by each selector it applies to. */
function rulesFor(cls: string): string[] {
  const out: string[] = [];
  const re = /([^{}]+)\{([^}]*)\}/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(CSS))) {
    const selectors = m[1].split(",").map((x) => x.trim());
    if (selectors.some((sel) => new RegExp(`\\.${cls.replace(/-/g, "\\-")}(?![\\w-])`).test(sel))) {
      out.push(m[2]);
    }
  }
  return out;
}

/** Is this class given its own line? */
function isStacked(cls: string): boolean {
  return rulesFor(cls).some((body) => /display:\s*(block|flex|grid)\b/.test(body));
}

/** Does this class stack its children, so inline kids would be separated? */
function parentStacks(cls: string): boolean {
  const first = cls.split(/\s+/)[0];
  if (!first) return false;
  // Any flex or grid parent lays its children out as separate boxes, so
  // they cannot run together as text. The bug this guards against is a
  // normal block parent holding inline spans.
  return rulesFor(first).some((body) => /display:\s*(flex|grid|inline-flex|inline-grid)\b/.test(body));
}

type Group = { file: string; parent: string; kids: string[] };

/**
 * Walk the JSX tags in order, keeping a stack, so each label span is matched
 * with its IMMEDIATE parent rather than the outermost container it happens
 * to sit in. Getting this wrong made the first version report false alarms
 * for cards whose own wrapper already stacks them.
 */
function findLabelGroups(): Group[] {
  const groups: Group[] = [];
  for (const file of allTsx(SRC)) {
    const src = readFileSync(file, "utf8");
    const tag = /<(\/?)(span|div|button|label|p|li|a)((?:"[^"]*"|'[^']*'|[^>"'])*?)(\/?)>/g;
    const stack: Array<{ cls: string; kids: string[] }> = [];
    let m: RegExpExecArray | null;
    while ((m = tag.exec(src))) {
      const [, closing, tagName, attrs = "", selfClosing] = m;
      // className can appear anywhere in the attribute list, not just first
      const cls = /className="([^"]*)"/.exec(attrs)?.[1] ?? "";
      if (closing) {
        const done = stack.pop();
        if (done && done.kids.length >= 2) {
          groups.push({ file: file.replace(SRC, "src"), parent: done.cls, kids: [...new Set(done.kids)] });
        }
        continue;
      }
      // Only <span> can collide: div, p, h3 and friends are block already.
      if (tagName === "span" && cls && !DECORATION.test(cls.trim()) && stack.length > 0) {
        stack[stack.length - 1].kids.push(cls.trim());
      }
      if (!selfClosing) stack.push({ cls: cls.trim(), kids: [] });
    }
  }
  return groups;
}

describe("no two text labels can share a line", () => {
  const groups = findLabelGroups();

  it("finds the label groups to check", () => {
    expect(groups.length).toBeGreaterThan(3);
  });

  it("every stacked label is block-level, or its parent is a column", () => {
    const broken: string[] = [];
    for (const g of groups) {
      if (parentStacks(g.parent)) continue;
      for (const kid of g.kids) {
        const first = kid.split(/\s+/)[0];
        if (!isStacked(first) && !parentStacks(first)) {
          broken.push(`${first} (inside .${g.parent}, ${g.file})`);
        }
      }
    }
    expect(
      broken,
      `these labels would collide on one line:\n  ${broken.join("\n  ")}`,
    ).toEqual([]);
  });

  it("no text wrapper is left without a class for CSS to reach", () => {
    // "<span>" immediately followed by a classed label span is the exact
    // shape that produced "I am new to chessStart from zero...".
    const offenders: string[] = [];
    for (const file of allTsx(SRC)) {
      const src = readFileSync(file, "utf8");
      const re = /<span>\s*\n\s*<span className="([^"]+)"/g;
      let m: RegExpExecArray | null;
      while ((m = re.exec(src))) {
        offenders.push(`${file.replace(SRC, "src")} -> unclassed wrapper around .${m[1]}`);
      }
    }
    expect(offenders, `give these wrappers a class:\n  ${offenders.join("\n  ")}`).toEqual([]);
  });
});
