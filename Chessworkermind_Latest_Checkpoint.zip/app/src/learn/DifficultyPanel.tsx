import { LEARNING_TIERS, useDifficulty } from "./difficulty";
import { adaptiveRecommendation, loadEvidence } from "./evidence";
import { conceptName } from "./journey";

export default function DifficultyPanel({ onPractice }: { onPractice?: (id: string) => void }) {
  const [settings, set] = useDifficulty();
  const learning = LEARNING_TIERS[settings.learning - 1];
  const suggestion = adaptiveRecommendation(loadEvidence(), settings.learning);
  const label = (n: number) => n <= 3 ? "Gentle" : n <= 6 ? "Growing" : "Challenging";
  return <details className="card difficulty-panel">
    <summary>Train settings · Learning {settings.learning} · Computer {settings.computer}</summary>
    <div className="stack" style={{ marginTop: 12 }}>
      <label htmlFor="learning-level">Learning level (1–10)</label>
      <p className="small muted" id="learning-description">Changes the lesson position and question, not your opponent. An in-app tier, not a rating.</p>
      <select id="learning-level" aria-describedby="learning-description" value={settings.learning}
        onChange={e => set({ learning: Number(e.target.value) })}>
        {LEARNING_TIERS.map(t => <option key={t.level} value={t.level}>{t.level} · {t.name}</option>)}
      </select>
      <p className="small">{learning.preview}</p>
      <label htmlFor="learning-mode">Learning guidance</label>
      <select id="learning-mode" value={settings.mode} onChange={e => set({ mode: e.target.value as "adaptive" | "manual" })}>
        <option value="adaptive">Adaptive recommendations</option><option value="manual">Manual</option>
      </select>
      {settings.mode === "adaptive" && <p className="small muted">{suggestion
        ? suggestion.reason.replace(/^[^:]+/, id => conceptName(id))
        : "Not enough varied independent evidence to suggest a change yet. Your selected level stays in control; hints and time alone never change it."}</p>}
      {settings.mode === "adaptive" && suggestion && <button className="btn" onClick={() => set({ learning: suggestion.level })}>Accept Learning {suggestion.level}</button>}
      {onPractice && <button className="btn btn--primary" onClick={() => onPractice(learning.lesson)}>Practise Learning {settings.learning}</button>}
      <label htmlFor="computer-strength">Computer strength (1–10)</label>
      <p className="small muted" id="computer-description">Changes subsequent computer replies only; no effect in local two-player mode. Requires Stockfish for the ten profiles; a failure is labelled as a legal fallback.</p>
      <select id="computer-strength" aria-describedby="computer-description" value={settings.computer}
        onChange={e => set({ computer: Number(e.target.value) })}>
        {LEARNING_TIERS.map(t => <option key={t.level} value={t.level}>{t.level} · {label(t.level)}</option>)}
      </select>
      <p className="small muted">Saved on this device. Real account sync is not connected. Strength tiers are bounded engine settings, not Elo or guaranteed strength ordering.</p>
    </div>
  </details>;
}
