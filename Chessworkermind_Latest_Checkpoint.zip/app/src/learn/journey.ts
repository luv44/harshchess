/**
 * The Learn journey — small, playable lessons from absolute zero upwards.
 *
 * HONESTY RULE: a stage is marked `built: true` only when its lessons are
 * really playable in this build. Stages that are designed but not implemented
 * are marked `built: false` and the UI says so plainly instead of showing a
 * dead button.
 *
 * Every lesson with a goal is validated by unit test: the FEN must be legal
 * and the goal must actually be achievable in that position.
 */

export type LessonGoal =
  /** Play this exact move. */
  | { kind: "exactMove"; from: string; to: string; promotion?: string }
  /** Capture anything (safely, if `safe` is set). */
  | { kind: "capture"; safe?: boolean }
  /** Get out of check. */
  | { kind: "escapeCheck" }
  /** Deliver checkmate this move. */
  | { kind: "mate" }
  /** Give check without losing the piece. */
  | { kind: "check" }
  /** Stop the opponent mating next move. Any move that does is correct. */
  | { kind: "avoidMate" }
  /** Make a move that does not hand over material or allow mate. */
  | { kind: "avoidLoss" }
  /** Just read — no move required. */
  | { kind: "read" };

export type Lesson = {
  id: string;
  /** One plain-language goal. */
  title: string;
  /** The interactive demonstration / explanation, in very easy English. */
  teach: string;
  /** The independent practice position. */
  fen?: string;
  goal: LessonGoal;
  /** Shown after success — what was understood + what to practise next. */
  afterSuccess: string;
  /** Gentle help, in order. */
  hints: string[];
  /** A different position that tests the SAME idea later (transfer). */
  transferFen?: string;
  transferGoal?: LessonGoal;
  /**
   * One short line the learner can actually carry away and use at the
   * board — the trick, not the explanation. Shown as the last hint and
   * again after a correct answer, because a rule you can repeat to
   * yourself is worth more than a paragraph you half-remember.
   */
  trick?: string;
  /** Concept ids this lesson teaches — used by the prerequisite graph. */
  concepts: string[];
  prerequisites?: string[];
};

export type Stage = {
  id: string;
  name: string;
  blurb: string;
  built: boolean;
  /** Shown when built === false. */
  plannedNote?: string;
  lessons: Lesson[];
};

const BLACK_KING_CORNER = "7k";

export const STAGES: Stage[] = [
  {
    id: "first-steps",
    name: "First steps",
    blurb: "You have never played before. Start here.",
    built: true,
    lessons: [
      {
        id: "board-and-sides",
        title: "The board, your colour and whose turn it is",
        teach:
          "Chess has two players: White and Black. White always moves first. You are White here, so the white pieces at the bottom are yours. Each square has a name, like e4: the letter is the column, the number is the row.",
        fen: "7k/8/8/8/8/8/4P3/4K3 w - - 0 1",
        goal: { kind: "exactMove", from: "e2", to: "e4" },
        afterSuccess:
          "You made your first move. You understood that the bottom pieces are yours and that White starts.",
        hints: [
          "Your pieces are the light ones at the bottom.",
          "Tap the pawn on e2 first. Its legal squares light up.",
          "Then tap e4 — two squares straight forward.",
        ],
        trick: "Your pieces are the ones nearest you, and White always starts.",
        concepts: ["orientation", "turns"],
      },
      {
        id: "pawn-capture",
        title: "How a pawn moves and takes",
        teach:
          "A pawn walks straight forward one square, but it takes diagonally. It never moves backwards. That is why pawns are good at guarding squares in front of them.",
        fen: "7k/8/8/3p4/4P3/8/8/4K3 w - - 0 1",
        goal: { kind: "exactMove", from: "e4", to: "d5" },
        afterSuccess: "You captured with a pawn. Remember: forward to walk, diagonal to take.",
        hints: [
          "The black pawn is on d5. Can your pawn reach it?",
          "Pawns capture diagonally, not straight ahead.",
          "Tap e4, then tap d5.",
        ],
        transferFen: "7k/8/8/5p2/4P3/8/8/4K3 w - - 0 1",
        transferGoal: { kind: "exactMove", from: "e4", to: "f5" },
        trick: "Pawns walk straight but hit diagonally.",
        concepts: ["pawnMoves", "capturing"],
      },
      {
        id: "knight-l",
        title: "The knight jumps in an L",
        teach:
          "The knight moves two squares one way and then one square across — an L shape. It is the only piece that can jump over others. Knights are tricky: their squares are never next door.",
        fen: `${BLACK_KING_CORNER}/8/8/8/8/5p2/8/4K1N1 w - - 0 1`,
        goal: { kind: "exactMove", from: "g1", to: "f3" },
        afterSuccess: "That is the L shape. Knights always land on a different colour square than they started.",
        hints: [
          "The knight is on g1.",
          "Count two squares, then one across.",
          "Tap the knight and look at the marked squares — f3 has a black pawn on it.",
        ],
        // a different knight and a different square — same L-shape idea
        transferFen: `${BLACK_KING_CORNER}/8/8/8/8/2p5/8/1N2K3 w - - 0 1`,
        transferGoal: { kind: "capture" },
        trick: "Two squares one way, one square across — and it jumps over everything.",
        concepts: ["knightMoves"],
        prerequisites: ["pawnMoves"],
      },
      {
        id: "bishop-diagonal",
        title: "The bishop slides on diagonals",
        teach:
          "A bishop only moves diagonally, as far as it wants, until something blocks it. It stays on the same colour square for the whole game.",
        fen: `${BLACK_KING_CORNER}/8/8/6p1/8/8/8/2B1K3 w - - 0 1`,
        goal: { kind: "exactMove", from: "c1", to: "g5" },
        afterSuccess: "Long diagonals make bishops strong. Keep them on open lines.",
        hints: ["The bishop is on c1.", "Follow the diagonal: d2, e3, f4…", "The pawn on g5 is on that diagonal."],
        trick: "A bishop keeps the colour it starts on, forever.",
        concepts: ["bishopMoves"],
      },
      {
        id: "rook-lines",
        title: "The rook slides in straight lines",
        teach:
          "A rook moves up, down, left or right, as far as it likes. Rooks love open columns and rows where nothing blocks them.",
        fen: `${BLACK_KING_CORNER}/p7/8/8/8/8/8/R3K3 w - - 0 1`,
        goal: { kind: "exactMove", from: "a1", to: "a7" },
        afterSuccess: "You used a whole open file. That is exactly what rooks are for.",
        hints: ["The rook is on a1.", "Nothing blocks the a-column.", "Slide all the way up to a7."],
        trick: "Rooks love open lines with nothing in the way.",
        concepts: ["rookMoves"],
      },
      {
        id: "queen-power",
        title: "The queen does both",
        teach:
          "The queen moves like a rook AND like a bishop: straight lines and diagonals. She is the strongest piece, so keep her safe — losing her usually loses the game.",
        fen: `${BLACK_KING_CORNER}/3p4/8/8/8/8/8/3QK3 w - - 0 1`,
        goal: { kind: "exactMove", from: "d1", to: "d7" },
        afterSuccess: "The queen is powerful, but never bring her out where she can be attacked for free.",
        hints: ["The queen is on d1.", "The d-column is empty.", "Slide up to d7."],
        trick: "The queen is a rook and a bishop in one — so she is also the easiest piece to lose.",
        concepts: ["queenMoves"],
        prerequisites: ["rookMoves", "bishopMoves"],
      },
      {
        id: "king-check",
        title: "Check: your king is attacked",
        teach:
          "When a piece attacks your king, that is check. You must answer it right away: move the king, block the attack, or capture the attacker. You are never allowed to leave your king in check.",
        fen: "4r2k/8/8/8/8/8/8/4K3 w - - 0 1",
        goal: { kind: "escapeCheck" },
        afterSuccess: "You got out of check. Always ask first: is my king safe?",
        hints: [
          "The black rook on e8 is attacking down the e-column.",
          "Your king is on e1, on that same column.",
          "Step the king off the e-column.",
        ],
        trick: "Check is not a suggestion. Move, block, or take.",
        concepts: ["check", "kingSafety"],
      },
      {
        id: "first-checkmate",
        title: "Checkmate ends the game",
        teach:
          "Checkmate means the king is attacked and has no legal way out. That wins the game immediately. Here the black king is stuck behind its own pawns — this is called a back-rank mate.",
        fen: "6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1",
        goal: { kind: "mate" },
        afterSuccess:
          "You delivered checkmate. Notice why it worked: the king had no escape squares because its own pawns blocked it.",
        hints: [
          "Look at the black king's escape squares. Its own pawns are in the way.",
          "Which of your pieces can attack the whole back row?",
          "Move the rook to a8.",
        ],
        trick: "Mate is check with nowhere to go.",
        concepts: ["checkmate", "backRank"],
        prerequisites: ["check"],
      },
      {
        id: "stalemate",
        title: "Stalemate is a draw, not a win",
        teach:
          "If the player to move is NOT in check but has no legal move at all, the game is a draw — stalemate. When you are winning, always give the other king a square, or take care to mate properly.",
        goal: { kind: "read" },
        fen: "7k/5Q2/6K1/8/8/8/8/8 b - - 0 1",
        afterSuccess:
          "Here Black is not in check but cannot move: it is a draw. Remember this when you are far ahead.",
        hints: [],
        trick: "No legal move and no check is a draw — even a queen up.",
        concepts: ["stalemate"],
        prerequisites: ["checkmate"],
      },
    ],
  },
  {
    id: "foundations",
    name: "Foundations",
    blurb: "Safe captures, threats, and getting your pieces out.",
    built: true,
    lessons: [
      {
        id: "free-piece",
        title: "Take what is free",
        teach:
          "Before anything else, look for pieces you can take for nothing. A piece is 'free' when nobody can take yours back afterwards.",
        fen: "7k/8/8/4n3/8/8/8/4R1K1 w - - 0 1",
        goal: { kind: "capture", safe: true },
        afterSuccess: "You won a knight for free. Every turn, check for a free capture first.",
        hints: [
          "Which black piece can your rook reach?",
          "Is anything defending it? Look for black pawns and pieces nearby.",
          "The knight on e5 is alone. Take it.",
        ],
        transferFen: "7k/8/8/3b4/8/8/8/3R2K1 w - - 0 1",
        transferGoal: { kind: "capture", safe: true },
        trick: "Before anything else, ask: is something of theirs undefended?",
        concepts: ["safeCapture", "hangingPiece"],
      },
      {
        id: "dont-take-defended",
        title: "Not every capture is a good capture",
        teach:
          "Here your rook can take the knight on e5 — but the pawn on f6 would take your rook back. A rook is worth much more than a knight, so that trade loses material. Look for the defender BEFORE you take.",
        fen: "7k/8/5p2/4n3/8/8/8/4R1K1 w - - 0 1",
        goal: { kind: "read" },
        afterSuccess:
          "You learned to look for defenders. The question is never just 'can I take?' but 'what happens after I take?'",
        hints: [],
        trick: "Never ask 'can I take?'. Ask 'what happens after I take?'",
        concepts: ["defenders", "trades"],
        prerequisites: ["safeCapture"],
      },
      {
        id: "save-your-piece",
        title: "Your piece is attacked — save it",
        teach:
          "Your queen on d5 is attacked by the pawn on e6. A pawn is cheap and a queen is expensive, so you must move her (or defend the square in a way that still works). Always answer the question: what can they take from me?",
        fen: "rnbqkbnr/pppp1ppp/4p3/3Q4/8/8/PPPP1PPP/RNB1KBNR w KQkq - 0 1",
        goal: { kind: "read" },
        afterSuccess: "You spotted the attack on your queen. Do this scan every single turn.",
        hints: [],
        trick: "Every turn, first check what they can take from you.",
        concepts: ["pieceSafety", "threats"],
      },
      {
        id: "give-check-safely",
        title: "Check — but only when it helps",
        teach:
          "Giving check forces an answer, which can be useful. But a check that just loses your piece helps nobody. Give a check here that keeps your piece safe.",
        fen: "7k/8/8/8/8/8/6Q1/6K1 w - - 0 1",
        goal: { kind: "check" },
        afterSuccess: "You gave a safe check. Forcing moves are strongest when they cost you nothing.",
        hints: ["Your queen is on g2.", "The black king is on h8.", "Find a square where you attack the king."],
        trick: "A check that loses a piece is just a gift with a noise.",
        concepts: ["forcingMoves", "check"],
        prerequisites: ["check"],
      },
      {
        id: "develop",
        title: "Bring your pieces out",
        teach:
          "At the start, your knights and bishops are stuck on the back row where they do nothing. Moving them towards the middle is called developing. Aim to get them out early instead of moving the same pawn again and again.",
        fen: "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 1",
        goal: { kind: "read" },
        afterSuccess:
          "Knights before bishops is a good habit, and the middle squares are the best homes for them.",
        hints: [],
        trick: "Knights before bishops, and get out before you attack.",
        concepts: ["development", "center"],
      },
      {
        id: "back-rank-again",
        title: "Transfer test: find the mate again",
        teach:
          "You saw a back-rank mate earlier. Here is a different position with the same idea. Can you spot it on your own?",
        fen: "5rk1/5ppp/8/8/8/8/5PPP/1R4K1 w - - 0 1",
        goal: { kind: "read" },
        afterSuccess:
          "Notice that the rook on f8 defends the back rank here — the same idea does NOT work. Checking whether the pattern really applies is the skill.",
        hints: [],
        trick: "Same pattern, different board — always check whether it really applies.",
        concepts: ["backRank", "transfer"],
        prerequisites: ["checkmate"],
      },
    ],
  },
  {
    id: "intermediate",
    name: "Intermediate",
    blurb: "Forks, pins, skewers, double attacks, candidate moves and giving your king air.",
    built: true,
    lessons: [
      {
        id: "what-is-a-fork",
        title: "A fork — one piece attacking two at once",
        teach:
          "A fork means one piece attacks two things at the same time. Your opponent can only answer one of them, so you win the other. A knight is the best forker because it jumps, and nothing can block a knight. Here your knight can check the king AND attack the rook on the same move.",
        fen: "r3k3/8/8/1N6/8/8/8/4K3 w - - 0 1",
        goal: { kind: "exactMove", from: "b5", to: "c7" },
        afterSuccess:
          "That is a fork. The king is in check so it MUST move, and when it does, the rook on a8 is yours. Checked on the board: every legal black answer still loses the rook.",
        hints: [
          "Look for a square where your knight touches two black pieces at once.",
          "One of the two should be the king, because then the check forces an answer.",
          "The knight on b5 can reach c7. Count what c7 attacks.",
        ],
        transferFen: "2r3k1/8/8/5N2/8/8/8/4K3 w - - 0 1",
        transferGoal: { kind: "exactMove", from: "f5", to: "e7" },
        trick: "Look for a square that touches two of their pieces — best of all when one is the king.",
        concepts: ["fork", "forcingMoves", "threats"],
        prerequisites: ["safeCapture"],
      },
      {
        id: "the-pin",
        title: "A pin — a piece that is not allowed to move",
        teach:
          "A pin is when a piece cannot move because something more valuable is directly behind it. Here the black knight on c6 stands between your bishop's diagonal and the black king on e8. If you line the bishop up, that knight is stuck: moving it would leave the king in check, and that is against the rules.",
        fen: "4k3/8/2n5/8/8/8/8/4KB2 w - - 0 1",
        goal: { kind: "exactMove", from: "f1", to: "b5" },
        afterSuccess:
          "The knight is now frozen — it has no legal moves at all. A pinned piece is a weak piece: you can attack it again and it cannot run away.",
        hints: [
          "Your bishop moves on diagonals. Find the diagonal that runs through c6.",
          "You want the black king to be directly behind the knight on that line.",
          "The diagonal f1, e2, d3, c4, b5 lines up with c6 and e8.",
        ],
        trick: "A pinned piece is a frozen piece. Attack it again.",
        concepts: ["pin", "threats"],
        prerequisites: ["safeCapture"],
      },
      {
        id: "the-skewer",
        title: "A skewer — a pin the other way round",
        teach:
          "A skewer is a pin turned around: the valuable piece is in FRONT and something you want is behind it. You check the king, the king has to step aside, and the piece behind it is left standing there for you. Your bishop can give check on the long diagonal, with the rook sitting right behind the king.",
        fen: "7r/6k1/8/8/8/8/8/2B1K3 w - - 0 1",
        goal: { kind: "exactMove", from: "c1", to: "b2" },
        afterSuccess:
          "The king must step off the diagonal, and then the rook on h8 is yours. Checked on the board: every legal black answer loses the rook.",
        hints: [
          "Find the long diagonal that runs through the black king on g7.",
          "The rook on h8 is on that same diagonal, just behind the king.",
          "Your bishop needs to get onto that diagonal with check. Try b2.",
        ],
        trick: "Check the big piece and take what was hiding behind it.",
        concepts: ["skewer", "forcingMoves"],
        prerequisites: ["check"],
      },
      {
        id: "queen-double-attack",
        title: "The queen hits two things at once",
        teach:
          "The queen can fork too, because she moves like a rook and a bishop together. Find one square where she gives check on one line and attacks something loose on another line. The check is what makes it work: it forces your opponent to deal with the king first.",
        fen: "7k/n7/8/8/8/8/8/1K1Q4 w - - 0 1",
        goal: { kind: "exactMove", from: "d1", to: "d4" },
        afterSuccess:
          "One square, two attacks. The king has to move and the knight cannot get back in time, so you win it. Notice the knight had no way to block — blocking is the usual defence against this.",
        hints: [
          "The black king is on h8 and the black knight is on a7.",
          "Is there a square that sees both of them? Think about the two diagonals.",
          "d4 looks at h8 one way and a7 the other way.",
        ],
        trick: "One square, two attacks. The check is what makes it work.",
        concepts: ["doubleAttack", "fork", "forcingMoves"],
        prerequisites: ["safeCapture"],
      },
      {
        id: "forcing-moves-first",
        title: "Look at checks, captures and threats — in that order",
        teach:
          "Before you choose a move, run the same short list every time: checks first, then captures, then threats. These are called forcing moves, because your opponent has very little choice about how to answer. Most tactics are found this way — not by staring at the board hoping something appears, but by checking a list. Looking at a forcing move does not mean playing it; plenty of checks are bad. You look so that you never miss one.",
        fen: "r3k3/8/8/1N6/8/8/8/4K3 w - - 0 1",
        goal: { kind: "read" },
        afterSuccess:
          "Checks, captures, threats. Say it to yourself every turn until you stop needing to. It is the single habit that finds the most material.",
        hints: [],
        trick: "Checks, captures, threats — in that order, every single turn.",
        concepts: ["forcingOrder", "forcingMoves"],
        prerequisites: ["forcingMoves"],
      },
      {
        id: "candidate-moves",
        title: "Pick two or three moves, then choose",
        teach:
          "Strong players do not calculate one move very deeply. They first write a short list in their head — two or three moves worth looking at — and only then work out what happens after each one. These are called candidate moves. It stops you falling in love with the first idea you see, which is where most mistakes come from.",
        fen: "7r/6k1/8/8/8/8/8/2B1K3 w - - 0 1",
        goal: { kind: "read" },
        afterSuccess:
          "Two or three candidates, then compare. If they all look the same, pick the safe one — that is a perfectly good answer and not a failure.",
        hints: [],
        trick: "Two or three candidates first, then compare. Never fall for your first idea.",
        concepts: ["candidates", "transfer"],
        prerequisites: ["trades"],
      },
      {
        id: "make-luft",
        title: "Give your king some air",
        teach:
          "Your king is sitting behind three pawns that have never moved. If a black rook ever reaches your back row, that is checkmate, because the king has nowhere to step. Moving one pawn up a square gives the king an escape square. Chess players call that giving the king air.",
        fen: "r5k1/5ppp/8/8/8/8/5PPP/6K1 w - - 0 1",
        goal: { kind: "exactMove", from: "h2", to: "h3" },
        afterSuccess:
          "Now the same rook check is only a check, not mate — the king steps up to h2. Checked on the board: before this move Ra1 was checkmate, after it, it is not.",
        hints: [
          "Imagine the black rook coming to a1. Where would your king go?",
          "It has no square, because your own pawns block it. That is checkmate.",
          "Move one of the pawns in front of the king up one square. h3 is the usual one.",
        ],
        trick: "Give the king a square before you need it, not after.",
        concepts: ["luft", "kingSafety", "backRank"],
        prerequisites: ["checkmate"],
      },
      {
        id: "count-before-you-trade",
        title: "Count both sides before you take",
        teach:
          "When several pieces are aimed at one square, do not guess. Count: how many of mine attack it, how many of theirs defend it, and what is each one worth. Take only if you come out level or ahead once every capture has been played out. A trade that looks even can still be bad if the piece you give up is worth more than the one you get.",
        fen: "7k/8/5p2/4n3/8/8/8/4R1K1 w - - 0 1",
        goal: { kind: "read" },
        afterSuccess:
          "Attackers, defenders, values — in that order. Doing this slowly on purpose is how it eventually becomes fast.",
        hints: [],
        trick: "Attackers, defenders, values — count all three before you take.",
        concepts: ["counting", "trades", "defenders"],
        prerequisites: ["trades"],
      },
      {
        id: "poisoned-pawn",
        title: "Trick: the pawn that is not free",
        teach:
          "Your bishop can take the pawn on d5 and nothing is defending it. That is exactly what makes it a trap. Look at the pawn on c6: it does not defend d5, it defends the SQUARE d5 the moment anything lands there, because pawns capture diagonally forward. Count what happens after the capture, not before it. There is a second way to lose the bishop in this position too.",
        fen: "4k3/8/2p5/3p4/8/8/6B1/4K3 w - - 0 1",
        goal: { kind: "avoidLoss" },
        afterSuccess:
          "Checked on the board: of the 11 legal moves here, exactly two lose the bishop — Bxd5, answered by cxd5, and Be4, which walks onto the very same square the c6 pawn covers. Free pieces are often not free.",
        hints: [
          "The pawn on c6 is the important one, not the pawn on d5.",
          "Pawns capture diagonally forwards. Which two squares does c6 cover?",
          "c6 covers b5 and d5. Keep your bishop off both, and off e4 which leads there.",
        ],
        trick: "A piece that looks free is the cheapest trap in chess. Count first.",
        concepts: ["counting", "defenders", "threats"],
        prerequisites: ["safeCapture"],
      },
    ],
  },
  {
    id: "advanced",
    name: "Advanced",
    blurb: "Rook technique, stalemate traps, prophylaxis, piece activity and passed pawns.",
    built: true,
    lessons: [
      {
        id: "cut-the-king-off",
        title: "Cut the enemy king off with your rook",
        teach:
          "In an endgame a rook does not chase the king — it builds a wall. Put the rook on the file or row next to the king and the king simply cannot cross it. Then you walk your own king up and make the wall smaller. This is how every rook endgame is won, and chasing is how they are drawn.",
        fen: "8/8/8/4k3/8/8/8/R3K3 w - - 0 1",
        goal: { kind: "exactMove", from: "a1", to: "d1" },
        afterSuccess:
          "Before that move the black king could step to d4, d5 or d6. Now it cannot reach the d-file at all — checked on the board. The king is stuck on one side of your rook.",
        hints: [
          "Do not chase the king. Build a wall next to it.",
          "The black king is on e5. Which file is right beside it?",
          "Put your rook on the d-file, on d1.",
        ],
        transferFen: "8/R7/8/8/3k4/8/8/4K3 w - - 0 1",
        transferGoal: { kind: "exactMove", from: "a7", to: "a5" },
        trick: "Do not chase the king. Build a wall beside it, then make it smaller.",
        concepts: ["cutOff", "rookTechnique"],
        prerequisites: ["checkmate"],
      },
      {
        id: "stalemate-trap",
        title: "One move wins, one move throws it away",
        teach:
          "You are a queen up and it is completely won — which is exactly when games get thrown away. If the enemy king has no legal move and is NOT in check, the game is an instant draw. So before every queen move in a position like this, ask one question: does the king still have a square, or am I about to give away the whole point?",
        fen: "k7/8/2K5/8/8/8/8/1Q6 w - - 0 1",
        goal: { kind: "mate" },
        afterSuccess:
          "Checked on the board: in this exact position there is only ONE move that mates, and one move that is stalemate. That is how thin the line is. Give check with the queen protected by your king.",
        hints: [
          "Your king on c6 already covers b7 and b6.",
          "Do not take away the king's last square without giving check — that is a draw.",
          "Bring the queen next to the king, onto a square your own king defends.",
        ],
        trick: "When you are winning, check that they still have a legal move.",
        concepts: ["stalemateTrap", "stalemate", "checkmate"],
        prerequisites: ["stalemate"],
      },
      {
        id: "prophylaxis",
        title: "Ask what THEY want before you play",
        teach:
          "Most players only look at their own plan. Before you move, spend one moment on the other side: if it were their turn, what would they play? Stopping their idea is often worth more than continuing yours. Here Black is about to be checkmated on f7 and may not have noticed, because Black is busy thinking about Black's own development.",
        fen: "r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 3 3",
        goal: { kind: "avoidMate" },
        afterSuccess:
          "You saw it coming. Checked on the board: if Black plays a slow move here, Qxf7 really is checkmate — and exactly eight moves stop it. Any one of the eight counts; asking 'what do they want?' is what finds them.",
        hints: [
          "It is Black to move. Before you plan anything, look at what White is aiming at.",
          "The white queen on h5 and the bishop on c4 are both pointing at one square. Which one?",
          "f7 is defended only by the king. Defend it, block the queen's path, or move the king.",
        ],
        trick: "Before you move, ask what you would play if it were their turn.",
        concepts: ["prophylaxis", "threats", "kingSafety"],
        prerequisites: ["threats"],
      },
      {
        id: "worst-piece",
        title: "Improve your worst piece",
        teach:
          "When there is nothing forcing to play, do not shuffle a good piece around. Look for the piece doing the least work and give it a job. A rook stuck behind its own pawns, a knight on the edge, a bishop staring at its own chain — those are the pieces to fix. This is the single most useful thing to do in a quiet position, and it is what 'having a plan' usually means in practice.",
        fen: "r5k1/5ppp/8/8/8/8/5PPP/1R4K1 w - - 0 1",
        goal: { kind: "read" },
        afterSuccess:
          "Worst piece first. It turns 'I have no idea what to do' into a question you can actually answer.",
        hints: [],
        trick: "No plan? Find your laziest piece and give it a job.",
        concepts: ["pieceActivity", "transfer"],
        prerequisites: ["development"],
      },
      {
        id: "rook-behind-passer",
        title: "Put the rook behind the passed pawn",
        teach:
          "A passed pawn is one with no enemy pawn able to stop it. The rule of thumb is old and reliable: rooks belong BEHIND passed pawns — yours and theirs. Behind your own pawn, the rook keeps gaining freedom as the pawn advances. Behind theirs, it keeps losing freedom as it retreats. A rook in front of a pawn is doing a job any pawn could do.",
        fen: "r5k1/8/8/P7/8/8/6PP/4R1K1 w - - 0 1",
        goal: { kind: "exactMove", from: "e1", to: "a1" },
        afterSuccess:
          "Behind the pawn. From a1 the rook pushes the pawn up the board and gains freedom with every step, while the black rook in front of it loses freedom. It is a rule of thumb, not a law — but it is right far more often than it is wrong.",
        hints: [
          "Your passed pawn is on a5. Nothing can stop it except that black rook.",
          "Rooks belong behind passed pawns. Which file is your pawn on?",
          "Bring the rook to a1, behind the pawn.",
        ],
        trick: "Rooks belong behind passed pawns — yours and theirs.",
        concepts: ["passedPawn", "rookTechnique"],
        prerequisites: ["trades"],
      },
      {
        id: "knight-promotion",
        title: "Trick: promote to a knight, not a queen",
        teach:
          "A queen is the strongest piece, so almost everyone promotes to one without thinking. But a queen cannot do the one thing a knight can: jump in an L and hit two things at once. Here your pawn reaches the eighth row. A new queen does not even give check. A new knight does — and it attacks something else at the same time.",
        fen: "8/2r1P3/5k2/8/8/8/8/K7 w - - 0 1",
        goal: { kind: "exactMove", from: "e7", to: "e8", promotion: "n" },
        afterSuccess:
          "Checked on the board: e8 as a knight gives check AND attacks the rook on c7, so whatever Black plays you take the rook next move. e8 as a queen is not even check. Promoting to a queen is right almost always — 'almost' is the point.",
        hints: [
          "You are about to promote. Ask what each piece would actually DO on e8.",
          "A queen on e8 does not attack the black king on f6. Does anything else?",
          "A knight on e8 hits f6 and c7 at the same time. Promote to a knight.",
        ],
        trick: "Before you promote, ask what a knight would do there. Once in a while it is better.",
        concepts: ["fork", "calculateToEnd", "passedPawn"],
        prerequisites: ["fork"],
      },
    ],
  },
  {
    id: "expert",
    name: "Expert",
    blurb: "Breakthroughs, calculating to the end, and checking your idea against their best reply.",
    built: true,
    lessons: [
      {
        id: "pawn-breakthrough",
        title: "The breakthrough — three pawns against three",
        teach:
          "Three pawns each, and nothing looks to be happening. But one of your three pawn moves wins by force and the other two do not. The idea is a sacrifice that clears a path: you give a pawn so that the pawn behind it, or beside it, gets a free run to the far side. Work the whole line out to the end before you play it — this only works if you calculate to the finish, because after the first move it looks like you are simply a pawn down.",
        fen: "6k1/ppp5/8/PPP5/8/8/8/6K1 w - - 0 1",
        goal: { kind: "exactMove", from: "b5", to: "b6" },
        afterSuccess:
          "That is the breakthrough. Whatever Black takes with, one of your pawns gets through and queens. Checked by searching every legal reply: this is the ONLY move here that forces a queen — the two other pawn moves and all five king moves do not.",
        hints: [
          "Do not count what you have. Count what happens if you give something away.",
          "Push the middle pawn. It attacks two squares, so Black must choose which way to take.",
          "Play b6. Then look at what each capture does to the black pawn wall.",
        ],
        trick: "When pawns face each other, look for the sacrifice that clears a path.",
        concepts: ["breakthrough", "calculateToEnd", "passedPawn"],
        prerequisites: ["passedPawn"],
      },
      {
        id: "their-best-reply",
        title: "Check their best reply, not their worst",
        teach:
          "The commonest way to lose a piece is to imagine the reply you would like instead of the reply they will actually play. Here your queen has already stepped onto c4, and the pawn on d5 can take her. Most of Black's answers change nothing — one of them wins the queen. Find a move that takes that one answer away.",
        fen: "4k3/8/8/3p4/2Q5/8/8/4K3 w - - 0 1",
        goal: { kind: "avoidLoss" },
        afterSuccess:
          "Checked on the board: out of 27 legal moves here, 6 lose the queen — every king move, because it leaves her on c4, and Qe4+ which walks onto the same pawn. A move is only as good as the best answer to it.",
        hints: [
          "Something of yours is attacked right now. What, and by what?",
          "The pawn on d5 takes diagonally — it covers c4 and e4.",
          "Move the queen anywhere that pawn cannot reach.",
        ],
        trick: "A move is only as good as their best answer to it.",
        concepts: ["bestReply", "candidates", "threats"],
        prerequisites: ["candidates"],
      },
      {
        id: "several-right-moves",
        title: "Often several moves are right",
        teach:
          "Engines give one number per move, which makes people think there is always a single correct answer. In most quiet positions there is not. Several moves are equally sound, and choosing between them is a matter of taste and of what you understand. Do not freeze looking for the one true move. Pick a sound one, know why you picked it, and play it.",
        fen: "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2",
        goal: { kind: "read" },
        afterSuccess:
          "Checked on the board: in this position the coach itself reports several equally sound moves, which is why it offers alternatives instead of one answer. That is a fact about chess, not a weakness in the advice.",
        hints: [],
        trick: "If several moves are sound, pick one you understand and move on.",
        concepts: ["severalSound", "candidates"],
        prerequisites: ["candidates"],
      },
      {
        id: "calculate-to-the-end",
        title: "Stop at a position, not in the middle of a capture",
        teach:
          "When you work out a line in your head, do not stop halfway through an exchange. Stop only when the captures have run out, then look at what is actually on the board and ask: am I happy here? Most calculation mistakes are not about depth. They are about stopping one move too early, at the moment things look good, instead of one move later when the recapture arrives.",
        fen: "6k1/1pp5/1p6/P1P5/8/8/8/6K1 w - - 0 2",
        goal: { kind: "exactMove", from: "c5", to: "c6" },
        afterSuccess:
          "This is the position two moves into the breakthrough, and it is where most people stop calculating and give up — you are a pawn down and it looks wrong. Checked by searching every legal move and every legal reply: c6 is the ONLY move that still forces a queen. Stopping one move earlier would have missed it.",
        hints: [
          "You are a pawn down and it looks bad. Keep going anyway.",
          "The same idea as the first move: give one pawn to open a path for another.",
          "Push the c-pawn to c6.",
        ],
        trick: "Stop counting when the captures stop, not when it looks good.",
        concepts: ["calculateToEnd", "counting"],
        prerequisites: ["counting"],
      },
      {
        id: "review-your-own",
        title: "Your own games are the best lessons",
        teach:
          "Puzzles show you ideas that someone else chose. Your own games show you the mistakes you actually make, which are usually the same two or three over and over. Under Games there is a reviewer: paste a finished game, or review the one you just played, and it will walk your moves and show you only the moments it can prove were costly. It will not grade you and it will not invent mistakes to seem useful.",
        fen: "r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 3 3",
        goal: { kind: "read" },
        afterSuccess:
          "Reviewing one of your own games teaches more than ten puzzles, because the mistakes are yours. Go to Games, then Review a game.",
        hints: [],
        trick: "Your own losses teach faster than anyone else's puzzles.",
        concepts: ["reviewOwnGames", "transfer"],
        prerequisites: ["transfer"],
      },
      {
        id: "check-is-not-free",
        title: "Trick: the only bad move here is the check",
        teach:
          "Checks are forcing, so we teach you to look at them first. Looking is not the same as playing. In this position you have twenty-one legal moves. Twenty of them are perfectly fine. The one that loses is the check — because the piece giving it can simply be taken. A check that hangs a piece is not a forcing move, it is a gift with a noise attached.",
        fen: "r5k1/5ppp/8/8/8/8/5PPP/1R3RK1 w - - 0 1",
        goal: { kind: "avoidLoss" },
        afterSuccess:
          "Checked on the board: of the 21 legal moves, exactly one loses material — Rb8+, answered by Rxb8. Always look at checks. Then check the check.",
        hints: [
          "There is one check available to you. Find it before you decide anything.",
          "Rb8 gives check. Now ask the only question that matters: what can answer it?",
          "The black rook on a8 covers b8. Play almost anything else.",
        ],
        trick: "Look at every check. Then ask what happens to the piece that gave it.",
        concepts: ["bestReply", "forcingOrder", "candidates"],
        prerequisites: ["forcingOrder"],
      },
    ],
  },
];

export function allBuiltLessons(): Lesson[] {
  return STAGES.filter((s) => s.built).flatMap((s) => s.lessons);
}

export function findLesson(id: string): { stage: Stage; lesson: Lesson } | null {
  for (const stage of STAGES) {
    const lesson = stage.lessons.find((l) => l.id === id);
    if (lesson) return { stage, lesson };
  }
  return null;
}

/**
 * Unlock by evidence + prerequisites, never by streaks or payment.
 * A lesson is available when every concept it depends on has been understood
 * at least once without a hint.
 */
export function isLessonUnlocked(lesson: Lesson, understoodConcepts: string[]): boolean {
  if (!lesson.prerequisites || lesson.prerequisites.length === 0) return true;
  return lesson.prerequisites.every((p) => understoodConcepts.includes(p));
}

/**
 * Plain-English names for the concept ids.
 *
 * The ids are for the code. A learner should never be shown "rookMoves,
 * bishopMoves" — that is a variable name, not a sentence. Anything missing
 * here falls back to spaced-out words rather than raw camelCase.
 */
const CONCEPT_NAMES: Record<string, string> = {
  orientation: "reading the board",
  turns: "whose turn it is",
  pawnMoves: "how the pawn moves",
  knightMoves: "how the knight moves",
  bishopMoves: "how the bishop moves",
  rookMoves: "how the rook moves",
  queenMoves: "how the queen moves",
  capturing: "taking a piece",
  check: "check",
  checkmate: "checkmate",
  stalemate: "stalemate",
  backRank: "back-row mates",
  safeCapture: "safe captures",
  hangingPiece: "spotting a free piece",
  defenders: "looking for defenders",
  trades: "working out a trade",
  pieceSafety: "keeping your pieces safe",
  threats: "spotting threats",
  forcingMoves: "forcing moves",
  forcingOrder: "checks, captures, threats",
  development: "bringing pieces out",
  center: "the middle of the board",
  transfer: "using an idea again",
  fork: "forks",
  pin: "pins",
  skewer: "skewers",
  doubleAttack: "double attacks",
  luft: "giving the king air",
  kingSafety: "king safety",
  candidates: "candidate moves",
  counting: "counting attackers",
  cutOff: "cutting the king off",
  rookTechnique: "rook endgames",
  stalemateTrap: "avoiding stalemate",
  prophylaxis: "spotting their plan",
  pieceActivity: "active pieces",
  passedPawn: "passed pawns",
};

/** "rookMoves" -> "how the rook moves". Never shows a raw id. */
export function conceptName(id: string): string {
  return CONCEPT_NAMES[id] ?? id.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase();
}

/** "how the rook moves and how the bishop moves" — a sentence, not a list. */
export function conceptList(ids: string[] | undefined): string {
  const names = (ids ?? []).map(conceptName);
  if (names.length === 0) return "an earlier lesson";
  if (names.length === 1) return names[0];
  return `${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
}


/** Stage names that are still not written, straight from the data. */
export function unbuiltStageNames(): string[] {
  return STAGES.filter((s) => !s.built).map((s) => s.name);
}

/**
 * "Expert is not written yet." — generated, never typed.
 *
 * This sentence used to be hard-coded as "Intermediate, Advanced and Expert
 * stages are not written yet" and went stale the moment those stages were
 * built, so the app was telling the learner something untrue about itself.
 */
export function unbuiltStagesSentence(): string {
  const names = unbuiltStageNames();
  if (names.length === 0) return "Every stage in the journey is written and playable.";
  const list =
    names.length === 1 ? names[0] : `${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
  return `It only measures the lessons that exist in this build. ${list} ${
    names.length === 1 ? "is" : "are"
  } not written yet.`;
}
