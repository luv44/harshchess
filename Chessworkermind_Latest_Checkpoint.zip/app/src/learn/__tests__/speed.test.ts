/**
 * Thinking-time measurement.
 *
 * The reference mock showed "Fork recognition 11.2s → 4.8s". These tests are
 * what stands between that number being real and it being decoration.
 */
import { beforeEach, describe, expect, it } from "vitest";
import {
  MIN_SPEED_SAMPLES,
  SPEED_NOISE,
  computeInsights,
  speedReport,
} from "../insights";
import {
  EMPTY_PROGRESS,
  MAX_SOLVE_MS,
  MIN_SOLVE_MS,
  MAX_SOLVE_SAMPLES,
  parseProgress,
  recordAttempt,
  type LearnProgress,
} from "../progress";

/** Six real lessons about how the pieces move, used as the speed sample set. */
const MOVE_LESSONS = ["board-and-sides", "pawn-capture", "knight-l", "bishop-diagonal", "rook-lines", "queen-power"];

function withSolves(times: Array<{ id: string; ms: number; unaided?: boolean }>): LearnProgress {
  let p = EMPTY_PROGRESS;
  for (const t of times) p = recordAttempt(p, t.id, [], t.unaided ?? true, t.ms);
  return p;
}

beforeEach(() => localStorage.clear());

describe("what gets timed", () => {
  it("records a solve time only when the lesson was solved with no help", () => {
    const hinted = recordAttempt(EMPTY_PROGRESS, "knight-l", ["knightMoves"], false, 9000);
    expect(hinted.solveTimes).toHaveLength(0);

    const alone = recordAttempt(EMPTY_PROGRESS, "knight-l", ["knightMoves"], true, 9000);
    expect(alone.solveTimes).toHaveLength(1);
    expect(alone.solveTimes[0]).toMatchObject({ id: "knight-l", ms: 9000 });
  });

  it("throws away a time from someone who put the phone down", () => {
    const walkedAway = recordAttempt(EMPTY_PROGRESS, "knight-l", [], true, MAX_SOLVE_MS + 1);
    expect(walkedAway.solveTimes).toHaveLength(0);
    // the lesson itself still counts — only the timing is dropped
    expect(walkedAway.lessons["knight-l"].unaidedSuccesses).toBe(1);
  });

  it("throws away an impossibly fast tap", () => {
    const luckyTap = recordAttempt(EMPTY_PROGRESS, "knight-l", [], true, MIN_SOLVE_MS - 1);
    expect(luckyTap.solveTimes).toHaveLength(0);
  });

  it("ignores a missing time instead of guessing one", () => {
    const noTime = recordAttempt(EMPTY_PROGRESS, "knight-l", [], true);
    expect(noTime.solveTimes).toHaveLength(0);
    expect(noTime.lessons["knight-l"].completed).toBe(true);
  });

  it("keeps the history bounded so storage cannot grow forever", () => {
    let p = EMPTY_PROGRESS;
    for (let i = 0; i < MAX_SOLVE_SAMPLES + 25; i++) {
      p = recordAttempt(p, "knight-l", [], true, 5000 + i);
    }
    expect(p.solveTimes).toHaveLength(MAX_SOLVE_SAMPLES);
    // the OLDEST are dropped, the newest are kept
    expect(p.solveTimes[p.solveTimes.length - 1].ms).toBe(5000 + MAX_SOLVE_SAMPLES + 24);
  });

  it("survives a reload, and an old save without timings still loads", () => {
    const p = recordAttempt(EMPTY_PROGRESS, "knight-l", [], true, 7000);
    expect(parseProgress(JSON.stringify(p)).solveTimes).toHaveLength(1);

    const legacy = parseProgress('{"version":1,"lessons":{},"concepts":[],"days":[]}');
    expect(legacy.solveTimes).toEqual([]);

    const rubbish = parseProgress('{"version":1,"lessons":{},"solveTimes":[{"id":1},null,{"id":"a","ms":"x"}]}');
    expect(rubbish.solveTimes).toEqual([]);
  });
});

describe("the speed report refuses to guess", () => {
  it("says nothing at all with no data", () => {
    const r = speedReport(EMPTY_PROGRESS);
    expect(r.enough).toBe(false);
    expect(r.trends).toEqual([]);
    expect(r.needed).toBe(MIN_SPEED_SAMPLES);
    // The heading on screen says "Not enough practice yet"; this line is the
    // explanation under it, so it must not repeat the same words.
    expect(r.line).toMatch(/starts being measured the first time you solve a lesson with no hint/i);
    expect(r.line).not.toMatch(/not enough practice yet/i);
  });

  it("still says nothing one sample short, and counts down honestly", () => {
    const p = withSolves(
      Array.from({ length: MIN_SPEED_SAMPLES - 1 }, (_, i) => ({ id: MOVE_LESSONS[i % 6], ms: 8000 })),
    );
    const r = speedReport(p);
    expect(r.enough).toBe(false);
    expect(r.needed).toBe(1);
    expect(r.line).toMatch(/^1 more unaided solve\b/);
    expect(r.line).not.toMatch(/not enough practice yet/i);
    expect(r.trends).toEqual([]);
  });

  it("reports a real improvement once there is enough evidence", () => {
    // clearly slower at the start, clearly faster later
    const p = withSolves([
      { id: MOVE_LESSONS[0], ms: 12000 },
      { id: MOVE_LESSONS[1], ms: 11000 },
      { id: MOVE_LESSONS[2], ms: 10600 },
      { id: MOVE_LESSONS[3], ms: 5200 },
      { id: MOVE_LESSONS[4], ms: 4600 },
      { id: MOVE_LESSONS[5], ms: 4600 },
    ]);
    const r = speedReport(p);
    expect(r.enough).toBe(true);
    expect(r.totalSamples).toBe(6);

    const overall = r.trends.find((t) => t.id === "all")!;
    expect(overall.direction).toBe("faster");
    expect(overall.beforeSec).toBeCloseTo(11.2, 1);
    expect(overall.afterSec).toBeCloseTo(4.8, 1);
    expect(overall.line).toBe("Overall: 11.2s → 4.8s");
  });

  it("calls a small difference steady instead of progress", () => {
    const flat = 8000;
    const p = withSolves(
      Array.from({ length: 6 }, (_, i) => ({
        id: MOVE_LESSONS[i % 6],
        ms: Math.round(flat * (1 + (i % 2 ? SPEED_NOISE / 3 : -SPEED_NOISE / 3))),
      })),
    );
    const overall = speedReport(p).trends.find((t) => t.id === "all")!;
    expect(overall.direction).toBe("same");
    expect(overall.line).toMatch(/steady/);
  });

  it("does not call a slower time a failure", () => {
    const p = withSolves([
      { id: MOVE_LESSONS[0], ms: 4000 },
      { id: MOVE_LESSONS[1], ms: 4200 },
      { id: MOVE_LESSONS[2], ms: 4100 },
      { id: MOVE_LESSONS[3], ms: 12000 },
      { id: MOVE_LESSONS[4], ms: 13000 },
      { id: MOVE_LESSONS[5], ms: 12500 },
    ]);
    const overall = speedReport(p).trends.find((t) => t.id === "all")!;
    expect(overall.direction).toBe("slower");
    expect(overall.line).toMatch(/different problems or conditions may affect time/);
    expect(overall.line).not.toMatch(/the newer problems are harder/);
    expect(overall.line).not.toMatch(/worse|bad|fail/i);
  });

  it("only reports an area that has its own six samples", () => {
    const p = withSolves(
      Array.from({ length: 6 }, (_, i) => ({ id: MOVE_LESSONS[i % 6], ms: 9000 - i * 500 })),
    );
    const r = speedReport(p);
    // "Piece moves" has the six samples; nothing else does
    const named = r.trends.filter((t) => t.id !== "all").map((t) => t.name);
    expect(named).toContain("Piece moves");
    expect(named).not.toContain("Checkmate");
    for (const t of r.trends) expect(t.samples).toBeGreaterThanOrEqual(MIN_SPEED_SAMPLES);
  });

  it("never lets a hinted solve into the speed numbers", () => {
    const p = withSolves([
      ...Array.from({ length: 6 }, (_, i) => ({ id: MOVE_LESSONS[i % 6], ms: 6000 })),
      { id: MOVE_LESSONS[0], ms: 100, unaided: false },
    ]);
    const r = speedReport(p);
    expect(r.totalSamples).toBe(6);
    expect(r.trends.find((t) => t.id === "all")!.afterSec).toBe(6);
  });

  it("does not change the brain score — speed is reported separately", () => {
    const fast = withSolves(Array.from({ length: 6 }, (_, i) => ({ id: MOVE_LESSONS[i % 6], ms: 2000 })));
    const slow = withSolves(Array.from({ length: 6 }, (_, i) => ({ id: MOVE_LESSONS[i % 6], ms: 60000 })));
    expect(computeInsights(fast).score).toBe(computeInsights(slow).score);
  });
});
