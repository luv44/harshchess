import { describe, it, expect } from "vitest";
import { Chess } from "chess.js";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { STAGES, allBuiltLessons, isLessonUnlocked, findLesson } from "../journey";
import { checkMove, goalAchievable, lessonIsPlayable, solutionMoves } from "../lessonEngine";
import { PIECE_HELP, pieceRole, practiceTask } from "../../coach/pieceHelp";
import { isLegal } from "../../coach/localAnalysis";

describe("every lesson we SHOW is really playable", () => {
  const built = allBuiltLessons();

  it("has real lessons in the built stages", () => {
    expect(built.length).toBeGreaterThanOrEqual(15);
  });

  it("uses only legal positions", () => {
    for (const l of built) {
      if (!l.fen) continue;
      expect(() => new Chess(l.fen!), `${l.id} has an illegal FEN`).not.toThrow();
    }
  });

  it("has an achievable goal in every practice position", () => {
    for (const l of built) {
      expect(lessonIsPlayable(l), `${l.id} goal is not achievable`).toBe(true);
    }
  });

  it("has a legal answer for every exact-move lesson", () => {
    for (const l of built) {
      if (l.goal.kind !== "exactMove" || !l.fen) continue;
      expect(isLegal(l.fen, l.goal.from, l.goal.to, l.goal.promotion), `${l.id}`).toBe(true);
    }
  });

  it("has achievable transfer positions too", () => {
    for (const l of built) {
      if (!l.transferFen || !l.transferGoal) continue;
      expect(() => new Chess(l.transferFen!), `${l.id} transfer FEN`).not.toThrow();
      expect(goalAchievable(l.transferFen, l.transferGoal), `${l.id} transfer goal`).toBe(true);
    }
  });

  it("gives every lesson a goal, a teach text and an after-success text", () => {
    for (const l of built) {
      expect(l.title.length, l.id).toBeGreaterThan(3);
      expect(l.teach.length, l.id).toBeGreaterThan(20);
      expect(l.afterSuccess.length, l.id).toBeGreaterThan(10);
      expect(l.concepts.length, l.id).toBeGreaterThan(0);
    }
  });

  it("a stage is built with lessons, or unbuilt with none — never in between", () => {
    // Every stage happens to be built now. The rule still has to hold, so
    // this checks the invariant rather than a snapshot of today's data:
    // nothing may claim to be playable without lessons, and nothing may
    // hide lessons behind a "not built" label.
    for (const s of STAGES) {
      if (s.built) {
        expect(s.lessons.length, `${s.id} says built but has no lessons`).toBeGreaterThan(0);
        expect(s.plannedNote, `${s.id} is built and should not carry a planned note`).toBeUndefined();
      } else {
        expect(s.lessons, `${s.id} is not built and must be empty`).toHaveLength(0);
        expect(s.plannedNote, `${s.id} must explain that it is not built`).toBeTruthy();
      }
    }
  });
});

describe("grading is accurate and kind", () => {
  const mate = "6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1";
  const free = "7k/8/8/4n3/8/8/8/4R1K1 w - - 0 1";
  const defended = "7k/8/5p2/4n3/8/8/8/4R1K1 w - - 0 1";

  it("accepts the real checkmate and refuses a non-mate", () => {
    expect(checkMove(mate, "a1", "a8", undefined, { kind: "mate" }).ok).toBe(true);
    expect(checkMove(mate, "g1", "h1", undefined, { kind: "mate" })).toEqual({ ok: false, reason: "noMate" });
  });

  it("accepts a free capture and refuses one that loses material", () => {
    expect(checkMove(free, "e1", "e5", undefined, { kind: "capture", safe: true }).ok).toBe(true);
    const bad = checkMove(defended, "e1", "e5", undefined, { kind: "capture", safe: true });
    expect(bad.ok).toBe(false);
    expect(bad.reason).toBe("notSafe");
  });

  it("tells the difference between an illegal move and a legal-but-different one", () => {
    const fen = "7k/8/8/3p4/4P3/8/8/4K3 w - - 0 1";
    expect(checkMove(fen, "e4", "e5", undefined, { kind: "exactMove", from: "e4", to: "d5" })).toEqual({
      ok: false,
      reason: "notThatMove",
    });
    expect(checkMove(fen, "e4", "d6", undefined, { kind: "exactMove", from: "e4", to: "d5" })).toEqual({
      ok: false,
      reason: "illegal",
    });
  });

  it("only counts a check that does not hang the piece", () => {
    const fen = "7k/8/8/8/8/8/6Q1/6K1 w - - 0 1";
    const sols = solutionMoves(fen, { kind: "check" });
    expect(sols.length).toBeGreaterThan(0);
    for (const s of sols) expect(checkMove(fen, s.from, s.to, undefined, { kind: "check" }).ok).toBe(true);
  });

  it("counts any legal move as escaping check", () => {
    const fen = "4r2k/8/8/8/8/8/8/4K3 w - - 0 1";
    const sols = solutionMoves(fen, { kind: "escapeCheck" });
    expect(sols.length).toBeGreaterThan(0);
    for (const s of sols) {
      const c = new Chess(fen);
      c.move({ from: s.from, to: s.to });
      expect(c.isCheck()).toBe(false);
    }
  });
});

describe("unlocking is by understanding, not by streaks or payment", () => {
  it("opens the first lesson to everyone", () => {
    const first = STAGES[0].lessons[0];
    expect(isLessonUnlocked(first, [])).toBe(true);
  });

  it("holds back a lesson until its prerequisite concept is understood", () => {
    const mateLesson = findLesson("first-checkmate")!.lesson;
    expect(isLessonUnlocked(mateLesson, [])).toBe(false);
    expect(isLessonUnlocked(mateLesson, ["check"])).toBe(true);
  });
});

describe("per-piece help has a real one-move practice", () => {
  it("every piece practice is legal and does what it claims", () => {
    for (const [type, help] of Object.entries(PIECE_HELP)) {
      expect(() => new Chess(help.practice.fen), type).not.toThrow();
      expect(isLegal(help.practice.fen, help.practice.from, help.practice.to), type).toBe(true);
      const c = new Chess(help.practice.fen);
      const piece = c.get(help.practice.from as never);
      expect(piece?.type, `${type} practice starts on the right piece`).toBe(type);
    }
  });

  it("has a short role line in every coach language", () => {
    for (const tag of ["en", "hi", "es-MX", "ar", "fr"]) {
      for (const type of ["p", "n", "b", "r", "q", "k"]) {
        expect(pieceRole(tag, type).length, `${tag}/${type}`).toBeGreaterThan(10);
      }
      for (const help of Object.values(PIECE_HELP)) {
        expect(practiceTask(tag, help.practice.taskKey).length, tag).toBeGreaterThan(5);
      }
    }
  });
});

describe("nothing is walled off, and every lesson leaves you with a trick", () => {
  it("every lesson has a short, memorable trick", () => {
    for (const s of STAGES) {
      for (const l of s.lessons) {
        expect(l.trick, `${l.id} has no trick`).toBeTruthy();
        expect(l.trick!.length, `${l.id} trick is too long to remember`).toBeLessThanOrEqual(110);
        expect(l.trick!.length, `${l.id} trick is too short to mean anything`).toBeGreaterThan(20);
        // a trick is an instruction, not a restatement of the title
        expect(l.trick!.toLowerCase()).not.toBe(l.title.toLowerCase());
      }
    }
  });

  it("prerequisites are advice about order, never a lock", () => {
    // The data still records a suggested order...
    const gated = STAGES.flatMap((s) => s.lessons).filter((l) => (l.prerequisites?.length ?? 0) > 0);
    expect(gated.length).toBeGreaterThan(10);

    // ...but the UI must not disable the row. A padlock on something that is
    // not behind a payment reads as a paywall, and nothing here is paid.
    const ui = readFileSync(resolve(__dirname, "../LearnJourney.tsx"), "utf8");
    expect(ui).not.toMatch(/disabled=\{!unlocked\}/);
    expect(ui).toMatch(/Easier after/);
  });
});
