/**
 * The Intermediate stage makes promises in its lesson text — "every legal
 * black answer still loses the rook", "the knight is now frozen", "before
 * this move Ra1 was checkmate, after it, it is not".
 *
 * A lesson that teaches something false is worse than no lesson. These tests
 * check each claim on a real board.
 */
import { describe, expect, it } from "vitest";
import { Chess } from "chess.js";
import { STAGES, findLesson, isLessonUnlocked, type Lesson } from "../journey";
import { goalAchievable, lessonIsPlayable } from "../lessonEngine";
import { SKILL_AREAS } from "../insights";

const stage = STAGES.find((s) => s.id === "intermediate")!;
const lesson = (id: string): Lesson => findLesson(id)!.lesson;

/** Play the lesson's intended move and return the resulting game. */
function solve(l: Lesson): Chess {
  const c = new Chess(l.fen!);
  if (l.goal.kind !== "exactMove") throw new Error(`${l.id} is not an exact-move lesson`);
  c.move({ from: l.goal.from, to: l.goal.to, promotion: l.goal.promotion ?? "q" });
  return c;
}

/** After our move, does `winner` capture on `target` no matter what they try? */
function winsWhateverTheyPlay(after: Chess, from: string, target: string): boolean {
  const replies = after.moves();
  if (replies.length === 0) return false;
  return replies.every((reply) => {
    const probe = new Chess(after.fen());
    probe.move(reply);
    return probe.moves({ verbose: true }).some((m) => m.from === from && m.to === target);
  });
}

describe("the Intermediate stage is really built", () => {
  it("is marked built and has lessons", () => {
    expect(stage.built).toBe(true);
    expect(stage.lessons.length).toBeGreaterThanOrEqual(8);
    expect(stage.plannedNote).toBeUndefined();
  });

  it("every lesson is playable and legal", () => {
    for (const l of stage.lessons) {
      expect(() => new Chess(l.fen!), `${l.id} FEN`).not.toThrow();
      expect(lessonIsPlayable(l), `${l.id} goal not achievable`).toBe(true);
      if (l.transferFen && l.transferGoal) {
        expect(goalAchievable(l.transferFen, l.transferGoal), `${l.id} transfer`).toBe(true);
      }
    }
  });

  it("gives every practice lesson real hints, and read lessons none", () => {
    for (const l of stage.lessons) {
      if (l.goal.kind === "read") expect(l.hints, l.id).toHaveLength(0);
      else expect(l.hints.length, `${l.id} needs a hint ladder`).toBeGreaterThanOrEqual(3);
    }
  });

  it("explains its jargon instead of assuming it", () => {
    for (const [id, word] of [
      ["what-is-a-fork", /attacks two/i],
      ["the-pin", /cannot move because/i],
      ["the-skewer", /valuable piece is in FRONT/i],
      ["make-luft", /escape square|nowhere to step/i],
    ] as const) {
      expect(lesson(id).teach, `${id} must explain itself`).toMatch(word);
    }
  });

  it("locks each lesson behind evidence, not behind payment or a streak", () => {
    for (const l of stage.lessons) {
      expect(l.prerequisites?.length, `${l.id} should need something first`).toBeGreaterThan(0);
      expect(isLessonUnlocked(l, []), `${l.id} must be locked at the start`).toBe(false);
      expect(isLessonUnlocked(l, l.prerequisites!), `${l.id} must open on evidence`).toBe(true);
    }
  });

  it("feeds the skill areas on the Progress page", () => {
    const known = new Set(SKILL_AREAS.flatMap((a) => a.concepts));
    for (const l of stage.lessons) {
      const mapped = l.concepts.filter((c) => known.has(c));
      expect(mapped.length, `${l.id} concepts ${l.concepts} map to no skill area`).toBeGreaterThan(0);
    }
  });
});

describe("the fork lesson tells the truth", () => {
  it("Nc7 really forks, and wins the rook against every reply", () => {
    const l = lesson("what-is-a-fork");
    const after = solve(l);
    expect(after.isCheck()).toBe(true);
    expect(winsWhateverTheyPlay(after, "c7", "a8")).toBe(true);
  });

  it("the transfer position is a different board with the same idea", () => {
    const l = lesson("what-is-a-fork");
    expect(l.transferFen).not.toBe(l.fen);
    const c = new Chess(l.transferFen!);
    const g = l.transferGoal!;
    if (g.kind !== "exactMove") throw new Error("transfer should be an exact move");
    c.move({ from: g.from, to: g.to });
    expect(c.isCheck()).toBe(true);
    expect(winsWhateverTheyPlay(c, "e7", "c8")).toBe(true);
  });
});

describe("the pin lesson tells the truth", () => {
  it("the knight really is frozen afterwards", () => {
    const after = solve(lesson("the-pin"));
    const knightMoves = after.moves({ verbose: true }).filter((m) => m.from === "c6");
    expect(knightMoves).toHaveLength(0);
    // and it is a pin, not a check — the king is not attacked
    expect(after.isCheck()).toBe(false);
  });
});

describe("the skewer lesson tells the truth", () => {
  it("checks the king and wins the rook behind it, whatever Black plays", () => {
    const after = solve(lesson("the-skewer"));
    expect(after.isCheck()).toBe(true);
    expect(winsWhateverTheyPlay(after, "b2", "h8")).toBe(true);
  });
});

describe("the queen double attack lesson tells the truth", () => {
  it("wins the knight, and Black genuinely cannot block", () => {
    const after = solve(lesson("queen-double-attack"));
    expect(after.isCheck()).toBe(true);
    expect(after.isCheckmate()).toBe(false);
    // the lesson says blocking is the usual defence and is unavailable here
    const blocks = after.moves({ verbose: true }).filter((m) => m.piece !== "k");
    expect(blocks).toHaveLength(0);
    expect(winsWhateverTheyPlay(after, "d4", "a7")).toBe(true);
  });
});

describe("the luft lesson tells the truth", () => {
  it("Ra1 is mate before the pawn move and not mate after it", () => {
    const l = lesson("make-luft");

    const before = new Chess(l.fen!);
    before.load(l.fen!.replace(" w ", " b ")); // give Black the move in the same position
    before.move("Ra1");
    expect(before.isCheckmate(), "the danger must be real").toBe(true);

    const after = solve(l);
    const probe = new Chess(after.fen());
    probe.move("Ra1");
    expect(probe.isCheck()).toBe(true);
    expect(probe.isCheckmate(), "h3 must actually fix it").toBe(false);
  });
});

describe("the reading lessons point at a real position", () => {
  it("each one uses a legal board the learner has already seen or will see", () => {
    for (const l of stage.lessons.filter((x) => x.goal.kind === "read")) {
      expect(l.fen, `${l.id} should still show a board`).toBeTruthy();
      expect(() => new Chess(l.fen!)).not.toThrow();
      expect(l.teach.length).toBeGreaterThan(120); // a reading lesson has to say something
    }
  });
});
