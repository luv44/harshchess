/**
 * The Advanced stage, held to the same standard as the Intermediate one:
 * anything the lesson text asserts has to be true on a real board.
 */
import { describe, expect, it } from "vitest";
import { Chess } from "chess.js";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { STAGES, findLesson, isLessonUnlocked, type Lesson } from "../journey";
import { goalAchievable, lessonIsPlayable } from "../lessonEngine";
import { SKILL_AREAS } from "../insights";

const stage = STAGES.find((s) => s.id === "advanced")!;
const lesson = (id: string): Lesson => findLesson(id)!.lesson;

/** Squares the side to move could walk its king to. */
function kingSquares(fen: string): string[] {
  return new Chess(fen)
    .moves({ verbose: true })
    .filter((m) => m.piece === "k")
    .map((m) => m.to)
    .sort();
}

describe("the Advanced stage is really built", () => {
  it("is marked built and has lessons", () => {
    expect(stage.built).toBe(true);
    expect(stage.lessons.length).toBeGreaterThanOrEqual(5);
    expect(stage.plannedNote).toBeUndefined();
  });

  it("every lesson is playable, legal and locked behind evidence", () => {
    for (const l of stage.lessons) {
      expect(() => new Chess(l.fen!), `${l.id} FEN`).not.toThrow();
      expect(lessonIsPlayable(l), `${l.id} goal not achievable`).toBe(true);
      if (l.transferFen && l.transferGoal) {
        expect(goalAchievable(l.transferFen, l.transferGoal), `${l.id} transfer`).toBe(true);
      }
      expect(l.prerequisites?.length, `${l.id} should need something first`).toBeGreaterThan(0);
      expect(isLessonUnlocked(l, []), `${l.id} must start locked`).toBe(false);
      expect(isLessonUnlocked(l, l.prerequisites!), `${l.id} must open on evidence`).toBe(true);
    }
  });

  it("feeds the skill areas on the Progress page", () => {
    const known = new Set(SKILL_AREAS.flatMap((a) => a.concepts));
    for (const l of stage.lessons) {
      expect(l.concepts.some((c) => known.has(c)), `${l.id} maps to no skill area`).toBe(true);
    }
  });

  it("explains its jargon rather than assuming it", () => {
    expect(lesson("rook-behind-passer").teach).toMatch(/passed pawn is one with no enemy pawn able to stop it/i);
    expect(lesson("stalemate-trap").teach).toMatch(/no legal move and is NOT in check/i);
    expect(lesson("prophylaxis").teach).toMatch(/what would they play/i);
  });
});

describe("the cut-off lesson tells the truth", () => {
  it("the black king really loses the d-file", () => {
    const l = lesson("cut-the-king-off");
    const before = kingSquares(l.fen!.replace(" w ", " b "));
    expect(before).toEqual(expect.arrayContaining(["d4", "d5", "d6"]));

    const c = new Chess(l.fen!);
    if (l.goal.kind !== "exactMove") throw new Error("expected an exact move");
    c.move({ from: l.goal.from, to: l.goal.to });

    const after = kingSquares(c.fen());
    for (const sq of ["d4", "d5", "d6"]) expect(after, `${sq} should be cut off`).not.toContain(sq);
    expect(after.length).toBeGreaterThan(0); // a wall, not a mate
  });

  it("the transfer position cuts the king off along a row instead of a file", () => {
    const l = lesson("cut-the-king-off");
    const g = l.transferGoal!;
    if (g.kind !== "exactMove") throw new Error("expected an exact move");
    const before = kingSquares(l.transferFen!.replace(" w ", " b "));
    expect(before).toEqual(expect.arrayContaining(["c5", "d5", "e5"]));

    const c = new Chess(l.transferFen!);
    c.move({ from: g.from, to: g.to });
    const after = kingSquares(c.fen());
    for (const sq of ["c5", "d5", "e5"]) expect(after).not.toContain(sq);
  });
});

describe("the stalemate lesson tells the truth", () => {
  it("there is exactly one mate and exactly one stalemate — that is the whole point", () => {
    const fen = lesson("stalemate-trap").fen!;
    const c = new Chess(fen);
    const mates = c.moves().filter((m) => {
      const d = new Chess(fen);
      d.move(m);
      return d.isCheckmate();
    });
    const stalemates = c.moves().filter((m) => {
      const d = new Chess(fen);
      d.move(m);
      return d.isStalemate();
    });
    expect(mates).toEqual(["Qb7#"]);
    expect(stalemates).toEqual(["Qb6"]);
  });

  it("only accepts the mate, and a stalemate is not treated as success", () => {
    const l = lesson("stalemate-trap");
    expect(l.goal.kind).toBe("mate");
    const c = new Chess(l.fen!);
    c.move("Qb6");
    expect(c.isStalemate()).toBe(true);
    expect(c.isCheckmate()).toBe(false);
  });
});

describe("the prophylaxis lesson tells the truth", () => {
  it("the mate it warns about is real, and the defences it counts are real", () => {
    const fen = lesson("prophylaxis").fen!;
    const c = new Chess(fen);
    expect(c.turn()).toBe("b");

    // a slow move really does lose to Qxf7#
    const slow = new Chess(fen);
    slow.move("a6");
    const mate = new Chess(slow.fen());
    mate.move("Qxf7");
    expect(mate.isCheckmate()).toBe(true);

    // and the lesson claims there are exactly eight moves that stop it
    const saves = c.moves().filter((m) => {
      const d = new Chess(fen);
      d.move(m);
      return !d.moves().some((x) => {
        const e = new Chess(d.fen());
        e.move(x);
        return e.isCheckmate();
      });
    });
    expect(saves).toHaveLength(8);
    expect(lesson("prophylaxis").afterSuccess).toMatch(/exactly eight moves/i);
  });
});

describe("the reading lessons still show a real board", () => {
  it("every read lesson has a legal position and says something substantial", () => {
    for (const l of stage.lessons.filter((x) => x.goal.kind === "read")) {
      expect(() => new Chess(l.fen!)).not.toThrow();
      expect(l.teach.length).toBeGreaterThan(150);
      expect(l.hints).toHaveLength(0);
    }
  });

  it("calls a rule of thumb a rule of thumb, not a law", () => {
    expect(lesson("rook-behind-passer").teach).toMatch(/rule of thumb/i);
    expect(lesson("rook-behind-passer").afterSuccess).toMatch(/not a law/i);
  });
});

describe("what is still honestly missing", () => {
  it("nothing is marked built unless it really has lessons", () => {
    for (const s of STAGES) {
      expect(s.built === s.lessons.length > 0, `${s.id} disagrees with itself`).toBe(true);
    }
  });
});

describe("the app never makes a stale claim about itself", () => {
  it("the 'not written yet' sentence is generated from the stages, not typed", async () => {
    const { unbuiltStageNames, unbuiltStagesSentence } = await import("../journey");
    const missing = unbuiltStageNames();

    // Every stage is written now, so the sentence must say that instead of
    // naming a stage. When a new unbuilt stage is added it will name it.
    expect(missing).toEqual([]);
    expect(unbuiltStagesSentence()).toBe("Every stage in the journey is written and playable.");

    // and it must NOT name a stage that is actually built
    for (const s of STAGES.filter((x) => x.built)) {
      expect(unbuiltStagesSentence(), `${s.name} is built and must not be called missing`).not.toContain(s.name);
    }
  });

  it("the Progress page shows that generated sentence, not a hard-coded one", () => {
    const src = readFileSync(resolve(__dirname, "../../brain/BrainScreen.tsx"), "utf8");
    expect(src).toContain("unbuiltStagesSentence()");
    // the old hard-coded claim, which went stale the moment the stages were built
    expect(src).not.toMatch(/Intermediate, Advanced and Expert stages are not written/);
  });
});

describe("Advanced and Expert are exercises, not reading", () => {
  it("most of them ask the learner to play something", async () => {
    const { STAGES: S } = await import("../journey");
    for (const id of ["advanced", "expert"]) {
      const st = S.find((x) => x.id === id)!;
      const playable = st.lessons.filter((l) => l.goal.kind !== "read");
      expect(playable.length, `${id} is mostly reading`).toBeGreaterThanOrEqual(st.lessons.length - 2);
    }
  });

  it("every playable lesson has a three-step hint ladder", async () => {
    const { STAGES: S } = await import("../journey");
    for (const id of ["advanced", "expert"]) {
      for (const l of S.find((x) => x.id === id)!.lessons) {
        if (l.goal.kind === "read") continue;
        expect(l.hints.length, `${l.id} needs hints`).toBeGreaterThanOrEqual(3);
      }
    }
  });
});

describe("the new exercise types are graded against the real board", () => {
  it("prophylaxis: exactly the eight moves that stop the mate are accepted", async () => {
    const { checkMove } = await import("../lessonEngine");
    const l = lesson("prophylaxis");
    const fen = l.fen!;
    const accepted = new Chess(fen)
      .moves({ verbose: true })
      .filter((m) => checkMove(fen, m.from, m.to, m.promotion, l.goal).ok);
    expect(accepted).toHaveLength(8);
    expect(l.afterSuccess).toMatch(/exactly eight moves stop it/i);

    // and each really does remove the mate
    for (const m of accepted) {
      const probe = new Chess(fen);
      probe.move({ from: m.from, to: m.to, promotion: m.promotion ?? "q" });
      const stillMate = probe.moves().some((san) => {
        const q = new Chess(probe.fen());
        q.move(san);
        return q.isCheckmate();
      });
      expect(stillMate, `${m.san} should stop the mate`).toBe(false);
    }
  });

  it("their best reply: the six queen-losing moves are rejected, the rest accepted", async () => {
    const { checkMove } = await import("../lessonEngine");
    const l = lesson("their-best-reply");
    const fen = l.fen!;
    const all = new Chess(fen).moves({ verbose: true });
    const rejected = all.filter((m) => !checkMove(fen, m.from, m.to, m.promotion, l.goal).ok);
    expect(all).toHaveLength(27);
    expect(rejected.map((m) => m.san).sort()).toEqual(["Kd1", "Kd2", "Ke2", "Kf1", "Kf2", "Qe4+"].sort());
    expect(l.afterSuccess).toMatch(/27 legal moves here, 6 lose the queen/i);
  });

  it("calculate to the end: c6 is again the only move that queens", async () => {
    const l = lesson("calculate-to-the-end");
    expect(l.goal).toEqual({ kind: "exactMove", from: "c5", to: "c6" });
    const c = new Chess(l.fen!);
    expect(c.moves({ verbose: true }).some((m) => m.from === "c5" && m.to === "c6")).toBe(true);
    // the position really is two plies into the breakthrough
    const bt = new Chess(lesson("pawn-breakthrough").fen!);
    bt.move("b6");
    bt.move("axb6");
    expect(bt.fen()).toBe(l.fen);
  });

  it("rook behind the passer: the rook really has to travel to get there", async () => {
    const l = lesson("rook-behind-passer");
    expect(l.goal).toEqual({ kind: "exactMove", from: "e1", to: "a1" });
    const c = new Chess(l.fen!);
    expect(c.get("a1"), "a1 must start empty or the lesson is pointless").toBeFalsy();
    expect(c.get("e1")).toMatchObject({ type: "r", color: "w" });
    expect(c.get("a5")).toMatchObject({ type: "p", color: "w" });
  });
});
