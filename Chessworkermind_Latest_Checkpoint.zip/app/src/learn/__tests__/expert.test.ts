/**
 * The Expert stage. Its central claim is the strongest one in the whole
 * journey — "this is the ONLY move here that forces a queen" — so it is
 * proved by searching every legal move and every legal reply, not asserted.
 */
import { describe, expect, it } from "vitest";
import { Chess } from "chess.js";
import { STAGES, findLesson, isLessonUnlocked, type Lesson } from "../journey";
import { lessonIsPlayable } from "../lessonEngine";
import { chooseSuggestion } from "../../coach/coachCard";
import { SKILL_AREAS } from "../insights";

const stage = STAGES.find((s) => s.id === "expert")!;
const lesson = (id: string): Lesson => findLesson(id)!.lesson;

/* ------------------------------------------------------------------ */
/* A tiny exact solver for the pawn endgame                            */
/* ------------------------------------------------------------------ */

const memo = new Map<string, boolean>();

/** Can White force a queen onto the board within `depthLeft` plies? */
function whiteForcesQueen(c: Chess, depthLeft: number): boolean {
  if (c.isCheckmate()) return c.turn() === "b";
  if (c.isStalemate() || c.isDraw()) return false;
  if (c.board().flat().some((s) => s && s.color === "w" && s.type === "q")) return true;
  if (depthLeft <= 0) return false;

  const key = `${c.fen().split(" ").slice(0, 4).join(" ")}|${depthLeft}`;
  const hit = memo.get(key);
  if (hit !== undefined) return hit;

  const whiteToMove = c.turn() === "w";
  let result = !whiteToMove; // White needs ONE good move; Black needs ALL to fail
  for (const m of c.moves()) {
    c.move(m);
    const r = whiteForcesQueen(c, depthLeft - 1);
    c.undo();
    if (whiteToMove && r) { result = true; break; }
    if (!whiteToMove && !r) { result = false; break; }
  }
  memo.set(key, result);
  return result;
}

describe("the Expert stage is really built", () => {
  it("is marked built and has lessons", () => {
    expect(stage.built).toBe(true);
    expect(stage.lessons.length).toBeGreaterThanOrEqual(5);
    expect(stage.plannedNote).toBeUndefined();
  });

  it("every lesson is legal, playable and locked behind evidence", () => {
    for (const l of stage.lessons) {
      expect(() => new Chess(l.fen!), `${l.id} FEN`).not.toThrow();
      expect(lessonIsPlayable(l), `${l.id} goal not achievable`).toBe(true);
      expect(l.prerequisites?.length, `${l.id} needs a prerequisite`).toBeGreaterThan(0);
      expect(isLessonUnlocked(l, []), `${l.id} must start locked`).toBe(false);
      expect(isLessonUnlocked(l, l.prerequisites!), `${l.id} must open on evidence`).toBe(true);
    }
  });

  it("promises no rating and no title", () => {
    const words = stage.lessons.map((l) => `${l.teach} ${l.afterSuccess}`).join(" ");
    expect(words).not.toMatch(/\bmaster\b|\btitle\b|\brating\b|\bElo\b|\bgrandmaster\b/i);
  });

  it("feeds the Progress skill areas", () => {
    const known = new Set(SKILL_AREAS.flatMap((a) => a.concepts));
    for (const l of stage.lessons) {
      expect(l.concepts.some((c) => known.has(c)), `${l.id} maps to no skill area`).toBe(true);
    }
  });
});

describe("the breakthrough lesson makes the strongest claim, so it gets the strongest proof", () => {
  const l = lesson("pawn-breakthrough");

  it(
    "b6 is the ONLY move that forces a queen — every other legal move fails",
    () => {
      const fen = l.fen!;
      const root = new Chess(fen);
      const results = root.moves().map((san) => {
        const c = new Chess(fen);
        c.move(san);
        return [san, whiteForcesQueen(c, 9)] as const;
      });

      const winning = results.filter(([, w]) => w).map(([san]) => san);
      expect(winning, "exactly one move should force a queen").toEqual(["b6"]);

      // and that is the move the lesson asks for
      if (l.goal.kind !== "exactMove") throw new Error("expected an exact move");
      const probe = new Chess(fen);
      const played = probe.move({ from: l.goal.from, to: l.goal.to });
      expect(played.san).toBe("b6");

      // the other two pawn pushes must really fail, or the lesson is a lie
      for (const san of ["a6", "c6"]) {
        expect(results.find(([m]) => m === san)?.[1], `${san} must not win`).toBe(false);
      }
    },
    120_000,
  );

  it("says out loud how it was checked", () => {
    expect(l.afterSuccess).toMatch(/searching every legal reply/i);
    expect(l.afterSuccess).toMatch(/ONLY move/);
  });
});

describe("the other Expert claims are checked too", () => {
  it("'check their best reply' really does punish leaving the queen on c4", () => {
    // The lesson now starts with the queen ALREADY on c4, so the learner has
    // to notice she is attacked. If they ignore her, dxc4 is the punishment.
    const l = lesson("their-best-reply");
    const c = new Chess(l.fen!);
    expect(c.get("c4")).toMatchObject({ type: "q", color: "w" });
    expect(c.get("d5")).toMatchObject({ type: "p", color: "b" });

    c.move({ from: "e1", to: "e2" }); // a king move: the queen is left hanging
    const grabs = c.moves({ verbose: true }).filter((m) => m.captured === "q");
    expect(grabs.map((m) => m.san)).toEqual(["dxc4"]);
  });

  it("'several moves are right' points at a position where that is true", () => {
    const l = lesson("several-right-moves");
    const picked = chooseSuggestion(l.fen!);
    expect(picked).not.toBeNull();
    expect(picked!.suggestion.severalSound, "the coach must really report several sound moves here").toBe(true);
    expect(picked!.suggestion.alternatives.length).toBeGreaterThan(0);
  });

  it("the review lesson sends people to a feature that exists", () => {
    const l = lesson("review-your-own");
    expect(l.teach).toMatch(/under games/i);
    expect(l.teach).toMatch(/will not grade you/i);
  });

  it("every reading lesson still shows a legal board and says something", () => {
    for (const l of stage.lessons.filter((x) => x.goal.kind === "read")) {
      expect(() => new Chess(l.fen!)).not.toThrow();
      expect(l.teach.length).toBeGreaterThan(150);
      expect(l.hints).toHaveLength(0);
    }
  });
});

describe("the trick lessons are genuinely tricky, and true", () => {
  it("poisoned pawn: exactly two of the eleven moves lose the bishop", async () => {
    const { checkMove } = await import("../lessonEngine");
    const { findLesson: find } = await import("../journey");
    const l = find("poisoned-pawn")!.lesson;
    const fen = l.fen!;
    const all = new Chess(fen).moves({ verbose: true });
    const rejected = all.filter((m) => !checkMove(fen, m.from, m.to, m.promotion, l.goal).ok);

    expect(all).toHaveLength(11);
    expect(rejected.map((m) => m.san).sort()).toEqual(["Be4", "Bxd5"]);
    expect(l.afterSuccess).toMatch(/exactly two lose the bishop/i);

    // and the punishment is real: cxd5 takes the bishop
    const probe = new Chess(fen);
    probe.move("Bxd5");
    expect(probe.moves()).toContain("cxd5");
  });

  it("knight promotion: the knight checks and forks, the queen does neither", async () => {
    const { findLesson: find } = await import("../journey");
    const l = find("knight-promotion")!.lesson;
    expect(l.goal).toEqual({ kind: "exactMove", from: "e7", to: "e8", promotion: "n" });

    const asKnight = new Chess(l.fen!);
    asKnight.move({ from: "e7", to: "e8", promotion: "n" });
    expect(asKnight.isCheck()).toBe(true);
    // the rook falls whatever Black does
    expect(
      asKnight.moves().every((r) => {
        const d = new Chess(asKnight.fen());
        d.move(r);
        return d.moves({ verbose: true }).some((m) => m.from === "e8" && m.to === "c7");
      }),
    ).toBe(true);

    const asQueen = new Chess(l.fen!);
    asQueen.move({ from: "e7", to: "e8", promotion: "q" });
    expect(asQueen.isCheck(), "a queen on e8 must NOT be check, or the lesson is pointless").toBe(false);
  });

  it("the check that loses: exactly one of twenty-one moves is bad, and it is the check", async () => {
    const { checkMove } = await import("../lessonEngine");
    const { findLesson: find } = await import("../journey");
    const l = find("check-is-not-free")!.lesson;
    const fen = l.fen!;
    const all = new Chess(fen).moves({ verbose: true });
    const rejected = all.filter((m) => !checkMove(fen, m.from, m.to, m.promotion, l.goal).ok);

    expect(all).toHaveLength(21);
    expect(rejected.map((m) => m.san)).toEqual(["Rb8+"]);
    // it really is the only check on the board
    const checks = all.filter((m) => m.san.includes("+"));
    expect(checks.map((m) => m.san)).toEqual(["Rb8+"]);
    // and it really is answered by a capture
    const probe = new Chess(fen);
    probe.move("Rb8+");
    expect(probe.moves()).toEqual(["Rxb8"]);
    expect(l.afterSuccess).toMatch(/exactly one loses material — Rb8\+/i);
  });

  it("each trick lesson leaves a line worth remembering", async () => {
    const { findLesson: find } = await import("../journey");
    for (const id of ["poisoned-pawn", "knight-promotion", "check-is-not-free"]) {
      const l = find(id)!.lesson;
      expect(l.trick, `${id} has no trick`).toBeTruthy();
      expect(l.hints.length, `${id} needs a hint ladder`).toBeGreaterThanOrEqual(3);
      expect(l.title).toMatch(/^Trick: /);
    }
  });
});
