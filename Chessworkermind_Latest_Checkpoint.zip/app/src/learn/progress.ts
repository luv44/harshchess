/**
 * Learning progress that means something.
 *
 * Rules:
 *  - Seeing a hint is recorded separately from solving alone.
 *  - A concept counts as "understood" only after an UNAIDED success.
 *  - Mistakes are never punished and there are no punitive streaks.
 *  - When there is not enough evidence we say so instead of inventing a score.
 *  - Solve times are recorded ONLY for unaided solves, only from the moment
 *    the position was shown, and absurd gaps (the phone was put down) are
 *    thrown away rather than averaged in.
 */

export type LessonRecord = {
  completed: boolean;
  /** true only if it was solved with no hint and no revealed answer */
  unaided: boolean;
  attempts: number;
  hintedSuccesses: number;
  unaidedSuccesses: number;
  lastAt: string;
  /** Older saves lack this; lifetime successes must not imply this week's result. */
  lastUnaided?: boolean;
};

/** One unaided solve, in the order it happened. */
export type SolveTime = {
  /** lesson id */
  id: string;
  /** milliseconds from seeing the position to the first correct move */
  ms: number;
  /** ISO timestamp */
  at: string;
};

/** Anything longer than this means the learner walked away. Not a think. */
export const MAX_SOLVE_MS = 5 * 60 * 1000;
/** Anything faster than this is a lucky tap, not a solved problem. */
export const MIN_SOLVE_MS = 400;
/** We keep a bounded history so localStorage never grows without limit. */
export const MAX_SOLVE_SAMPLES = 200;

export type LearnProgress = {
  version: 1;
  lessons: Record<string, LessonRecord>;
  /** concepts with at least one unaided success */
  concepts: string[];
  /** every calendar day (YYYY-MM-DD, local) on which something was practised */
  days: string[];
  /** unaided solve times, oldest first — the only speed evidence we have */
  solveTimes: SolveTime[];
};

export const PROGRESS_KEY = "chessworkermind:learn:v1";

export const EMPTY_PROGRESS: LearnProgress = {
  version: 1,
  lessons: {},
  concepts: [],
  days: [],
  solveTimes: [],
};

/** Local calendar day, so a streak means "days you showed up", not UTC hours. */
export function dayKey(d: Date = new Date()): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export function parseProgress(raw: string | null): LearnProgress {
  if (!raw) return EMPTY_PROGRESS;
  try {
    const p = JSON.parse(raw) as LearnProgress;
    if (!p || typeof p !== "object" || !p.lessons) return EMPTY_PROGRESS;
    return {
      version: 1,
      lessons: p.lessons ?? {},
      concepts: Array.isArray(p.concepts) ? p.concepts : [],
      days: Array.isArray(p.days) ? p.days : [],
      solveTimes: Array.isArray(p.solveTimes)
        ? p.solveTimes.filter(
            (t) => t && typeof t.id === "string" && typeof t.ms === "number" && Number.isFinite(t.ms),
          )
        : [],
    };
  } catch {
    return EMPTY_PROGRESS;
  }
}

export function loadProgress(): LearnProgress {
  try {
    return parseProgress(localStorage.getItem(PROGRESS_KEY));
  } catch {
    return EMPTY_PROGRESS;
  }
}

export function saveProgress(p: LearnProgress): void {
  try {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(p));
  } catch {
    /* ignore */
  }
}

/** Record one finished attempt. Pure — returns the new progress. */
export function recordAttempt(
  prev: LearnProgress,
  lessonId: string,
  concepts: string[],
  unaided: boolean,
  /** how long the learner looked at the position before solving it, in ms */
  solveMs?: number,
): LearnProgress {
  const old = prev.lessons[lessonId];
  const rec: LessonRecord = {
    completed: true,
    // once earned, an unaided success is never taken away by a later hinted run
    unaided: (old?.unaided ?? false) || unaided,
    attempts: (old?.attempts ?? 0) + 1,
    hintedSuccesses: (old?.hintedSuccesses ?? 0) + (unaided ? 0 : 1),
    unaidedSuccesses: (old?.unaidedSuccesses ?? 0) + (unaided ? 1 : 0),
    lastAt: new Date().toISOString(),
    lastUnaided: unaided,
  };
  const nextConcepts = new Set(prev.concepts);
  if (unaided) for (const c of concepts) nextConcepts.add(c);
  const today = dayKey();

  // A speed sample only counts when the lesson was solved with NO help and
  // the time is believable. Everything else is silently ignored — we would
  // rather have no speed data than wrong speed data.
  const usable =
    unaided &&
    typeof solveMs === "number" &&
    Number.isFinite(solveMs) &&
    solveMs >= MIN_SOLVE_MS &&
    solveMs <= MAX_SOLVE_MS;
  const solveTimes = usable
    ? [...prev.solveTimes, { id: lessonId, ms: Math.round(solveMs), at: rec.lastAt }].slice(
        -MAX_SOLVE_SAMPLES,
      )
    : prev.solveTimes;

  const next: LearnProgress = {
    version: 1,
    lessons: { ...prev.lessons, [lessonId]: rec },
    concepts: [...nextConcepts],
    days: prev.days.includes(today) ? prev.days : [...prev.days, today].sort(),
    solveTimes,
  };
  saveProgress(next);
  return next;
}

/** An honest summary — never a made-up mastery percentage. */
export function summarize(p: LearnProgress): { line: string; enoughData: boolean } {
  const records = Object.values(p.lessons);
  const unaided = records.filter((r) => r.unaidedSuccesses > 0).length;
  if (records.length < 3) {
    return { line: "Not enough data yet — finish a few more lessons.", enoughData: false };
  }
  if (unaided === 0) {
    return {
      line: `You finished ${records.length} lessons, all with help so far. That is a normal start.`,
      enoughData: true,
    };
  }
  return {
    line: `You solved ${unaided} of ${records.length} lessons without any hint.`,
    enoughData: true,
  };
}
