/**
 * Lesson grading — pure and verified against the real board.
 *
 * A lesson never says "wrong" harshly: a legal move that is not the target
 * gets a kind, specific response, and the learner can keep trying.
 */

import { Chess } from "chess.js";
import { isLegal, materialSwing, safeCaptures, safeChess } from "../coach/localAnalysis";
import { isSerious, reviewMove } from "../coach/reviewMove";
import type { Lesson, LessonGoal } from "./journey";

export type GoalResult = {
  ok: boolean;
  /** Why it did not count — used to pick friendly wording, never a scolding. */
  reason:
    | "ok"
    | "illegal"
    | "notThatMove"
    | "notACapture"
    | "notSafe"
    | "noMate"
    | "noCheck"
    | "stillMated"
    | "losesMaterial"
    | "readOnly";
};

export function checkMove(
  fen: string,
  from: string,
  to: string,
  promotion: string | undefined,
  goal: LessonGoal,
): GoalResult {
  if (goal.kind === "read") return { ok: true, reason: "readOnly" };
  if (!isLegal(fen, from, to, promotion)) return { ok: false, reason: "illegal" };

  const c = safeChess(fen);
  if (!c) return { ok: false, reason: "illegal" };

  switch (goal.kind) {
    case "exactMove": {
      const ok = from === goal.from && to === goal.to && (!goal.promotion || promotion === goal.promotion);
      return { ok, reason: ok ? "ok" : "notThatMove" };
    }
    case "avoidMate": {
      // Did the move actually take the mate away? Replayed, never assumed.
      const sim = new Chess(fen);
      sim.move({ from, to, promotion: (promotion as never) ?? "q" });
      if (sim.isGameOver()) return { ok: true, reason: "ok" };
      const theyMate = sim.moves().some((san) => {
        const probe = new Chess(sim.fen());
        probe.move(san);
        return probe.isCheckmate();
      });
      return theyMate ? { ok: false, reason: "stillMated" } : { ok: true, reason: "ok" };
    }
    case "avoidLoss": {
      // Uses the same evidence rule as the coach: a move is only called
      // losing when the punishment can be replayed on the board.
      const r = reviewMove({ fen, from, to, promotion });
      return isSerious(r.risk) ? { ok: false, reason: "losesMaterial" } : { ok: true, reason: "ok" };
    }
    case "escapeCheck": {
      // chess.js only produces legal moves, so any legal move here ends the check
      return { ok: true, reason: "ok" };
    }
    case "capture": {
      const before = new Chess(fen);
      const mv = before.moves({ verbose: true }).find((m) => m.from === from && m.to === to);
      if (!mv) return { ok: false, reason: "illegal" };
      const isCap = mv.flags.includes("c") || mv.flags.includes("e");
      if (!isCap) return { ok: false, reason: "notACapture" };
      if (goal.safe) {
        const safe = safeCaptures(fen).some((m) => m.from === from && m.to === to);
        if (!safe) return { ok: false, reason: "notSafe" };
      }
      return { ok: true, reason: "ok" };
    }
    case "mate": {
      const sim = new Chess(fen);
      sim.move({ from, to, promotion: promotion as never });
      return sim.isCheckmate() ? { ok: true, reason: "ok" } : { ok: false, reason: "noMate" };
    }
    case "check": {
      const sim = new Chess(fen);
      const color = c.turn();
      sim.move({ from, to, promotion: promotion as never });
      if (!sim.isCheck()) return { ok: false, reason: "noCheck" };
      // a check that simply hangs the piece does not count as a good check
      if (materialSwing(sim, color) < 0) return { ok: false, reason: "notSafe" };
      return { ok: true, reason: "ok" };
    }
    default:
      return { ok: false, reason: "illegal" };
  }
}

/** Is the lesson's goal actually reachable in its position? (test guard) */
export function goalAchievable(fen: string, goal: LessonGoal): boolean {
  if (goal.kind === "read") return true;
  if (goal.kind === "avoidMate" || goal.kind === "avoidLoss") {
    const c = safeChess(fen);
    if (!c) return false;
    return c.moves({ verbose: true }).some((m) => checkMove(fen, m.from, m.to, m.promotion, goal).ok);
  }
  const c = safeChess(fen);
  if (!c) return false;
  return c
    .moves({ verbose: true })
    .some((m) => checkMove(fen, m.from, m.to, m.promotion, goal).ok);
}

/** The move(s) that satisfy the goal — used for the "show me" tier. */
export function solutionMoves(fen: string, goal: LessonGoal): Array<{ from: string; to: string; san: string }> {
  const c = safeChess(fen);
  if (!c) return [];
  return c
    .moves({ verbose: true })
    .filter((m) => checkMove(fen, m.from, m.to, m.promotion, goal).ok)
    .map((m) => ({ from: m.from, to: m.to, san: m.san }));
}

export function lessonIsPlayable(lesson: Lesson): boolean {
  if (lesson.goal.kind === "read") return !lesson.fen || !!safeChess(lesson.fen);
  if (!lesson.fen) return false;
  return goalAchievable(lesson.fen, lesson.goal);
}
