import { loadEvidence, skillEvidence } from "./evidence";
import { conceptName } from "./journey";

export default function EvidencePanel({onPractice}:{onPractice:(id:string)=>void}) {
  const attempts=loadEvidence();
  const concepts=[...new Set(attempts.flatMap(a=>a.concepts))];
  return <section className="card" aria-label="Practice evidence">
    <h2>What the evidence says</h2>
    <p className="small muted">Recognition, calculation and execution are not yet measured separately. These records support move-choice and transfer practice only. Time and repeated answers do not prove mastery.</p>
    {attempts.length===0?<p>Not enough practice yet. New exercise attempts will appear here with their exact position and help level. Older summary counts are preserved but cannot prove independent transfer.</p>:
      <><p>{attempts.length} recorded attempts. No numerical Chess Brain rating.</p>
        {concepts.map(concept=>{const e=skillEvidence(attempts,concept);return <details key={concept}>
          <summary>{conceptName(concept)} · {e.distinctIndependent} different independent positions</summary>
          <p>{e.successes} independently correct; {e.transfer} transfer successes. {e.distinctIndependent<3?"Evidence is still sparse; no mastery claim.":"Practice evidence, not a certified skill assessment."}</p>
          <ul>{attempts.filter(a=>a.concepts.includes(concept)).slice(-5).map(a=><li key={a.id}>
            {a.answer} — {a.correct?"goal met":"practice / goal not met"}; {a.independent?"independent":"helped or repeated"}; hints {a.hintLevel}; Learning {a.learningLevel}, Computer {a.computerStrength}; exercise tier {a.exerciseTier}.
            <details><summary>Supporting position and verification</summary><code className="evidence-fen">{a.fen}</code><p>{a.provenance.verifier}; engine: {a.provenance.engineVersion}. {a.at}</p></details>
            <button className="btn btn--sm" onClick={()=>onPractice(a.lessonId)}>Practise this example</button>
          </li>)}</ul>
        </details>;})}
      </>}
  </section>;
}
