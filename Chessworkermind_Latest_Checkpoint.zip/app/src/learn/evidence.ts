import { loadDifficulty } from "./difficulty";
import { Chess } from "chess.js";

export type PracticeAttempt = {
  id: string; at: string; lessonId: string; positionId: string; fen: string;
  concepts: string[]; dimension: "move-choice" | "transfer";
  exerciseTier: number; learningLevel: number; computerStrength: number;
  mode: "adaptive" | "manual"; hintLevel: number; revealed: boolean;
  answer: string; correct: boolean; independent: boolean;
  provenance: { verifier: "chess.js legal replay + lesson goal"; engineVersion: "not used"; version: 1 };
};
export const EVIDENCE_KEY = "chessworkermind:attempts:v1";
export function loadEvidence(): PracticeAttempt[] {
  try {
    const p: unknown = JSON.parse(localStorage.getItem(EVIDENCE_KEY) ?? "[]");
    return Array.isArray(p) ? p.filter(a => a && typeof a.id === "string" && typeof a.fen === "string" && Array.isArray(a.concepts) && typeof a.correct === "boolean" && typeof a.independent === "boolean" && Number.isFinite(Date.parse(a.at))) : [];
  } catch { return []; }
}
export function recordEvidence(input: Omit<PracticeAttempt, "at" | "learningLevel" | "computerStrength" | "mode" | "provenance">) {
  const settings = loadDifficulty();
  const all = loadEvidence();
  if (all.some(a => a.id === input.id)) return; // idempotent, including React strict-mode rerenders
  // Same board with different counters or a different lesson ID is still the same position.
  const positionId = new Chess(input.fen).fen().split(" ").slice(0,4).join(" ");
  const priorExposure = all.some(a => a.fen.split(" ").slice(0,4).join(" ") === positionId);
  const attempt: PracticeAttempt = {
    ...input, positionId, independent: input.independent && !input.revealed && input.hintLevel === 0 && !priorExposure,
    at: new Date().toISOString(), learningLevel: settings.learning,
    computerStrength: settings.computer, mode: settings.mode,
    provenance: { verifier: "chess.js legal replay + lesson goal", engineVersion: "not used", version: 1 },
  };
  try { localStorage.setItem(EVIDENCE_KEY, JSON.stringify([...all, attempt].slice(-2000))); } catch { /* storage unavailable */ }
}
export function skillEvidence(attempts: PracticeAttempt[], concept: string) {
  const evidence = attempts.filter(a => a.concepts.includes(concept));
  const unique = new Map<string, PracticeAttempt>();
  for (const a of evidence) if (a.independent && !unique.has(a.positionId)) unique.set(a.positionId, a);
  const independent = [...unique.values()];
  const successes = independent.filter(a => a.correct).length;
  // Beta(1,1) estimate; deliberately not displayed as a mastery percentage.
  const alpha = 1 + successes, beta = 1 + independent.length - successes;
  const estimate = alpha / (alpha + beta);
  const uncertainty = Math.sqrt(alpha * beta / ((alpha + beta) ** 2 * (alpha + beta + 1)));
  return { concept, attempts: evidence.length, distinctIndependent: independent.length, successes, estimate, uncertainty,
    transfer: independent.filter(a => a.dimension === "transfer" && a.correct).length };
}
export function adaptiveRecommendation(attempts: PracticeAttempt[], current: number): { level: number; reason: string } | null {
  for (const concept of new Set(attempts.flatMap(a => a.concepts))) {
    const comparable = attempts.filter(a => a.exerciseTier === current);
    const skill = skillEvidence(comparable, concept);
    if (current < 10 && skill.distinctIndependent >= 3 && skill.successes >= 3 && skill.transfer > 0) {
      return { level: current + 1, reason: `${concept}: ${skill.successes} independent successes in different tier-${current} positions, including transfer. Try one tier higher; you can undo this choice.` };
    }
  }
  return null;
}
