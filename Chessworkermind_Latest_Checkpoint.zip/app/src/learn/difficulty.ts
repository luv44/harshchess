import { useEffect, useState } from "react";
import { allBuiltLessons, type Lesson } from "./journey";

export type DifficultySettings = { learning: number; computer: number; mode: "adaptive" | "manual" };
export const DIFFICULTY_KEY = "chessworkermind:difficulty:v1";
const changed = "cwm:difficulty-changed";
export const DEFAULT_DIFFICULTY: DifficultySettings = { learning: 1, computer: 1, mode: "adaptive" };
export const tier = (n: unknown, fallback = 1): number => typeof n === "number" && Number.isInteger(n) && n >= 1 && n <= 10 ? n : fallback;

/** Existing quality-checked lessons, not canned claims about the live game.
 * Upper tiers are representative exercises, NOT a complete expert curriculum. */
export const LEARNING_TIERS = [
  { level: 1, name: "First moves", lesson: "board-and-sides", preview: "Piece movement and legal squares; hints available on request." },
  { level: 2, name: "Board safety", lesson: "free-piece", preview: "Inspect a capture and check whether it is safe." },
  { level: 3, name: "Threat spotting", lesson: "give-check-safely", preview: "Find a legal check and inspect the consequence." },
  { level: 4, name: "Simple tactics", lesson: "what-is-a-fork", preview: "Recognise one verified double attack." },
  { level: 5, name: "Calculation start", lesson: "poisoned-pawn", preview: "Avoid a capture the opponent can punish." },
  { level: 6, name: "Combining ideas", lesson: "prophylaxis", preview: "Find a defense against an immediate mate threat." },
  { level: 7, name: "Candidate comparison", lesson: "their-best-reply", preview: "Compare legal choices without handing over material." },
  { level: 8, name: "Deeper plans", lesson: "knight-promotion", preview: "Consider a promotion other than a queen." },
  { level: 9, name: "Advanced calculation", lesson: "pawn-breakthrough", preview: "A verified pawn breakthrough. Full advanced curriculum is still in progress." },
  { level: 10, name: "Expert practice", lesson: "calculate-to-the-end", preview: "Continue a verified forcing line. Deep own-game expert practice is not yet built." },
] as const;

export function lessonForTier(level: number): Lesson {
  return allBuiltLessons().find(l => l.id === LEARNING_TIERS[tier(level) - 1].lesson)!;
}
export function difficultyForLesson(id: string): number {
  return LEARNING_TIERS.find(t => t.lesson === id)?.level ?? 1;
}
export function loadDifficulty(): DifficultySettings {
  try {
    const raw = localStorage.getItem(DIFFICULTY_KEY);
    if (!raw) {
      const old = localStorage.getItem("cwm:level");
      return { ...DEFAULT_DIFFICULTY, computer: old === "sharp" ? 8 : old === "steady" ? 4 : 1 };
    }
    const p = JSON.parse(raw);
    return { learning: tier(p?.learning), computer: tier(p?.computer), mode: p?.mode === "manual" ? "manual" : "adaptive" };
  } catch { return { ...DEFAULT_DIFFICULTY }; }
}
export function saveDifficulty(settings: DifficultySettings) {
  try { localStorage.setItem(DIFFICULTY_KEY, JSON.stringify(settings)); } catch { /* usable in memory */ }
  window.dispatchEvent(new CustomEvent(changed, { detail: settings }));
}
export function useDifficulty() {
  const [settings, setSettings] = useState(loadDifficulty);
  useEffect(() => {
    const update = (e: Event) => setSettings(e instanceof CustomEvent ? e.detail : loadDifficulty());
    window.addEventListener(changed, update);
    window.addEventListener("storage", update);
    return () => { window.removeEventListener(changed, update); window.removeEventListener("storage", update); };
  }, []);
  const set = (patch: Partial<DifficultySettings>) => {
    const next = { ...settings, ...patch };
    setSettings(next); saveDifficulty(next);
  };
  return [settings, set] as const;
}
