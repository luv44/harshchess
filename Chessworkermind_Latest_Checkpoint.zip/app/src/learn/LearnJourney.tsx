import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chess, type Square } from "chess.js";
import Board from "../chess/Board";
import { STAGES, conceptList, isLessonUnlocked, type Lesson, type LessonGoal, type Stage } from "./journey";
import { checkMove, solutionMoves } from "./lessonEngine";
import { loadProgress, recordAttempt, type LearnProgress } from "./progress";
import { difficultyForLesson } from "./difficulty";
import { loadEvidence, recordEvidence } from "./evidence";
import DifficultyPanel from "./DifficultyPanel";

/**
 * The Learn journey.
 *
 * A stage that is not built is shown as "not built yet" instead of a dead
 * button. Lessons unlock by understanding (prerequisite concepts), never by
 * streaks or payment, and every beginner lesson stays free.
 */

export default function LearnJourney({
  openLessonId,
  onBackToGuided,
}: { openLessonId?: string | null; onBackToGuided?: () => void } = {}) {
  const [progress, setProgress] = useState<LearnProgress>(() => loadProgress());
  const [active, setActive] = useState<{ lesson: Lesson; transfer: boolean } | null>(() => {
    if (!openLessonId) return null;
    const lesson = STAGES.filter((s) => s.built)
      .flatMap((s) => s.lessons)
      .find((l) => l.id === openLessonId);
    return lesson ? { lesson, transfer: false } : null;
  });

  const understood = progress.concepts;
  const builtStages = STAGES.filter((s) => s.built);
  const totalLessons = builtStages.reduce((n, s) => n + s.lessons.length, 0);
  const doneLessons = builtStages
    .flatMap((s) => s.lessons)
    .filter((l) => progress.lessons[l.id]?.completed).length;

  const onFinish = useCallback(
    (lessonId: string, concepts: string[], unaided: boolean, solveMs?: number) => {
      setProgress((p) => recordAttempt(p, lessonId, concepts, unaided, solveMs));
    },
    [],
  );

  if (active) {
    return (
      <LessonRunner
        key={`${active.lesson.id}:${active.transfer}`}
        lesson={active.lesson}
        outOfOrder={!isLessonUnlocked(active.lesson, understood)}
        transfer={active.transfer}
        onClose={() => setActive(null)}
        onFinish={onFinish}
        onTransfer={() => setActive({ lesson: active.lesson, transfer: true })}
      />
    );
  }

  return (
    <div className="stack lessonspage">
      {onBackToGuided && (
        <button className="btn btn--ghost btn--sm" style={{ alignSelf: "flex-start" }} onClick={onBackToGuided}>
          ← Back to the guided game
        </button>
      )}
      <div className="screenhead">
        <h1 className="screenhead__hi">Lessons</h1>
        <p className="screenhead__sub screenhead__sub--muted">
          Small, playable lessons. Start at the very beginning — the board and the pieces — and keep going.
        </p>
      </div>

      <div className="card">
        <div>
          <div className="progressbar" aria-label="Lessons completed">
            <i style={{ width: `${totalLessons ? (doneLessons / totalLessons) * 100 : 0}%` }} />
          </div>
          <p className="small muted" style={{ marginTop: 6 }}>
            {doneLessons} of {totalLessons} playable lessons done
            {doneLessons === 0 && " — nothing yet, that is a perfectly normal place to start."}
          </p>
        </div>
      </div>

      <DifficultyPanel onPractice={id => { const lesson = builtStages.flatMap(s => s.lessons).find(l => l.id === id); if (lesson) setActive({ lesson, transfer: false }); }} />

      {STAGES.map((stage, i) => (
        <StageBlock
          key={stage.id}
          stage={stage}
          index={i + 1}
          progress={progress}
          understood={understood}
          onOpen={(lesson) => setActive({ lesson, transfer: false })}
        />
      ))}

      <div className="card">
        <strong>How progress is measured</strong>
        <p className="small muted" style={{ marginTop: 5 }}>
          Solving something after a hint is not counted as doing it on your own. The same idea comes back later in a
          different position. A single success is practice evidence, not mastery. Repeated independent recall and transfer
          are needed before a level suggestion. No numerical chess rating is assigned.
        </p>
      </div>
    </div>
  );
}

function StageBlock({
  stage,
  index,
  progress,
  understood,
  onOpen,
}: {
  stage: Stage;
  index: number;
  progress: LearnProgress;
  understood: string[];
  onOpen: (l: Lesson) => void;
}) {
  return (
    <section className={`stage ${stage.built ? "" : "stage--planned"}`}>
      <div className="stage__head">
        <span className="stage__n">{index}</span>
        <span className="stage__text">
          <span className="stage__t">{stage.name}</span>
          <span className="stage__b">{stage.blurb}</span>
        </span>
      </div>
      {!stage.built ? (
        <p className="emptynote">
          <strong>Not built yet.</strong> {stage.plannedNote}
        </p>
      ) : (
        <div className="lessonlist">
          {stage.lessons.map((lesson) => {
            const done = !!progress.lessons[lesson.id]?.completed;
            const unaided = !!progress.lessons[lesson.id]?.unaided;
            const unlocked = isLessonUnlocked(lesson, understood);
            return (
              <button
                key={lesson.id}
                className={`lessonrow ${done ? "lessonrow--done" : ""} ${unlocked ? "" : "lessonrow--early"}`}
                onClick={() => onOpen(lesson)}
              >
                <span
                  className={`lessonrow__badge ${done ? "lessonrow__badge--done" : ""} ${unlocked ? "" : "lessonrow__badge--lock"}`}
                  aria-hidden="true"
                >
                  {!unlocked ? "🔑" : done ? "✓" : "›"}
                </span>
                <span className="lessonrow__body">
                  <span className="lessonrow__title">{lesson.title}</span>
                  <span className="lessonrow__note">
                    {!unlocked
                      ? `Easier after ${conceptList(lesson.prerequisites)} — but you can try it now`
                      : done
                        ? unaided
                          ? "Done on your own"
                          : "Done with a hint — it will come back later"
                        : lesson.goal.kind === "read"
                          ? "Read and look"
                          : "One move to find"}
                  </span>
                </span>
                <span className="rowcard__chev" aria-hidden="true">›</span>
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ */

function LessonRunner({
  lesson,
  transfer,
  onClose,
  outOfOrder,
  onFinish,
  onTransfer,
}: {
  lesson: Lesson;
  outOfOrder: boolean;
  transfer: boolean;
  onClose: () => void;
  onFinish: (lessonId: string, concepts: string[], unaided: boolean, solveMs?: number) => void;
  onTransfer: () => void;
}) {
  const fen = (transfer ? lesson.transferFen : lesson.fen) ?? lesson.fen;
  const goal: LessonGoal = (transfer ? lesson.transferGoal : lesson.goal) ?? lesson.goal;

  const [position, setPosition] = useState<string>(fen ?? "");
  const [hintsUsed, setHintsUsed] = useState(0);
  /**
   * When the learner first saw this position. Used ONLY to measure unaided
   * thinking time. It restarts on reset, and a solve that used a hint is
   * never timed.
   */
  const shownAt = useRef<number>(Date.now());
  const [solved, setSolved] = useState(goal.kind === "read");
  const [feedback, setFeedback] = useState<string | null>(null);
  const [showSolution, setShowSolution] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const [repeated, setRepeated] = useState(false);
  const attemptId = useRef(crypto.randomUUID());
  const startFen = fen ?? "";
  const positionId = `${lesson.id}:${startFen}`;
  const previouslySeen = useRef(loadEvidence().some(a => a.fen.split(" ").slice(0,4).join(" ") === startFen.split(" ").slice(0,4).join(" ")));

  const view = useMemo(() => {
    try {
      return new Chess(position);
    } catch {
      return new Chess();
    }
  }, [position]);

  const getLegalTargets = useCallback(
    (from: Square) => view.moves({ verbose: true, square: from }).map((m) => m.to as Square),
    [view],
  );

  const isPromotionMove = useCallback(
    (from: Square, to: Square) =>
      view.moves({ verbose: true, square: from }).some((m) => m.to === to && m.promotion),
    [view],
  );

  const tryMove = useCallback(
    (from: Square, to: Square, promotion?: "q" | "r" | "b" | "n") => {
      if (attempted || (solved && goal.kind !== "read") || position !== startFen) return false;
      const res = checkMove(position, from, to, promotion, goal);
      if (res.reason === "illegal") {
        setFeedback("That piece cannot go there. Tap a piece to see its legal squares.");
        return false;
      }
      // the move is legal — play it so the learner SEES the consequence
      const c = new Chess(position);
      c.move({ from, to, promotion: promotion as never });
      setPosition(c.fen());
      setAttempted(true);
      const unaided = hintsUsed === 0 && !showSolution && !repeated && !previouslySeen.current;
      recordEvidence({ id: attemptId.current, lessonId: lesson.id, positionId, fen: startFen,
        concepts: lesson.concepts, dimension: transfer ? "transfer" : "move-choice",
        exerciseTier: difficultyForLesson(lesson.id), hintLevel: hintsUsed, revealed: showSolution,
        answer: `${from}${to}${promotion ?? ""}`, correct: res.ok, independent: unaided });
      if (res.ok) {
        setSolved(true);
        setFeedback(null);
        onFinish(lesson.id, lesson.concepts, unaided, Date.now() - shownAt.current);
      } else {
        setFeedback(friendly(res.reason));
      }
      return true;
    },
    [position, goal, solved, hintsUsed, showSolution, lesson, onFinish, attempted, startFen, repeated, positionId, transfer],
  );

  const reset = useCallback(() => {
    setPosition(startFen);
    setSolved(goal.kind === "read");
    setFeedback(null);
    setAttempted(false);
    setRepeated(true);
    attemptId.current = crypto.randomUUID();
    shownAt.current = Date.now();
  }, [startFen, goal.kind]);

  // A new lesson (or the transfer position) is a new problem: restart the clock.
  useEffect(() => {
    shownAt.current = Date.now();
  }, [lesson.id, transfer]);

  const askHint = (level: number) => {
    setHintsUsed(n => Math.max(n, level));
    recordEvidence({ id: `${attemptId.current}:hint:${level}`, lessonId: lesson.id, positionId, fen: startFen,
      concepts: lesson.concepts, dimension: transfer ? "transfer" : "move-choice", exerciseTier: difficultyForLesson(lesson.id),
      hintLevel: level, revealed: false, answer: "hint requested", correct: false, independent: false });
  };
  const solutions = useMemo(() => (startFen ? solutionMoves(startFen, goal) : []), [startFen, goal]);

  const showHighlights =
    showSolution && position === startFen && solutions[0]
      ? { suggestFrom: solutions[0].from, suggestTo: solutions[0].to }
      : {};

  return (
    <div className="stack">
      <div className="btnrow">
        <button className="btn btn--ghost btn--sm" onClick={onClose}>← All lessons</button>
        {transfer && <span className="pill pill--ok">Transfer test — same idea, new position</span>}
      </div>

      <div className="card">
        <h2 style={{ fontSize: "1.12rem" }}>{lesson.title}</h2>
        <p style={{ marginTop: 7 }}>{lesson.teach}</p>
      </div>

      {startFen && (
        <div>
          <Board
            fen={position}
            orientation="w"
            lastMove={null}
            getLegalTargets={getLegalTargets}
            isPromotionMove={isPromotionMove}
            tryMove={tryMove}
            canPickUp={color => !attempted && (!solved || goal.kind === "read") && color === new Chess(startFen).turn()}
            highlights={showHighlights}
          />
        </div>
      )}

      {outOfOrder && !solved && (
        <p className="pill pill--warn" style={{ whiteSpace: "normal" }}>
          You are taking this one early. Nothing is stopping you — if you solve it with no hint it counts just the
          same. It will simply make more sense after {conceptList(lesson.prerequisites)}.
        </p>
      )}

      {solved ? (
        <div className="card" style={{ borderColor: "var(--success)" }}>
          <strong>{goal.kind === "read" ? "What to notice" : "Well done"}</strong>
          <p style={{ marginTop: 6 }}>{lesson.afterSuccess}</p>
          {lesson.trick && (
            <p className="trick">
              <span className="trick__label">Remember</span>
              <span className="trick__text">{lesson.trick}</span>
            </p>
          )}
          {hintsUsed > 0 || showSolution || repeated || previouslySeen.current ? (
            <p className="small muted" style={{ marginTop: 8 }}>
              This was helped or repeated practice, not independent evidence. Try a different position later.
            </p>
          ) : (
            goal.kind !== "read" && (
              <p className="small" style={{ marginTop: 8, color: "var(--success)" }}>
                You did this one entirely on your own.
              </p>
            )
          )}
          <div className="btnrow" style={{ marginTop: 12 }}>
            {lesson.transferFen && !transfer && (
              <button className="btn btn--primary" onClick={onTransfer}>Try a similar idea →</button>
            )}
            <button className="btn" onClick={onClose}>Back to lessons</button>
            {goal.kind !== "read" && <button className="btn btn--ghost" onClick={reset}>Try again</button>}
          </div>
        </div>
      ) : (
        <div className="card">
          <strong>Your turn</strong>
          {feedback && (
            <p className="threatline threatline--calm" style={{ marginTop: 8 }}>
              <em aria-hidden="true">💡</em>
              <span>{feedback}</span>
            </p>
          )}
          {attempted && <button className="btn" onClick={reset}>Reset exercise — try from the original position</button>}
          <div className="tiers" style={{ marginTop: 10 }}>
            {lesson.hints.map((h, i) => {
              const shown = i < hintsUsed;
              return (
                <button
                  key={i}
                  className={`tier ${shown ? "tier--revealed" : ""}`}
                  onClick={() => askHint(i + 1)}
                  disabled={shown}
                >
                  <span className="tier__n">{i + 1}</span>
                  <span>{shown ? h : `Clue ${i + 1}`}</span>
                </button>
              );
            })}
            {lesson.trick && (
              <button
                className={`tier ${hintsUsed >= lesson.hints.length ? "tier--revealed" : ""}`}
                onClick={() => askHint(lesson.hints.length)}
                disabled={hintsUsed >= lesson.hints.length}
              >
                <span className="tier__n">💡</span>
                <span>{hintsUsed >= lesson.hints.length ? lesson.trick : "The idea behind it"}</span>
              </button>
            )}
            {solutions.length > 0 && (
              <button
                className={`tier ${showSolution ? "tier--revealed" : ""}`}
                onClick={() => { setShowSolution(true); recordEvidence({ id: `${attemptId.current}:reveal`, lessonId: lesson.id,
                  positionId, fen: startFen, concepts: lesson.concepts, dimension: transfer ? "transfer" : "move-choice",
                  exerciseTier: difficultyForLesson(lesson.id), hintLevel: 4, revealed: true, answer: "revealed", correct: false, independent: false }); }}
                disabled={showSolution}
              >
                <span className="tier__n">★</span>
                <span>{showSolution ? "Shown on the board" : "Show me the answer"}</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function friendly(reason: string): string {
  switch (reason) {
    case "notThatMove":
      return "That is a legal move, just not the one this lesson is about. Look at the goal again and try another.";
    case "notACapture":
      return "That move does not capture anything. Which of your pieces can reach a black piece?";
    case "notSafe":
      return "That capture can be answered — the other side takes back and you come out worse. Look for the defender first.";
    case "noMate":
      return "Good try, but the king can still escape. Which square would take away every escape?";
    case "noCheck":
      return "That move does not attack the king. Find a square where your piece hits the king directly.";
    case "stillMated":
      return "That is legal, but the mate is still there — they can play it next move. What exactly are they threatening, and what would take it away?";
    case "losesMaterial":
      return "That move can be punished: they have a reply that wins material and you cannot win it back. Which of your pieces is attacked right now?";
    default:
      return "Try another move.";
  }
}
