/**
 * The numbers behind the Home and Brain screens.
 *
 * HONESTY RULES (these are the whole point of this file):
 *  - Every number here is DERIVED from things the learner actually did.
 *    Nothing is seeded, simulated or rounded up to look better.
 *  - The "brain score" is a transparent formula, printed in the UI, not a
 *    mysterious rating.
 *  - Below `MIN_EVIDENCE` finished lessons we return `enoughData: false` and
 *    the UI must say "Not enough data yet" instead of drawing a bar.
 *  - A skill area with no built lessons reports `built: 0` so the UI can say
 *    "no lessons yet" rather than showing an empty bar that looks like failure.
 */

import { STAGES, isLessonUnlocked, type Lesson } from "./journey";
import { dayKey, type LearnProgress, type SolveTime } from "./progress";

export const MIN_EVIDENCE = 3;

/** Points are a plain, published formula — see `SCORE_EXPLANATION`. */
export const POINTS_UNAIDED = 40;
export const POINTS_WITH_HELP = 15;
export const SCORE_EXPLANATION = `${POINTS_UNAIDED} points for every lesson you solved with no help, ${POINTS_WITH_HELP} for every lesson you finished with a hint. Nothing is ever taken away.`;

export type SkillArea = {
  id: string;
  name: string;
  /** Plain-language description of what this area means. */
  about: string;
  concepts: string[];
};

/**
 * Areas are defined by the concepts our lessons actually teach, so the bars
 * can never claim knowledge we never tested.
 */
export const SKILL_AREAS: SkillArea[] = [
  {
    id: "moves",
    name: "Piece moves",
    about: "How each piece travels and captures.",
    concepts: ["orientation", "turns", "pawnMoves", "knightMoves", "bishopMoves", "rookMoves", "queenMoves", "capturing"],
  },
  {
    id: "tactics",
    name: "Tactics",
    about: "Spotting free material and forcing moves.",
    concepts: ["safeCapture", "hangingPiece", "forcingMoves", "threats", "fork", "pin", "skewer", "doubleAttack"],
  },
  {
    id: "defense",
    name: "Defence",
    about: "Keeping your king and your pieces safe.",
    concepts: ["check", "kingSafety", "pieceSafety", "defenders", "stalemate", "luft", "stalemateTrap", "prophylaxis"],
  },
  {
    id: "mating",
    name: "Checkmate",
    about: "Finishing the game off.",
    concepts: ["checkmate", "backRank", "cutOff", "rookTechnique"],
  },
  {
    id: "opening",
    name: "Opening ideas",
    about: "Getting your pieces out and taking the middle.",
    concepts: ["development", "center"],
  },
  {
    id: "calculation",
    name: "Calculation",
    about: "Working out what happens after a trade, and using an idea in a new position.",
    concepts: ["trades", "transfer", "candidates", "counting", "forcingOrder", "pieceActivity", "passedPawn"],
  },
];

export type AreaScore = {
  id: string;
  name: string;
  about: string;
  /** the lesson to open when the learner taps this skill, or null if none is
   *  open to them yet — the UI must then say so rather than dead-ending */
  practiceLessonId: string | null;
  practiceLessonTitle: string | null;
  practiceLocked: boolean;
  /** lessons built in this area */
  built: number;
  /** lessons in this area finished at all */
  done: number;
  /** lessons in this area solved with no help */
  unaided: number;
  /** 0-100, unaided out of built. Only meaningful when `built > 0`. */
  percent: number;
};

export type Insights = {
  enoughData: boolean;
  /** number of lessons with at least one finished attempt */
  lessonsDone: number;
  lessonsUnaided: number;
  lessonsBuilt: number;
  score: number;
  /** consecutive days up to today (or yesterday, so one late night is not punished) */
  streak: number;
  /** lessons finished only with help — they come back for review */
  reviewsDue: number;
  reviewLessons: Lesson[];
  areas: AreaScore[];
  /** one short, true sentence for the home screen */
  headline: string;
};

function builtLessons(): Lesson[] {
  return STAGES.filter((s) => s.built).flatMap((s) => s.lessons);
}

/**
 * Consecutive practice days ending today or yesterday.
 * Missing a day simply ends the streak; it never subtracts anything earned.
 */
export function currentStreak(days: string[], today: string = dayKey()): number {
  if (days.length === 0) return 0;
  const set = new Set(days);
  const cursor = new Date(`${today}T12:00:00`);
  if (!set.has(today)) {
    cursor.setDate(cursor.getDate() - 1);
    if (!set.has(dayKey(cursor))) return 0; // nothing today or yesterday
  }
  let n = 0;
  for (;;) {
    if (!set.has(dayKey(cursor))) break;
    n += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return n;
}

export function computeInsights(p: LearnProgress, today: string = dayKey()): Insights {
  const lessons = builtLessons();
  const records = Object.entries(p.lessons);

  const lessonsDone = records.length;
  const lessonsUnaided = records.filter(([, r]) => r.unaidedSuccesses > 0).length;
  const helpedOnly = records.filter(([, r]) => r.unaidedSuccesses === 0 && r.completed).length;

  const reviewLessons = lessons.filter((l) => {
    const r = p.lessons[l.id];
    return !!r && r.completed && r.unaidedSuccesses === 0;
  });

  const areas: AreaScore[] = SKILL_AREAS.map((area) => {
    const inArea = lessons.filter((l) => l.concepts.some((c) => area.concepts.includes(c)));
    const done = inArea.filter((l) => p.lessons[l.id]?.completed).length;
    const unaided = inArea.filter((l) => (p.lessons[l.id]?.unaidedSuccesses ?? 0) > 0).length;

    // Tapping a skill must land on a REAL lesson. Prefer one not yet solved
    // alone; fall back to the first lesson so the card is never a dead end.
    const openInArea = inArea.filter((l) => isLessonUnlocked(l, p.concepts));
    const target =
      openInArea.find((l) => (p.lessons[l.id]?.unaidedSuccesses ?? 0) === 0) ?? openInArea[0] ?? null;

    return {
      id: area.id,
      name: area.name,
      about: area.about,
      practiceLessonId: target?.id ?? null,
      practiceLessonTitle: target?.title ?? null,
      practiceLocked: inArea.length > 0 && openInArea.length === 0,
      built: inArea.length,
      done,
      unaided,
      percent: inArea.length === 0 ? 0 : Math.round((unaided / inArea.length) * 100),
    };
  });

  const score = lessonsUnaided * POINTS_UNAIDED + helpedOnly * POINTS_WITH_HELP;
  const enoughData = lessonsDone >= MIN_EVIDENCE;

  let headline: string;
  if (lessonsDone === 0) {
    headline = "You have not started a lesson yet. The first one takes about a minute.";
  } else if (!enoughData) {
    headline = `You have finished ${lessonsDone} ${lessonsDone === 1 ? "lesson" : "lessons"}. Not enough data yet to say what you are good at.`;
  } else if (lessonsUnaided === 0) {
    headline = `You finished ${lessonsDone} lessons, all with a hint so far. That is a normal start.`;
  } else {
    headline = `You solved ${lessonsUnaided} of ${lessonsDone} lessons with no help at all.`;
  }

  return {
    enoughData,
    lessonsDone,
    lessonsUnaided,
    lessonsBuilt: lessons.length,
    score,
    streak: currentStreak(p.days, today),
    reviewsDue: reviewLessons.length,
    reviewLessons,
    areas,
    headline,
  };
}

export type ImprovementReport = {
  enough: boolean;
  /** lessons solved with no help in the last 7 days */
  solvedAlone: number;
  /** lessons practised at all in the last 7 days */
  practised: number;
  /** names of the skill areas that gained an unaided success this week */
  areasImproved: string[];
  line: string;
};

/**
 * "This week" in real terms. If nothing happened we say "Not enough practice
 * yet" — we never invent "3 concepts improved".
 */
export function improvementReport(p: LearnProgress, now: Date = new Date()): ImprovementReport {
  const cutoff = now.getTime() - 7 * 24 * 60 * 60 * 1000;
  const recent = Object.entries(p.lessons).filter(([, r]) => {
    const t = Date.parse(r.lastAt);
    return Number.isFinite(t) && t >= cutoff;
  });
  const solvedAlone = recent.filter(([, r]) => r.lastUnaided === true).length;
  const lessons = builtLessons();
  const areasImproved = SKILL_AREAS.filter((area) =>
    recent.some(([id, r]) => {
      if (r.lastUnaided !== true) return false;
      const lesson = lessons.find((l) => l.id === id);
      return !!lesson && lesson.concepts.some((c) => area.concepts.includes(c));
    }),
  ).map((a) => a.name);

  if (recent.length === 0) {
    return {
      enough: false,
      solvedAlone: 0,
      practised: 0,
      areasImproved: [],
      line: "No practice logged this week yet. One lesson is enough to start a report.",
    };
  }
  return {
    enough: true,
    solvedAlone,
    practised: recent.length,
    areasImproved,
    line:
      solvedAlone === 0
        ? `You practised ${recent.length} ${recent.length === 1 ? "lesson" : "lessons"} this week. No latest unaided success is recorded for these attempts.`
        : `You solved ${solvedAlone} ${solvedAlone === 1 ? "lesson" : "lessons"} with no help this week${areasImproved.length ? `, in ${areasImproved.join(" and ")}` : ""}.`,
  };
}

/* ------------------------------------------------------------------ */
/* Thinking speed — measured, never guessed                            */
/* ------------------------------------------------------------------ */

/**
 * We will not show a speed trend until there are this many unaided solves in
 * an area. Three "before" samples and three "after" samples is the smallest
 * honest comparison; anything less is noise.
 */
export const MIN_SPEED_SAMPLES = 6;

/** Below this the two halves are the same within noise, so we say so. */
export const SPEED_NOISE = 0.12;

export type SpeedTrend = {
  id: string;
  name: string;
  samples: number;
  /** average of the FIRST half, in seconds */
  beforeSec: number;
  /** average of the LAST half, in seconds */
  afterSec: number;
  direction: "faster" | "slower" | "same";
  /** a whole sentence the UI can print as-is */
  line: string;
};

export type SpeedReport = {
  enough: boolean;
  totalSamples: number;
  /** how many more unaided solves are needed before anything can be shown */
  needed: number;
  trends: SpeedTrend[];
  line: string;
};

function mean(xs: number[]): number {
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

const round1 = (ms: number) => Math.round(ms / 100) / 10;

function trendFor(id: string, name: string, samples: SolveTime[]): SpeedTrend | null {
  if (samples.length < MIN_SPEED_SAMPLES) return null;
  const half = Math.floor(samples.length / 2);
  const before = mean(samples.slice(0, half).map((s) => s.ms));
  const after = mean(samples.slice(-half).map((s) => s.ms));
  const beforeSec = round1(before);
  const afterSec = round1(after);
  const change = (before - after) / before;

  let direction: SpeedTrend["direction"] = "same";
  if (change > SPEED_NOISE) direction = "faster";
  else if (change < -SPEED_NOISE) direction = "slower";

  const line =
    direction === "faster"
      ? `${name}: ${beforeSec}s → ${afterSec}s`
      : direction === "slower"
        ? `${name}: ${beforeSec}s → ${afterSec}s (different problems or conditions may affect time)`
        : `${name}: about ${afterSec}s, steady`;

  return { id, name, samples: samples.length, beforeSec, afterSec, direction, line };
}

/**
 * How the learner's thinking time is changing, from REAL measurements only.
 *
 * Every sample is one unaided solve, timed from the moment the position
 * appeared. Hinted solves are never timed. Under MIN_SPEED_SAMPLES in an area
 * we show nothing for that area and say how many more are needed.
 */
export function speedReport(p: LearnProgress): SpeedReport {
  const all = p.solveTimes ?? [];
  const lessons = builtLessons();
  const byId = new Map(lessons.map((l) => [l.id, l]));

  const trends: SpeedTrend[] = [];
  for (const area of SKILL_AREAS) {
    const inArea = all.filter((t) => {
      const lesson = byId.get(t.id);
      return !!lesson && lesson.concepts.some((c) => area.concepts.includes(c));
    });
    const trend = trendFor(area.id, area.name, inArea);
    if (trend) trends.push(trend);
  }

  const overall = trendFor("all", "Overall", all);
  if (overall) trends.unshift(overall);

  if (all.length < MIN_SPEED_SAMPLES) {
    return {
      enough: false,
      totalSamples: all.length,
      needed: MIN_SPEED_SAMPLES - all.length,
      trends: [],
      line:
        all.length === 0
          ? "Your thinking time starts being measured the first time you solve a lesson with no hint."
          : `${MIN_SPEED_SAMPLES - all.length} more unaided ${MIN_SPEED_SAMPLES - all.length === 1 ? "solve" : "solves"} and a real trend appears.`,
    };
  }

  return {
    enough: true,
    totalSamples: all.length,
    needed: 0,
    trends,
    line: `Measured from ${all.length} solves where you used no hint at all.`,
  };
}

/** "Good morning" / "Good afternoon" / "Good evening" from the device clock. */
export function greeting(d: Date = new Date()): string {
  const h = d.getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}
