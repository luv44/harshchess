import { useCallback, useEffect, useState } from "react";
import PlayScreen from "./play/PlayScreen";
import Onboarding, { type OnboardingResult } from "./play/Onboarding";
import LearnJourney from "./learn/LearnJourney";
import { useStockfishSetting } from "./engine/stockfishSetting";
import TrainScreen from "./train/TrainScreen";
import ReviewScreen from "./review/ReviewScreen";
import HomeScreen from "./home/HomeScreen";
import BrainScreen from "./brain/BrainScreen";
import { useChessGame } from "./chess/useChessGame";
import { useLanguage } from "./i18n/useLanguage";
import { LanguagePicker } from "./i18n/LanguagePicker";
import { AccountPage } from "./billing/AccountPage";
import { LearnPage } from "./coach/LearnPage";
import { SalesPage, StatusPage } from "./pages/LegacyPages";
import { hasCoachWording } from "./coach/coachText";
import { getLanguage } from "./i18n/languages";
import DifficultyPanel from "./learn/DifficultyPanel";
import "./styles/discovery.css";

type Tab = "home" | "train" | "games" | "brain";
type SettingsPage = "menu" | "sales" | "account" | "status" | "lab";

const ONBOARD_KEY = "chessworkermind:onboarded:v2";
const BEGINNER_KEY = "chessworkermind:beginner:v1";
const PIECE_HINT_KEY = "chessworkermind:pieceHints:v1";

const TABS: Array<{ id: Tab; label: string; icon: string }> = [
  { id: "home", label: "Home", icon: "⌂" },
  { id: "train", label: "Train", icon: "♟" },
  { id: "games", label: "Games", icon: "♞" },
  { id: "brain", label: "Progress", icon: "◈" },
];

function useOnline() {
  const [online, setOnline] = useState<boolean>(typeof navigator !== "undefined" ? navigator.onLine : true);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  return online;
}

export default function App() {
  const [tab, setTab] = useState<Tab>("home");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsPage, setSettingsPage] = useState<SettingsPage>("menu");
  const [openLessonId, setOpenLessonId] = useState<string | null>(null);
  // Train shows the guided game by default; the lesson list is one tap away.
  const [trainView, setTrainView] = useState<"guided" | "lessons">("guided");
  // The Games tab holds the free game and the game reviewer.
  const [gamesView, setGamesView] = useState<"play" | "review">("play");
  const game = useChessGame();
  const { tag, setTag, level, setLevel } = useLanguage();
  const online = useOnline();
  const [stockfishOn, setStockfishOn] = useStockfishSetting();
  const [installPrompt, setInstallPrompt] = useState<unknown>(null);

  const [showOnboarding, setShowOnboarding] = useState<boolean>(() => {
    try {
      return localStorage.getItem(ONBOARD_KEY) !== "1";
    } catch {
      return true;
    }
  });
  const [beginner, setBeginner] = useState<boolean>(() => {
    try {
      return localStorage.getItem(BEGINNER_KEY) !== "0";
    } catch {
      return true;
    }
  });

  useEffect(() => {
    const h = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
    };
    window.addEventListener("beforeinstallprompt" as never, h as never);
    return () => window.removeEventListener("beforeinstallprompt" as never, h as never);
  }, []);

  const doInstall = useCallback(async () => {
    const e = installPrompt as { prompt: () => Promise<void>; userChoice?: Promise<{ outcome: string }> } | null;
    if (!e) return;
    try {
      await e.prompt();
      await e.userChoice;
    } catch {
      /* ignore */
    }
    setInstallPrompt(null);
  }, [installPrompt]);

  const finishOnboarding = useCallback(
    (r: OnboardingResult) => {
      game.startGame(r.mode, r.humanSide);
      setBeginner(r.beginner);
      try {
        localStorage.setItem(ONBOARD_KEY, "1");
        localStorage.setItem(BEGINNER_KEY, r.beginner ? "1" : "0");
      } catch {
        /* ignore */
      }
      setShowOnboarding(false);
      setTab("games");
    },
    [game],
  );

  const skipOnboarding = useCallback(() => {
    try {
      localStorage.setItem(ONBOARD_KEY, "1");
    } catch {
      /* ignore */
    }
    setShowOnboarding(false);
  }, []);

  /** Open the lesson list (optionally straight into one lesson). */
  const goTrain = useCallback((lessonId?: string) => {
    setOpenLessonId(lessonId ?? null);
    setTrainView("lessons");
    setSettingsOpen(false);
    setTab("train");
  }, []);

  /** Open the guided "What's your move?" game. */
  const goGuided = useCallback(() => {
    setOpenLessonId(null);
    setTrainView("guided");
    setSettingsOpen(false);
    setTab("train");
  }, []);

  const goTab = useCallback((next: Tab) => {
    setSettingsOpen(false);
    if (next !== "train") {
      setOpenLessonId(null);
      setTrainView("guided");
    }
    if (next !== "games") setGamesView("play");
    setTab(next);
  }, []);

  const langName = getLanguage(tag)?.nameOwn ?? tag;

  useEffect(() => {
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
  }, [tab, settingsOpen, trainView, gamesView]);

  return (
    <div className="appshell">
      <a className="skip-link" href="#main">Skip to the board</a>

      <header className="topbar" role="banner">
        <div className="topbar__brand">
          <span className="topbar__name">Chessworkermind</span>
          <span className="topbar__tag">A brighter thinker tomorrow</span>
        </div>
        <div className="topbar__spacer" />
        {!online && <span className="pill pill--warn">Offline</span>}
        <button
          className="iconbtn"
          onClick={() => {
            setSettingsOpen(true);
            setSettingsPage("menu");
          }}
          aria-label="Settings and language"
          aria-expanded={settingsOpen}
        >
          ⚙
        </button>
      </header>

      <main id="main" className="screen">
        {tag !== "en" && <p className="pill pill--warn" style={{whiteSpace:"normal"}}>Partial translation: some coaching and lesson text is in English. Chess coordinates stay unchanged. Choose English in Settings for a consistent interface.</p>}
        {settingsOpen ? (
          <SettingsSection
            stockfishOn={stockfishOn}
            setStockfishOn={setStockfishOn}
            page={settingsPage}
            setPage={setSettingsPage}
            onClose={() => setSettingsOpen(false)}
            tag={tag}
            setTag={setTag}
            level={level}
            setLevel={setLevel}
            online={online}
            canInstall={!!installPrompt}
            onInstall={doInstall}
            onPlay={() => goTab("games")}
            onRestartTour={() => {
              setSettingsOpen(false);
              setShowOnboarding(true);
              setTab("games");
            }}
            langName={langName}
          />
        ) : (
          <>
            {tab === "home" && (
              <HomeScreen
                onTrain={goTrain}
                onGuided={goGuided}
                onPlay={() => goTab("games")}
                onBrain={() => goTab("brain")}
                savedGameMoves={game.historySan.length}
                onResume={() => goTab("games")}
              />
            )}

            {tab === "train" &&
              (trainView === "guided" ? (
                <TrainScreen
                  game={game}
                  tag={tag}
                  online={online}
                  onOpenLessons={() => setTrainView("lessons")}
                />
              ) : (
                <LearnJourney
                  openLessonId={openLessonId}
                  onBackToGuided={() => {
                    setOpenLessonId(null);
                    setTrainView("guided");
                  }}
                />
              ))}

            {tab === "games" &&
              (gamesView === "review" ? (
                <ReviewScreen
                  tag={tag}
                  currentPgn={game.pgn}
                  currentMoveCount={game.historySan.length}
                  currentHumanSide={game.humanSide}
                  onBack={() => setGamesView("play")}
                />
              ) : (
                <>
                  <PlayScreen
                    game={game}
                    tag={tag}
                    wording={level === "deeper" ? "deeper" : "beginner"}
                    beginner={beginner}
                    onOpenLearn={() => goTrain()}
                  />
                  <button
                    className="rowcard"
                    style={{ marginTop: 14 }}
                    onClick={() => setGamesView("review")}
                  >
                    <span className="rowcard__icon" aria-hidden="true">🔎</span>
                    <span className="rowcard__body">
                      <span className="rowcard__kicker">Review a game</span>
                      <span className="rowcard__title">
                        Walk through this game, or paste another one, and see the moments the coach can prove were
                        costly
                      </span>
                    </span>
                    <span className="rowcard__chev" aria-hidden="true">›</span>
                  </button>
                </>
              ))}

            {tab === "brain" && (
              <BrainScreen
                onTrain={(lessonId) => goTrain(lessonId)}
                onPlay={() => { setGamesView("play"); setTab("games"); }}
                onReview={() => { setGamesView("review"); setTab("games"); }}
              />
            )}
          </>
        )}
      </main>

      <nav className="bottomnav" aria-label="Main">
        {TABS.map((t) => (
          <button
            key={t.id}
            className="bottomnav__btn"
            aria-current={!settingsOpen && tab === t.id ? "page" : undefined}
            onClick={() => goTab(t.id)}
          >
            <em aria-hidden="true">{t.icon}</em>
            {t.label}
          </button>
        ))}
      </nav>

      {showOnboarding && <Onboarding onDone={finishOnboarding} onSkip={skipOnboarding} />}
    </div>
  );
}

function SettingsSection({
  stockfishOn,
  setStockfishOn,
  page,
  setPage,
  onClose,
  tag,
  setTag,
  level,
  setLevel,
  online,
  canInstall,
  onInstall,
  onPlay,
  onRestartTour,
  langName,
}: {
  stockfishOn: boolean;
  setStockfishOn: (on: boolean) => void;
  page: SettingsPage;
  setPage: (p: SettingsPage) => void;
  onClose: () => void;
  tag: string;
  setTag: (t: string) => void;
  level: "beginner" | "deeper";
  setLevel: (l: "beginner" | "deeper") => void;
  online: boolean;
  canInstall: boolean;
  onInstall: () => void;
  onPlay: () => void;
  onRestartTour: () => void;
  langName: string;
}) {
  const [pieceHints, setPieceHintsState] = useState<boolean>(() => {
    try {
      return localStorage.getItem(PIECE_HINT_KEY) !== "0";
    } catch {
      return true;
    }
  });
  const togglePieceHints = (on: boolean) => {
    setPieceHintsState(on);
    try {
      localStorage.setItem(PIECE_HINT_KEY, on ? "1" : "0");
    } catch {
      /* ignore */
    }
  };

  if (page !== "menu") {
    return (
      <div className="stack">
        <button className="btn btn--ghost btn--sm" style={{ alignSelf: "flex-start" }} onClick={() => setPage("menu")}>
          ← Back
        </button>
        {page === "sales" && <SalesPage onPlay={onPlay} canInstall={canInstall} onInstall={onInstall} />}
        {page === "account" && <AccountPage />}
        {page === "status" && <StatusPage tag={tag} canInstall={canInstall} onInstall={onInstall} />}
        {page === "lab" && (
          <>
            <p className="emptynote">
              Coach lab — the technical view of the learner model, ranked exercises and FactPackets from the
              previous milestone. Kept for inspection; the friendly version is the Train tab.
            </p>
            <LearnPage tag={tag} setTag={setTag} level={level} setLevel={setLevel} />
          </>
        )}
      </div>
    );
  }

  return (
    <div className="stack">
      <div className="screenhead" style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <button className="btn btn--ghost btn--sm" onClick={onClose}>← Back</button>
        <h1 className="screenhead__hi" style={{ fontSize: "1.4rem", margin: 0 }}>Settings</h1>
      </div>

      <DifficultyPanel />
      <div className="card">
        <h2 style={{ fontSize: "1.05rem" }}>On the board</h2>
        <div style={{ marginTop: 12 }}>
          <div className="csec__label">Piece tips</div>
          <p className="small muted" style={{ marginTop: 4 }}>
            When this is on, tapping one of your pieces shows a short line under the board saying how it moves. It
            never covers the board and it never blocks your turn.
          </p>
          <div className="seg" role="group" aria-label="Piece tips" style={{ marginTop: 8 }}>
            <button className="seg__btn" aria-pressed={pieceHints} onClick={() => togglePieceHints(true)}>
              Show tips
            </button>
            <button className="seg__btn" aria-pressed={!pieceHints} onClick={() => togglePieceHints(false)}>
              Off
            </button>
          </div>
        </div>
        <div style={{ marginTop: 16 }}>
          <div className="csec__label">Deeper checking with Stockfish</div>
          <p className="small muted" style={{ marginTop: 4 }}>
            Off by default. Turning it on downloads about 1.7 MB once and uses more battery. The coach works fully
            without it — every suggestion is checked on the real board either way, and the engine is only ever
            allowed to reorder moves the app has already verified.
          </p>
          <div className="seg" role="group" aria-label="Stockfish engine" style={{ marginTop: 8 }}>
            <button className="seg__btn" aria-pressed={stockfishOn} onClick={() => setStockfishOn(true)}>
              Use the engine
            </button>
            <button className="seg__btn" aria-pressed={!stockfishOn} onClick={() => setStockfishOn(false)}>
              Rules only
            </button>
          </div>
        </div>

        <div style={{ marginTop: 16 }}>
          <div className="csec__label">How much detail the coach gives</div>
          <div className="seg" role="group" aria-label="Wording level" style={{ marginTop: 8 }}>
            <button className="seg__btn" aria-pressed={level === "beginner"} onClick={() => setLevel("beginner")}>
              Very simple
            </button>
            <button className="seg__btn" aria-pressed={level === "deeper"} onClick={() => setLevel("deeper")}>
              More detail
            </button>
          </div>
        </div>
      </div>

      <div className="card">
        <h2 style={{ fontSize: "1.05rem" }}>Language</h2>
        <p className="small muted" style={{ marginTop: 4 }}>
          Choose how you want to learn. Your choice is remembered on this device.
        </p>
        <div style={{ marginTop: 10 }}>
          <LanguagePicker value={tag} onChange={setTag} />
        </div>
        {!hasCoachWording(tag) && (
          <p className="pill pill--warn" style={{ marginTop: 10, whiteSpace: "normal" }}>
            The interface is available in {langName}, but the coach's move explanations are not written in{" "}
            {langName} yet — they will be shown in English with a notice, never silently. Written coach wording:
            English, हिन्दी, Español (MX), العربية, Français.
          </p>
        )}
      </div>

      <div className="card">
        <h2 style={{ fontSize: "1.05rem" }}>App</h2>
        <div className="stack" style={{ marginTop: 10 }}>
          <button className="btn" onClick={onRestartTour}>🌱 Show the welcome screen again</button>
          {canInstall ? (
            <button className="btn btn--primary" onClick={onInstall}>⬇ Install Chessworkermind</button>
          ) : (
            <div className="emptynote">
              <strong>Add to Home Screen (optional)</strong>
              <br />
              iPhone Safari: Share → Add to Home Screen. Android Chrome: Menu → Install app. Desktop: the install
              icon in the address bar. Everything works in the browser without installing.
            </div>
          )}
          <p className="small muted">
            {online
              ? "Online. Saved games live in this browser. Account sync is a local test adapter, not a connected cloud service."
              : "Offline — the board and your saved game still work. Sync and purchase need a connection."}
          </p>
        </div>
      </div>

      <div className="card">
        <h2 style={{ fontSize: "1.05rem" }}>More</h2>
        <div className="stack" style={{ marginTop: 10 }}>
          <button className="btn" onClick={() => setPage("sales")}>About Chessworkermind &amp; Free/Pro</button>
          <button className="btn" onClick={() => setPage("account")}>Account &amp; billing</button>
          <button className="btn" onClick={() => setPage("status")}>Build status &amp; honest feature list</button>
          <button className="btn btn--ghost" onClick={() => setPage("lab")}>Coach lab (technical view)</button>
        </div>
      </div>

      <footer className="card" style={{ textAlign: "center" }}>
        <p className="small muted">Chessworkermind — learn how to think, not just what move to play.</p>
        <p className="small muted" style={{ marginTop: 6 }}>
          No ads in this release. Pro checkout is disabled until it is fully tested.
        </p>
      </footer>
    </div>
  );
}
