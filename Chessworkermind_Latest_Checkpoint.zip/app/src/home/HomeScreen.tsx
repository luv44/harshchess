import { useMemo } from "react";
import { computeInsights, greeting } from "../learn/insights";
import { lessonForTier, useDifficulty } from "../learn/difficulty";
import { loadProgress } from "../learn/progress";
import { allBuiltLessons, isLessonUnlocked } from "../learn/journey";

type Props = {
  onTrain: (lessonId?: string) => void;
  /** open the guided "What's your move?" game */
  onGuided: () => void;
  onPlay: () => void;
  onBrain: () => void;
  /** how many moves are in the game currently saved on this device */
  savedGameMoves: number;
  onResume: () => void;
};

/**
 * The first screen. Everything on it is a real number taken from what the
 * learner has actually done — there is no demo data. When nothing has been
 * done yet, the screen says so in plain words instead of showing zeros that
 * look like failure.
 */
export default function HomeScreen({ onTrain, onGuided, onPlay, onBrain, savedGameMoves, onResume }: Props) {
  const progress = useMemo(() => loadProgress(), []);
  const [difficulty] = useDifficulty();
  const insights = useMemo(() => computeInsights(progress), [progress]);

  // The next lesson is the first unlocked one that has not been solved unaided.
  const nextLesson = useMemo(() => {
    const lessons = allBuiltLessons();
    const selected = lessonForTier(difficulty.learning);
    if (difficulty.mode === "manual" || !progress.lessons[selected.id]?.completed) return selected;
    return (
      lessons.find(
        (l) => isLessonUnlocked(l, progress.concepts) && (progress.lessons[l.id]?.unaidedSuccesses ?? 0) === 0,
      ) ?? null
    );
  }, [progress, difficulty]);

  const reviewLesson = insights.reviewLessons[0] ?? null;

  return (
    <div className="homepage">
      <div className="screenhead homepage__full">
        <h1 className="screenhead__hi">{greeting()}.</h1>
        <p className={`screenhead__sub ${insights.lessonsDone === 0 ? "screenhead__sub--muted" : ""}`}>
          {insights.headline}
        </p>
      </div>

      <section className="herocard">
        <div className="herocard__eyebrow">
          {nextLesson ? "Today's training · about 2 min" : "Today's training"}
        </div>
        <h2 className="herocard__title">{nextLesson ? nextLesson.title : "You have finished every built lesson"}</h2>
        <p className="herocard__goal">
          {nextLesson
            ? nextLesson.teach.split(". ")[0] + "."
            : "Revisit a lesson in a different position or review your own game. Finishing lessons is not proof of mastery."}
        </p>
        <button className="herocard__cta" onClick={() => onTrain(nextLesson?.id)}>
          {nextLesson ? "Start training" : "Open the lesson list"} ›
        </button>
      </section>

      <div className="tiles">
        <div className="tile">
          <div className="tile__icon" aria-hidden="true">🔥</div>
          <div className={insights.streak > 0 ? "tile__num" : "tile__num tile__num--small"}>
            {insights.streak > 0 ? `${insights.streak}-day` : "Not yet"}
          </div>
          <div className="tile__label">practice streak</div>
        </div>
        <div className="tile">
          <div className="tile__icon" aria-hidden="true">📄</div>
          <div className="tile__num">{insights.reviewsDue}</div>
          <div className="tile__label">to review</div>
        </div>
        <button className="tile" onClick={onBrain} aria-label="Open your Chess Brain page">
          <div className="tile__icon" aria-hidden="true">◈</div>
          <div className={insights.enoughData ? "tile__num" : "tile__num tile__num--small"}>
            {insights.lessonsUnaided}
          </div>
          <div className="tile__label">lessons solved without help</div>
        </button>
      </div>

      {!insights.enoughData && (
        <p className="small muted" style={{ margin: "10px 4px 0" }}>
          Practice counts are not a chess rating. Independent recall in different positions is needed before an improvement claim.
        </p>
      )}

      {savedGameMoves > 0 && (
        <button className="rowcard" onClick={onResume}>
          <span className="rowcard__icon" aria-hidden="true">♟</span>
          <span className="rowcard__body">
            <span className="rowcard__kicker">Your saved game</span>
            <span className="rowcard__title">
              {savedGameMoves} {savedGameMoves === 1 ? "move" : "moves"} played — carry on where you stopped
            </span>
          </span>
          <span className="rowcard__chev" aria-hidden="true">›</span>
        </button>
      )}

      {reviewLesson && (
        <button className="rowcard" onClick={() => onTrain(reviewLesson.id)}>
          <span className="rowcard__icon" aria-hidden="true">🔁</span>
          <span className="rowcard__body">
            <span className="rowcard__kicker">Come back to this</span>
            <span className="rowcard__title">
              {reviewLesson.title} — you solved it with a hint, so it is worth one more try
            </span>
          </span>
          <span className="rowcard__chev" aria-hidden="true">›</span>
        </button>
      )}

      <button className="rowcard" onClick={onGuided}>
        <span className="rowcard__icon" aria-hidden="true">?</span>
        <span className="rowcard__body">
          <span className="rowcard__kicker">What's your move?</span>
          <span className="rowcard__title">
            A guided game: the computer moves once, the coach explains it, then you choose
          </span>
        </span>
        <span className="rowcard__chev" aria-hidden="true">›</span>
      </button>

      <button className="rowcard" onClick={onPlay}>
        <span className="rowcard__icon" aria-hidden="true">♞</span>
        <span className="rowcard__body">
          <span className="rowcard__kicker">Free game</span>
          <span className="rowcard__title">Just play, with the full coach card beside the board</span>
        </span>
        <span className="rowcard__chev" aria-hidden="true">›</span>
      </button>

      <p className="quote">“A sharper you, one day at a time.”</p>
    </div>
  );
}
