import { useMemo } from "react";
import {
  computeInsights,
  improvementReport,
  MIN_EVIDENCE,
} from "../learn/insights";
import { loadProgress } from "../learn/progress";
import EvidencePanel from "../learn/EvidencePanel";
import { allBuiltLessons, isLessonUnlocked, unbuiltStagesSentence } from "../learn/journey";

/** Monochrome glyphs only. Emoji render in their own colours and fight the
 *  palette — the shield, book and abacus were bright blue, brown and red. */
const AREA_ICON: Record<string, string> = {
  moves: "♟",
  tactics: "✦",
  defense: "◈",
  mating: "♚",
  opening: "◇",
  calculation: "∑",
};

/**
 * PROGRESS — "Chess Brain" (screen 4 of the design).
 *
 * Nothing here is a made-up rating. The score is a published formula, every
 * skill card is "lessons you solved with no help ÷ lessons that exist in that
 * area", the weekly report only counts real attempts from the last 7 days,
 * and tapping a skill opens a real lesson.
 */
export default function BrainScreen({
  onTrain,
  onPlay,
  onReview,
}: {
  onTrain: (lessonId?: string) => void;
  onPlay: () => void;
  onReview: () => void;
}) {
  const progress = useMemo(() => loadProgress(), []);
  const insights = useMemo(() => computeInsights(progress), [progress]);
  const report = useMemo(() => improvementReport(progress), [progress]);


  /** The lesson the main button should actually open — the same one Home
   *  offers, so the two screens never disagree about what is next. */
  const nextLesson = useMemo(
    () =>
      allBuiltLessons().find(
        (l) => isLessonUnlocked(l, progress.concepts) && (progress.lessons[l.id]?.unaidedSuccesses ?? 0) === 0,
      ) ?? null,
    [progress],
  );

  return (
    <div className="brainpage">
      <div className="screenhead brainpage__full">
        <h1 className="screenhead__hi">Your chess brain</h1>
        <p className="screenhead__sub screenhead__sub--muted">{insights.headline}</p>
      </div>

      <section className="brainhero">
        <div className="brainhero__badge" aria-hidden="true">♞</div>
        <div className="brainhero__name">Chess Brain</div>
        {insights.enoughData ? (
          <>
            <div className="brainhero__score">{insights.lessonsUnaided} lessons</div>
            <p className="brainhero__note">Solved without hints in your saved summary. This counts practice, not intelligence or chess strength. Repeated independent transfer is still needed.</p>
          </>
        ) : (
          <>
            <div className="brainhero__score brainhero__score--none">Not enough practice yet</div>
            {/* Show the distance to the first score as something you can see
                filling up, rather than only as a sentence. */}
            <div
              className="brainhero__meter"
              role="img"
              aria-label={`${insights.lessonsDone} of ${MIN_EVIDENCE} lessons in your first practice set`}
            >
              {Array.from({ length: MIN_EVIDENCE }, (_, i) => (
                <span key={i} className={`brainhero__pip ${i < insights.lessonsDone ? "is-done" : ""}`} />
              ))}
            </div>
            <p className="brainhero__note">
              {MIN_EVIDENCE - insights.lessonsDone} more{" "}
              {MIN_EVIDENCE - insights.lessonsDone === 1 ? "lesson" : "lessons"} in your first practice set. A completed set is not a mastery score.
            </p>
          </>
        )}
        <button
          className="btn btn--primary btn--big brainhero__cta"
          onClick={() => onTrain(nextLesson?.id)}
        >
          {insights.lessonsDone === 0 ? "Start your first lesson" : "Carry on training"}
        </button>
        {nextLesson && <p className="brainhero__next">Next: {nextLesson.title}</p>}
      </section>

      {/* Three things you can actually do from here. */}
      <nav className="quickrow brainpage__full" aria-label="What next">
        <button className="quickbtn" onClick={() => onTrain()}>
          <span className="quickbtn__icon" aria-hidden="true">♟</span>
          <span className="quickbtn__label">Train</span>
          <span className="quickbtn__sub">Guided game</span>
        </button>
        <button className="quickbtn" onClick={onPlay}>
          <span className="quickbtn__icon" aria-hidden="true">♞</span>
          <span className="quickbtn__label">Play</span>
          <span className="quickbtn__sub">Free game</span>
        </button>
        <button className="quickbtn" onClick={onReview}>
          <span className="quickbtn__icon" aria-hidden="true">◎</span>
          <span className="quickbtn__label">Review</span>
          <span className="quickbtn__sub">A finished game</span>
        </button>
      </nav>

      <h2 className="brainpage__full" style={{ fontSize: "1.05rem", margin: "22px 4px 0" }}>Your skills</h2>
      <p className="small muted brainpage__full" style={{ margin: "4px 4px 0" }}>
        Each card counts only the lessons you solved <strong>with no hint</strong>. Tap one to practise it.
      </p>

      <div className="skillgrid">
        {insights.areas.map((a) => {
          const hasData = a.unaided > 0;
          return (
            <button
              key={a.id}
              className="skillcard"
              onClick={() => onTrain(a.practiceLessonId ?? undefined)}
              disabled={a.built === 0}
              aria-label={
                a.built === 0
                  ? `${a.name}: no lessons built yet`
                  : `${a.name}: ${a.unaided} of ${a.built} lessons solved without help. Practise ${a.practiceLessonTitle ?? "a lesson"}.`
              }
            >
              <span className="skillcard__top">
                <span className="skillcard__icon" aria-hidden="true">{AREA_ICON[a.id] ?? "•"}</span>
                <span className="skillcard__name">{a.name}</span>
              </span>
              {a.built === 0 ? (
                <span className="skillcard__val skillcard__val--none">No lessons built yet</span>
              ) : hasData ? (
                <span className="skillcard__val">
                  {a.unaided}
                  <span className="skillcard__of">/{a.built}</span>
                </span>
              ) : (
                <span className="skillcard__val skillcard__val--empty" aria-label="no practice yet">
                  —
                </span>
              )}
              {hasData && (
                <span className="bar__track" aria-hidden="true">
                  <span className="bar__fill" style={{ width: `${a.percent}%` }} />
                </span>
              )}
              <span className="skillcard__sub">
                {a.built === 0
                  ? a.about
                  : a.practiceLocked
                    ? "Earlier lessons open this one"
                    : hasData
                      ? `Next: ${a.practiceLessonTitle}`
                      : `Start with: ${a.practiceLessonTitle}`}
              </span>
              {a.built > 0 && (
                <span className="skillcard__go" aria-hidden="true">
                  Practise <span className="skillcard__arrow">→</span>
                </span>
              )}
            </button>
          );
        })}
      </div>

      <EvidencePanel onPractice={onTrain} />

      <div className="card" style={{ marginTop: 16 }}>
        <h3 style={{ fontSize: "1rem" }}>This week's report</h3>
        <p className="small" style={{ marginTop: 8, lineHeight: 1.6 }}>{report.line}</p>

        <dl className="statrow">
          <div className="statrow__item">
            <dt>Finished</dt>
            <dd>
              {insights.lessonsDone}
              <span className="statrow__of">/{insights.lessonsBuilt}</span>
            </dd>
          </div>
          <div className="statrow__item">
            <dt>With no help</dt>
            <dd>{insights.lessonsUnaided}</dd>
          </div>
          <div className="statrow__item">
            <dt>To review</dt>
            <dd>{insights.reviewsDue}</dd>
          </div>
        </dl>

        <button className="btn btn--primary" style={{ marginTop: 12 }} onClick={() => onTrain()}>
          Go to training
        </button>
      </div>


      <details className="card disclaimer" style={{ marginTop: 12 }}>
        <summary className="disclaimer__toggle">What this page does not claim</summary>
        <ul className="small muted" style={{ marginTop: 8, paddingInlineStart: 18, lineHeight: 1.6 }}>
          <li>This is not an Elo rating and it does not predict tournament results.</li>
          <li>{unbuiltStagesSentence()}</li>
          <li>Thinking speed is measured only inside lessons, only on unaided solves, and only from the moment the position appeared. It is not measured during a normal game.</li>
          <li>A faster time is not proof of understanding on its own — the problems are not all the same difficulty.</li>
          <li>Saved attempts are preserved. No overall numerical chess rating is assigned.</li>
        </ul>
      </details>
    </div>
  );
}
