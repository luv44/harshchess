/**
 * "This knight jumps in an L shape" — one short line per piece, plus ONE
 * practice move. Never a wall of text.
 *
 * Practice positions are plain FENs with a single clear task. They are checked
 * for legality by unit test, so a lesson can never ask for an illegal move.
 */

export type PiecePractice = {
  fen: string;
  /** The move the learner should find. */
  from: string;
  to: string;
  /** Short task line, localized below. */
  taskKey: string;
};

export type PieceHelp = {
  type: "p" | "n" | "b" | "r" | "q" | "k";
  practice: PiecePractice;
};

export const PIECE_HELP: Record<string, PieceHelp> = {
  p: {
    type: "p",
    practice: { fen: "7k/8/8/3p4/4P3/8/8/4K3 w - - 0 1", from: "e4", to: "d5", taskKey: "pawnTask" },
  },
  n: {
    type: "n",
    practice: { fen: "7k/8/8/8/8/5p2/8/4K1N1 w - - 0 1", from: "g1", to: "f3", taskKey: "knightTask" },
  },
  b: {
    type: "b",
    practice: { fen: "7k/8/8/6p1/8/8/8/2B1K3 w - - 0 1", from: "c1", to: "g5", taskKey: "bishopTask" },
  },
  r: {
    type: "r",
    practice: { fen: "7k/p7/8/8/8/8/8/R3K3 w - - 0 1", from: "a1", to: "a7", taskKey: "rookTask" },
  },
  q: {
    type: "q",
    practice: { fen: "7k/3p4/8/8/8/8/8/3QK3 w - - 0 1", from: "d1", to: "d7", taskKey: "queenTask" },
  },
  k: {
    type: "k",
    practice: { fen: "7k/8/8/8/8/8/8/4K3 w - - 0 1", from: "e1", to: "e2", taskKey: "kingTask" },
  },
};

type HelpPack = {
  role: Record<string, string>;
  task: Record<string, string>;
  tryIt: string;
  done: string;
  moves: string;
};

const PACKS: Record<string, HelpPack> = {
  en: {
    role: {
      p: "This pawn walks forward one square, but captures diagonally. It never goes backwards.",
      n: "This knight jumps in an L shape: two squares one way, then one square across. It can jump over pieces.",
      b: "This bishop slides along diagonals only. It stays on its own colour for the whole game.",
      r: "This rook slides in straight lines: up, down, left or right, as far as it likes.",
      q: "This queen is the strongest piece. It slides in straight lines AND diagonals.",
      k: "This king moves one square in any direction. Keep it safe — if it cannot escape an attack, the game ends.",
    },
    task: {
      pawnTask: "Capture the black pawn with your pawn. Pawns take diagonally.",
      knightTask: "Capture the black pawn with your knight using an L-shaped jump.",
      bishopTask: "Slide your bishop along the diagonal and capture the pawn.",
      rookTask: "Slide your rook up the file and capture the pawn.",
      queenTask: "Use the queen's straight line to capture the pawn.",
      kingTask: "Move your king one square forward.",
    },
    tryIt: "Try one move",
    done: "Nice — that is exactly how it moves.",
    moves: "Legal squares are marked on the board.",
  },
  hi: {
    role: {
      p: "यह प्यादा एक कदम आगे चलता है, पर तिरछा काटता है। यह कभी पीछे नहीं जाता।",
      n: "यह घोड़ा 'L' आकार में कूदता है: दो घर एक ओर, फिर एक घर बगल में। यह ऊपर से कूद सकता है।",
      b: "यह ऊँट सिर्फ तिरछी लाइनों पर चलता है और पूरे खेल में अपने ही रंग पर रहता है।",
      r: "यह हाथी सीधी लाइनों में चलता है: ऊपर, नीचे, बाएँ या दाएँ, जितना चाहे।",
      q: "यह वज़ीर सबसे ताकतवर मोहरा है। यह सीधी और तिरछी दोनों लाइनों पर चलता है।",
      k: "यह राजा किसी भी दिशा में एक घर चलता है। इसे सुरक्षित रखें — अगर यह हमले से नहीं बच सका, खेल खत्म।",
    },
    task: {
      pawnTask: "अपने प्यादे से काले प्यादे को काटें। प्यादे तिरछा काटते हैं।",
      knightTask: "अपने घोड़े से 'L' कूद लगाकर काले प्यादे को काटें।",
      bishopTask: "अपने ऊँट को तिरछी लाइन पर ले जाकर प्यादा काटें।",
      rookTask: "अपने हाथी को सीधी लाइन में ले जाकर प्यादा काटें।",
      queenTask: "वज़ीर की सीधी लाइन से प्यादा काटें।",
      kingTask: "अपने राजा को एक घर आगे ले जाएँ।",
    },
    tryIt: "एक चाल आज़माएँ",
    done: "बढ़िया — यह बिल्कुल ऐसे ही चलता है।",
    moves: "वैध घर बोर्ड पर दिखाए गए हैं।",
  },
  "es-MX": {
    role: {
      p: "Este peón avanza una casilla, pero captura en diagonal. Nunca retrocede.",
      n: "Este caballo salta en forma de L: dos casillas en una dirección y una de lado. Puede saltar piezas.",
      b: "Este alfil se mueve solo en diagonal. Se queda en su color toda la partida.",
      r: "Esta torre se mueve en línea recta: arriba, abajo, izquierda o derecha.",
      q: "Esta dama es la pieza más fuerte. Se mueve en líneas rectas Y en diagonal.",
      k: "Este rey mueve una casilla en cualquier dirección. Protégelo: si no puede escapar, la partida termina.",
    },
    task: {
      pawnTask: "Captura el peón negro con tu peón. Los peones capturan en diagonal.",
      knightTask: "Captura el peón negro con tu caballo usando un salto en L.",
      bishopTask: "Mueve el alfil por la diagonal y captura el peón.",
      rookTask: "Mueve la torre por la columna y captura el peón.",
      queenTask: "Usa la línea recta de la dama para capturar el peón.",
      kingTask: "Mueve tu rey una casilla adelante.",
    },
    tryIt: "Prueba una jugada",
    done: "Muy bien — así se mueve exactamente.",
    moves: "Las casillas legales están marcadas en el tablero.",
  },
  ar: {
    role: {
      p: "هذا البيدق يتقدّم مربعاً واحداً، لكنه يأخذ قطرياً. ولا يعود إلى الخلف أبداً.",
      n: "هذا الحصان يقفز على شكل حرف L: مربعان في اتجاه ثم مربع جانبي. ويستطيع القفز فوق القطع.",
      b: "هذا الفيل يتحرك على الأقطار فقط، ويبقى على لونه طوال المباراة.",
      r: "هذا الرخ يتحرك في خطوط مستقيمة: أعلى، أسفل، يمين أو يسار.",
      q: "هذا الوزير أقوى قطعة. يتحرك في الخطوط المستقيمة والأقطار معاً.",
      k: "هذا الملك يتحرك مربعاً واحداً في أي اتجاه. احمِه — إذا لم يستطع الهرب انتهت المباراة.",
    },
    task: {
      pawnTask: "خذ بيدق الخصم ببيدقك. البيادق تأخذ قطرياً.",
      knightTask: "خذ البيدق بحصانك بقفزة على شكل L.",
      bishopTask: "حرّك الفيل على القطر وخذ البيدق.",
      rookTask: "حرّك الرخ على العمود وخذ البيدق.",
      queenTask: "استخدم خط الوزير المستقيم لأخذ البيدق.",
      kingTask: "حرّك ملكك مربعاً واحداً إلى الأمام.",
    },
    tryIt: "جرّب نقلة واحدة",
    done: "ممتاز — هكذا يتحرك تماماً.",
    moves: "المربعات القانونية معلّمة على الرقعة.",
  },
  fr: {
    role: {
      p: "Ce pion avance d'une case, mais capture en diagonale. Il ne recule jamais.",
      n: "Ce cavalier saute en L : deux cases dans un sens, puis une de côté. Il peut sauter par-dessus les pièces.",
      b: "Ce fou se déplace uniquement en diagonale. Il reste sur sa couleur toute la partie.",
      r: "Cette tour se déplace en ligne droite : haut, bas, gauche ou droite.",
      q: "Cette dame est la pièce la plus forte. Elle va en ligne droite ET en diagonale.",
      k: "Ce roi avance d'une case dans toutes les directions. Protège-le : s'il ne peut plus fuir, la partie est finie.",
    },
    task: {
      pawnTask: "Capture le pion noir avec ton pion. Les pions prennent en diagonale.",
      knightTask: "Capture le pion noir avec ton cavalier par un saut en L.",
      bishopTask: "Fais glisser ton fou sur la diagonale et prends le pion.",
      rookTask: "Fais glisser ta tour sur la colonne et prends le pion.",
      queenTask: "Utilise la ligne droite de la dame pour prendre le pion.",
      kingTask: "Avance ton roi d'une case.",
    },
    tryIt: "Essaie un coup",
    done: "Bravo — c'est exactement comme ça qu'il bouge.",
    moves: "Les cases légales sont marquées sur l'échiquier.",
  },
};

export function helpPack(tag: string): HelpPack {
  return PACKS[tag] ?? PACKS.en;
}

export function pieceRole(tag: string, type: string): string {
  return helpPack(tag).role[type] ?? helpPack("en").role[type] ?? "";
}

export function practiceTask(tag: string, key: string): string {
  return helpPack(tag).task[key] ?? helpPack("en").task[key] ?? "";
}
