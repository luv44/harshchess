/**
 * The one line to carry away from a coach card.
 *
 * The lessons each end with a "Remember" line, and learners told us that is
 * the part that sticks. The coach card was five sections of prose with no
 * such line — so the same idea is applied here, keyed to the reason the
 * coach actually gave. Same voice as the lesson tricks, deliberately.
 *
 * There is a trick for every ReasonKey. If a new reason is added without
 * one, `coachTrick` returns null and the UI simply shows nothing rather
 * than inventing advice.
 */
import type { ReasonKey } from "./coachCard";

const TRICKS: Record<ReasonKey, string> = {
  mate: "Mate is check with nowhere to go — always look for it first.",
  escapeCheck: "Check is not a suggestion. Move, block, or take.",
  savesPiece: "Every turn, first ask what they can take from you.",
  safeCapture: "Before anything else, look for a piece of theirs that is undefended.",
  defendsPiece: "A piece with no defender is a piece you are about to lose.",
  castleSafety: "Get the king tucked away before you start anything.",
  develops: "Knights before bishops, and get out before you attack.",
  controlsCenter: "The middle squares reach everywhere — take them early.",
  safeIdea: "When nothing is forced, make a quiet move that loses nothing.",
};

export function coachTrick(key: ReasonKey | undefined | null): string | null {
  if (!key) return null;
  return TRICKS[key] ?? null;
}

export const COACH_TRICK_KEYS = Object.keys(TRICKS) as ReasonKey[];


/* ------------------------------------------------------------------ */
/* The same idea for the move reviewer, which uses its own reason set  */
/* ------------------------------------------------------------------ */

import type { CandidateReasonKey } from "./reviewMove";

const CANDIDATE_TRICKS: Record<CandidateReasonKey, string> = {
  winsMaterial: "A free piece is worth more than a clever plan. Take it.",
  savesPiece: "Move the piece that is attacked before you start anything else.",
  escapeCheck: "Check is not a suggestion. Move, block, or take.",
  givesMate: "Mate is check with nowhere to go — always look for it first.",
  develops: "Knights before bishops, and get out before you attack.",
  controlsCentre: "The middle squares reach everywhere — take them early.",
  keepsEverythingDefended: "A quiet move that loses nothing is never a bad move.",
};

export function candidateTrick(key: CandidateReasonKey | undefined | null): string | null {
  if (!key) return null;
  return CANDIDATE_TRICKS[key] ?? null;
}

export const CANDIDATE_TRICK_KEYS = Object.keys(CANDIDATE_TRICKS) as CandidateReasonKey[];
