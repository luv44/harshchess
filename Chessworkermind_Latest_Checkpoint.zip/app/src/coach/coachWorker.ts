/**
 * Coach worker — builds the Coach card off the main thread.
 *
 * The board must stay responsive on a phone, so all verification work
 * (capture search, threat detection, candidate ranking) happens here.
 * Every reply carries the exact FEN + positionId it was computed for, so the
 * UI can throw away stale results after a move, undo, new game or mode switch.
 */

import { buildCoachCard, type CoachCard, type RawMove } from "./coachCard";

export type CoachRequest = {
  type: "build";
  fen: string;
  positionId: number;
  humanSide: "w" | "b";
  lastMove?: RawMove | null;
  engineCandidates?: Array<{ uci: string; scoreCp?: number; scoreMate?: number }>;
};

export type CoachResponse =
  | { type: "card"; positionId: number; fen: string; card: CoachCard; ms: number }
  | { type: "error"; positionId: number; fen: string; message: string };

self.onmessage = (e: MessageEvent<CoachRequest>) => {
  const req = e.data;
  if (!req || req.type !== "build") return;
  const started = Date.now();
  try {
    const card = buildCoachCard({
      fen: req.fen,
      positionId: req.positionId,
      humanSide: req.humanSide,
      lastMove: req.lastMove ?? null,
      engineCandidates: req.engineCandidates,
    });
    const res: CoachResponse = {
      type: "card",
      positionId: req.positionId,
      fen: req.fen,
      card,
      ms: Date.now() - started,
    };
    (self as unknown as Worker).postMessage(res);
  } catch (err) {
    const res: CoachResponse = {
      type: "error",
      positionId: req.positionId,
      fen: req.fen,
      message: String((err as Error)?.message ?? err),
    };
    (self as unknown as Worker).postMessage(res);
  }
};
