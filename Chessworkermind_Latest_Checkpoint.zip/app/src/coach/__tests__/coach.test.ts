import { describe, it, expect } from "vitest";
import { Chess } from "chess.js";
import {
  findThreat,
  hangingPieces,
  isLegal,
  legalMoves,
  nullMoveFen,
  safeCaptures,
  scoreMoves,
} from "../localAnalysis";
import type { ReasonKey } from "../coachCard";
import { buildCoachCard, cardStillValid, chooseSuggestion } from "../coachCard";
import { renderCoachCard, hasCoachWording } from "../coachText";

const START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
/** After 1.e4 e5 2.Bc4 Nc6 3.Qh5 — Black to move, White really threatens Qxf7#. */
const SCHOLAR = "r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 3 3";
/** White queen on d5 is attacked by the e6 pawn and undefended. */
const HANGING_QUEEN = "rnbqkbnr/pppp1ppp/4p3/3Q4/8/8/PPPP1PPP/RNB1KBNR w KQkq - 0 1";
/** Back-rank mate in one: Ra8#. */
const MATE_IN_1 = "6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1";
/** White is in check from the bishop on b4. */
const IN_CHECK = "rnbqk1nr/pppp1ppp/8/4p3/1b2P3/8/PPP1PPPP/RNBQKBNR w KQkq - 0 1";

describe("verified board facts (no invention)", () => {
  it("knows the 20 legal opening moves", () => {
    expect(legalMoves(START)).toHaveLength(20);
  });

  it("reports NO threat in a calm opening position", () => {
    expect(findThreat(START)).toBeNull();
  });

  it("finds a real mate threat and proves it by replay", () => {
    const t = findThreat(SCHOLAR);
    expect(t).not.toBeNull();
    expect(t!.kind).toBe("mate");
    expect(t!.to).toBe("f7");
    // the claimed move must actually be legal and actually be mate
    const c = new Chess(t!.threatFen);
    const played = c.move(t!.san);
    expect(played).toBeTruthy();
    expect(c.isCheckmate()).toBe(true);
  });

  it("sees a hanging queen and values it honestly", () => {
    const loose = hangingPieces(HANGING_QUEEN, "w");
    expect(loose.length).toBeGreaterThan(0);
    expect(loose[0].square).toBe("d5");
    expect(loose[0].type).toBe("q");
    expect(loose[0].loss).toBeGreaterThan(500);
  });

  it("treats an existing check as an immediate threat, not a guess", () => {
    const t = findThreat(IN_CHECK);
    expect(t).not.toBeNull();
    expect(t!.kind).toBe("check");
    expect(t!.immediate).toBe(true);
  });

  it("refuses to null-move out of a check (illegal pass)", () => {
    expect(nullMoveFen(IN_CHECK)).toBeNull();
    expect(nullMoveFen(START)).not.toBeNull();
  });

  it("only lists captures that do not lose material", () => {
    // 1.e4 d5 — exd5 is a free pawn, verified by the capture search
    const fen = "rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 2";
    const caps = safeCaptures(fen);
    expect(caps.some((m) => m.from === "e4" && m.to === "d5")).toBe(true);
  });

  it("does not offer a capture that simply hangs the piece", () => {
    // White queen can take the b7 pawn but the bishop on c8 recaptures for free.
    const fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    const caps = safeCaptures(fen);
    expect(caps).toHaveLength(0); // no captures exist at all in the start position
  });
});

describe("the suggested move is always legal and never speculative", () => {
  const positions = [START, SCHOLAR, HANGING_QUEEN, MATE_IN_1, IN_CHECK];

  it("produces a legal suggestion for every tested position", () => {
    for (const fen of positions) {
      const picked = chooseSuggestion(fen);
      expect(picked, `no suggestion for ${fen}`).not.toBeNull();
      const s = picked!.suggestion;
      expect(isLegal(fen, s.from, s.to, s.promotion), `illegal suggestion ${s.san} in ${fen}`).toBe(true);
    }
  });

  it("finds the forced mate and calls it mate", () => {
    const picked = chooseSuggestion(MATE_IN_1)!;
    expect(picked.suggestion.isMate).toBe(true);
    expect(picked.reason.key).toBe("mate");
    const c = new Chess(MATE_IN_1);
    c.move(picked.suggestion.san);
    expect(c.isCheckmate()).toBe(true);
  });

  it("rescues a hanging queen instead of ignoring it", () => {
    const picked = chooseSuggestion(HANGING_QUEEN)!;
    expect(["savesPiece", "defendsPiece", "safeCapture"]).toContain(picked.reason.key);
    // after the suggested move the queen must no longer be losable for free
    const c = new Chess(HANGING_QUEEN);
    c.move({ from: picked.suggestion.from, to: picked.suggestion.to });
    const after = hangingPieces(c.fen(), "w");
    expect(after.some((h) => h.type === "q" && h.loss > 500)).toBe(false);
  });

  it("gets out of check when in check", () => {
    const picked = chooseSuggestion(IN_CHECK)!;
    const c = new Chess(IN_CHECK);
    c.move(picked.suggestion.san);
    expect(c.isCheck()).toBe(false); // our own king is no longer attacked
  });

  it("does not hard-code the same pawn push for every position", () => {
    const sans = positions.map((f) => chooseSuggestion(f)!.suggestion.san);
    expect(new Set(sans).size).toBeGreaterThan(1);
  });

  it("only uses engine candidates after re-checking them for legality", () => {
    const bogus = [{ uci: "e2e9" }, { uci: "a1a8" }]; // both illegal in the start position
    const picked = chooseSuggestion(START, bogus)!;
    expect(isLegal(START, picked.suggestion.from, picked.suggestion.to)).toBe(true);
    expect(picked.suggestion.source).toBe("local"); // engine input was rejected, said honestly
  });
});

describe("the whole Coach card", () => {
  it("builds five verified sections for the opening position", () => {
    const card = buildCoachCard({ fen: START, positionId: 1, humanSide: "w" });
    expect(card.abstained).toBe(false);
    expect(card.threat.present).toBe(false); // honest: no drama invented
    expect(card.suggestion).not.toBeNull();
    expect(card.reason).not.toBeNull();
    expect(card.future!.lines.length).toBeGreaterThan(0);
    expect(card.practice).not.toBeNull();
  });

  it("every conditional continuation it shows is legal", () => {
    for (const fen of [START, SCHOLAR, HANGING_QUEEN]) {
      const card = buildCoachCard({ fen, positionId: 1, humanSide: fen === SCHOLAR ? "b" : "w" });
      const s = card.suggestion!;
      const c = new Chess(fen);
      c.move({ from: s.from, to: s.to, promotion: s.promotion as never });
      for (const line of card.future!.lines) {
        const sim = new Chess(c.fen());
        const played = sim.move(line.theirMove.san);
        expect(played, `illegal opponent line ${line.theirMove.san}`).toBeTruthy();
        if (line.ourReply) {
          const reply = sim.move(line.ourReply.san);
          expect(reply, `illegal follow-up ${line.ourReply.san}`).toBeTruthy();
        }
      }
    }
  });

  it("describes what the opponent actually just did", () => {
    const c = new Chess();
    c.move("e4");
    c.move("e5");
    c.move("Bc4");
    c.move("Nc6");
    c.move("Qh5");
    const card = buildCoachCard({ fen: c.fen(), positionId: 2, humanSide: "b", history: c });
    expect(card.opponentMove!.from).toBe("d1");
    expect(card.opponentMove!.to).toBe("h5");
    expect(card.opponentMove!.pieceType).toBe("q");
    expect(card.threat.present).toBe(true);
    expect(card.threat.threat!.kind).toBe("mate");
  });

  it("is frozen to one exact position and invalidated when the board changes", () => {
    const card = buildCoachCard({ fen: START, positionId: 1, humanSide: "w" });
    expect(cardStillValid(card, START)).toBe(true);
    const moved = new Chess(START);
    moved.move("e4");
    expect(cardStillValid(card, moved.fen())).toBe(false);
  });

  it("reports the end of the game instead of suggesting a move", () => {
    const c = new Chess(MATE_IN_1);
    c.move("Ra8#");
    const card = buildCoachCard({ fen: c.fen(), positionId: 3, humanSide: "w", history: c });
    expect(card.gameOver!.kind).toBe("checkmate");
    expect(card.gameOver!.winner).toBe("w");
    expect(card.suggestion).toBeNull();
  });

  it("handles promotion and en passant positions without breaking", () => {
    const promo = "8/4P3/8/8/8/8/4k3/4K3 w - - 0 1";
    const card = buildCoachCard({ fen: promo, positionId: 4, humanSide: "w" });
    expect(card.suggestion).not.toBeNull();
    expect(isLegal(promo, card.suggestion!.from, card.suggestion!.to, card.suggestion!.promotion)).toBe(true);

    const ep = "rnbqkbnr/ppp1p1pp/8/3pPp2/8/8/PPPP1PPP/RNBQKBNR w KQkq f6 0 3";
    const epCard = buildCoachCard({ fen: ep, positionId: 5, humanSide: "w" });
    expect(epCard.suggestion).not.toBeNull();
    expect(isLegal(ep, epCard.suggestion!.from, epCard.suggestion!.to, epCard.suggestion!.promotion)).toBe(true);
  });

  it("survives a nonsense FEN by abstaining, not by guessing", () => {
    const card = buildCoachCard({ fen: "not-a-fen", positionId: 6, humanSide: "w" });
    expect(card.abstained).toBe(true);
    expect(card.suggestion).toBeNull();
  });
});

describe("plain-language rendering keeps chess facts identical", () => {
  const card = buildCoachCard({ fen: HANGING_QUEEN, positionId: 1, humanSide: "w" });

  it("writes beginner English with real square names", () => {
    const r = renderCoachCard(card, "en");
    expect(r.s2Line).toMatch(/[a-h][1-8]/);
    expect(r.s2Line).toContain(card.suggestion!.from);
    expect(r.s2Line).toContain(card.suggestion!.to);
    expect(r.moveForMeLabel).toBe("Move it for me");
  });

  it("keeps the same squares in Hindi and Arabic", () => {
    for (const tag of ["hi", "ar", "es-MX", "fr"]) {
      const r = renderCoachCard(card, tag);
      expect(r.s2Line, tag).toContain(card.suggestion!.from);
      expect(r.s2Line, tag).toContain(card.suggestion!.to);
      expect(r.fallbackNotice, tag).toBeUndefined();
    }
  });

  it("says out loud when coach wording is missing instead of silently using English", () => {
    expect(hasCoachWording("ja")).toBe(false);
    const r = renderCoachCard(card, "ja", "beginner", "日本語");
    expect(r.fallbackNotice).toBeTruthy();
    expect(r.s2Line).toContain(card.suggestion!.to);
  });

  it("shows one line for beginners and more for the deeper setting", () => {
    const beginner = renderCoachCard(card, "en", "beginner");
    const deeper = renderCoachCard(card, "en", "deeper");
    expect(beginner.s4Lines.length).toBeLessThanOrEqual(1);
    expect(deeper.s4Lines.length).toBeGreaterThanOrEqual(beginner.s4Lines.length);
  });

  it("says 'nothing is in danger' when that is the truth", () => {
    const calm = buildCoachCard({ fen: START, positionId: 1, humanSide: "w" });
    const r = renderCoachCard(calm, "en");
    expect(r.threatIsReal).toBe(false);
    expect(r.threatLine.toLowerCase()).toContain("calm");
  });
});

describe("performance guard — the phone must not freeze", () => {
  it("scores a full middlegame position quickly", () => {
    const mid = "r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/2N2N2/PPPP1PPP/R1BQK2R w KQkq - 0 1";
    const t0 = Date.now();
    const moves = scoreMoves(mid);
    const ms = Date.now() - t0;
    expect(moves.length).toBeGreaterThan(20);
    expect(ms).toBeLessThan(4000);
  });
});

describe("the coach card ends with something you can remember", () => {
  it("has a trick for every reason the coach can give", async () => {
    const { coachTrick, COACH_TRICK_KEYS } = await import("../coachTrick");
    const reasons: ReasonKey[] = [
      "mate", "escapeCheck", "savesPiece", "safeCapture",
      "defendsPiece", "castleSafety", "develops", "controlsCenter", "safeIdea",
    ];
    // every reason the card can carry must have a line
    for (const r of reasons) {
      const t = coachTrick(r);
      expect(t, `no trick for ${r}`).toBeTruthy();
      expect(t!.length).toBeGreaterThan(20);
      expect(t!.length).toBeLessThanOrEqual(110);
    }
    expect(new Set(COACH_TRICK_KEYS)).toEqual(new Set(reasons));
  });

  it("says nothing rather than inventing a line for an unknown reason", async () => {
    const { coachTrick } = await import("../coachTrick");
    expect(coachTrick(undefined)).toBeNull();
    expect(coachTrick(null)).toBeNull();
    expect(coachTrick("somethingNew" as ReasonKey)).toBeNull();
  });

  it("the trick matches the reason actually chosen for a real position", async () => {
    const { coachTrick } = await import("../coachTrick");
    const card = buildCoachCard({
      fen: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
      positionId: 1,
      humanSide: "w",
    });
    expect(card.reason).not.toBeNull();
    const t = coachTrick(card.reason!.key);
    expect(t, "a real card must produce a real trick").toBeTruthy();
  });
});

describe("the coach card does not dump five sections at once", () => {
  it("folds why / what next / try it yourself behind one control", async () => {
    const { readFileSync } = await import("node:fs");
    const { resolve } = await import("node:path");
    const view = readFileSync(resolve(__dirname, "../../play/CoachCardView.tsx"), "utf8");

    const foldAt = view.indexOf("<details className=\"coachmore\"");
    expect(foldAt).toBeGreaterThan(0);

    // ABOVE the fold there is one idea and nothing else: the situation in a
    // line, the move, the trick, and the two buttons.
    const idea = view.slice(0, foldAt);
    expect(idea).toMatch(/idea__status/);
    expect(idea).toMatch(/idea__move/);
    expect(idea).toMatch(/trick__text/);
    expect(idea).toMatch(/showMeLabel/);
    expect(idea).toMatch(/moveForMeLabel/);

    // every numbered section, including the detail of 1 and 2, is INSIDE
    const fold = view.slice(foldAt);
    for (const t of ["s1Title", "s2Title", "s3Title", "s4Title", "s5Title"]) {
      expect(fold, `${t} should be inside the fold`).toMatch(new RegExp(`\\{text\\.${t}\\}`));
    }

    // the long caveats must not be shouted before the answer
    expect(idea).not.toMatch(/You do not have to play this/);
  });
});

describe("regression: a threat has two shapes, and the type now says so", () => {
  it("an existing check is NOT a playable move, and is flagged as such", async () => {
    const { findThreat, threatIsReplayable } = await import("../localAnalysis");
    // White to move and already in check from the queen on a1.
    const fen = "rnb1k1n1/pQp2p1r/8/4p2p/2PPpP1P/5N2/3NBP2/q2K3R w - - 0 21";
    const t = findThreat(fen)!;

    expect(t.immediate).toBe(true);
    expect(t.kind).toBe("check");
    expect(threatIsReplayable(t), "an existing check is not a move you can play").toBe(false);

    // The old doc comment promised this would be legal. It never was: you
    // cannot capture a king, and it is not even the attacker's turn.
    const probe = new Chess(t.threatFen);
    expect(() => probe.move({ from: t.from, to: t.to })).toThrow();

    // What it DOES describe correctly: the attacker and our king.
    const board = new Chess(fen);
    expect(board.get(t.from)!.color).toBe("b");
    expect(board.get(t.to)).toMatchObject({ type: "k", color: "w" });
  });

  it("a future threat IS playable, and is flagged as such", async () => {
    const { findThreat, threatIsReplayable } = await import("../localAnalysis");
    // Black queen hangs on d5; White is not in check.
    const fen = "rnbqkbnr/pppp1ppp/4p3/3Q4/8/8/PPPP1PPP/RNB1KBNR b KQkq - 0 1";
    const t = findThreat(fen);
    if (!t) return;
    expect(t.immediate).toBe(false);
    expect(threatIsReplayable(t)).toBe(true);
    const probe = new Chess(t.threatFen);
    expect(() => probe.move({ from: t.from, to: t.to, promotion: "q" })).not.toThrow();
  });

  it("the coach never prints the placeholder SAN of an existing check", () => {
    const fen = "rnb1k1n1/pQp2p1r/8/4p2p/2PPpP1P/5N2/3NBP2/q2K3R w - - 0 21";
    const card = buildCoachCard({ fen, positionId: 1, humanSide: "w" });
    // "check" is a placeholder, not real notation — it must never reach a
    // continuation line that is shown to the learner as a move
    expect(card.threat.continuation).not.toContain("check");
  });
});
