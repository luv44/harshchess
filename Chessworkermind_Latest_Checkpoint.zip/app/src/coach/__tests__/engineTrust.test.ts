/**
 * The engine is an ADVISOR, never an authority.
 *
 * Stockfish (or anything pretending to be it) can be wrong, out of date, or
 * garbled by a dropped worker message. These tests feed the coach hostile
 * engine output and check that it can never be talked into a false statement.
 *
 * The rule the code must hold to: the engine may RANK moves; only replay on
 * the real board may CLAIM anything.
 */
import { describe, expect, it } from "vitest";
import { Chess } from "chess.js";
import { buildCoachCard, chooseSuggestion } from "../coachCard";
import { engineCacheTag } from "../../engine/stockfishSetting";

const START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
const ITALIAN = "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 0 4";
const MATE_IN_1 = "6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1";
const FREE_QUEEN_FOR_BLACK = "4k3/8/8/3p4/2Q5/8/8/4K3 b - - 1 1";

function card(fen: string, engineCandidates?: Array<{ uci: string; scoreCp?: number; scoreMate?: number }>) {
  const c = new Chess(fen);
  return buildCoachCard({ fen, positionId: 1, humanSide: c.turn(), engineCandidates });
}

/** Everything the card points at must be playable on the real board. */
function assertCardIsPlayable(fen: string, built: ReturnType<typeof card>) {
  if (built.suggestion) {
    const probe = new Chess(fen);
    expect(() =>
      probe.move({ from: built.suggestion!.from, to: built.suggestion!.to, promotion: "q" }),
    ).not.toThrow();
    for (const alt of built.suggestion.alternatives) {
      const p2 = new Chess(fen);
      expect(() => p2.move({ from: alt.from, to: alt.to, promotion: "q" })).not.toThrow();
    }
  }
  if (built.future) {
    for (const line of built.future.lines) {
      const p = new Chess(fen);
      p.move({ from: built.suggestion!.from, to: built.suggestion!.to, promotion: "q" });
      expect(() =>
        p.move({ from: line.theirMove.from, to: line.theirMove.to, promotion: "q" }),
      ).not.toThrow();
    }
  }
}

describe("an engine that is talking nonsense", () => {
  it("ignores moves that are not legal here", () => {
    const built = card(START, [
      { uci: "e2e5", scoreCp: 900 }, // a pawn cannot go there
      { uci: "a1a8", scoreCp: 850 }, // the rook is blocked
      { uci: "e7e5", scoreCp: 800 }, // that is Black's move, not White's
    ]);
    expect(built.suggestion).not.toBeNull();
    expect(built.suggestion!.source).toBe("local"); // no legal engine move survived
    assertCardIsPlayable(START, built);
  });

  it("does not crash on garbled or empty candidates", () => {
    const junk = [
      { uci: "" },
      { uci: "x" },
      { uci: "zz99zz" },
      { uci: "e2e4e4e4" },
      { uci: "E2E4" }, // wrong case
      { uci: "  " },
    ];
    for (const bad of junk) {
      const built = card(START, [bad]);
      expect(built.suggestion).not.toBeNull();
      assertCardIsPlayable(START, built);
    }
    // all of them at once, plus one good move
    const mixed = card(START, [...junk, { uci: "g1f3", scoreCp: 30 }]);
    expect(mixed.suggestion!.source).toBe("engine");
    assertCardIsPlayable(START, mixed);
  });

  it("throws away a result that belongs to the previous position", () => {
    // These are legal in the Italian, not in the starting position.
    const stale = [{ uci: "c6d4", scoreCp: 500 }, { uci: "g8f6", scoreCp: 480 }];
    const built = card(START, stale);
    expect(built.suggestion!.source).toBe("local");
    assertCardIsPlayable(START, built);
  });

  it("uses only the legal half of a half-stale answer", () => {
    const built = card(ITALIAN, [
      { uci: "e2e4", scoreCp: 900 }, // White's move, illegal for Black here
      { uci: "g8f6", scoreCp: 40 }, // legal
    ]);
    expect(built.suggestion!.source).toBe("engine");
    const probe = new Chess(ITALIAN);
    expect(() => probe.move({ from: built.suggestion!.from, to: built.suggestion!.to })).not.toThrow();
  });
});

describe("an engine that is lying", () => {
  it("does not repeat a mate claim that is not mate", () => {
    // The engine insists Nf3 is mate in one. It is not.
    const built = card(START, [{ uci: "g1f3", scoreMate: 1 }]);
    expect(built.suggestion!.isMate).toBe(false);
    expect(built.reason?.key).not.toBe("mate");
    const probe = new Chess(START);
    probe.move({ from: "g1", to: "f3" });
    expect(probe.isCheckmate()).toBe(false);
  });

  it("still finds the real mate when the engine points somewhere else", () => {
    const built = card(MATE_IN_1, [{ uci: "g1g2", scoreCp: 1200 }]);
    expect(built.suggestion).not.toBeNull();
    const probe = new Chess(MATE_IN_1);
    probe.move({ from: built.suggestion!.from, to: built.suggestion!.to, promotion: "q" });
    // whatever it picked, the card's claim about it must be true
    expect(built.suggestion!.isMate).toBe(probe.isCheckmate());
    if (built.reason?.key === "mate") expect(probe.isCheckmate()).toBe(true);
  });

  it("does not claim a capture won material when it did not", () => {
    // An engine that loves grabbing things. Every capture claim in the card
    // must survive being played out on the board.
    const c = new Chess(ITALIAN);
    const grabs = c
      .moves({ verbose: true })
      .filter((m) => m.captured)
      .map((m) => ({ uci: `${m.from}${m.to}`, scoreCp: 2000 }));
    const built = card(ITALIAN, grabs.length ? grabs : undefined);

    if (built.suggestion?.isCapture) {
      const probe = new Chess(ITALIAN);
      const played = probe.move({ from: built.suggestion.from, to: built.suggestion.to, promotion: "q" });
      expect(played.captured).toBeTruthy();
      expect(built.suggestion.captured).toBe(played.captured);
    }
    if (built.reason?.key === "safeCapture") {
      const probe = new Chess(ITALIAN);
      const played = probe.move({ from: built.suggestion!.from, to: built.suggestion!.to, promotion: "q" });
      expect(played.captured).toBeTruthy();
    }
  });

  it("a huge fake score cannot invent a threat that is not on the board", () => {
    const calm = card(START, [{ uci: "e2e4", scoreCp: 30000 }]);
    expect(calm.threat.present).toBe(false);
    expect(calm.threat.continuation).toEqual([]);
  });

  it("a fake score cannot hide a threat that IS on the board", () => {
    // Black to move, White's queen on c4 can be taken by the d5 pawn.
    const built = card(FREE_QUEEN_FOR_BLACK, [{ uci: "e8e7", scoreCp: 5000 }]);
    // Whatever the engine says, the board facts are unchanged and legal.
    assertCardIsPlayable(FREE_QUEEN_FOR_BLACK, built);
    const probe = new Chess(FREE_QUEEN_FOR_BLACK);
    expect(probe.moves().includes("dxc4")).toBe(true);
  });
});

describe("the engine only ever reorders verified moves", () => {
  it("never promotes a move the local search rejected as losing", () => {
    // Black to move. The engine begs for the king to walk to d7... which is
    // fine; the point is whatever wins, the SUGGESTION is still a legal move
    // taken from the locally scored pool.
    const fen = FREE_QUEEN_FOR_BLACK;
    const local = chooseSuggestion(fen);
    const withEngine = chooseSuggestion(fen, [{ uci: "e8f8", scoreCp: 9999 }]);
    expect(local).not.toBeNull();
    expect(withEngine).not.toBeNull();

    const probe = new Chess(fen);
    expect(() =>
      probe.move({ from: withEngine!.suggestion.from, to: withEngine!.suggestion.to, promotion: "q" }),
    ).not.toThrow();
    // the reason is about the move it actually chose
    expect(withEngine!.reason.squares).toContain(withEngine!.suggestion.to);
  });

  it("marks the source honestly in both directions", () => {
    expect(chooseSuggestion(START)!.suggestion.source).toBe("local");
    expect(chooseSuggestion(START, [{ uci: "d2d4" }])!.suggestion.source).toBe("engine");
    expect(chooseSuggestion(START, [{ uci: "d2d9" }])!.suggestion.source).toBe("local");
    expect(chooseSuggestion(START, [])!.suggestion.source).toBe("local");
  });
});

describe("when the engine never answers", () => {
  it("the coach still produces a full, usable card", () => {
    const built = card(START, undefined);
    expect(built.suggestion).not.toBeNull();
    expect(built.reason).not.toBeNull();
    expect(built.practice).not.toBeNull();
    expect(built.abstained).toBe(false);
    expect(built.suggestion!.source).toBe("local");
    assertCardIsPlayable(START, built);
  });

  it("an empty answer is the same as no answer, not an error", () => {
    const built = card(ITALIAN, []);
    expect(built.suggestion).not.toBeNull();
    expect(built.suggestion!.source).toBe("local");
  });
});

describe("the coach cache knows the engine is part of the answer", () => {
  it("gives a rules-only card and an engine card different keys", () => {
    // This was a real bug: every card was cached as "local", so once a
    // rules-only card existed the engine's opinion was silently dropped.
    expect(engineCacheTag(undefined)).toBe("local");
    expect(engineCacheTag([])).toBe("local");
    expect(engineCacheTag([{ uci: "e2e4" }])).not.toBe("local");
    expect(engineCacheTag([{ uci: "e2e4" }])).not.toBe(engineCacheTag([{ uci: "d2d4" }]));
    expect(engineCacheTag([{ uci: "e2e4" }])).toBe(engineCacheTag([{ uci: "e2e4" }]));
  });
});

describe("regression: the engine's opinion is not thrown away by the cache", () => {
  it("asking again WITH the engine gives an engine-backed card, not the cached rules one", async () => {
    const { renderHook, act, waitFor } = await import("@testing-library/react");
    const { useCoach } = await import("../useCoach");

    const { result } = renderHook(() => useCoach());

    // 1. the engine has not answered yet — a rules-only card is built and cached
    act(() => {
      result.current.request({ fen: START, humanSide: "w" });
    });
    await waitFor(() => expect(result.current.status).toBe("ready"));
    expect(result.current.card?.suggestion?.source).toBe("local");

    // 2. Stockfish finishes and we ask again for the SAME position.
    //    Before the fix both cards were cached under "...|local", so this
    //    returned the stale rules-only card and the engine was ignored.
    act(() => {
      result.current.request({
        fen: START,
        humanSide: "w",
        engineCandidates: [{ uci: "d2d4", scoreCp: 25 }],
      });
    });
    await waitFor(() => expect(result.current.status).toBe("ready"));
    expect(result.current.card?.suggestion?.source).toBe("engine");
    expect(result.current.card?.fen).toBe(START);

    // 3. and going back to no-engine still returns the rules card, not the engine one
    act(() => {
      result.current.request({ fen: START, humanSide: "w" });
    });
    await waitFor(() => expect(result.current.status).toBe("ready"));
    expect(result.current.card?.suggestion?.source).toBe("local");
  });
})
