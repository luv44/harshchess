import { describe, expect, it } from "vitest";
import { Chess } from "chess.js";
import { reviewMove, RISK_THRESHOLD, spellMove, spellOpponentMove } from "../reviewMove";

/**
 * These tests exist to stop "Why not my move?" inventing accusations.
 * Every claim it makes must be replayable on the real board.
 */

const START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

describe("reviewMove refuses to invent", () => {
  it("marks an illegal move as illegal and claims nothing about it", () => {
    const r = reviewMove({ fen: START, from: "e2", to: "e5" });
    expect(r.legal).toBe(false);
    expect(r.risk).toBeNull();
    expect(r.candidates).toHaveLength(0);
    expect(r.uncertain).toBe(true);
  });

  it("does not accuse a perfectly normal opening move", () => {
    const r = reviewMove({ fen: START, from: "e2", to: "e4" });
    expect(r.legal).toBe(true);
    expect(r.risk).toBeNull();
    expect(r.playedIsSound).toBe(true);
    expect(r.played?.san).toBe("e4");
  });

  it("does not accuse the other normal first moves either", () => {
    for (const [from, to] of [["d2", "d4"], ["g1", "f3"], ["c2", "c4"], ["b1", "c3"]] as const) {
      const r = reviewMove({ fen: START, from, to });
      expect(r.legal).toBe(true);
      expect(r.risk, `${from}${to} should not be called risky`).toBeNull();
    }
  });
});

describe("reviewMove proves the punishment before it names it", () => {
  it("shows the legal capture that punishes hanging a knight", () => {
    // White knight walks to a square a black pawn attacks, and nothing defends it.
    const fen = "rnbqkbnr/pppp1ppp/8/4p3/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 2";
    const r = reviewMove({ fen, from: "g1", to: "f3" });
    // Nf3 is fine here — the pawn on e5 can take it but White recaptures nothing;
    // whatever the verdict is, it must be provable.
    if (r.risk) {
      const probe = new Chess(r.fenAfter!);
      expect(() => probe.move({ from: r.risk!.from, to: r.risk!.to, promotion: "q" })).not.toThrow();
      expect(r.risk.materialLost).toBeGreaterThanOrEqual(RISK_THRESHOLD);
    }
  });

  it("catches a queen put on a square a pawn can take for free", () => {
    // White queen steps onto c4, where the d5 pawn simply takes it and
    // nothing can recapture. This is provable, so the coach may say it.
    const fen = "4k3/8/8/3p4/8/8/8/2Q1K3 w - - 0 1";
    const r = reviewMove({ fen, from: "c1", to: "c4" });

    expect(r.legal).toBe(true);
    expect(r.risk).not.toBeNull();
    expect(r.risk!.kind).toBe("wins-material");
    expect(r.risk!.san).toBe("dxc4");
    expect(r.risk!.materialLost).toBeGreaterThanOrEqual(800);
    expect(r.playedIsSound).toBe(false);

    // and the punishment really is playable on the real board
    const probe = new Chess(r.fenAfter!);
    expect(() => probe.move({ from: r.risk!.from, to: r.risk!.to })).not.toThrow();

    // a quiet queen move in the same position must NOT be accused
    const safe = reviewMove({ fen, from: "c1", to: "c3" });
    expect(safe.legal).toBe(true);
    expect(safe.risk).toBeNull();
  });

  it("every punishment it reports is a legal move in the position after the learner's move", () => {
    const positions = [
      START,
      "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2",
      "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 0 4",
      "8/5pk1/6p1/7p/7P/6P1/5PK1/3R4 w - - 0 1",
    ];
    for (const fen of positions) {
      const c = new Chess(fen);
      for (const m of c.moves({ verbose: true }).slice(0, 12)) {
        const r = reviewMove({ fen, from: m.from, to: m.to, promotion: m.promotion });
        expect(r.legal).toBe(true);
        if (r.risk) {
          const probe = new Chess(r.fenAfter!);
          expect(
            () => probe.move({ from: r.risk!.from, to: r.risk!.to, promotion: "q" }),
            `punishment ${r.risk.san} must be legal after ${m.san} in ${fen}`,
          ).not.toThrow();
        }
      }
    }
  });

  it("never claims a loss smaller than a pawn", () => {
    const c = new Chess("r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 0 4");
    for (const m of c.moves({ verbose: true })) {
      const r = reviewMove({ fen: c.fen(), from: m.from, to: m.to, promotion: m.promotion });
      if (r.risk && r.risk.kind === "wins-material") {
        expect(r.risk.materialLost).toBeGreaterThanOrEqual(RISK_THRESHOLD);
      }
    }
  });
});

describe("reviewMove candidates", () => {
  it("offers at most three candidates and every one of them is legal", () => {
    for (const fen of [
      START,
      "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 0 4",
      "6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1",
    ]) {
      const r = reviewMove({ fen, from: "e2", to: "e4" });
      expect(r.candidates.length).toBeLessThanOrEqual(3);
      for (const cand of r.candidates) {
        const probe = new Chess(fen);
        expect(() => probe.move({ from: cand.from, to: cand.to, promotion: "q" })).not.toThrow();
        expect(cand.san.length).toBeGreaterThan(0);
      }
    }
  });

  it("finds checkmate as a candidate when mate is really there", () => {
    const r = reviewMove({ fen: "6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1", from: "a1", to: "a7" });
    const mate = r.candidates.find((c) => c.reason === "givesMate");
    expect(mate).toBeTruthy();
    const probe = new Chess("6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1");
    probe.move(mate!.san);
    expect(probe.isCheckmate()).toBe(true);
  });

  it("reports the end of the game instead of advice", () => {
    const r = reviewMove({ fen: "6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1", from: "a1", to: "a8" });
    expect(r.endsGame).toEqual({ kind: "checkmate", winner: "w" });
    expect(r.risk).toBeNull();
  });
});

describe("plain wording", () => {
  it("spells moves out in words, never notation only", () => {
    expect(spellMove("n", "g1", "f3")).toBe("your knight from g1 to f3");
    expect(spellOpponentMove("b", "q", "d8", "h4")).toBe("Black moved the queen from d8 to h4.");
    expect(spellOpponentMove("b", "q", "d8", "h4", "p")).toMatch(/took your pawn/);
  });
});
