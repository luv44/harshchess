import { Chess, type Square } from "chess.js";
import type { Analysis } from "../engine/useEngine";

export type CoachingFactPacket = {
  fen: string; positionId: number;
  boardFacts: { inCheck: boolean; turn: "w" | "b"; legalMoves: string[]; checks: string[]; captures: string[]; attacked: string[]; undefended: string[] };
  verifiedAnalysis: { engineVersion: string; depth: number; lines: string[][] } | null;
  teachingInference: string;
  unknown: string[];
};
export function legalLine(fen: string, line: string[]): { fens: string[]; sans: string[] } | null {
  const c = new Chess(fen); const fens=[c.fen()], sans: string[]=[];
  try {
    for (const uci of line) {
      if (c.isGameOver() || !/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(uci)) return null;
      const m=c.move({from:uci.slice(0,2),to:uci.slice(2,4),promotion:uci.slice(4)||undefined});
      sans.push(m.san);fens.push(c.fen());
    }
    return { fens, sans };
  } catch { return null; }
}
export function positionFacts(fen: string, positionId: number, analysis?: Analysis | null): CoachingFactPacket {
  const c=new Chess(fen), turn=c.turn(), enemy=turn === "w" ? "b" : "w";
  const moves=c.isGameOver() ? [] : c.moves({verbose:true});
  const attacked:string[]=[], undefended:string[]=[];
  for (const rank of c.board()) for (const p of rank) {
    if (!p || p.color !== turn || p.type === "k") continue;
    if (c.isAttacked(p.square,enemy)) attacked.push(p.square);
    if (c.attackers(p.square,turn).length === 0) undefended.push(p.square);
  }
  let verifiedAnalysis: CoachingFactPacket['verifiedAnalysis']=null;
  if (analysis?.fen === fen && analysis.positionId === positionId) {
    const lines=analysis.candidates.flatMap(candidate=>{
      const replay=new Chess(fen), line:string[]=[];
      try { for(const san of candidate.pvSans) { const m=replay.move(san);line.push(`${m.from}${m.to}${m.promotion??""}`); } }
      catch { return []; }
      return line.length && line[0] === candidate.uci ? [line] : [];
    });
    if(lines.length) verifiedAnalysis={engineVersion:analysis.engineVersion,depth:analysis.depth,lines};
  }
  return { fen,positionId, boardFacts:{inCheck:c.isCheck(),turn,legalMoves:moves.map(m=>m.san),
    checks:moves.filter(m=>/[+#]$/.test(m.san)).map(m=>m.san),captures:moves.filter(m=>m.captured).map(m=>m.san),attacked,undefended},
    verifiedAnalysis, teachingInference:c.isCheck()?"First find a legal answer to check.":"Compare a legal choice with a possible reply before committing.",
    unknown:["An attacked or undefended piece is not automatically lost.","No strongest reply or forced threat is established by an attack map."] };
}
export function defenders(fen:string,square:Square):string[] {
  const c=new Chess(fen),p=c.get(square);return p?c.attackers(square,p.color):[];
}
