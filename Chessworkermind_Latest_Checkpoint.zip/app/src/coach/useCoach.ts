/**
 * useCoach — one frozen Coach card per position.
 *
 * Rules enforced here:
 *  - A card belongs to exactly ONE position (FEN + monotonic positionId).
 *  - Results that arrive for an older position are dropped, so text and arrows
 *    never jump while the learner is reading.
 *  - The displayed card is replaced only on a new position or an explicit
 *    refresh, never mid-read.
 *  - If Workers are unavailable the card is built synchronously instead, so the
 *    coach still works (slower) rather than disappearing.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { buildCoachCard, cardStillValid, type CoachCard, type RawMove } from "./coachCard";
import type { CoachRequest, CoachResponse } from "./coachWorker";
import { engineCacheTag } from "../engine/stockfishSetting";

export type CoachStatus = "idle" | "thinking" | "ready" | "error";

const CARD_CACHE = new Map<string, CoachCard>();
const CACHE_LIMIT = 60;

function cacheKey(fen: string, humanSide: string, engineTag: string) {
  return `${fen}|${humanSide}|${engineTag}`;
}

export function useCoach() {
  const workerRef = useRef<Worker | null>(null);
  const positionIdRef = useRef(0);
  /** The engine tag of the request currently in flight, so the worker's
   *  answer is cached under the same key the request was looked up with. */
  const pendingTagRef = useRef("local");
  const pendingFenRef = useRef<string | null>(null);
  const [card, setCard] = useState<CoachCard | null>(null);
  const [status, setStatus] = useState<CoachStatus>("idle");
  const [lastMs, setLastMs] = useState<number | null>(null);
  const [workerOk, setWorkerOk] = useState(true);

  useEffect(() => {
    if (typeof Worker === "undefined") {
      setWorkerOk(false);
      return;
    }
    try {
      const w = new Worker(new URL("./coachWorker.ts", import.meta.url), { type: "module" });
      w.onmessage = (e: MessageEvent<CoachResponse>) => {
        const msg = e.data;
        // stale guard — a result for an old position is never shown
        if (msg.positionId !== positionIdRef.current || msg.fen !== pendingFenRef.current) return;
        if (msg.type === "card") {
          const key = cacheKey(msg.fen, msg.card.humanSide, pendingTagRef.current);
          if (CARD_CACHE.size > CACHE_LIMIT) CARD_CACHE.clear();
          CARD_CACHE.set(key, msg.card);
          setCard(msg.card);
          setLastMs(msg.ms);
          setStatus("ready");
        } else {
          setStatus("error");
        }
      };
      w.onerror = () => {
        setWorkerOk(false); setStatus("error"); setCard(null);
        w.terminate(); workerRef.current = null;
      };
      workerRef.current = w;
    } catch {
      setWorkerOk(false);
    }
    return () => {
      try {
        workerRef.current?.terminate();
      } catch {
        /* ignore */
      }
      workerRef.current = null;
      positionIdRef.current += 1;
      pendingFenRef.current = null;
    };
  }, []);

  /** Ask for a card for this exact position. Cancels anything older. */
  const request = useCallback(
    (args: {
      fen: string;
      humanSide: "w" | "b";
      lastMove?: RawMove | null;
      engineCandidates?: Array<{ uci: string; scoreCp?: number; scoreMate?: number }>;
      force?: boolean;
    }) => {
      positionIdRef.current += 1;
      const positionId = positionIdRef.current;

      // The engine's opinion is part of the identity of a card. Keying every
      // card as "local" meant a rules-only card could be served after the
      // engine had spoken, and vice versa.
      pendingFenRef.current = args.fen;
      const tag = `${engineCacheTag(args.engineCandidates)}|last:${args.lastMove?.from ?? ""}${args.lastMove?.to ?? ""}`;
      pendingTagRef.current = tag;
      const key = cacheKey(args.fen, args.humanSide, tag);
      const cached = args.force ? undefined : CARD_CACHE.get(key);
      if (cached && cardStillValid(cached, args.fen)) {
        setCard({ ...cached, positionId });
        setStatus("ready");
        return positionId;
      }

      setStatus("thinking");
      setCard(null);
      const w = workerRef.current;
      if (w) {
        const req: CoachRequest = {
          type: "build",
          fen: args.fen,
          positionId,
          humanSide: args.humanSide,
          lastMove: args.lastMove ?? null,
          engineCandidates: args.engineCandidates,
        };
        w.postMessage(req);
        return positionId;
      }

      // No worker available — build on the main thread so the coach still works.
      try {
        const built = buildCoachCard({
          fen: args.fen,
          positionId,
          humanSide: args.humanSide,
          lastMove: args.lastMove ?? null,
          engineCandidates: args.engineCandidates,
        });
        if (positionId === positionIdRef.current) {
          CARD_CACHE.set(key, built);
          setCard(built);
          setStatus("ready");
        }
      } catch {
        setStatus("error");
      }
      return positionId;
    },
    [],
  );

  /** Drop the current card and stop caring about in-flight work. */
  const clear = useCallback(() => {
    positionIdRef.current += 1;
    pendingFenRef.current = null;
    setCard(null);
    setStatus("idle");
  }, []);

  return { card, status, lastMs, workerOk, request, clear, positionId: positionIdRef.current };
}
