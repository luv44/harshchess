/**
 * "Why not my move?" — an HONEST comparison between the move the learner
 * played and the move the coach suggests.
 *
 * The hard rules this file exists to enforce:
 *
 *  1. We only say a move was risky when we can SHOW the punishment: a legal
 *     reply, replayed on the real board, that wins material or gives mate.
 *  2. We compare against what was actually available. A move is not "bad"
 *     just because a computer likes something else — it is only called risky
 *     when it loses material that a reasonable alternative would have kept.
 *  3. If we cannot verify anything, `uncertain` is true and the UI must say
 *     "the coach cannot prove anything here" instead of inventing a fork, a
 *     lost queen, a forced mate or an evaluation.
 *  4. Every square, piece name and continuation comes from chess.js replay,
 *     never from a template.
 */

import { Chess, type Square } from "chess.js";
import {
  PIECE_VALUE,
  isLegal,
  legalMoves,
  safeChess,
  scoreMoves,
  tacticalSwing,
} from "./localAnalysis";
import type { Color } from "../chess/session";

/** One pawn. Below this we do not claim a move "loses material" at all. */
export const RISK_THRESHOLD = 100;

/**
 * Two pawns. Below this we will MENTION a loss but never interrupt the
 * learner or list the move as a mistake in a game report.
 *
 * Why: giving up a single pawn is a normal, deliberate idea in real chess.
 * In the Ruy Lopez, 5.O-O allows 5...Nxe4 and wins a pawn for Black — and
 * that is a main line played by world champions, not a blunder. An earlier
 * version of this file flagged exactly that move and would have told a
 * beginner their castling was a mistake. A material-only search cannot tell
 * a gambit from a giveaway, so it is not allowed to shout about one pawn.
 */
export const SERIOUS_LOSS = 200;

/** Is this bad enough to stop the learner, or to put in a game report? */
export function isSerious(risk: PunishReply | null): boolean {
  if (!risk) return false;
  return risk.kind === "mate" || risk.materialLost >= SERIOUS_LOSS;
}

/** How many alternatives we test to work out what was actually available. */
const ALTERNATIVES_TESTED = 5;

export type PunishReply = {
  from: Square;
  to: Square;
  san: string;
  pieceType: string;
  captured?: string;
  /** centipawns the learner loses after the whole exchange is played out */
  materialLost: number;
  kind: "mate" | "wins-material";
};

export type CandidateReasonKey =
  | "winsMaterial"
  | "savesPiece"
  | "escapeCheck"
  | "givesMate"
  | "develops"
  | "controlsCentre"
  | "keepsEverythingDefended";

export type Candidate = {
  from: Square;
  to: Square;
  san: string;
  pieceType: string;
  promotion?: string;
  isCapture: boolean;
  captured?: string;
  reason: CandidateReasonKey;
  /** squares the reason is about, so words and board agree */
  squares: Square[];
  /** material the opponent can win after this move — 0 means nothing hangs */
  opponentCanWin: number;
};

export type MoveReview = {
  /** position BEFORE the learner's move — everything below is tied to this */
  fen: string;
  legal: boolean;
  played: {
    from: Square;
    to: Square;
    san: string;
    pieceType: string;
    isCapture: boolean;
    captured?: string;
    isCheck: boolean;
    isMate: boolean;
  } | null;
  /** Position after the learner's move. */
  fenAfter: string | null;
  /**
   * The punishment, only when replay proves it AND a normal alternative
   * avoided it. Null means: we have nothing to accuse the move of.
   */
  risk: PunishReply | null;
  /** How much better the best tested alternative was, in centipawns. */
  riskVersusBest: number;
  /** At most three legal candidates for THIS position, best first. */
  candidates: Candidate[];
  /** True when the played move is one of the sound choices. */
  playedIsSound: boolean;
  /** True when we cannot judge and must say so. */
  uncertain: boolean;
  /** Set when the learner's move ends the game. */
  endsGame: null | { kind: "checkmate" | "stalemate" | "draw"; winner?: Color };
};

/** Material the side to move can win in this position, verified by replay. */
function opponentGain(fen: string): number {
  const swing = tacticalSwing(fen);
  return swing > 0 ? swing : 0;
}

/** Is there a mate in one for the side to move? Confirmed by replaying it. */
function mateInOne(fen: string): { from: Square; to: Square; san: string; pieceType: string } | null {
  const c = safeChess(fen);
  if (!c) return null;
  for (const raw of c.moves({ verbose: true })) {
    if (!raw.san.includes("#")) continue;
    const probe = safeChess(fen);
    if (!probe) continue;
    try {
      probe.move({ from: raw.from, to: raw.to, promotion: raw.promotion ?? "q" });
    } catch {
      continue;
    }
    if (!probe.isCheckmate()) continue; // never trust the "#" alone
    return { from: raw.from as Square, to: raw.to as Square, san: raw.san, pieceType: raw.piece };
  }
  return null;
}

/** The single best way for the side to move to win material here. */
function bestGrab(fen: string): PunishReply | null {
  const c = safeChess(fen);
  if (!c) return null;

  const mate = mateInOne(fen);
  if (mate) {
    return { ...mate, materialLost: 0, kind: "mate" };
  }

  let best: PunishReply | null = null;
  for (const raw of c.moves({ verbose: true })) {
    if (!raw.captured) continue;
    const victim = PIECE_VALUE[raw.captured] ?? 0;
    const probe = safeChess(fen);
    if (!probe) continue;
    try {
      probe.move({ from: raw.from, to: raw.to, promotion: raw.promotion ?? "q" });
    } catch {
      continue;
    }
    // what the victim's owner wins back once the exchange is played out
    const winBack = tacticalSwing(probe.fen());
    const net = victim - (winBack > 0 ? winBack : 0);
    if (net >= RISK_THRESHOLD && (!best || net > best.materialLost)) {
      best = {
        from: raw.from as Square,
        to: raw.to as Square,
        san: raw.san,
        pieceType: raw.piece,
        captured: raw.captured,
        materialLost: net,
        kind: "wins-material",
      };
    }
  }
  return best;
}

const CENTRE: Square[] = ["d4", "e4", "d5", "e5"] as Square[];

function candidateReason(fen: string, move: { from: Square; to: Square; san: string; piece: string; captured?: string }): {
  reason: CandidateReasonKey;
  squares: Square[];
} {
  const before = safeChess(fen);
  if (!before) return { reason: "develops", squares: [move.from, move.to] };

  if (move.san.includes("#")) return { reason: "givesMate", squares: [move.to] };
  if (before.isCheck()) return { reason: "escapeCheck", squares: [move.from, move.to] };

  if (move.captured) {
    const probe = safeChess(fen)!;
    try {
      probe.move({ from: move.from, to: move.to, promotion: "q" });
      const winBack = tacticalSwing(probe.fen());
      const net = (PIECE_VALUE[move.captured] ?? 0) - (winBack > 0 ? winBack : 0);
      if (net >= RISK_THRESHOLD) return { reason: "winsMaterial", squares: [move.to] };
    } catch {
      /* fall through */
    }
  }

  // Was this piece in danger where it stood, and is it safe now?
  const stayed = opponentGain(passTurn(fen) ?? fen);
  const probe = safeChess(fen)!;
  try {
    probe.move({ from: move.from, to: move.to, promotion: "q" });
    const nowRisk = opponentGain(probe.fen());
    if (stayed - nowRisk >= RISK_THRESHOLD) return { reason: "savesPiece", squares: [move.from, move.to] };
    if (nowRisk === 0 && stayed === 0 && CENTRE.includes(move.to)) {
      return { reason: "controlsCentre", squares: [move.to] };
    }
    if (nowRisk === 0) {
      if (move.piece === "n" || move.piece === "b" || move.piece === "r" || move.piece === "q") {
        return { reason: "develops", squares: [move.from, move.to] };
      }
      return { reason: "keepsEverythingDefended", squares: [move.to] };
    }
  } catch {
    /* fall through */
  }
  return { reason: "develops", squares: [move.from, move.to] };
}

/** Give the move to the other side without moving anything (for "if I did nothing"). */
function passTurn(fen: string): string | null {
  const c = safeChess(fen);
  if (!c || c.isCheck()) return null;
  const parts = fen.split(" ");
  if (parts.length < 4) return null;
  parts[1] = parts[1] === "w" ? "b" : "w";
  parts[3] = "-";
  return safeChess(parts.join(" ")) ? parts.join(" ") : null;
}

export function reviewMove(args: {
  fen: string;
  from: string;
  to: string;
  promotion?: string;
}): MoveReview {
  const { fen, from, to, promotion } = args;
  const empty: MoveReview = {
    fen,
    legal: false,
    played: null,
    fenAfter: null,
    risk: null,
    riskVersusBest: 0,
    candidates: [],
    playedIsSound: false,
    uncertain: true,
    endsGame: null,
  };

  const base = safeChess(fen);
  if (!base || base.isGameOver()) return empty;
  if (!isLegal(fen, from, to, promotion)) return empty;

  const after = safeChess(fen)!;
  let raw;
  try {
    raw = after.move({ from, to, promotion: promotion ?? "q" });
  } catch {
    return empty;
  }
  if (!raw) return empty;

  const fenAfter = after.fen();
  const played = {
    from: raw.from as Square,
    to: raw.to as Square,
    san: raw.san,
    pieceType: raw.piece,
    isCapture: !!raw.captured,
    captured: raw.captured,
    isCheck: after.isCheck(),
    isMate: after.isCheckmate(),
  };

  let endsGame: MoveReview["endsGame"] = null;
  if (after.isCheckmate()) endsGame = { kind: "checkmate", winner: raw.color as Color };
  else if (after.isStalemate()) endsGame = { kind: "stalemate" };
  else if (after.isDraw()) endsGame = { kind: "draw" };

  // ---- candidates for the ORIGINAL position, at most three ---------------
  const ranked = scoreMoves(fen, { limit: 24 }).slice(0, 12);
  const candidates: Candidate[] = [];
  for (const m of ranked) {
    if (candidates.length >= 3) break;
    const probe = safeChess(fen)!;
    let r;
    try {
      r = probe.move({ from: m.from, to: m.to, promotion: m.promotion ?? "q" });
    } catch {
      continue;
    }
    if (!r) continue;
    const { reason, squares } = candidateReason(fen, {
      from: m.from as Square,
      to: m.to as Square,
      san: r.san,
      piece: r.piece,
      captured: r.captured,
    });
    candidates.push({
      from: m.from as Square,
      to: m.to as Square,
      san: r.san,
      pieceType: r.piece,
      promotion: m.promotion,
      isCapture: !!r.captured,
      captured: r.captured,
      reason,
      squares,
      opponentCanWin: opponentGain(probe.fen()),
    });
  }

  // ---- what the opponent can do to us now --------------------------------
  const punish = endsGame ? null : bestGrab(fenAfter);

  // ---- what a reasonable alternative would have allowed -------------------
  let bestAlternativeLoss = Number.POSITIVE_INFINITY;
  const tested = scoreMoves(fen, { limit: 24 }).slice(0, ALTERNATIVES_TESTED);
  for (const m of tested) {
    if (m.from === played.from && m.to === played.to) continue;
    const probe = safeChess(fen)!;
    try {
      probe.move({ from: m.from, to: m.to, promotion: m.promotion ?? "q" });
    } catch {
      continue;
    }
    if (probe.isCheckmate()) {
      bestAlternativeLoss = 0;
      break;
    }
    const grab = bestGrab(probe.fen());
    const loss = grab ? (grab.kind === "mate" ? 100000 : grab.materialLost) : 0;
    if (loss < bestAlternativeLoss) bestAlternativeLoss = loss;
  }
  if (!Number.isFinite(bestAlternativeLoss)) bestAlternativeLoss = 0;

  const playedLoss = punish ? (punish.kind === "mate" ? 100000 : punish.materialLost) : 0;
  const delta = playedLoss - bestAlternativeLoss;

  // Only accuse the move when a normal alternative genuinely avoided the loss.
  const risk = punish && delta >= RISK_THRESHOLD ? punish : null;

  const soundSet = new Set(tested.map((m) => `${m.from}${m.to}`));
  const playedIsSound = !risk && (soundSet.has(`${played.from}${played.to}`) || playedLoss === 0);

  // We are uncertain when there is nothing to compare against.
  const uncertain = legalMoves(fen).length <= 1 || (candidates.length === 0 && !risk);

  return {
    fen,
    legal: true,
    played,
    fenAfter,
    risk,
    riskVersusBest: risk ? delta : 0,
    candidates,
    playedIsSound,
    uncertain,
    endsGame,
  };
}

/** Plain-English piece names for beginner wording. */
export const PIECE_WORD: Record<string, string> = {
  p: "pawn",
  n: "knight",
  b: "bishop",
  r: "rook",
  q: "queen",
  k: "king",
};

/** "Move your knight from g1 to f3." — never notation-only. */
export function spellMove(pieceType: string, from: string, to: string): string {
  return `your ${PIECE_WORD[pieceType] ?? "piece"} from ${from} to ${to}`;
}

/** "Black moved the queen from d8 to h4." */
export function spellOpponentMove(color: Color, pieceType: string, from: string, to: string, captured?: string): string {
  const side = color === "w" ? "White" : "Black";
  const base = `${side} moved the ${PIECE_WORD[pieceType] ?? "piece"} from ${from} to ${to}`;
  return captured ? `${base} and took your ${PIECE_WORD[captured] ?? "piece"}.` : `${base}.`;
}

export const CANDIDATE_REASON_TEXT: Record<CandidateReasonKey, string> = {
  winsMaterial: "wins a piece safely",
  savesPiece: "moves your piece out of danger",
  escapeCheck: "gets your king out of check",
  givesMate: "is checkmate",
  develops: "brings a piece into the game",
  controlsCentre: "takes space in the middle",
  keepsEverythingDefended: "keeps everything defended",
};

/** A fork, explained. Used wherever the word appears. */
export const JARGON: Record<string, string> = {
  fork: "one piece attacks two pieces at the same time",
  pin: "a piece cannot move because something more valuable is behind it",
  check: "your king is being attacked and you must answer it",
  develop: "bring a piece out from its starting square so it can help",
};
