/**
 * The Coach card: ONE card per computer turn, five sections, in order.
 *
 *   1. "Black just moved…"      — what happened, plus a VERIFIED threat or an
 *                                 honest "no immediate threat".
 *   2. "Your move to try."      — one legal, checked suggestion for the CURRENT
 *                                 position (from = 1, to = 2).
 *   3. "Why this helps."        — ONE reason, in easy words, anchored to squares.
 *   4. "What might happen next."— at most two concrete, legal, conditional lines.
 *   5. "Try it yourself."       — tiered help, ending in "Move it for me".
 *
 * The card is LANGUAGE-NEUTRAL: it carries fact keys + parameters (squares,
 * piece types, numbers). Wording happens in coachText.ts. That keeps chess
 * truth separate from translation, exactly as the master spec requires.
 *
 * Nothing here is speculative. Every square, move and continuation is replayed
 * with chess.js before it is allowed into the card.
 */

import { Chess, type Color, type Square } from "chess.js";
import {
  PIECE_VALUE,
  evaluate,
  findThreat,
  hangingPieces,
  isLegal,
  legalMoves,
  safeCaptures,
  safeChess,
  scoreMoves,
  squaresCoveredFrom,
  type LegalMove,
  type ScoredMove,
  threatIsReplayable,
  type Threat,
} from "./localAnalysis";

export type ReasonKey =
  | "mate"
  | "escapeCheck"
  | "savesPiece"
  | "safeCapture"
  | "defendsPiece"
  | "castleSafety"
  | "develops"
  | "controlsCenter"
  | "safeIdea";

export type QuestionKey = "kingDanger" | "canITake" | "whatCanTheyTake" | "whoNeedsHelp";

export type PlanKey = "protect" | "develop" | "center" | "kingSafety";

export type OpponentMoveFact = {
  color: Color;
  pieceType: string;
  from: Square;
  to: Square;
  san: string;
  captured?: string;
  isCheck: boolean;
  isMate: boolean;
  isCastle: boolean;
  isEnPassant: boolean;
  promotion?: string;
  /** Squares between from and to (sliding pieces) for path highlighting. */
  path: Square[];
};

export type ThreatFact = {
  present: boolean;
  threat?: Threat;
  /** The squares to light up so the learner SEES it. */
  highlight: Square[];
  /** Verified continuation if the threat is ignored (SAN), max 2 plies. */
  continuation: string[];
};

export type SuggestionFact = {
  from: Square;
  to: Square;
  san: string;
  uci: string;
  pieceType: string;
  promotion?: string;
  isCapture: boolean;
  captured?: string;
  isCheck: boolean;
  isMate: boolean;
  isCastle: boolean;
  /** Up to two other moves that are just as sound — honest "several are fine". */
  alternatives: Array<{ from: Square; to: Square; san: string; pieceType: string }>;
  /** True when several moves score within a small margin: say "one safe idea". */
  severalSound: boolean;
  /** Where the evidence came from. */
  source: "engine" | "local";
  confidence: "high" | "medium" | "low";
};

export type ReasonFact = {
  key: ReasonKey;
  /** Squares this reason is about, so text and board agree. */
  squares: Square[];
  pieceType?: string;
  capturedType?: string;
  /** Centipawns saved/won — only used to pick wording, never shown raw to a beginner. */
  value?: number;
};

export type FutureLine = {
  /** Opponent reply — legal in the position after the suggestion. */
  theirMove: { from: Square; to: Square; san: string; pieceType: string };
  /** Our follow-up — legal after their reply. */
  ourReply?: { from: Square; to: Square; san: string; pieceType: string };
};

export type FutureFact = {
  lines: FutureLine[];
  plan: PlanKey;
  question: QuestionKey;
};

export type PracticeFact = {
  question: QuestionKey;
  /** tier 1 = think, 2 = gentle hint (piece only), 3 = from/to, 4 = do it for me */
  hintPieceType: string;
  fromSquare: Square;
  toSquare: Square;
};

export type CoachCard = {
  /** The EXACT position this card describes. Card is frozen to this FEN. */
  fen: string;
  positionId: number;
  humanSide: Color;
  turn: Color;
  gameOver: null | { kind: "checkmate" | "stalemate" | "draw"; winner?: Color };
  opponentMove: OpponentMoveFact | null;
  threat: ThreatFact;
  suggestion: SuggestionFact | null;
  reason: ReasonFact | null;
  future: FutureFact | null;
  practice: PracticeFact | null;
  /** Filled when the coach has nothing verified to say (abstention). */
  abstained: boolean;
};

/* ------------------------------------------------------------------ */

const FILES = "abcdefgh";

function squaresBetween(from: Square, to: Square, pieceType: string): Square[] {
  if (pieceType === "n" || pieceType === "k" || pieceType === "p") return [];
  const f1 = FILES.indexOf(from[0]);
  const r1 = Number(from[1]);
  const f2 = FILES.indexOf(to[0]);
  const r2 = Number(to[1]);
  const df = Math.sign(f2 - f1);
  const dr = Math.sign(r2 - r1);
  // must be a straight line
  if (!(f1 === f2 || r1 === r2 || Math.abs(f2 - f1) === Math.abs(r2 - r1))) return [];
  const out: Square[] = [];
  let f = f1 + df;
  let r = r1 + dr;
  while (f !== f2 || r !== r2) {
    if (f < 0 || f > 7 || r < 1 || r > 8) break;
    out.push(`${FILES[f]}${r}` as Square);
    f += df;
    r += dr;
  }
  return out;
}

/** A plain, structurally-cloneable description of the move just played. */
export type RawMove = {
  color: string;
  piece: string;
  from: string;
  to: string;
  san: string;
  flags: string;
  captured?: string;
  promotion?: string;
};

export function factFromRawMove(last: RawMove | null | undefined): OpponentMoveFact | null {
  if (!last) return null;
  return {
    color: last.color as Color,
    pieceType: last.piece,
    from: last.from as Square,
    to: last.to as Square,
    san: last.san,
    captured: last.captured,
    isCheck: last.san.includes("+") || last.san.includes("#"),
    isMate: last.san.includes("#"),
    isCastle: last.flags.includes("k") || last.flags.includes("q"),
    isEnPassant: last.flags.includes("e"),
    promotion: last.promotion,
    path: squaresBetween(last.from as Square, last.to as Square, last.piece),
  };
}

/** Facts about the move that was just played, read from real history. */
export function describeLastMove(chess: Chess): OpponentMoveFact | null {
  const hist = chess.history({ verbose: true });
  const last = hist[hist.length - 1];
  return factFromRawMove(last as RawMove | undefined);
}

function buildThreatFact(fen: string): ThreatFact {
  const threat = findThreat(fen);
  if (!threat) return { present: false, highlight: [], continuation: [] };
  const highlight: Square[] = [threat.from, threat.to];
  const continuation: string[] = [];
  if (threatIsReplayable(threat)) {
    // Replay the threat to prove it is legal, then show one honest follow-up.
    const sim = safeChess(threat.threatFen);
    if (sim) {
      try {
        const played = sim.move(threat.san);
        if (played) {
          continuation.push(played.san);
          const reply = scoreMoves(sim.fen(), { limit: 6 })[0];
          if (reply) continuation.push(reply.san);
        }
      } catch {
        // If it does not replay legally we do NOT claim it.
        return { present: false, highlight: [], continuation: [] };
      }
    }
  }
  return { present: true, threat, highlight, continuation };
}

/**
 * Pick ONE move to teach. Prefer a simple, safe and teachable move when
 * several are similarly sound; stay honest about comparative quality.
 */
export function chooseSuggestion(
  fen: string,
  engineCandidates?: Array<{ uci: string; scoreCp?: number; scoreMate?: number }>,
): { suggestion: SuggestionFact; reason: ReasonFact } | null {
  const c = safeChess(fen);
  if (!c || c.isGameOver()) return null;
  const color = c.turn();
  const scored = scoreMoves(fen);
  if (scored.length === 0) return null;

  // Merge engine opinion when it is available AND legal. Engine ranks; we verify.
  let source: SuggestionFact["source"] = "local";
  let pool = scored;
  if (engineCandidates && engineCandidates.length > 0) {
    const legalEngine = engineCandidates.filter((e) =>
      isLegal(fen, e.uci.slice(0, 2), e.uci.slice(2, 4), e.uci.slice(4) || undefined),
    );
    if (legalEngine.length > 0) {
      source = "engine";
      const engineSet = new Set(legalEngine.map((e) => e.uci.slice(0, 4)));
      const boosted = scored.filter((m) => engineSet.has(`${m.from}${m.to}`));
      if (boosted.length > 0) pool = boosted;
    }
  }

  const best = pool[0];
  // "Similarly sound" group — never punish equally good moves.
  // Capped: in a quiet position dozens of moves tie, and the teachability loop
  // below does real board work per move. 10 is plenty to find a teachable one.
  const soundGroup = pool.filter((m) => best.score - m.score <= 60).slice(0, 10);
  const severalSound = soundGroup.length > 1 && best.score - (pool[1]?.score ?? best.score) < 50;

  const preHanging = hangingPieces(fen, color);
  const worstHanging = preHanging[0];
  const preSafeCaptures = safeCaptures(fen);
  const inCheck = c.isCheck();

  // Teachability score — explains WHY we picked it, and the reason we will show.
  type Pick = { move: ScoredMove; teach: number; reason: ReasonFact };
  const picks: Pick[] = [];

  for (const m of soundGroup) {
    let teach = 0;
    let reason: ReasonFact = { key: "safeIdea", squares: [m.from, m.to], pieceType: m.piece };

    if (m.isMate) {
      teach = 1000;
      reason = { key: "mate", squares: [m.from, m.to], pieceType: m.piece };
    } else if (inCheck) {
      teach = 900;
      reason = { key: "escapeCheck", squares: [m.from, m.to], pieceType: m.piece };
    } else if (worstHanging) {
      // Does this move actually rescue the piece? Verify on the resulting board.
      const sim = safeChess(fen);
      if (sim) {
        sim.move(m.san);
        const after = hangingPieces(sim.fen(), color);
        const stillLoose = after.some(
          (h) => h.square === (m.from === worstHanging.square ? m.to : worstHanging.square) && h.loss >= 100,
        );
        const movedAway = m.from === worstHanging.square;
        const rescued = !stillLoose && (movedAway || after.every((h) => h.square !== worstHanging.square));
        if (rescued) {
          teach = 800 + Math.min(200, worstHanging.loss / 10);
          reason = {
            key: movedAway ? "savesPiece" : "defendsPiece",
            squares: movedAway ? [m.from, m.to] : [worstHanging.square, m.to],
            pieceType: worstHanging.type,
            value: worstHanging.loss,
          };
        }
      }
    }

    if (teach === 0 && m.isCapture && preSafeCaptures.some((s) => s.from === m.from && s.to === m.to)) {
      teach = 600 + (PIECE_VALUE[m.captured ?? "p"] ?? 0) / 10;
      reason = {
        key: "safeCapture",
        squares: [m.from, m.to],
        pieceType: m.piece,
        capturedType: m.captured,
        value: PIECE_VALUE[m.captured ?? "p"] ?? 0,
      };
    }
    if (teach === 0 && m.isCastle) {
      teach = 500;
      reason = { key: "castleSafety", squares: [m.from, m.to], pieceType: "k" };
    }
    if (teach === 0 && (m.piece === "n" || m.piece === "b")) {
      const backRank = color === "w" ? "1" : "8";
      if (m.from[1] === backRank && m.to[1] !== backRank) {
        teach = 400;
        reason = { key: "develops", squares: [m.from, m.to], pieceType: m.piece };
      }
    }
    if (teach === 0) {
      const covered = (() => {
        const sim = safeChess(fen);
        if (!sim) return [] as Square[];
        sim.move(m.san);
        return squaresCoveredFrom(sim.fen(), m.to);
      })();
      const centerCovered = covered.filter((s) => ["d4", "e4", "d5", "e5"].includes(s));
      const landsCenter = ["d4", "e4", "d5", "e5"].includes(m.to);
      if (landsCenter || centerCovered.length > 0) {
        teach = 300 + (landsCenter ? 20 : 0);
        reason = {
          key: "controlsCenter",
          squares: [m.to, ...centerCovered].slice(0, 4) as Square[],
          pieceType: m.piece,
        };
      }
    }
    if (teach === 0) teach = 100;
    // Never recommend something that drops material relative to the best move.
    teach += (m.score - best.score) / 10;
    picks.push({ move: m, teach, reason });
  }

  picks.sort((a, b) => b.teach - a.teach);
  const chosen = picks[0];
  if (!chosen) return null;

  // Final legality gate — the suggestion MUST be legal in this exact FEN.
  if (!isLegal(fen, chosen.move.from, chosen.move.to, chosen.move.promotion)) return null;

  const alternatives = picks
    .slice(1, 3)
    .filter((p) => Math.abs(p.move.score - chosen.move.score) <= 60)
    .map((p) => ({ from: p.move.from, to: p.move.to, san: p.move.san, pieceType: p.move.piece }));

  const margin = chosen.move.score - (pool.find((m) => m.san !== chosen.move.san)?.score ?? chosen.move.score);
  const confidence: SuggestionFact["confidence"] =
    chosen.move.isMate || margin >= 200 ? "high" : margin >= 60 ? "medium" : "low";

  return {
    suggestion: {
      from: chosen.move.from,
      to: chosen.move.to,
      san: chosen.move.san,
      uci: chosen.move.uci,
      pieceType: chosen.move.piece,
      promotion: chosen.move.promotion,
      isCapture: chosen.move.isCapture,
      captured: chosen.move.captured,
      isCheck: chosen.move.isCheck,
      isMate: chosen.move.isMate,
      isCastle: chosen.move.isCastle,
      alternatives,
      severalSound: severalSound && !chosen.move.isMate,
      source,
      confidence,
    },
    reason: chosen.reason,
  };
}

function buildFuture(fen: string, suggestion: SuggestionFact, humanSide: Color): FutureFact {
  const lines: FutureLine[] = [];
  const sim = safeChess(fen);
  if (sim) {
    try {
      sim.move({ from: suggestion.from, to: suggestion.to, promotion: suggestion.promotion as never });
      const replies = scoreMoves(sim.fen(), { limit: 8 }).slice(0, 2);
      for (const [idx, r] of replies.entries()) {
        const after = safeChess(sim.fen());
        let ourReply: FutureLine["ourReply"];
        // Only the first line gets a verified follow-up: beginners see one line,
        // and this halves the work done on every turn.
        if (after && idx === 0) {
          after.move(r.san);
          const our = scoreMoves(after.fen(), { limit: 8 })[0];
          if (our) ourReply = { from: our.from, to: our.to, san: our.san, pieceType: our.piece };
        }
        lines.push({
          theirMove: { from: r.from, to: r.to, san: r.san, pieceType: r.piece },
          ourReply,
        });
      }
    } catch {
      /* if it does not replay, we show no line rather than a fake one */
    }
  }

  // A plan the learner can actually act on, chosen from real board facts.
  const c = safeChess(fen);
  let plan: PlanKey = "develop";
  let question: QuestionKey = "whoNeedsHelp";
  if (c) {
    const loose = hangingPieces(fen, humanSide);
    const caps = safeCaptures(fen);
    const kingSq = (() => {
      for (const row of c.board()) for (const sq of row) if (sq && sq.type === "k" && sq.color === humanSide) return sq.square;
      return null;
    })();
    const backRank = humanSide === "w" ? "1" : "8";
    const kingHome = kingSq ? kingSq[1] === backRank && (kingSq[0] === "e" || kingSq[0] === "d") : false;
    const undeveloped = (() => {
      let n = 0;
      for (const row of c.board())
        for (const sq of row)
          if (sq && sq.color === humanSide && (sq.type === "n" || sq.type === "b") && sq.square[1] === backRank) n++;
      return n;
    })();

    if (c.isCheck()) {
      plan = "kingSafety";
      question = "kingDanger";
    } else if (loose.length > 0) {
      plan = "protect";
      question = "whatCanTheyTake";
    } else if (caps.length > 0) {
      plan = "develop";
      question = "canITake";
    } else if (undeveloped >= 2) {
      plan = "develop";
      question = "whoNeedsHelp";
    } else if (kingHome) {
      plan = "kingSafety";
      question = "kingDanger";
    } else {
      plan = "center";
      question = "whoNeedsHelp";
    }
  }
  return { lines, plan, question };
}

/**
 * Build the whole card for an exact position.
 * `positionId` freezes the card so the text cannot jump while the engine thinks.
 */
export function buildCoachCard(args: {
  fen: string;
  positionId: number;
  humanSide: Color;
  /** Optional Stockfish candidates; used only after legality re-check. */
  engineCandidates?: Array<{ uci: string; scoreCp?: number; scoreMate?: number }>;
  /** Pass the live Chess object when you want "what just happened" from history. */
  history?: Chess;
  /** Or pass the plain move object (this is what crosses the Worker boundary). */
  lastMove?: RawMove | null;
}): CoachCard {
  const { fen, positionId, humanSide, engineCandidates, history, lastMove } = args;
  const c = safeChess(fen);

  const empty: CoachCard = {
    fen,
    positionId,
    humanSide,
    turn: "w",
    gameOver: null,
    opponentMove: null,
    threat: { present: false, highlight: [], continuation: [] },
    suggestion: null,
    reason: null,
    future: null,
    practice: null,
    abstained: true,
  };
  if (!c) return empty;

  const turn = c.turn();
  let gameOver: CoachCard["gameOver"] = null;
  if (c.isCheckmate()) gameOver = { kind: "checkmate", winner: turn === "w" ? "b" : "w" };
  else if (c.isStalemate()) gameOver = { kind: "stalemate" };
  else if (c.isDraw()) gameOver = { kind: "draw" };

  const opponentMove = history ? describeLastMove(history) : factFromRawMove(lastMove);

  if (gameOver) {
    return {
      ...empty,
      turn,
      gameOver,
      opponentMove,
      abstained: false,
    };
  }

  const threat = buildThreatFact(fen);
  const picked = chooseSuggestion(fen, engineCandidates);
  if (!picked) {
    return { ...empty, turn, opponentMove, threat, abstained: true };
  }

  const future = buildFuture(fen, picked.suggestion, turn);

  return {
    fen,
    positionId,
    humanSide,
    turn,
    gameOver: null,
    opponentMove,
    threat,
    suggestion: picked.suggestion,
    reason: picked.reason,
    future,
    practice: {
      question: future.question,
      hintPieceType: picked.suggestion.pieceType,
      fromSquare: picked.suggestion.from,
      toSquare: picked.suggestion.to,
    },
    abstained: false,
  };
}

/** Re-validate a frozen card against the live board before showing it. */
export function cardStillValid(card: CoachCard | null, fen: string): boolean {
  if (!card) return false;
  if (card.fen !== fen) return false;
  if (!card.suggestion) return true;
  return isLegal(fen, card.suggestion.from, card.suggestion.to, card.suggestion.promotion);
}

export function moveCountFor(fen: string): number {
  return legalMoves(fen).length;
}

export type { LegalMove };
export function evaluateFor(fen: string, color: Color): number {
  const c = safeChess(fen);
  return c ? evaluate(c, color) : 0;
}
