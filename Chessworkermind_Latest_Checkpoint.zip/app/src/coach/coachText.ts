/**
 * ExplanationRenderer for the Coach card.
 *
 * Takes a language-neutral CoachCard + language + wording level and produces
 * short, easy sentences. Square names (e2, e4), SAN and FEN stay canonical in
 * every language; only the words around them change.
 *
 * Languages with human-written coach wording here: en, hi, es-MX, ar, fr.
 * Other supported UI languages fall back to English AND say so out loud
 * (never a silent English reply).
 */

import { Chess } from "chess.js";
import type { CoachCard, PlanKey, QuestionKey, ReasonKey } from "./coachCard";

export type WordingLevel = "beginner" | "deeper";

export const COACH_LANGUAGES = ["en", "hi", "es-MX", "ar", "fr"] as const;

export function hasCoachWording(tag: string): boolean {
  return (COACH_LANGUAGES as readonly string[]).includes(tag);
}
export function coachLangFor(tag: string): string {
  return hasCoachWording(tag) ? tag : "en";
}

type PieceWords = Record<string, string>;

type Pack = {
  piece: PieceWords;
  white: string;
  black: string;
  /** section titles */
  t1: (opp: string) => string;
  t2: string;
  t3: string;
  t4: string;
  t5: string;
  /** section 1 */
  moved: (piece: string, from: string, to: string) => string;
  movedCapture: (piece: string, from: string, to: string, victim: string) => string;
  movedCheck: string;
  movedCastle: (color: string) => string;
  movedEnPassant: string;
  movedPromote: (piece: string) => string;
  threatCapture: (piece: string, square: string, victim: string) => string;
  threatMate: (square: string) => string;
  threatCheckNow: string;
  noThreat: string;
  ifIgnored: (line: string) => string;
  /** section 2 */
  suggest: (piece: string, from: string, to: string) => string;
  suggestCapture: (piece: string, from: string, to: string, victim: string) => string;
  oneSafeIdea: string;
  alsoFine: (list: string) => string;
  showMe: string;
  moveForMe: string;
  /** section 3 */
  reason: Record<ReasonKey, (p: { piece: string; victim: string; a: string; b: string }) => string>;
  /** section 4 */
  ifThen: (their: string, ours: string) => string;
  ifOnly: (their: string) => string;
  theyMayChoose: string;
  plan: Record<PlanKey, string>;
  seeMore: string;
  /** section 5 */
  question: Record<QuestionKey, string>;
  tierThink: string;
  tierHint: (piece: string) => string;
  tierShow: (from: string, to: string) => string;
  tierDo: string;
  yourTurn: string;
  waitTurn: string;
  /** endings */
  youWon: string;
  youLost: string;
  drawn: string;
  fallbackNotice: (lang: string) => string;
  noAdvice: string;
};

const EN: Pack = {
  piece: { p: "pawn", n: "knight", b: "bishop", r: "rook", q: "queen", k: "king" },
  white: "White",
  black: "Black",
  t1: (opp) => `${opp} just moved`,
  t2: "Your move to try",
  t3: "Why this helps",
  t4: "What might happen next",
  t5: "Try it yourself",
  moved: (piece, from, to) => `Their ${piece} moved from ${from} to ${to}.`,
  movedCapture: (piece, from, to, victim) => `Their ${piece} moved from ${from} to ${to} and took your ${victim}.`,
  movedCheck: "This move attacks your king. You must answer the check.",
  movedCastle: (color) => `${color} castled — the king stepped to safety and the rook came out.`,
  movedEnPassant: "That was an en passant capture — a special pawn rule.",
  movedPromote: (piece) => `Their pawn reached the end and became a ${piece}.`,
  threatCapture: (piece, square, victim) => `If you leave this alone, their ${piece} can take your ${victim} on ${square}.`,
  threatMate: (square) => `Careful: they have a checkmate move to ${square}. You must stop it.`,
  threatCheckNow: "Your king is in check right now. You have to get out of it.",
  noThreat: "Nothing of yours is in danger right now. This is a calm moment.",
  ifIgnored: (line) => `Checked line: ${line}`,
  suggest: (piece, from, to) => `Move your ${piece} from ${from} to ${to}.`,
  suggestCapture: (piece, from, to, victim) => `Take with your ${piece}: ${from} to ${to}, capturing the ${victim}.`,
  oneSafeIdea: "This is one safe idea — other good moves exist too.",
  alsoFine: (list) => `These are just as good: ${list}.`,
  showMe: "Show me on the board",
  moveForMe: "Move it for me",
  reason: {
    mate: () => "This is checkmate. The game ends and you win.",
    escapeCheck: () => "Your king is being attacked. This move gets your king out of danger.",
    savesPiece: (p) => `Your ${p.piece} on ${p.a} could be taken. Moving it to ${p.b} saves it.`,
    defendsPiece: (p) => `This protects your ${p.piece} on ${p.a}. If they take it, you can take back.`,
    safeCapture: (p) => `You win their ${p.victim} and they cannot take your ${p.piece} back for free.`,
    castleSafety: () => "This puts your king behind its pawns, which is much safer.",
    develops: (p) => `Your ${p.piece} starts on the back row. Bringing it to ${p.b} lets it help.`,
    controlsCenter: (p) => `This helps you control the middle squares, where pieces are strongest.`,
    safeIdea: () => "This is a safe, simple move that does not lose anything.",
  },
  ifThen: (their, ours) => `If they play ${their}, you can try ${ours}.`,
  ifOnly: (their) => `They might answer with ${their}.`,
  theyMayChoose: "They may choose something else — always look again at the new board.",
  plan: {
    protect: "Plan: keep your pieces protected.",
    develop: "Plan: bring out the pieces still sitting at home.",
    center: "Plan: control the four middle squares.",
    kingSafety: "Plan: make your king safer.",
  },
  seeMore: "See more choices",
  question: {
    kingDanger: "Is my king in danger?",
    canITake: "Can I take something safely?",
    whatCanTheyTake: "What can they take from me?",
    whoNeedsHelp: "Which of my pieces needs help?",
  },
  tierThink: "Look at the board first. Tap what you notice.",
  tierHint: (piece) => `Hint: think about your ${piece}.`,
  tierShow: (from, to) => `Move from ${from} (1) to ${to} (2).`,
  tierDo: "Move it for me",
  yourTurn: "Your turn",
  waitTurn: "Thinking…",
  youWon: "Checkmate — you won! Well played.",
  youLost: "Checkmate — they won this one. Every game teaches something.",
  drawn: "The game is a draw. Nobody wins.",
  fallbackNotice: (lang) => `Coach wording is not available in ${lang} yet — showing English. Chess facts are the same.`,
  noAdvice: "No clear teaching point here. Just make a safe move you like.",
};

const HI: Pack = {
  ...EN,
  piece: { p: "प्यादा", n: "घोड़ा", b: "ऊँट", r: "हाथी", q: "वज़ीर", k: "राजा" },
  white: "सफ़ेद",
  black: "काला",
  t1: (opp) => `${opp} ने अभी चाल चली`,
  t2: "आपकी अगली चाल",
  t3: "यह क्यों मदद करता है",
  t4: "आगे क्या हो सकता है",
  t5: "अब आप कोशिश करें",
  moved: (piece, from, to) => `उनका ${piece} ${from} से ${to} पर गया।`,
  movedCapture: (piece, from, to, victim) => `उनका ${piece} ${from} से ${to} पर गया और आपका ${victim} ले लिया।`,
  movedCheck: "यह चाल आपके राजा पर हमला करती है। आपको जवाब देना होगा।",
  movedCastle: (color) => `${color} ने कैसलिंग की — राजा सुरक्षित हुआ और हाथी बाहर आया।`,
  movedEnPassant: "यह 'आन पासां' चाल थी — प्यादे का विशेष नियम।",
  movedPromote: (piece) => `उनका प्यादा अंत तक पहुँचा और ${piece} बन गया।`,
  threatCapture: (piece, square, victim) => `अगर आपने कुछ नहीं किया, तो उनका ${piece} ${square} पर आपका ${victim} ले सकता है।`,
  threatMate: (square) => `सावधान: उनके पास ${square} पर शह-मात की चाल है। इसे रोकें।`,
  threatCheckNow: "अभी आपके राजा को शह है। पहले उससे बाहर निकलें।",
  noThreat: "अभी आपका कुछ भी खतरे में नहीं है। यह शांत क्षण है।",
  ifIgnored: (line) => `जाँची गई लाइन: ${line}`,
  suggest: (piece, from, to) => `अपना ${piece} ${from} से ${to} पर ले जाएँ।`,
  suggestCapture: (piece, from, to, victim) => `अपने ${piece} से लें: ${from} से ${to}, ${victim} को काटते हुए।`,
  oneSafeIdea: "यह एक सुरक्षित विचार है — और भी अच्छी चालें हैं।",
  alsoFine: (list) => `ये भी उतनी ही अच्छी हैं: ${list}।`,
  showMe: "बोर्ड पर दिखाएँ",
  moveForMe: "मेरे लिए चाल चलें",
  reason: {
    mate: () => "यह शह-मात है। खेल खत्म, आप जीते।",
    escapeCheck: () => "आपके राजा पर हमला है। यह चाल उसे बचाती है।",
    savesPiece: (p) => `${p.a} पर आपका ${p.piece} कट सकता था। ${p.b} पर जाकर वह बच जाता है।`,
    defendsPiece: (p) => `यह ${p.a} पर आपके ${p.piece} की रक्षा करता है। अगर वे लेंगे, आप वापस ले सकते हैं।`,
    safeCapture: (p) => `आप उनका ${p.victim} जीतते हैं और वे आपका ${p.piece} मुफ़्त में नहीं ले सकते।`,
    castleSafety: () => "यह आपके राजा को प्यादों के पीछे सुरक्षित कर देता है।",
    develops: (p) => `आपका ${p.piece} पिछली पंक्ति में बैठा है। ${p.b} पर आकर वह काम करने लगेगा।`,
    controlsCenter: () => "यह बीच के चौकों पर आपका नियंत्रण बढ़ाता है, जहाँ मोहरे सबसे ताकतवर होते हैं।",
    safeIdea: () => "यह एक सरल, सुरक्षित चाल है जिसमें कुछ नहीं खोता।",
  },
  ifThen: (their, ours) => `अगर वे ${their} खेलें, तो आप ${ours} आज़मा सकते हैं।`,
  ifOnly: (their) => `वे ${their} खेल सकते हैं।`,
  theyMayChoose: "वे कुछ और भी चल सकते हैं — नए बोर्ड को हर बार दोबारा देखें।",
  plan: {
    protect: "योजना: अपने मोहरों की रक्षा करें।",
    develop: "योजना: घर पर बैठे मोहरों को बाहर लाएँ।",
    center: "योजना: बीच के चार चौकों पर कब्ज़ा करें।",
    kingSafety: "योजना: अपने राजा को सुरक्षित करें।",
  },
  seeMore: "और विकल्प देखें",
  question: {
    kingDanger: "क्या मेरा राजा खतरे में है?",
    canITake: "क्या मैं सुरक्षित रूप से कुछ ले सकता हूँ?",
    whatCanTheyTake: "वे मुझसे क्या ले सकते हैं?",
    whoNeedsHelp: "मेरे किस मोहरे को मदद चाहिए?",
  },
  tierThink: "पहले बोर्ड देखें। जो दिखे उस पर टैप करें।",
  tierHint: (piece) => `संकेत: अपने ${piece} के बारे में सोचें।`,
  tierShow: (from, to) => `${from} (1) से ${to} (2) पर चलें।`,
  tierDo: "मेरे लिए चाल चलें",
  yourTurn: "आपकी बारी",
  waitTurn: "सोच रहे हैं…",
  youWon: "शह-मात — आप जीत गए! बढ़िया खेल।",
  youLost: "शह-मात — इस बार वे जीते। हर खेल कुछ सिखाता है।",
  drawn: "खेल बराबरी पर रहा।",
  fallbackNotice: (lang) => `${lang} में कोच की भाषा अभी उपलब्ध नहीं — अंग्रेज़ी दिखाई जा रही है।`,
  noAdvice: "यहाँ कोई खास सीख नहीं है। कोई सुरक्षित चाल चलें।",
};

const ES: Pack = {
  ...EN,
  piece: { p: "peón", n: "caballo", b: "alfil", r: "torre", q: "dama", k: "rey" },
  white: "Blancas",
  black: "Negras",
  t1: (opp) => `${opp} acaba de jugar`,
  t2: "Tu jugada para intentar",
  t3: "Por qué ayuda",
  t4: "Qué puede pasar después",
  t5: "Inténtalo tú",
  moved: (piece, from, to) => `Su ${piece} fue de ${from} a ${to}.`,
  movedCapture: (piece, from, to, victim) => `Su ${piece} fue de ${from} a ${to} y capturó tu ${victim}.`,
  movedCheck: "Esta jugada ataca a tu rey. Tienes que responder al jaque.",
  movedCastle: (color) => `${color} enrocó — el rey se puso a salvo y la torre salió.`,
  movedEnPassant: "Fue una captura al paso — una regla especial del peón.",
  movedPromote: (piece) => `Su peón llegó al final y se convirtió en ${piece}.`,
  threatCapture: (piece, square, victim) => `Si no haces nada, su ${piece} puede tomar tu ${victim} en ${square}.`,
  threatMate: (square) => `Cuidado: tienen jaque mate jugando a ${square}. Hay que impedirlo.`,
  threatCheckNow: "Tu rey está en jaque ahora mismo. Primero sal del jaque.",
  noThreat: "Nada tuyo está en peligro ahora. Es un momento tranquilo.",
  ifIgnored: (line) => `Línea verificada: ${line}`,
  suggest: (piece, from, to) => `Mueve tu ${piece} de ${from} a ${to}.`,
  suggestCapture: (piece, from, to, victim) => `Captura con tu ${piece}: de ${from} a ${to}, tomando el ${victim}.`,
  oneSafeIdea: "Es una idea segura — también hay otras buenas jugadas.",
  alsoFine: (list) => `Estas son igual de buenas: ${list}.`,
  showMe: "Muéstramelo en el tablero",
  moveForMe: "Muévelo por mí",
  reason: {
    mate: () => "Esto es jaque mate. La partida termina y ganas.",
    escapeCheck: () => "Tu rey está atacado. Esta jugada lo pone a salvo.",
    savesPiece: (p) => `Tu ${p.piece} en ${p.a} podía caer. Llevarlo a ${p.b} lo salva.`,
    defendsPiece: (p) => `Esto protege tu ${p.piece} en ${p.a}. Si lo toman, puedes recapturar.`,
    safeCapture: (p) => `Ganas su ${p.victim} y no pueden tomar tu ${p.piece} gratis.`,
    castleSafety: () => "Pone a tu rey detrás de sus peones, mucho más seguro.",
    develops: (p) => `Tu ${p.piece} está en la fila de atrás. Llevarlo a ${p.b} lo pone a trabajar.`,
    controlsCenter: () => "Te ayuda a controlar las casillas centrales, donde las piezas son más fuertes.",
    safeIdea: () => "Es una jugada simple y segura que no pierde nada.",
  },
  ifThen: (their, ours) => `Si juegan ${their}, puedes probar ${ours}.`,
  ifOnly: (their) => `Podrían responder con ${their}.`,
  theyMayChoose: "Pueden elegir otra cosa — mira siempre el tablero nuevo.",
  plan: {
    protect: "Plan: mantén tus piezas protegidas.",
    develop: "Plan: saca las piezas que siguen en casa.",
    center: "Plan: controla las cuatro casillas centrales.",
    kingSafety: "Plan: pon a tu rey más seguro.",
  },
  seeMore: "Ver más opciones",
  question: {
    kingDanger: "¿Está mi rey en peligro?",
    canITake: "¿Puedo capturar algo con seguridad?",
    whatCanTheyTake: "¿Qué me pueden capturar?",
    whoNeedsHelp: "¿Qué pieza mía necesita ayuda?",
  },
  tierThink: "Mira primero el tablero. Toca lo que notes.",
  tierHint: (piece) => `Pista: piensa en tu ${piece}.`,
  tierShow: (from, to) => `Mueve de ${from} (1) a ${to} (2).`,
  tierDo: "Muévelo por mí",
  yourTurn: "Tu turno",
  waitTurn: "Pensando…",
  youWon: "Jaque mate — ¡ganaste! Bien jugado.",
  youLost: "Jaque mate — esta vez ganaron ellos. Cada partida enseña algo.",
  drawn: "La partida es tablas. Nadie gana.",
  fallbackNotice: (lang) => `El texto del coach aún no existe en ${lang} — se muestra en inglés.`,
  noAdvice: "Aquí no hay una lección clara. Haz una jugada segura que te guste.",
};

const AR: Pack = {
  ...EN,
  piece: { p: "بيدق", n: "حصان", b: "فيل", r: "رخ", q: "وزير", k: "ملك" },
  white: "الأبيض",
  black: "الأسود",
  t1: (opp) => `${opp} لعب للتو`,
  t2: "نقلتك المقترحة",
  t3: "لماذا تساعد",
  t4: "ماذا قد يحدث بعد ذلك",
  t5: "جرّب بنفسك",
  moved: (piece, from, to) => `تحرّك ${piece} من ${from} إلى ${to}.`,
  movedCapture: (piece, from, to, victim) => `تحرّك ${piece} من ${from} إلى ${to} وأخذ ${victim} الخاص بك.`,
  movedCheck: "هذه النقلة تهاجم ملكك. يجب أن تردّ على الكش.",
  movedCastle: (color) => `${color} قام بالتبييت — الملك أصبح آمناً وخرج الرخ.`,
  movedEnPassant: "كان هذا أخذاً بالمرور — قاعدة خاصة بالبيدق.",
  movedPromote: (piece) => `وصل بيدقهم إلى النهاية وتحوّل إلى ${piece}.`,
  threatCapture: (piece, square, victim) => `إذا تركت الأمر، يستطيع ${piece} أخذ ${victim} على ${square}.`,
  threatMate: (square) => `انتبه: لديهم كش مات باللعب إلى ${square}. يجب منعه.`,
  threatCheckNow: "ملكك في كش الآن. عليك الخروج منه أولاً.",
  noThreat: "لا شيء لديك في خطر الآن. هذه لحظة هادئة.",
  ifIgnored: (line) => `خط تم التحقق منه: ${line}`,
  suggest: (piece, from, to) => `حرّك ${piece} من ${from} إلى ${to}.`,
  suggestCapture: (piece, from, to, victim) => `خذ بـ ${piece}: من ${from} إلى ${to}، آخذاً ${victim}.`,
  oneSafeIdea: "هذه فكرة آمنة — توجد نقلات جيدة أخرى أيضاً.",
  alsoFine: (list) => `هذه جيدة بالمثل: ${list}.`,
  showMe: "أرِني على الرقعة",
  moveForMe: "حرّكها نيابة عني",
  reason: {
    mate: () => "هذا كش مات. تنتهي المباراة وتفوز.",
    escapeCheck: () => "ملكك مهاجَم. هذه النقلة تخرجه من الخطر.",
    savesPiece: (p) => `${p.piece} على ${p.a} كان يمكن أخذه. نقله إلى ${p.b} ينقذه.`,
    defendsPiece: (p) => `هذا يحمي ${p.piece} على ${p.a}. إذا أخذوه يمكنك الأخذ بالمقابل.`,
    safeCapture: (p) => `تكسب ${p.victim} ولا يمكنهم أخذ ${p.piece} مجاناً.`,
    castleSafety: () => "يضع ملكك خلف بيادقه، وهو أكثر أماناً.",
    develops: (p) => `${p.piece} ما زال في الصف الخلفي. نقله إلى ${p.b} يجعله يعمل.`,
    controlsCenter: () => "يساعدك على السيطرة على المربعات الوسطى حيث تكون القطع أقوى.",
    safeIdea: () => "نقلة بسيطة وآمنة لا تخسر شيئاً.",
  },
  ifThen: (their, ours) => `إذا لعبوا ${their}، يمكنك تجربة ${ours}.`,
  ifOnly: (their) => `قد يردّون بـ ${their}.`,
  theyMayChoose: "قد يختارون شيئاً آخر — انظر دائماً إلى الوضع الجديد.",
  plan: {
    protect: "الخطة: احمِ قطعك.",
    develop: "الخطة: أخرج القطع التي ما زالت في مكانها.",
    center: "الخطة: سيطر على المربعات الأربعة الوسطى.",
    kingSafety: "الخطة: اجعل ملكك أكثر أماناً.",
  },
  seeMore: "عرض خيارات أخرى",
  question: {
    kingDanger: "هل ملكي في خطر؟",
    canITake: "هل أستطيع الأخذ بأمان؟",
    whatCanTheyTake: "ماذا يمكنهم أن يأخذوا مني؟",
    whoNeedsHelp: "أي قطعة لديّ تحتاج مساعدة؟",
  },
  tierThink: "انظر إلى الرقعة أولاً. المس ما تلاحظه.",
  tierHint: (piece) => `تلميح: فكّر في ${piece}.`,
  tierShow: (from, to) => `انقل من ${from} (1) إلى ${to} (2).`,
  tierDo: "حرّكها نيابة عني",
  yourTurn: "دورك",
  waitTurn: "يفكر…",
  youWon: "كش مات — لقد فزت! أحسنت.",
  youLost: "كش مات — فازوا هذه المرة. كل مباراة تعلّم شيئاً.",
  drawn: "انتهت المباراة بالتعادل.",
  fallbackNotice: (lang) => `نص المدرب غير متوفر بعد بلغة ${lang} — يتم عرض الإنجليزية.`,
  noAdvice: "لا يوجد درس واضح هنا. العب نقلة آمنة تعجبك.",
};

const FR: Pack = {
  ...EN,
  piece: { p: "pion", n: "cavalier", b: "fou", r: "tour", q: "dame", k: "roi" },
  white: "Les Blancs",
  black: "Les Noirs",
  t1: (opp) => `${opp} viennent de jouer`,
  t2: "Ton coup à essayer",
  t3: "Pourquoi ça aide",
  t4: "Ce qui peut arriver ensuite",
  t5: "À toi d'essayer",
  moved: (piece, from, to) => `Leur ${piece} est allé de ${from} à ${to}.`,
  movedCapture: (piece, from, to, victim) => `Leur ${piece} est allé de ${from} à ${to} et a pris ton ${victim}.`,
  movedCheck: "Ce coup attaque ton roi. Tu dois répondre à l'échec.",
  movedCastle: (color) => `${color} ont roqué — le roi est à l'abri et la tour entre en jeu.`,
  movedEnPassant: "C'était une prise en passant — une règle spéciale du pion.",
  movedPromote: (piece) => `Leur pion est arrivé au bout et devient ${piece}.`,
  threatCapture: (piece, square, victim) => `Si tu ne fais rien, leur ${piece} peut prendre ton ${victim} en ${square}.`,
  threatMate: (square) => `Attention : ils ont un échec et mat en jouant en ${square}. Il faut l'empêcher.`,
  threatCheckNow: "Ton roi est en échec. Il faut d'abord en sortir.",
  noThreat: "Rien à toi n'est en danger pour l'instant. C'est un moment calme.",
  ifIgnored: (line) => `Ligne vérifiée : ${line}`,
  suggest: (piece, from, to) => `Déplace ton ${piece} de ${from} à ${to}.`,
  suggestCapture: (piece, from, to, victim) => `Prends avec ton ${piece} : de ${from} à ${to}, en capturant le ${victim}.`,
  oneSafeIdea: "C'est une idée sûre — d'autres bons coups existent aussi.",
  alsoFine: (list) => `Ceux-ci sont aussi bons : ${list}.`,
  showMe: "Montre-moi sur l'échiquier",
  moveForMe: "Joue-le pour moi",
  reason: {
    mate: () => "C'est échec et mat. La partie est finie, tu gagnes.",
    escapeCheck: () => "Ton roi est attaqué. Ce coup le met hors de danger.",
    savesPiece: (p) => `Ton ${p.piece} en ${p.a} pouvait être pris. L'amener en ${p.b} le sauve.`,
    defendsPiece: (p) => `Cela protège ton ${p.piece} en ${p.a}. S'ils prennent, tu reprends.`,
    safeCapture: (p) => `Tu gagnes leur ${p.victim} et ils ne peuvent pas prendre ton ${p.piece} gratuitement.`,
    castleSafety: () => "Cela met ton roi derrière ses pions, bien plus en sécurité.",
    develops: (p) => `Ton ${p.piece} est encore au fond. L'amener en ${p.b} le met au travail.`,
    controlsCenter: () => "Cela t'aide à contrôler les cases du centre, où les pièces sont les plus fortes.",
    safeIdea: () => "Un coup simple et sûr qui ne perd rien.",
  },
  ifThen: (their, ours) => `S'ils jouent ${their}, tu peux essayer ${ours}.`,
  ifOnly: (their) => `Ils pourraient répondre ${their}.`,
  theyMayChoose: "Ils peuvent choisir autre chose — regarde toujours le nouvel échiquier.",
  plan: {
    protect: "Plan : garde tes pièces protégées.",
    develop: "Plan : sors les pièces encore à la maison.",
    center: "Plan : contrôle les quatre cases centrales.",
    kingSafety: "Plan : mets ton roi plus en sécurité.",
  },
  seeMore: "Voir d'autres choix",
  question: {
    kingDanger: "Mon roi est-il en danger ?",
    canITake: "Puis-je prendre quelque chose sans risque ?",
    whatCanTheyTake: "Que peuvent-ils me prendre ?",
    whoNeedsHelp: "Quelle pièce a besoin d'aide ?",
  },
  tierThink: "Regarde d'abord l'échiquier. Touche ce que tu remarques.",
  tierHint: (piece) => `Indice : pense à ton ${piece}.`,
  tierShow: (from, to) => `Déplace de ${from} (1) à ${to} (2).`,
  tierDo: "Joue-le pour moi",
  yourTurn: "À toi",
  waitTurn: "Réflexion…",
  youWon: "Échec et mat — tu as gagné ! Bien joué.",
  youLost: "Échec et mat — ils gagnent cette fois. Chaque partie apprend quelque chose.",
  drawn: "La partie est nulle. Personne ne gagne.",
  fallbackNotice: (lang) => `Le texte du coach n'existe pas encore en ${lang} — affichage en anglais.`,
  noAdvice: "Pas de leçon claire ici. Joue un coup sûr qui te plaît.",
};

const PACKS: Record<string, Pack> = { en: EN, hi: HI, "es-MX": ES, ar: AR, fr: FR };

export function pack(tag: string): Pack {
  return PACKS[coachLangFor(tag)] ?? EN;
}

export function pieceWord(tag: string, type: string): string {
  return pack(tag).piece[type] ?? type;
}

export type RenderedCard = {
  /** Section 1 */
  s1Title: string;
  s1Lines: string[];
  threatLine: string;
  threatIsReal: boolean;
  /** Section 2 */
  s2Title: string;
  s2Line: string;
  s2Note?: string;
  s2Alternatives?: string;
  showMeLabel: string;
  moveForMeLabel: string;
  /** Section 3 */
  s3Title: string;
  s3Line: string;
  /** Section 4 */
  s4Title: string;
  s4Lines: string[];
  s4Caveat: string;
  s4Plan: string;
  seeMoreLabel: string;
  /** Section 5 */
  s5Title: string;
  s5Question: string;
  tier1: string;
  tier2: string;
  tier3: string;
  tier4: string;
  /** end / meta */
  endLine?: string;
  fallbackNotice?: string;
};

/** Render a frozen CoachCard into the learner's language. */
export function renderCoachCard(
  card: CoachCard,
  tag: string,
  level: WordingLevel = "beginner",
  languageNameForFallback?: string,
): RenderedCard {
  const P = pack(tag);
  const oppColor = card.turn === "w" ? P.black : P.white;
  const w = (t?: string) => (t ? P.piece[t] ?? t : "");

  const s1Lines: string[] = [];
  const om = card.opponentMove;
  if (om) {
    if (om.captured) s1Lines.push(P.movedCapture(w(om.pieceType), om.from, om.to, w(om.captured)));
    else if (om.isCastle) s1Lines.push(P.movedCastle(om.color === "w" ? P.white : P.black));
    else s1Lines.push(P.moved(w(om.pieceType), om.from, om.to));
    if (om.isEnPassant) s1Lines.push(P.movedEnPassant);
    if (om.promotion) s1Lines.push(P.movedPromote(w(om.promotion)));
    if (om.isCheck && !om.isMate) s1Lines.push(P.movedCheck);
  }

  let threatLine = P.noThreat;
  const th = card.threat.threat;
  if (card.threat.present && th) {
    if (th.kind === "mate") threatLine = P.threatMate(th.to);
    else if (th.kind === "check") threatLine = P.threatCheckNow;
    else threatLine = P.threatCapture(w(pieceTypeAt(card.fen, th.from)), th.to, w(th.capturedPiece ?? "p"));
  }

  const sg = card.suggestion;
  const s2Line = sg
    ? sg.isCapture
      ? P.suggestCapture(w(sg.pieceType), sg.from, sg.to, w(sg.captured ?? "p"))
      : P.suggest(w(sg.pieceType), sg.from, sg.to)
    : P.noAdvice;

  const s3Line = card.reason
    ? P.reason[card.reason.key]({
        piece: w(card.reason.pieceType),
        victim: w(card.reason.capturedType ?? "p"),
        a: card.reason.squares[0] ?? "",
        b: card.reason.squares[1] ?? "",
      })
    : P.noAdvice;

  const s4Lines: string[] = [];
  const maxLines = level === "beginner" ? 1 : 2;
  for (const line of (card.future?.lines ?? []).slice(0, maxLines)) {
    if (line.ourReply) s4Lines.push(P.ifThen(line.theirMove.san, line.ourReply.san));
    else s4Lines.push(P.ifOnly(line.theirMove.san));
  }

  let endLine: string | undefined;
  if (card.gameOver) {
    if (card.gameOver.kind === "checkmate") {
      endLine = card.gameOver.winner === card.humanSide ? P.youWon : P.youLost;
    } else {
      endLine = P.drawn;
    }
  }

  return {
    s1Title: P.t1(oppColor),
    s1Lines,
    threatLine,
    threatIsReal: card.threat.present,
    s2Title: P.t2,
    s2Line,
    s2Note: sg?.severalSound ? P.oneSafeIdea : undefined,
    s2Alternatives:
      sg && sg.alternatives.length > 0 ? P.alsoFine(sg.alternatives.map((a) => a.san).join(", ")) : undefined,
    showMeLabel: P.showMe,
    moveForMeLabel: P.moveForMe,
    s3Title: P.t3,
    s3Line,
    s4Title: P.t4,
    s4Lines,
    s4Caveat: P.theyMayChoose,
    s4Plan: card.future ? P.plan[card.future.plan] : "",
    seeMoreLabel: P.seeMore,
    s5Title: P.t5,
    s5Question: card.practice ? P.question[card.practice.question] : P.question.whoNeedsHelp,
    tier1: P.tierThink,
    tier2: card.practice ? P.tierHint(w(card.practice.hintPieceType)) : "",
    tier3: card.practice ? P.tierShow(card.practice.fromSquare, card.practice.toSquare) : "",
    tier4: P.tierDo,
    endLine,
    fallbackNotice: hasCoachWording(tag)
      ? undefined
      : P.fallbackNotice(languageNameForFallback ?? tag),
  };
}

function pieceTypeAt(fen: string, square: string): string {
  try {
    const c = new Chess(fen);
    return c.get(square as never)?.type ?? "p";
  } catch {
    return "p";
  }
}
