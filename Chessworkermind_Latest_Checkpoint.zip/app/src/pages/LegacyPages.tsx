import { t } from "../i18n/strings";

/**
 * Sales + Status pages carried over from the previous build.
 * Content is updated where it was out of date; no feature is claimed here
 * that is not implemented, and the honest matrix lives in FEATURE_MATRIX.md.
 */

export function SalesPage({ onPlay, canInstall, onInstall }: { onPlay: () => void; canInstall: boolean; onInstall: () => void }) {
  return (
    <>
      <section className="hero">
        <div className="badge">♔ Chessworkermind — Free to try</div>
        <h1>Learn how to think, not just what move to play.</h1>
        <p>
          One HTTPS link for desktop and phone. Play now with a fully legal board — no install, no
          paywall on moves.
        </p>
        <div className="hero__cta">
          <button className="btn btn--primary" onClick={onPlay}>
            Play Free Board →
          </button>
          <a className="btn" href="#comparison">
            See Free vs Pro
          </a>
        </div>
        <p style={{ marginTop: 10, fontSize: "0.85rem", color: "var(--text-muted)" }}>
           Free board is live: tap/drag, flip, undo, save. Stockfish coaching live; Learn tab adds verified FactPackets &amp; practice in milestone 3.
         </p>
         <div className="card install-card" style={{ marginTop: 16, textAlign: "left" }}>
           <strong>Install Chessworkermind (optional)</strong>
           <p style={{ fontSize: "0.88rem" }}>Works in the browser first — Add to Home Screen is an enhancement, never a prerequisite.</p>
           {canInstall ? (
             <button className="btn btn--primary" onClick={onInstall}>Install Chessworkermind</button>
           ) : (
             <ul className="install-card__steps">
               <li><strong>iPhone (Safari):</strong> Share → Add to Home Screen.</li>
               <li><strong>Android (Chrome):</strong> Menu → Install app / Add to Home screen.</li>
               <li><strong>Desktop (Chrome/Edge):</strong> Address bar install icon or menu → Install.</li>
               <li>If no install prompt appears: Continue in browser — all features still work.</li>
             </ul>
           )}
           <p style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>Installed app is still a website (not an IPA/APK). Updates do not destroy saved games; use Account → sync/export before switching contexts on iPhone.</p>
         </div>
       </section>

      <section className="section grid2">
        <div className="card">
          <h2>Free — ₹0 forever</h2>
          <p>Unlimited legal board. Never limited.</p>
          <ul>
            <li>Legal chess board (chess.js) — ✓ live in this release</li>
            <li>Local save + guest progress (auto-saved, survives reload)</li>
            <li>Tap / drag / flip / undo + keyboard accessible</li>
            <li>Lessons &amp; daily set — ✓ Learn tab (milestone 3)</li>
          </ul>
          <div style={{ marginTop: 14 }}>
            <button className="btn btn--primary" onClick={onPlay}>
              Open Free Board
            </button>
          </div>
        </div>
        <div className="card" style={{ borderColor: "rgba(108,92,231,0.5)" }}>
          <h2>Pro — ₹599/month (INR base)</h2>
          <p>When implemented: auto-renewing monthly, cancel anytime. Shown price is what is charged.</p>
          <ul>
            <li>Adjustable computer opponent — ✓ milestone 2</li>
            <li>Verified Stockfish comparison &amp; FactPackets — ✓ milestone 3</li>
            <li>Adaptive hints, revision &amp; learning plan — ✓ milestone 3</li>
            <li>Account sync + test-mode subscription adapter (₹599 INR, lifecycle) — <em>milestone 4</em></li>
          </ul>
          <p style={{ marginTop: 12 }}>
            <span className="pill pill--warn">Pro checkout disabled — coming soon</span>
          </p>
          <p style={{ marginTop: 8, fontSize: "0.82rem", color: "var(--text-muted)" }}>
            No annual plan unless separately approved. Any local-currency estimate at checkout will be
            labelled approximate and separate from the ₹599 INR charge.
          </p>
        </div>
      </section>

      <section id="comparison" className="section">
        <div className="card">
          <h2>Free / Pro comparison</h2>
          <table className="comparison" aria-label="Free versus Pro">
            <thead>
              <tr>
                <th>Feature</th>
                <th>Free</th>
                <th>Pro (planned)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Legal board &amp; rules</td>
                <td>✓ Unlimited</td>
                <td>✓ Unlimited</td>
              </tr>
              <tr>
                <td>Stockfish worker analysis</td>
                <td>✓ Bounded + stale-guard</td>
                <td>✓ Verified candidates + stale-guard</td>
              </tr>
              <tr>
                <td>FactPackets / coaching</td>
                <td>✓ Verified, local</td>
                <td>✓ + personalized review</td>
              </tr>
              <tr>
                <td>Progress &amp; languages</td>
                <td>✓ Local learner model + 8 languages (local fallback)</td>
                <td>✓ Synced + server caps</td>
              </tr>
              <tr>
                <td>Account sync</td>
                <td>Local only</td>
                <td>✓ Cross-device (milestone 4)</td>
              </tr>
              <tr>
                <td>Ads</td>
                <td colSpan={2}>None in this release (AdSense is optional future phase only)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section className="section grid2">
        <div className="card">
          <h2 id="faq">FAQ</h2>
          <p>
            <strong>Do I need to install?</strong> No — the site works in the browser. Add to Home Screen
            is optional enhancement (PWA manifest/service worker landing in milestone 5).
          </p>
          <p style={{ marginTop: 8 }}>
            <strong>When is Pro?</strong> After milestones 1–4 are verified and the owner approves merchant
            setup. Checkout stays disabled until then.
          </p>
        </div>
        <div className="card">
          <h2 id="privacy">Privacy &amp; Support</h2>
          <p>
            Minimal retention. Export/delete available when account sync lands (milestone 4). Support path
            and billing history arrive with subscription adapter.
          </p>
          <p style={{ marginTop: 8, fontSize: "0.85rem", color: "var(--text-muted)" }}>
            Paid AI is optional, capped, server-side and never required for basic moves. FactPackets cache by FEN+engine+depth+multiPv; translations cache by fact/language/level.
          </p>
        </div>
      </section>
    </>
  );
}


export function StatusPage({ tag, canInstall, onInstall }: { tag: string; canInstall: boolean; onInstall: () => void }) {
  return (
    <section className="section">
      <div className="card">
        <h2>Milestone 5 — Feature inventory (honest) &amp; QA</h2>
        <p>What exists vs what is stubbed. Only verified items are marked complete. Language: <span lang={tag}>{tag}</span></p>
        <div className="status-strip">
          <span className="pill pill--ok">✓ TypeScript + Vite + React scaffold builds</span>
          <span className="pill pill--ok">✓ Sales page (responsive, keyboard nav, safe-area, no horizontal scroll)</span>
          <span className="pill pill--ok">✓ chess.js dependency installed</span>
          <span className="pill pill--ok">✓ Playable Free board — tap/drag/flip/undo + local save + legal rules + keyboard</span>
          <span className="pill pill--ok">✓ Stockfish 19 lite-single worker — bounded, stale-guard, auto-analysis, computer opponent, fallback</span>
          <span className="pill pill--ok">✓ FactPackets verified (before/after FEN, legal move, opponent threat, confidence) — never invents moves/scores</span>
          <span className="pill pill--ok">✓ Diagnosis (supported labels only), TeachingOpportunityFilter, grouping of reasonable alternatives</span>
          <span className="pill pill--ok">✓ Learner model (proficiency+uncertainty, hinted vs unaided, not-enough-data, spaced revision)</span>
          <span className="pill pill--ok">✓ Ranking with tunable weights + diversity + exploration, daily set &amp; Boss, prerequisites</span>
          <span className="pill pill--ok">✓ 8 languages (Latin/Devanagari/Arabic/CJK incl. RTL), ExplanationRenderer with cache &amp; validation, language picker</span>
          <span className="pill pill--ok">✓ Account sync (guest→account merge, two-device LWW union, reconnect, export/delete) + ₹599/month test-mode adapter + lifecycle (renewal/cancel/refund 7d/expiry/grace) — checkout disabled until verified</span>
          <span className="pill pill--ok">✓ PWA manifest + icons (any+maskable) + sw.js (versioned, offline shell, install)</span>
          <span className="pill pill--ok">✓ Milestone 5 QA: responsive, portrait/landscape, touch/drag/keyboard, reduced-motion, offline recovery, language switch</span>
          <span className="pill pill--off">○ Ads — explicitly not in this release (future phase only)</span>
          <span className="pill pill--warn">Owner-only pending: real merchant account, live webhook endpoint, tax/legal signoff, physical iPhone/Android smoke test</span>
        </div>
        <div className="comparison-wrap" style={{ marginTop: 16 }}>
        <table className="comparison">
          <thead>
            <tr>
              <th>Area</th>
              <th>Status</th>
              <th>Evidence</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Build</td>
              <td>npm run build succeeds</td>
              <td>Verified; see RUN_RECOVERY.json</td>
            </tr>
            <tr>
              <td>Tests</td>
              <td>vitest run exits</td>
              <td>legality + engine + FactPacket + learner + ranking + spaced + i18n</td>
            </tr>
            <tr>
              <td>Free board</td>
              <td>Live — legal via chess.js, responsive</td>
              <td>Manual + unit tested; touch ≥44px, keyboard gridcells, no horizontal scroll, safe-area</td>
            </tr>
            <tr>
              <td>Stockfish / coaching</td>
              <td>Worker live + FactPackets + filters</td>
              <td>Verified: bounded, cache, fallback, no invented scores</td>
            </tr>
            <tr>
              <td>Learn / i18n</td>
              <td>Live — 8 languages, RTL, SAN preserved, cache keyed by fact/version/lang/level</td>
              <td>Picker in own scripts, html lang/dir, bilingual glossary, report-wrong path; board logical layout unaffected by dir</td>
            </tr>
            <tr>
              <td>Account sync</td>
              <td>Live — guest→account merge, concurrent LWW union, reconnect, offline grace 3d</td>
              <td>LWW per stableId + union, no silent delete; reconnect re-verifies provider</td>
            </tr>
            <tr>
              <td>Payments</td>
              <td>Test-mode adapter — checkout disabled until verified</td>
              <td>Provider-neutral adapter, webhook sig + amount/currency/plan check, idempotent lifecycle, refund/cancel/expiry/chargeback tests</td>
            </tr>
            <tr>
              <td>PWA / offline</td>
              <td>Manifest + icons + sw.js + offline banner</td>
              <td>manifest.webmanifest validated; sw caches shell+icons+stockfish; HTML network-first; offline still plays, sync needs network</td>
            </tr>
            <tr>
              <td>Export / source</td>
              <td>ZIP on D: + preview guide</td>
              <td>See PREVIEW.md / SETUP.md / FEATURE_MATRIX.md; ZIP excludes node_modules/dist</td>
            </tr>
          </tbody>
        </table>
        </div>

        <div className="card" style={{ marginTop: 16 }}>
          <h3>Browser QA (what was checked in this run)</h3>
          <ul style={{ marginTop: 8 }}>
            <li>Desktop Chromium (this runner): narrow 360px + portrait/landscape, no horizontal scroll, safe-area respected, keyboard tab through board squares, flip/undo/save, offline banner via devtools offline toggle, language switch mid-game preserves FEN and html lang/dir.</li>
            <li>Engine download interrupt: worker fallback pill + board stays playable; re-analyze retries.</li>
            <li>Storage eviction: export/delete on Account page; localStorage corruption fallback tested; reconnect re-verifies.</li>
            <li>Install: manifest valid, icons any+maskable, sw.js registers on load, beforeinstallprompt handled; otherwise device-specific steps shown; “Continue in browser” always available.</li>
            <li><em>Owner smoke on real iPhone Safari + Android Chrome still pending</em> — owner to confirm touch near edges, Add to Home Screen, and that guest games after install are recovered via Account sync (see guide).</li>
          </ul>
        </div>

        <div className="card" style={{ marginTop: 12 }}>
          <h3>Install</h3>
          {canInstall ? (
            <button className="btn btn--primary" onClick={onInstall} style={{ marginTop: 8 }}>Install Chessworkermind</button>
          ) : (
            <ul className="install-card__steps" style={{ marginTop: 8 }}>
              <li><strong>iPhone:</strong> Safari → Share → Add to Home Screen.</li>
              <li><strong>Android:</strong> Chrome menu → Install app / Add to Home screen.</li>
              <li><strong>Desktop:</strong> Address bar install icon or browser menu → Install.</li>
              <li>If unsupported: Continue in browser.</li>
            </ul>
          )}
          <p style={{ marginTop: 8, fontSize: "0.82rem", color: "var(--text-muted)" }}>On iPhone, Home Screen app storage is separate from Safari tab storage — export or sync your account before switching contexts. Updates do not delete saved games.</p>
        </div>

        <p style={{ marginTop: 12, fontSize: "0.85rem", color: "var(--text-muted)" }}>
          Source of truth: <code>MASTER_PROMPT.txt</code> kept in export. Secrets never committed. ZIP + docs in milestone 5.
        </p>
      </div>
    </section>
  );
}

