import { test, expect, type Page } from "@playwright/test";
import { Chess } from "chess.js";
import fs from "node:fs";
const KEY="chessworkermind:game:v2";
const sq=(page:Page,s:string)=>page.getByRole("gridcell",{name:new RegExp(`^${s},`)});
const nav=(page:Page,name:string)=>page.getByRole("navigation",{name:"Main",exact:true}).getByRole("button",{name,exact:true});
const saved=(page:Page)=>page.evaluate(key=>JSON.parse(localStorage.getItem(key)!),KEY);
async function boot(page:Page,computer=true) {
  await page.addInitScript(({key,computer,fen})=>{
    if (!sessionStorage.getItem('test-boot')) {
      localStorage.setItem("chessworkermind:onboarded:v2","1");
      localStorage.setItem(key,JSON.stringify({fen,pgn:"",orientation:"w",mode:computer?"vsComputer":"solo",humanSide:"w",updatedAt:new Date().toISOString()}));
      sessionStorage.setItem('test-boot','1');
    }
  },{key:KEY,computer,fen:new Chess().fen()});
  await page.goto("/",{waitUntil:"domcontentloaded"});
}

test("real Stockfish turn, discovery, isolated retry, persistence and narrow layout",async({page})=>{
  await page.setViewportSize({width:393,height:851});
  await boot(page);await nav(page,"Train").click();
  await sq(page,"e2").click();await sq(page,"e4").click();
  await expect.poll(async()=>{const p=await saved(page);return new Chess(p.fen).turn();}).toBe("w");
  const snapshot=await saved(page);const game=new Chess();game.loadPgn(snapshot.pgn);
  expect(game.history()).toHaveLength(2);
  await expect(page.getByText("Last computer reply: Stockfish",{exact:true})).toBeVisible();
  await page.waitForTimeout(1200);expect((await saved(page)).fen).toBe(snapshot.fen);
  await expect(page.getByText("Explore this exact position",{exact:true})).toBeVisible();
  await page.getByText("Explore this exact position",{exact:true}).click();
  await page.getByRole("button",{name:"Show me where to look",exact:true}).click();
  await expect(page.getByText("BOARD FACT",{exact:true})).toBeVisible();
  // Generated from the actual engine reply, not a canned continuation.
  const live=new Chess(snapshot.fen),candidate=live.moves({verbose:true})[0];
  const uci=`${candidate.from}${candidate.to}${candidate.promotion??""}`;
  await page.getByLabel("Candidate check — choose a legal idea").selectOption(uci);
  await page.getByRole("button",{name:"If I play this…",exact:true}).click();
  await page.getByRole("button",{name:"Next move",exact:true}).click();
  await expect(page.getByText(/Conditional continuation, step 1/)).toBeVisible();
  await page.getByRole("button",{name:"Retry from original position",exact:true}).click();
  await expect(page.getByText("Separate practice board. Your original game and move history are unchanged.")).toBeVisible();
  expect((await saved(page)).pgn).toBe(snapshot.pgn);
  await page.getByRole("button",{name:"Return to current position",exact:true}).click();
  await page.getByRole("button",{name:/Focus mode/}).click();
  await expect(page.getByText("All hints and highlights are hidden. Just you and the board.")).toBeVisible();
  await page.screenshot({path:"qa/mobile-train.png",fullPage:true});
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  await page.reload({waitUntil:"domcontentloaded"});expect((await saved(page)).fen).toBe(snapshot.fen);
  fs.writeFileSync("qa/live-loop.json",JSON.stringify({fen:snapshot.fen,pgn:snapshot.pgn,opponent:game.history()[1],candidate:uci,source:"real Stockfish browser worker",savedHistoryUnchanged:true},null,2));
});

test("all ten numeric strengths own exactly one real legal Black reply",async({page})=>{
  test.setTimeout(180000);
  await boot(page);await nav(page,"Train").click();
  const evidence=[];
  for(let tier=1;tier<=10;tier++) {
    await page.getByText(/Train settings ·/).click();
    await page.getByLabel("Computer strength (1–10)").selectOption(String(tier));
    await page.getByText(/Train settings ·/).click();
    await sq(page,"d2").click();await sq(page,"d4").click();
    await expect.poll(async()=>new Chess((await saved(page)).fen).turn()).toBe("w");
    const p=await saved(page),c=new Chess();c.loadPgn(p.pgn);
    expect(c.history()).toHaveLength(2);await expect(page.getByText("Last computer reply: Stockfish",{exact:true})).toBeVisible();
    await page.waitForTimeout(600);expect((await saved(page)).pgn).toBe(p.pgn);
    evidence.push({tier,pgn:p.pgn,fen:p.fen});
    await page.getByRole("button",{name:/New game/}).click();
  }
  fs.writeFileSync('qa/ten-strength-browser.json',JSON.stringify(evidence,null,2));
});

test("selectors survive restart and narrow/desktop screens have no overflow",async({page})=>{
  test.setTimeout(240000);
  await boot(page,false);await nav(page,"Train").click();
  await page.getByText(/Train settings ·/).click();
  await page.getByLabel("Learning level (1–10)").selectOption("2");
  await page.getByLabel("Computer strength (1–10)").selectOption("7");
  await page.getByLabel("Learning guidance").selectOption("manual");
  await page.reload({waitUntil:"domcontentloaded"});await nav(page,"Train").click();
  await page.getByText(/Train settings ·/).click();
  await expect(page.getByLabel("Learning level (1–10)")).toHaveValue("2");
  await expect(page.getByLabel("Computer strength (1–10)")).toHaveValue("7");
  await expect(page.getByLabel("Learning guidance")).toHaveValue("manual");
  for(const width of [360,1280]){
    await page.setViewportSize({width,height:900});
    for(const name of ["Home","Train","Games","Progress"]){
      await nav(page,name).click();await page.screenshot({path:`qa/${width}-${name.toLowerCase()}.png`,fullPage:true});
      expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`${name} ${width}`).toBe(true);
    }
  }
  await page.setViewportSize({width:393,height:851});
  await page.evaluate(()=>document.documentElement.style.fontSize="24px");
  await nav(page,"Train").click();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  await page.screenshot({path:"qa/mobile-large-text.png",fullPage:true});
});

test("offline cached shell and rules-only engine failure remain usable",async({page,context})=>{
  // Explicit platform failure; page routing cannot intercept service-worker fetches.
  await page.addInitScript(()=>Object.defineProperty(window,"Worker",{value:undefined,configurable:true}));
  await boot(page);
  await nav(page,"Train").click();await sq(page,"e2").click();await sq(page,"e4").click();
  await expect(page.getByText(/Last computer reply: rules-only fallback/)).toBeVisible();
  await expect.poll(async()=>new Chess((await saved(page)).fen).turn()).toBe("w");
  await page.evaluate(async()=>{await navigator.serviceWorker.ready;});
  await page.waitForTimeout(500);await context.setOffline(true);await page.reload({waitUntil:"domcontentloaded"});
  await nav(page,"Train").click();await expect(page.getByText(/^You are offline\./)).toBeVisible();
  expect((await saved(page)).pgn).toContain("e4");
  await page.getByRole("button",{name:/Undo/}).click();expect(new Chess((await saved(page)).fen).turn()).toBe("w");
  await page.screenshot({path:"qa/offline-train.png",fullPage:true});
});
