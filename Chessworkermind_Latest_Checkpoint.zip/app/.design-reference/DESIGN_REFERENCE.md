# Design reference — written down so any future run can resume without the image

**There is no `DESIGN_REFERENCE.png` file in this repository.** The four-screen
mock was supplied as a chat attachment on 2026-09-30 and was viewed directly.
This file records exactly what it showed, so the next run does not have to
guess and does not have to claim it inspected a file that is not here.

## Palette and feel

A calm, premium chess study room.

| Token | Value in `src/styles/coach.css` | Where it came from |
|---|---|---|
| page background | `--bg: #f6efe3` | warm ivory paper |
| card surface | `--surface: #fdfaf4` | slightly lighter cream |
| text | `--text: #33271b` | dark espresso |
| muted text | `--text-muted: #7c6a56` | soft brown-grey |
| accent | `--accent: #6b4b2f`, `--accent-2: #4a3220` | espresso buttons and headings |
| gold | `--gold: #b8873f` | the small "yesterday you missed…" line |
| board | `--board-light: #ecd9b6`, `--board-dark: #b07f52`, frame `#8a5f39` | realistic wood |

Headings are serif (`--serif`), body text is the system sans. Cards are
~18-26px radius with a soft shadow. Buttons are full pills. Generous spacing.

## Screen 1 — Home

- Header: "Chess Mind" (ours: **Chessworkermind**) over a small-caps tagline
  "A BRIGHTER THINKER TOMORROW", gear icon top right.
- Serif greeting "Good morning, Alex." with a gold sub-line underneath.
- One dark espresso card: eyebrow "Today's Training · 7 min", a goal sentence,
  and a pill button "Start Training ›". Decorative board corner bottom-right.
- Three small tiles: streak (🔥), reviews due (📄), brain score (🧠).
- A row card "From your last game →".
- Italic serif quote near the bottom.
- Bottom nav, four items: Home, Train, Games, Brain (ours: **Progress**).

**Not copied:** the name "Alex", the 12-day streak, "3 reviews due", the score
623 and "you missed two opponent threats". Those are mock data. Our screen
computes all of it from real practice and shows "No data" / "Not yet" instead.

## Screen 2 — Train, "What's Your Move?"

- Back chevron, centred title, overflow dots.
- A chip above the board: "♟ Black just played ...Qh4".
- Large wooden board with file/rank coordinates.
- Serif question "What would you play?".
- A hint row: "💡 Hint 1: Look for a forcing move ›".
- Full-width espresso button "View Solution".
- Two ghost buttons: "⟲ Reset Position" and "💡 More Hints".

**Ours:** the chip is written in full words from the real move history
("Black moved the queen from d8 to h4."), hints are tiered 1 → 2 → "Show one
move", and the controls are Try again / Undo / New game / Focus mode.

## Screen 3 — "Why Not My Move?"

- Board at the top with the important squares tinted.
- A red row: "✕ Your move: Qh5? — Nxh5, your queen is lost."
- Italic divider "Let's rewind and compare".
- Two or three candidate rows, each with a piece icon, the move and a one-line
  reason, and a chevron.
- Espresso button "▶ Play Best Move" next to a ghost "Try Again".

**Ours:** the accusation only appears when `reviewMove` replayed a legal
punishing reply on the real board AND a normal alternative avoided it. When
nothing is proven the screen says so.

## Screen 4 — Progress, "Chess Brain"

- Centred brain icon, "Chess Brain", a big serif number, a caption.
- Six labelled bars: Tactics, Calculation, Strategy, Endgame, Opening, Defense.
- A card with a stopwatch: "Fork recognition 11.2s → 4.8s".
- A row card "This Week's Report — 3 concepts improved ›".

**Ours:** six skill cards built from the concepts our lessons really teach
(Piece moves, Tactics, Defence, Checkmate, Opening ideas, Calculation), each
tappable into a real lesson. The score is a published formula. There is **no
speed card**, because nothing measures thinking time yet — inventing
"11.2s → 4.8s" would be a lie. The weekly report counts real attempts from the
last seven days and otherwise says "Not enough practice yet".
