# QA report — updated-prompt continuation, 2026-10-02

This report supersedes the archive's historical claims. The actual supplied React/TypeScript app was tested, not a replacement or screenshot-only mockup. Current-run logs are in `qa/` (those logs are excluded from the source checkpoint when they are browser/cache output).

## Final checks actually run

| Check | Result |
|---|---|
| `npm run lint` | **Passed** — TypeScript no-emit (`qa/final-lint.log`) |
| `npm run typecheck` | **Passed** (`qa/final-typecheck.log`) |
| `npm run build` | **Passed**; Vite warns the main minified chunk is >500 kB (`qa/build-final.log`) |
| Full `npm test -- --maxWorkers=2 --pool=threads --reporter=dot` | **34 files, 492 passed, 1 skipped** (`qa/final-tests.log`) |
| Final targeted regression run | **5 files, 79 passed**: real turn loop, no duplicate/stale move, settings, engine failure/timeout, evidence/progress (`qa/final-targeted.log`) |
| Final service-worker/docs/build checks | **3 files, 38 passed, 1 skipped** (`qa/final-sw-tests.log`); offline build skip is intentional when that test cannot inspect a fresh dist in its worker |
| Focused new legality/evidence checks | **3 files, 47 passed** (`qa/focused-parent.log`) |
| Engine/opponent track | **84 passed across 7 files**, plus real Stockfish WASM smoke documented in `ENGINE_STRENGTH.md` |
| Production Chromium browser loop | **3 integrated tests passed**: real Stockfish turn/persistence/discovery/retry, all ten computer tiers, and 360/1280 responsive selector screenshots (`qa/e2e-second.log`) |
| Offline Chromium rerun | **Passed** after repairing cache URL matching: rules-only fallback, cached offline reload, saved game and undo (`qa/e2e-offline-final.log`) |

The first integrated browser run intentionally remains recorded as a failure in `qa/e2e-first.log`: it found that the old 10-second load watchdog was too short on this D-drive filesystem and that the offline routing test did not model service-worker fetches. The watchdog was bounded at 30 seconds (search budgets unchanged), and the real offline path then exposed and fixed an actual first-visit precache/cache-key issue. The final isolated offline browser test passed.

## User-visible work completed

- Preserved the existing Chessworkermind app and disabled billing architecture; no deployment, credentials, live payments or ads.
- Fixed status/turn correctness: game-over moves rejected and threefold repetition uses the full move history instead of rebuilding from FEN.
- Preserved the real Stockfish worker/opponent work and added ten documented, reproducible computer strength profiles separate from coaching. The UI exposes **Computer 1–10** and labels Stockfish versus rules-only fallback. No Elo/guaranteed ordering claim.
- Added separate **Learning 1–10** and Adaptive/Manual controls. They persist locally, explain that levels are instructional tiers rather than ratings, and select existing legally validated representative exercises.
- Added an auditable attempt ledger: exact FEN/position, legal replay verifier, answer, help/reveal level, independent/repeated status, transfer dimension, selected settings and timestamp. Progress now shows supporting evidence rather than a numerical “Chess Brain” rating.
- Added verified exact-position discovery: attention highlight, legal checks/captures/defenders, explicit unknowns, candidate selection and conditional line replay. “If I play this…” and retry use an isolated board; original saved game history remains unchanged.
- Fixed lesson transfer remount and learner-turn guarding. Hints/reveals/repeats are recorded as help and do not count as independent evidence. The selected hint ladder is visible and every hint tap is logged.
- Replayed FactPacket PVs end-to-end, rejects omitted promotion/illegal suffixes, and no longer calls a reply from another candidate variation a threat. Updated conditional language avoids claiming opponent intent or guaranteed future play.
- Bundled a local font so chess pieces render in Chromium without relying on host glyphs. Added third-party licensing notes and GPLv3 text for the shipped Stockfish package.
- Repaired PWA first-visit offline precaching: Vite emits `offline-assets.json`; the service worker atomically precaches hashed app assets and resolves full URL/path cache keys. Failed installs do not replace the previous cache.

## Explicit gaps / not claimed

- Physical Android/iPhone devices were **not tested**. Headless Chromium viewport emulation is not native touch feel, battery measurement, Safari, VoiceOver/TalkBack, install/uninstall or real-device offline validation.
- Full updated-prompt curriculum breadth is not complete: concept catalogue metadata, per-micro-skill calibration, delayed spaced scheduling, own-game evidence integration, deeper engine stability checks and expert own-game practice remain partial.
- Training/lesson translation is partial (English and Hindi plus existing app fallbacks). Long Arabic/RTL/CJK visual and native-speaker quality checks remain open.
- Account backend, real cross-device sync and real merchant/provider subscription lifecycle are not connected. The ₹599/month test adapter remains disabled; no checkout or payment occurred.
- No calibrated Elo, numerical Brain rating, fake streak/achievement, expert certification or mastery claim is made. No public deployment, AdSense, secrets or live charge occurred.
