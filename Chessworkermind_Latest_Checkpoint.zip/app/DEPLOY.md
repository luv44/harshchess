# Putting Chessworkermind online — free, and still private

## Why this is not already done

You asked for a free host and told me to keep the site **private** and not
to launch it publicly. Those two together rule out the obvious answer:

- **GitHub Pages** is free, and the repository is already on GitHub — but
  Pages from a **private** repository needs a paid plan. On the free plan
  GitHub would require the repository to be made **public**. That breaks
  your rule, so I did not do it.
- **Netlify** free tier has no password protection (it is a paid feature).
- **Vercel** Hobby does not give password protection on a production
  deployment either.

So I did not deploy anything. What I did instead was make the build go
anywhere, and pick the one host that is genuinely free **and** private.

## The recommendation: Cloudflare Pages + Cloudflare Access

Both are free. Pages hosts static sites with no cost, and Access puts a
login in front of it — free for up to 50 people. Nobody but you sees it.

You have to do this part: it needs an account, and I cannot create one.

### 1. Build

```bash
cd app
npm install
npm run build        # produces app/dist
```

### 2. Upload

1. Sign up at **dash.cloudflare.com** (free, no card).
2. **Workers & Pages → Create → Pages → Upload assets**.
3. Drag the **`app/dist`** folder in. Name it, for example,
   `chessworkermind`.
4. It gives you a URL like `https://chessworkermind.pages.dev`.

At this point the site works but anyone with the link can open it.

### 3. Lock it to you

1. **Zero Trust → Access → Applications → Add an application → Self-hosted**.
2. Domain: your `*.pages.dev` address.
3. Policy: **Allow**, rule **Emails** → your own email address.
4. Save.

Now opening the link sends a one-time code to your email first. That is a
private site on a free plan.

### Updating it later

Re-run `npm run build` and drag `app/dist` in again, or connect the Git
repository so it rebuilds on push. Connecting the repo keeps it private —
Cloudflare reads it with your permission; the repository stays private.

## It will also work anywhere else

The build no longer assumes it sits at a domain root. Assets, the service
worker and the manifest all use relative paths, so `app/dist` can be
dropped into a sub-folder — `example.com/chess/` — and still work. That is
checked by tests: `offlineBuild.test.ts` fails the build if an absolute
path comes back, and `serviceWorker.test.ts` runs the worker from
`/chessworkermind/` to prove it caches its own folder rather than the
domain root.

## What you get either way

A production build over HTTPS means:

- it installs to a home screen
- it works with no signal at all, after the first visit
- the optional Stockfish download is cached

## What I can still do from here

- The preview in this session, whenever you ask.
- A GitHub Actions workflow, ready to run, if you ever decide the
  repository can be public — say the word and I will add it, but I will
  not add it quietly.
