# Updated-prompt audit — 2026-10-02

Scope: continue the supplied app; no replacement, deployment, live checkout or ads. The current requirements are in `UPDATED_PROMPT.txt`; they supersede conflicting older product claims in `MASTER_PROMPT.txt`. Only app/ was extracted. No existing extracted project was found under the workspace. The archive remains untouched.

## Source audit (before modifications)

| Area | Evidence | Finding / priority |
|---|---|---|
| Legal games | `useChessGame.ts`, chess.js, board and rules integration tests | Substantial real implementation exists. Repetition status incorrectly reconstructs a Chess from FEN, losing history. Move application also needs a game-over gate. High priority. |
| Opponent | `useComputerOpponent.ts`, `opponentWorker.ts` | Three tiers only. Train never supplies an engine move. The sharp-engine branch lacks effect cleanup; commit lacks a fresh turn/paused check. Repair and test. |
| Engine | `engineWorker.ts`, `useEngine.ts` | Module worker uses importScripts (not available in module workers), absolute asset URL, reassigns search identity before old search drains, eagerly initializes while setting says off. Browser verification required. |
| Coaching | `factPacket.ts` | PV UCI array repeats the first move; an unrelated candidate reply is called a threat after the played move. Invalid promotion may throw. Must legally replay each complete line and abstain on unsupported threat. |
| Guided game | `TrainScreen.tsx` | Uses shared saved mode but assumes computer mode; local Black turn is blocked. Review banners persist after board changes; retry mutates original game. Exact position/turn lifecycle needs repair. |
| Why this move | `WhyNotMyMove.tsx` | Opponent “wants” and “reply to expect” infer intent/prediction. No board replay of consequence. Needs conditional language and isolated rehearsal. |
| Lessons | `LearnJourney.tsx` | Transfer changes props but not internal board state. After a wrong move, another side can move and still get lesson credit. Retrying revealed/same-position answers can appear independent. Preserve help/exposure and record evidence. |
| Difficulty | legacy cwm:level | No independent learning 1–10 vs computer 1–10. Existing catalogue has 36 lessons; advanced tiers must not be advertised as a full calibrated curriculum. |
| Progress | `insights.ts`, Home/Brain | Numerical Brain rating conflicts with new prompt. Speed trends mix repeated positions/difficulties and claim newer problems are harder without evidence. Weekly unaided count uses lifetime successes. Repair visible claims, retain historical saves. |
| Language | App, Train and reviewer | Partial translations only. Some Hindi/other-language screens still contain English. Add clear partial-English fallback notice; full translation QA remains open. |
| Business | billing adapter | Preserve test-only adapter and disabled checkout; no real account sync can be claimed. |
| Design | `.design-reference/DESIGN_REFERENCE.md` | Written design reference exists; PNG/four-screen attachment is not in the workspace. Preserve/refine warm existing theme. |

## Baseline / running-screen audit

Baseline build succeeded. The baseline suite reported 443 passes, one stale document-count failure, one skipped test and a reporting timeout. Focused new regressions reproduced history-based repetition failure and the broken transfer board, then passed after repair (47 tests). Engine/opponent focused tests passed (84 tests).

Real Chromium production QA now runs on D: (headless shell plus local libraries, no global install). Narrow screenshots at 360/393px and desktop 1280px are saved in qa/. All ten engine tiers produced exactly one real, legal Black reply in browser checks. Separate candidate/retry and saved-game persistence passed. First-load module delivery exceeded the original ten-second watchdog on this filesystem: extended the bounded loading allowance to thirty seconds, without increasing search budgets.

**Additional real offline bug found:** first-visit JavaScript/CSS loaded before the service worker controlled the page and were never cached. The old shell-only installation tests passed, yet a real offline reload was blank. Added a build-generated offline asset manifest and atomic install precache of hashed assets; failed installs now reject rather than replace a working version. This is a functional repair, not just a timeout/test adjustment. Browser offline rerun is recorded in QA_REPORT.md.

Missing host chess glyphs in the first screenshot were repaired with a locally bundled licensed font. No design-reference PNG exists here. Physical phones, full translation review, broad expert/adaptive curriculum and real account/provider infrastructure remain unverified/incomplete.
