# Third-party assets and redistribution

- React, chess.js, Vite, TypeScript, Vitest, Testing Library and Playwright remain governed by their package licences. Exact resolved packages are in package-lock.json; `npm ci` restores them.
- The shipped Stockfish.js 19 lite single-thread JS/WASM binaries are GPLv3. The licence is included at `public/stockfish/COPYING-GPLv3.txt`. Upstream engine/port source and build instructions: https://github.com/nmrugg/stockfish.js (Stockfish 19 release). The current engine protocol and settings are documented in `ENGINE_STRENGTH.md`.
- The original archive included two names for the Stockfish pair; they are preserved to avoid breaking prior/offline paths. The current adapter uses stockfish-19-lite-single.js and its adjacent WASM.
- The board font is DejaVu Sans, copied from Ubuntu's fonts-dejavu-core package. Its copyright/licence is included at `public/fonts/LICENSE-DejaVu.txt`. It renders the existing Unicode chess pieces; it does not replace the rules or board with an image.

This local source checkpoint is not a public release or legal compliance certification. Before publishing/distributing an engine-enabled hosted product, verify the exact engine source/build provenance and supply the corresponding source/build materials as required by GPLv3, alongside licence/attribution. No paid assets, proprietary images, external font services or private credentials were added.
