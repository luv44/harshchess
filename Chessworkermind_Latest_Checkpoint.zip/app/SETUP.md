# Run the saved Chessworkermind app

Project: `D:\MMy New Project\Chessworkermind\app` (WSL `/mnt/d/MMy New Project/Chessworkermind/app`). Node 22 was used in this session. No keys or account are required for local play. Keep all project caches/output on D:.

## Ubuntu WSL

```bash
cd '/mnt/d/MMy New Project/Chessworkermind/app'
mkdir -p .cache/npm .cache/tmp
TMPDIR="$PWD/.cache/tmp" npm ci --no-bin-links --cache "$PWD/.cache/npm"
npm run build
npm run preview -- --host 127.0.0.1
```

Open **http://localhost:4173** on this PC. For editing: `npm run dev -- --host 127.0.0.1` at **http://localhost:5173**. These are local servers, not public links. Servers are stopped at handoff; run the command yourself to reopen them.

This D-drive mount rejected npm symlinks. `--no-bin-links` avoids that; npm scripts invoke the installed Node entry points directly, so the real build/test commands still work without `.bin` symlinks. On Windows native Node, ordinary `npm ci` also works. No global settings were changed.

## Checks

```bash
npm run typecheck
npm run lint       # existing alias for TypeScript; not a separate ESLint configuration
npm run build      # build first: offline tests inspect real dist/
npm test -- --maxWorkers=2
```

The exhaustive expert lesson proof and fuzz/mirror tests are intentionally substantial. D-drive filesystem overhead can make the full suite take several minutes. Actual run results, not historical totals, are in `QA_REPORT.md`.

## Browser checks

`npm run test:e2e` uses Playwright against an already-running production preview at port 4173. `CHROME_PATH` can select an installed Chromium executable. The session used a local headless shell and runtime libraries in `.cache/`, all on D:. Those browser binaries and libraries are NOT in the source ZIP. For a normal Linux environment use Playwright's Chromium install and point `CHROME_PATH` at it; the system also needs Chromium's native libraries. Do not mistake a missing browser for an app test pass.

The source tests are `e2e/checkpoint.spec.ts`; production snapshots/logs are in `qa/`. The separate engine smoke is documented in `ENGINE_STRENGTH.md`.

## Offline and installation

The app registers its service worker in a production build, not dev mode. A secure context (HTTPS **or localhost**) is required. Load the board, font, rules and engine assets before going offline. A phone cannot reach this computer using its own localhost. Physical phone testing, HTTPS hosting and public launch are separate tasks; nothing has been deployed. Unsynced browser data can disappear; account cloud sync is not connected.

## Source checkpoint

`D:\MMy New Project\Chessworkermind_Latest_Checkpoint.zip` contains root **app/**. Extract to a new folder to avoid overwriting newer changes. It includes source, package/lock files, engine assets, font licence, documentation and both state files. It excludes credentials, node_modules, dist, caches and old ZIPs. The dated checkpoint folder and archive verification are recorded in `RUN_RECOVERY.json`.

Resume from `UPDATED_PROMPT.txt`, `FEATURE_AUDIT.md`, `PROJECT_STATE.json`, and `RUN_RECOVERY.json`; do not scaffold a new app. Preserve existing user games and keep checkout disabled.
